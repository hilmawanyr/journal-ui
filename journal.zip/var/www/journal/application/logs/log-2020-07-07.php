<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-07-07 00:00:47 --> Config Class Initialized
INFO - 2020-07-07 00:00:47 --> Hooks Class Initialized
DEBUG - 2020-07-07 00:00:47 --> UTF-8 Support Enabled
INFO - 2020-07-07 00:00:47 --> Utf8 Class Initialized
INFO - 2020-07-07 00:00:47 --> URI Class Initialized
INFO - 2020-07-07 00:00:47 --> Router Class Initialized
INFO - 2020-07-07 00:00:47 --> Output Class Initialized
INFO - 2020-07-07 00:00:47 --> Security Class Initialized
DEBUG - 2020-07-07 00:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 00:00:47 --> Input Class Initialized
INFO - 2020-07-07 00:00:47 --> Language Class Initialized
INFO - 2020-07-07 00:00:47 --> Language Class Initialized
INFO - 2020-07-07 00:00:47 --> Config Class Initialized
INFO - 2020-07-07 00:00:47 --> Loader Class Initialized
INFO - 2020-07-07 00:00:47 --> Helper loaded: url_helper
INFO - 2020-07-07 00:00:47 --> Helper loaded: main_helper
INFO - 2020-07-07 00:00:47 --> Database Driver Class Initialized
DEBUG - 2020-07-07 00:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 00:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 00:00:47 --> Controller Class Initialized
INFO - 2020-07-07 00:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 00:00:47 --> Pagination Class Initialized
ERROR - 2020-07-07 00:00:47 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 00:00:47 --> Helper loaded: file_helper
DEBUG - 2020-07-07 00:00:47 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 00:00:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 00:00:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 00:00:47 --> Encryption Class Initialized
INFO - 2020-07-07 00:00:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 00:00:47 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-07 00:00:47 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 00:00:47 --> Final output sent to browser
DEBUG - 2020-07-07 00:00:47 --> Total execution time: 0.0049
INFO - 2020-07-07 00:00:49 --> Config Class Initialized
INFO - 2020-07-07 00:00:49 --> Hooks Class Initialized
DEBUG - 2020-07-07 00:00:49 --> UTF-8 Support Enabled
INFO - 2020-07-07 00:00:49 --> Utf8 Class Initialized
INFO - 2020-07-07 00:00:49 --> URI Class Initialized
INFO - 2020-07-07 00:00:49 --> Router Class Initialized
INFO - 2020-07-07 00:00:49 --> Output Class Initialized
INFO - 2020-07-07 00:00:49 --> Security Class Initialized
DEBUG - 2020-07-07 00:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 00:00:49 --> Input Class Initialized
INFO - 2020-07-07 00:00:49 --> Language Class Initialized
INFO - 2020-07-07 00:00:49 --> Language Class Initialized
INFO - 2020-07-07 00:00:49 --> Config Class Initialized
INFO - 2020-07-07 00:00:49 --> Loader Class Initialized
INFO - 2020-07-07 00:00:49 --> Helper loaded: url_helper
INFO - 2020-07-07 00:00:49 --> Helper loaded: main_helper
INFO - 2020-07-07 00:00:49 --> Database Driver Class Initialized
DEBUG - 2020-07-07 00:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 00:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 00:00:49 --> Controller Class Initialized
INFO - 2020-07-07 00:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 00:00:49 --> Pagination Class Initialized
ERROR - 2020-07-07 00:00:49 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 00:00:49 --> Helper loaded: file_helper
DEBUG - 2020-07-07 00:00:49 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 00:00:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 00:00:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 00:00:49 --> Encryption Class Initialized
INFO - 2020-07-07 00:00:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 00:00:51 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 00:00:51 --> Final output sent to browser
DEBUG - 2020-07-07 00:00:51 --> Total execution time: 2.0121
INFO - 2020-07-07 00:01:46 --> Config Class Initialized
INFO - 2020-07-07 00:01:46 --> Hooks Class Initialized
DEBUG - 2020-07-07 00:01:46 --> UTF-8 Support Enabled
INFO - 2020-07-07 00:01:46 --> Utf8 Class Initialized
INFO - 2020-07-07 00:01:46 --> URI Class Initialized
INFO - 2020-07-07 00:01:46 --> Router Class Initialized
INFO - 2020-07-07 00:01:46 --> Output Class Initialized
INFO - 2020-07-07 00:01:46 --> Security Class Initialized
DEBUG - 2020-07-07 00:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 00:01:46 --> Input Class Initialized
INFO - 2020-07-07 00:01:46 --> Language Class Initialized
INFO - 2020-07-07 00:01:46 --> Language Class Initialized
INFO - 2020-07-07 00:01:46 --> Config Class Initialized
INFO - 2020-07-07 00:01:46 --> Loader Class Initialized
INFO - 2020-07-07 00:01:46 --> Helper loaded: url_helper
INFO - 2020-07-07 00:01:46 --> Helper loaded: main_helper
INFO - 2020-07-07 00:01:46 --> Database Driver Class Initialized
DEBUG - 2020-07-07 00:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 00:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 00:01:46 --> Controller Class Initialized
INFO - 2020-07-07 00:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 00:01:46 --> Pagination Class Initialized
ERROR - 2020-07-07 00:01:46 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 00:01:46 --> Helper loaded: file_helper
DEBUG - 2020-07-07 00:01:46 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 00:01:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 00:01:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 00:01:46 --> Encryption Class Initialized
INFO - 2020-07-07 00:01:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 00:01:47 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 00:01:47 --> Final output sent to browser
DEBUG - 2020-07-07 00:01:47 --> Total execution time: 1.2441
INFO - 2020-07-07 00:02:12 --> Config Class Initialized
INFO - 2020-07-07 00:02:12 --> Hooks Class Initialized
DEBUG - 2020-07-07 00:02:12 --> UTF-8 Support Enabled
INFO - 2020-07-07 00:02:12 --> Utf8 Class Initialized
INFO - 2020-07-07 00:02:12 --> URI Class Initialized
INFO - 2020-07-07 00:02:12 --> Router Class Initialized
INFO - 2020-07-07 00:02:12 --> Output Class Initialized
INFO - 2020-07-07 00:02:12 --> Security Class Initialized
DEBUG - 2020-07-07 00:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 00:02:12 --> Input Class Initialized
INFO - 2020-07-07 00:02:12 --> Language Class Initialized
INFO - 2020-07-07 00:02:12 --> Language Class Initialized
INFO - 2020-07-07 00:02:12 --> Config Class Initialized
INFO - 2020-07-07 00:02:12 --> Loader Class Initialized
INFO - 2020-07-07 00:02:12 --> Helper loaded: url_helper
INFO - 2020-07-07 00:02:12 --> Helper loaded: main_helper
INFO - 2020-07-07 00:02:12 --> Database Driver Class Initialized
DEBUG - 2020-07-07 00:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 00:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 00:02:12 --> Controller Class Initialized
INFO - 2020-07-07 00:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 00:02:12 --> Pagination Class Initialized
ERROR - 2020-07-07 00:02:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 00:02:12 --> Helper loaded: file_helper
DEBUG - 2020-07-07 00:02:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 00:02:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 00:02:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 00:02:12 --> Encryption Class Initialized
INFO - 2020-07-07 00:02:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 00:02:13 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 00:02:13 --> Final output sent to browser
DEBUG - 2020-07-07 00:02:13 --> Total execution time: 1.6317
INFO - 2020-07-07 00:16:46 --> Config Class Initialized
INFO - 2020-07-07 00:16:46 --> Hooks Class Initialized
DEBUG - 2020-07-07 00:16:46 --> UTF-8 Support Enabled
INFO - 2020-07-07 00:16:46 --> Utf8 Class Initialized
INFO - 2020-07-07 00:16:46 --> URI Class Initialized
INFO - 2020-07-07 00:16:46 --> Router Class Initialized
INFO - 2020-07-07 00:16:46 --> Output Class Initialized
INFO - 2020-07-07 00:16:46 --> Security Class Initialized
DEBUG - 2020-07-07 00:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 00:16:46 --> Input Class Initialized
INFO - 2020-07-07 00:16:46 --> Language Class Initialized
INFO - 2020-07-07 00:16:46 --> Language Class Initialized
INFO - 2020-07-07 00:16:46 --> Config Class Initialized
INFO - 2020-07-07 00:16:46 --> Loader Class Initialized
INFO - 2020-07-07 00:16:46 --> Helper loaded: url_helper
INFO - 2020-07-07 00:16:46 --> Helper loaded: main_helper
INFO - 2020-07-07 00:16:46 --> Database Driver Class Initialized
DEBUG - 2020-07-07 00:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 00:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 00:16:46 --> Controller Class Initialized
INFO - 2020-07-07 00:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 00:16:46 --> Pagination Class Initialized
ERROR - 2020-07-07 00:16:46 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 00:16:46 --> Helper loaded: file_helper
DEBUG - 2020-07-07 00:16:46 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 00:16:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 00:16:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 00:16:46 --> Encryption Class Initialized
INFO - 2020-07-07 00:16:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 00:16:48 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 00:16:48 --> Final output sent to browser
DEBUG - 2020-07-07 00:16:48 --> Total execution time: 1.3591
INFO - 2020-07-07 00:31:32 --> Config Class Initialized
INFO - 2020-07-07 00:31:32 --> Hooks Class Initialized
DEBUG - 2020-07-07 00:31:32 --> UTF-8 Support Enabled
INFO - 2020-07-07 00:31:32 --> Utf8 Class Initialized
INFO - 2020-07-07 00:31:32 --> URI Class Initialized
INFO - 2020-07-07 00:31:32 --> Router Class Initialized
INFO - 2020-07-07 00:31:32 --> Output Class Initialized
INFO - 2020-07-07 00:31:32 --> Security Class Initialized
DEBUG - 2020-07-07 00:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 00:31:32 --> Input Class Initialized
INFO - 2020-07-07 00:31:32 --> Language Class Initialized
INFO - 2020-07-07 00:31:32 --> Language Class Initialized
INFO - 2020-07-07 00:31:32 --> Config Class Initialized
INFO - 2020-07-07 00:31:32 --> Loader Class Initialized
INFO - 2020-07-07 00:31:32 --> Helper loaded: url_helper
INFO - 2020-07-07 00:31:32 --> Helper loaded: main_helper
INFO - 2020-07-07 00:31:32 --> Database Driver Class Initialized
DEBUG - 2020-07-07 00:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 00:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 00:31:32 --> Controller Class Initialized
INFO - 2020-07-07 00:31:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 00:31:32 --> Pagination Class Initialized
ERROR - 2020-07-07 00:31:32 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 00:31:32 --> Helper loaded: file_helper
DEBUG - 2020-07-07 00:31:32 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 00:31:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 00:31:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 00:31:32 --> Encryption Class Initialized
INFO - 2020-07-07 00:31:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 00:31:33 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 00:31:33 --> Final output sent to browser
DEBUG - 2020-07-07 00:31:33 --> Total execution time: 1.7661
INFO - 2020-07-07 00:52:52 --> Config Class Initialized
INFO - 2020-07-07 00:52:52 --> Hooks Class Initialized
DEBUG - 2020-07-07 00:52:52 --> UTF-8 Support Enabled
INFO - 2020-07-07 00:52:52 --> Utf8 Class Initialized
INFO - 2020-07-07 00:52:52 --> URI Class Initialized
INFO - 2020-07-07 00:52:52 --> Router Class Initialized
INFO - 2020-07-07 00:52:52 --> Output Class Initialized
INFO - 2020-07-07 00:52:52 --> Security Class Initialized
DEBUG - 2020-07-07 00:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 00:52:52 --> Input Class Initialized
INFO - 2020-07-07 00:52:52 --> Language Class Initialized
INFO - 2020-07-07 00:52:52 --> Language Class Initialized
INFO - 2020-07-07 00:52:52 --> Config Class Initialized
INFO - 2020-07-07 00:52:52 --> Loader Class Initialized
INFO - 2020-07-07 00:52:52 --> Helper loaded: url_helper
INFO - 2020-07-07 00:52:52 --> Helper loaded: main_helper
INFO - 2020-07-07 00:52:52 --> Database Driver Class Initialized
DEBUG - 2020-07-07 00:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 00:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 00:52:52 --> Controller Class Initialized
INFO - 2020-07-07 00:52:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 00:52:52 --> Pagination Class Initialized
ERROR - 2020-07-07 00:52:52 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 00:52:52 --> Helper loaded: file_helper
DEBUG - 2020-07-07 00:52:52 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 00:52:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 00:52:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 00:52:52 --> Encryption Class Initialized
INFO - 2020-07-07 00:52:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 00:52:54 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 00:52:54 --> Final output sent to browser
DEBUG - 2020-07-07 00:52:54 --> Total execution time: 1.3749
INFO - 2020-07-07 10:33:55 --> Config Class Initialized
INFO - 2020-07-07 10:33:55 --> Hooks Class Initialized
DEBUG - 2020-07-07 10:33:55 --> UTF-8 Support Enabled
INFO - 2020-07-07 10:33:55 --> Utf8 Class Initialized
INFO - 2020-07-07 10:33:55 --> URI Class Initialized
INFO - 2020-07-07 10:33:55 --> Router Class Initialized
INFO - 2020-07-07 10:33:55 --> Output Class Initialized
INFO - 2020-07-07 10:33:55 --> Security Class Initialized
DEBUG - 2020-07-07 10:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 10:33:55 --> Input Class Initialized
INFO - 2020-07-07 10:33:55 --> Language Class Initialized
INFO - 2020-07-07 10:33:55 --> Language Class Initialized
INFO - 2020-07-07 10:33:55 --> Config Class Initialized
INFO - 2020-07-07 10:33:55 --> Loader Class Initialized
INFO - 2020-07-07 10:33:55 --> Helper loaded: url_helper
INFO - 2020-07-07 10:33:55 --> Helper loaded: main_helper
INFO - 2020-07-07 10:33:55 --> Database Driver Class Initialized
DEBUG - 2020-07-07 10:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 10:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 10:33:55 --> Controller Class Initialized
INFO - 2020-07-07 10:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 10:33:55 --> Pagination Class Initialized
ERROR - 2020-07-07 10:33:55 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 10:33:55 --> Helper loaded: file_helper
DEBUG - 2020-07-07 10:33:55 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 10:33:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 10:33:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 10:33:55 --> Encryption Class Initialized
INFO - 2020-07-07 10:33:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 10:33:55 --> Final output sent to browser
DEBUG - 2020-07-07 10:33:55 --> Total execution time: 0.0053
INFO - 2020-07-07 10:34:01 --> Config Class Initialized
INFO - 2020-07-07 10:34:01 --> Hooks Class Initialized
DEBUG - 2020-07-07 10:34:01 --> UTF-8 Support Enabled
INFO - 2020-07-07 10:34:01 --> Utf8 Class Initialized
INFO - 2020-07-07 10:34:01 --> URI Class Initialized
INFO - 2020-07-07 10:34:01 --> Router Class Initialized
INFO - 2020-07-07 10:34:01 --> Output Class Initialized
INFO - 2020-07-07 10:34:01 --> Security Class Initialized
DEBUG - 2020-07-07 10:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 10:34:01 --> Input Class Initialized
INFO - 2020-07-07 10:34:01 --> Language Class Initialized
INFO - 2020-07-07 10:34:01 --> Language Class Initialized
INFO - 2020-07-07 10:34:01 --> Config Class Initialized
INFO - 2020-07-07 10:34:01 --> Loader Class Initialized
INFO - 2020-07-07 10:34:01 --> Helper loaded: url_helper
INFO - 2020-07-07 10:34:01 --> Helper loaded: main_helper
INFO - 2020-07-07 10:34:01 --> Database Driver Class Initialized
DEBUG - 2020-07-07 10:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 10:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 10:34:01 --> Controller Class Initialized
INFO - 2020-07-07 10:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 10:34:01 --> Pagination Class Initialized
ERROR - 2020-07-07 10:34:01 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 10:34:01 --> Helper loaded: file_helper
DEBUG - 2020-07-07 10:34:01 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 10:34:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 10:34:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 10:34:01 --> Encryption Class Initialized
INFO - 2020-07-07 10:34:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 10:34:03 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-07 10:34:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 10:34:03 --> Final output sent to browser
DEBUG - 2020-07-07 10:34:03 --> Total execution time: 1.3169
INFO - 2020-07-07 10:34:09 --> Config Class Initialized
INFO - 2020-07-07 10:34:09 --> Hooks Class Initialized
DEBUG - 2020-07-07 10:34:09 --> UTF-8 Support Enabled
INFO - 2020-07-07 10:34:09 --> Utf8 Class Initialized
INFO - 2020-07-07 10:34:09 --> URI Class Initialized
INFO - 2020-07-07 10:34:09 --> Router Class Initialized
INFO - 2020-07-07 10:34:09 --> Output Class Initialized
INFO - 2020-07-07 10:34:09 --> Security Class Initialized
DEBUG - 2020-07-07 10:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 10:34:09 --> Input Class Initialized
INFO - 2020-07-07 10:34:09 --> Language Class Initialized
INFO - 2020-07-07 10:34:09 --> Language Class Initialized
INFO - 2020-07-07 10:34:09 --> Config Class Initialized
INFO - 2020-07-07 10:34:09 --> Loader Class Initialized
INFO - 2020-07-07 10:34:09 --> Helper loaded: url_helper
INFO - 2020-07-07 10:34:09 --> Helper loaded: main_helper
INFO - 2020-07-07 10:34:09 --> Database Driver Class Initialized
DEBUG - 2020-07-07 10:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 10:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 10:34:09 --> Controller Class Initialized
INFO - 2020-07-07 10:34:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 10:34:09 --> Pagination Class Initialized
ERROR - 2020-07-07 10:34:09 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 10:34:09 --> Helper loaded: file_helper
DEBUG - 2020-07-07 10:34:09 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 10:34:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 10:34:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 10:34:09 --> Encryption Class Initialized
INFO - 2020-07-07 10:34:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 10:34:10 --> Severity: error --> Exception: Argument 1 passed to DOMDocument::saveXML() must be an instance of DOMNode or null, string given /var/www/journal/application/modules/landing/views/xml_export_v.php 54
INFO - 2020-07-07 10:34:27 --> Config Class Initialized
INFO - 2020-07-07 10:34:27 --> Hooks Class Initialized
DEBUG - 2020-07-07 10:34:27 --> UTF-8 Support Enabled
INFO - 2020-07-07 10:34:27 --> Utf8 Class Initialized
INFO - 2020-07-07 10:34:27 --> URI Class Initialized
INFO - 2020-07-07 10:34:27 --> Router Class Initialized
INFO - 2020-07-07 10:34:27 --> Output Class Initialized
INFO - 2020-07-07 10:34:27 --> Security Class Initialized
DEBUG - 2020-07-07 10:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 10:34:27 --> Input Class Initialized
INFO - 2020-07-07 10:34:27 --> Language Class Initialized
INFO - 2020-07-07 10:34:27 --> Language Class Initialized
INFO - 2020-07-07 10:34:27 --> Config Class Initialized
INFO - 2020-07-07 10:34:27 --> Loader Class Initialized
INFO - 2020-07-07 10:34:27 --> Helper loaded: url_helper
INFO - 2020-07-07 10:34:27 --> Helper loaded: main_helper
INFO - 2020-07-07 10:34:27 --> Database Driver Class Initialized
DEBUG - 2020-07-07 10:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 10:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 10:34:27 --> Controller Class Initialized
INFO - 2020-07-07 10:34:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 10:34:27 --> Pagination Class Initialized
ERROR - 2020-07-07 10:34:27 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 10:34:27 --> Helper loaded: file_helper
DEBUG - 2020-07-07 10:34:27 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 10:34:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 10:34:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 10:34:27 --> Encryption Class Initialized
INFO - 2020-07-07 10:34:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 10:34:28 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 10:34:28 --> Final output sent to browser
DEBUG - 2020-07-07 10:34:28 --> Total execution time: 1.1654
INFO - 2020-07-07 10:37:22 --> Config Class Initialized
INFO - 2020-07-07 10:37:22 --> Hooks Class Initialized
DEBUG - 2020-07-07 10:37:22 --> UTF-8 Support Enabled
INFO - 2020-07-07 10:37:22 --> Utf8 Class Initialized
INFO - 2020-07-07 10:37:22 --> URI Class Initialized
INFO - 2020-07-07 10:37:22 --> Router Class Initialized
INFO - 2020-07-07 10:37:22 --> Output Class Initialized
INFO - 2020-07-07 10:37:22 --> Security Class Initialized
DEBUG - 2020-07-07 10:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 10:37:22 --> Input Class Initialized
INFO - 2020-07-07 10:37:22 --> Language Class Initialized
INFO - 2020-07-07 10:37:22 --> Language Class Initialized
INFO - 2020-07-07 10:37:22 --> Config Class Initialized
INFO - 2020-07-07 10:37:22 --> Loader Class Initialized
INFO - 2020-07-07 10:37:22 --> Helper loaded: url_helper
INFO - 2020-07-07 10:37:22 --> Helper loaded: main_helper
INFO - 2020-07-07 10:37:22 --> Database Driver Class Initialized
DEBUG - 2020-07-07 10:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 10:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 10:37:22 --> Controller Class Initialized
INFO - 2020-07-07 10:37:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 10:37:22 --> Pagination Class Initialized
ERROR - 2020-07-07 10:37:22 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 10:37:22 --> Helper loaded: file_helper
DEBUG - 2020-07-07 10:37:22 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 10:37:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 10:37:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 10:37:22 --> Encryption Class Initialized
INFO - 2020-07-07 10:37:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 10:37:24 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 10:37:24 --> Final output sent to browser
DEBUG - 2020-07-07 10:37:24 --> Total execution time: 1.2396
INFO - 2020-07-07 11:17:38 --> Config Class Initialized
INFO - 2020-07-07 11:17:38 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:17:38 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:17:38 --> Utf8 Class Initialized
INFO - 2020-07-07 11:17:38 --> URI Class Initialized
INFO - 2020-07-07 11:17:38 --> Router Class Initialized
INFO - 2020-07-07 11:17:38 --> Output Class Initialized
INFO - 2020-07-07 11:17:38 --> Security Class Initialized
DEBUG - 2020-07-07 11:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:17:38 --> Input Class Initialized
INFO - 2020-07-07 11:17:38 --> Language Class Initialized
INFO - 2020-07-07 11:17:38 --> Language Class Initialized
INFO - 2020-07-07 11:17:38 --> Config Class Initialized
INFO - 2020-07-07 11:17:38 --> Loader Class Initialized
INFO - 2020-07-07 11:17:38 --> Helper loaded: url_helper
INFO - 2020-07-07 11:17:38 --> Helper loaded: main_helper
INFO - 2020-07-07 11:17:38 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:17:38 --> Controller Class Initialized
INFO - 2020-07-07 11:17:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:17:38 --> Pagination Class Initialized
ERROR - 2020-07-07 11:17:38 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:17:38 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:17:38 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:17:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:17:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:17:38 --> Encryption Class Initialized
INFO - 2020-07-07 11:17:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:17:39 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 11:17:39 --> Final output sent to browser
DEBUG - 2020-07-07 11:17:39 --> Total execution time: 1.3781
INFO - 2020-07-07 11:17:47 --> Config Class Initialized
INFO - 2020-07-07 11:17:47 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:17:47 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:17:47 --> Utf8 Class Initialized
INFO - 2020-07-07 11:17:47 --> URI Class Initialized
INFO - 2020-07-07 11:17:47 --> Router Class Initialized
INFO - 2020-07-07 11:17:47 --> Output Class Initialized
INFO - 2020-07-07 11:17:47 --> Security Class Initialized
DEBUG - 2020-07-07 11:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:17:47 --> Input Class Initialized
INFO - 2020-07-07 11:17:47 --> Language Class Initialized
INFO - 2020-07-07 11:17:47 --> Language Class Initialized
INFO - 2020-07-07 11:17:47 --> Config Class Initialized
INFO - 2020-07-07 11:17:47 --> Loader Class Initialized
INFO - 2020-07-07 11:17:47 --> Helper loaded: url_helper
INFO - 2020-07-07 11:17:47 --> Helper loaded: main_helper
INFO - 2020-07-07 11:17:47 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:17:47 --> Controller Class Initialized
INFO - 2020-07-07 11:17:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:17:47 --> Pagination Class Initialized
ERROR - 2020-07-07 11:17:47 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:17:47 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:17:47 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:17:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:17:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:17:47 --> Encryption Class Initialized
INFO - 2020-07-07 11:17:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:17:48 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 11:17:48 --> Final output sent to browser
DEBUG - 2020-07-07 11:17:48 --> Total execution time: 1.1715
INFO - 2020-07-07 11:29:43 --> Config Class Initialized
INFO - 2020-07-07 11:29:43 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:29:43 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:29:43 --> Utf8 Class Initialized
INFO - 2020-07-07 11:29:43 --> URI Class Initialized
INFO - 2020-07-07 11:29:43 --> Router Class Initialized
INFO - 2020-07-07 11:29:43 --> Output Class Initialized
INFO - 2020-07-07 11:29:43 --> Security Class Initialized
DEBUG - 2020-07-07 11:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:29:43 --> Input Class Initialized
INFO - 2020-07-07 11:29:43 --> Language Class Initialized
INFO - 2020-07-07 11:29:43 --> Language Class Initialized
INFO - 2020-07-07 11:29:43 --> Config Class Initialized
INFO - 2020-07-07 11:29:43 --> Loader Class Initialized
INFO - 2020-07-07 11:29:43 --> Helper loaded: url_helper
INFO - 2020-07-07 11:29:43 --> Helper loaded: main_helper
INFO - 2020-07-07 11:29:43 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:29:43 --> Controller Class Initialized
INFO - 2020-07-07 11:29:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:29:43 --> Pagination Class Initialized
ERROR - 2020-07-07 11:29:43 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:29:43 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:29:43 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:29:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:29:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:29:43 --> Encryption Class Initialized
INFO - 2020-07-07 11:29:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:29:45 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-07 11:29:45 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 11:29:45 --> Final output sent to browser
DEBUG - 2020-07-07 11:29:45 --> Total execution time: 2.0153
INFO - 2020-07-07 11:29:48 --> Config Class Initialized
INFO - 2020-07-07 11:29:48 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:29:48 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:29:48 --> Utf8 Class Initialized
INFO - 2020-07-07 11:29:48 --> URI Class Initialized
INFO - 2020-07-07 11:29:48 --> Router Class Initialized
INFO - 2020-07-07 11:29:48 --> Output Class Initialized
INFO - 2020-07-07 11:29:48 --> Security Class Initialized
DEBUG - 2020-07-07 11:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:29:48 --> Input Class Initialized
INFO - 2020-07-07 11:29:48 --> Language Class Initialized
INFO - 2020-07-07 11:29:48 --> Language Class Initialized
INFO - 2020-07-07 11:29:48 --> Config Class Initialized
INFO - 2020-07-07 11:29:48 --> Loader Class Initialized
INFO - 2020-07-07 11:29:48 --> Helper loaded: url_helper
INFO - 2020-07-07 11:29:48 --> Helper loaded: main_helper
INFO - 2020-07-07 11:29:48 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:29:48 --> Controller Class Initialized
INFO - 2020-07-07 11:29:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:29:48 --> Pagination Class Initialized
ERROR - 2020-07-07 11:29:48 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:29:48 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:29:48 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:29:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:29:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:29:48 --> Encryption Class Initialized
INFO - 2020-07-07 11:29:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:29:50 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 11:29:50 --> Final output sent to browser
DEBUG - 2020-07-07 11:29:50 --> Total execution time: 1.3428
INFO - 2020-07-07 11:29:55 --> Config Class Initialized
INFO - 2020-07-07 11:29:55 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:29:55 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:29:55 --> Utf8 Class Initialized
INFO - 2020-07-07 11:29:55 --> URI Class Initialized
INFO - 2020-07-07 11:29:55 --> Router Class Initialized
INFO - 2020-07-07 11:29:55 --> Output Class Initialized
INFO - 2020-07-07 11:29:55 --> Security Class Initialized
DEBUG - 2020-07-07 11:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:29:55 --> Input Class Initialized
INFO - 2020-07-07 11:29:55 --> Language Class Initialized
INFO - 2020-07-07 11:29:55 --> Language Class Initialized
INFO - 2020-07-07 11:29:55 --> Config Class Initialized
INFO - 2020-07-07 11:29:55 --> Loader Class Initialized
INFO - 2020-07-07 11:29:55 --> Helper loaded: url_helper
INFO - 2020-07-07 11:29:55 --> Helper loaded: main_helper
INFO - 2020-07-07 11:29:55 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:29:55 --> Controller Class Initialized
INFO - 2020-07-07 11:29:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:29:55 --> Pagination Class Initialized
ERROR - 2020-07-07 11:29:55 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:29:55 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:29:55 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:29:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:29:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:29:55 --> Encryption Class Initialized
INFO - 2020-07-07 11:29:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:29:56 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 11:29:56 --> Final output sent to browser
DEBUG - 2020-07-07 11:29:56 --> Total execution time: 1.2433
INFO - 2020-07-07 11:30:02 --> Config Class Initialized
INFO - 2020-07-07 11:30:02 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:30:02 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:30:02 --> Utf8 Class Initialized
INFO - 2020-07-07 11:30:02 --> URI Class Initialized
INFO - 2020-07-07 11:30:02 --> Router Class Initialized
INFO - 2020-07-07 11:30:02 --> Output Class Initialized
INFO - 2020-07-07 11:30:02 --> Security Class Initialized
DEBUG - 2020-07-07 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:30:02 --> Input Class Initialized
INFO - 2020-07-07 11:30:02 --> Language Class Initialized
INFO - 2020-07-07 11:30:02 --> Language Class Initialized
INFO - 2020-07-07 11:30:02 --> Config Class Initialized
INFO - 2020-07-07 11:30:02 --> Loader Class Initialized
INFO - 2020-07-07 11:30:02 --> Helper loaded: url_helper
INFO - 2020-07-07 11:30:02 --> Helper loaded: main_helper
INFO - 2020-07-07 11:30:02 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:30:02 --> Controller Class Initialized
INFO - 2020-07-07 11:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:30:02 --> Pagination Class Initialized
ERROR - 2020-07-07 11:30:02 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:30:02 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:30:02 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:30:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:30:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:30:02 --> Encryption Class Initialized
INFO - 2020-07-07 11:30:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:30:03 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:30:03 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:31:05 --> Config Class Initialized
INFO - 2020-07-07 11:31:05 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:31:05 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:31:05 --> Utf8 Class Initialized
INFO - 2020-07-07 11:31:05 --> URI Class Initialized
INFO - 2020-07-07 11:31:05 --> Router Class Initialized
INFO - 2020-07-07 11:31:05 --> Output Class Initialized
INFO - 2020-07-07 11:31:05 --> Security Class Initialized
DEBUG - 2020-07-07 11:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:31:05 --> Input Class Initialized
INFO - 2020-07-07 11:31:05 --> Language Class Initialized
INFO - 2020-07-07 11:31:05 --> Language Class Initialized
INFO - 2020-07-07 11:31:05 --> Config Class Initialized
INFO - 2020-07-07 11:31:05 --> Loader Class Initialized
INFO - 2020-07-07 11:31:05 --> Helper loaded: url_helper
INFO - 2020-07-07 11:31:05 --> Helper loaded: main_helper
INFO - 2020-07-07 11:31:05 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:31:05 --> Controller Class Initialized
INFO - 2020-07-07 11:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:31:05 --> Pagination Class Initialized
ERROR - 2020-07-07 11:31:05 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:31:05 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:31:05 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:31:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:31:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:31:05 --> Encryption Class Initialized
INFO - 2020-07-07 11:31:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:31:06 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:31:06 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:31:36 --> Config Class Initialized
INFO - 2020-07-07 11:31:36 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:31:36 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:31:36 --> Utf8 Class Initialized
INFO - 2020-07-07 11:31:36 --> URI Class Initialized
INFO - 2020-07-07 11:31:36 --> Router Class Initialized
INFO - 2020-07-07 11:31:36 --> Output Class Initialized
INFO - 2020-07-07 11:31:36 --> Security Class Initialized
DEBUG - 2020-07-07 11:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:31:36 --> Input Class Initialized
INFO - 2020-07-07 11:31:36 --> Language Class Initialized
INFO - 2020-07-07 11:31:36 --> Language Class Initialized
INFO - 2020-07-07 11:31:36 --> Config Class Initialized
INFO - 2020-07-07 11:31:36 --> Loader Class Initialized
INFO - 2020-07-07 11:31:36 --> Helper loaded: url_helper
INFO - 2020-07-07 11:31:36 --> Helper loaded: main_helper
INFO - 2020-07-07 11:31:36 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:31:36 --> Controller Class Initialized
INFO - 2020-07-07 11:31:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:31:36 --> Pagination Class Initialized
ERROR - 2020-07-07 11:31:36 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:31:36 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:31:36 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:31:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:31:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:31:36 --> Encryption Class Initialized
INFO - 2020-07-07 11:31:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:31:38 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:31:38 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:32:00 --> Config Class Initialized
INFO - 2020-07-07 11:32:00 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:32:00 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:32:00 --> Utf8 Class Initialized
INFO - 2020-07-07 11:32:00 --> URI Class Initialized
INFO - 2020-07-07 11:32:00 --> Router Class Initialized
INFO - 2020-07-07 11:32:00 --> Output Class Initialized
INFO - 2020-07-07 11:32:00 --> Security Class Initialized
DEBUG - 2020-07-07 11:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:32:00 --> Input Class Initialized
INFO - 2020-07-07 11:32:00 --> Language Class Initialized
INFO - 2020-07-07 11:32:00 --> Language Class Initialized
INFO - 2020-07-07 11:32:00 --> Config Class Initialized
INFO - 2020-07-07 11:32:00 --> Loader Class Initialized
INFO - 2020-07-07 11:32:00 --> Helper loaded: url_helper
INFO - 2020-07-07 11:32:00 --> Helper loaded: main_helper
INFO - 2020-07-07 11:32:00 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:32:00 --> Controller Class Initialized
INFO - 2020-07-07 11:32:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:32:00 --> Pagination Class Initialized
ERROR - 2020-07-07 11:32:00 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:32:00 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:32:00 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:32:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:32:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:32:00 --> Encryption Class Initialized
INFO - 2020-07-07 11:32:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:32:00 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-07 11:32:00 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 11:32:00 --> Final output sent to browser
DEBUG - 2020-07-07 11:32:00 --> Total execution time: 0.0053
INFO - 2020-07-07 11:32:05 --> Config Class Initialized
INFO - 2020-07-07 11:32:05 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:32:05 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:32:05 --> Utf8 Class Initialized
INFO - 2020-07-07 11:32:05 --> URI Class Initialized
INFO - 2020-07-07 11:32:05 --> Router Class Initialized
INFO - 2020-07-07 11:32:05 --> Output Class Initialized
INFO - 2020-07-07 11:32:05 --> Security Class Initialized
DEBUG - 2020-07-07 11:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:32:05 --> Input Class Initialized
INFO - 2020-07-07 11:32:05 --> Language Class Initialized
INFO - 2020-07-07 11:32:05 --> Language Class Initialized
INFO - 2020-07-07 11:32:05 --> Config Class Initialized
INFO - 2020-07-07 11:32:05 --> Loader Class Initialized
INFO - 2020-07-07 11:32:05 --> Helper loaded: url_helper
INFO - 2020-07-07 11:32:05 --> Helper loaded: main_helper
INFO - 2020-07-07 11:32:05 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:32:05 --> Controller Class Initialized
INFO - 2020-07-07 11:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:32:05 --> Pagination Class Initialized
ERROR - 2020-07-07 11:32:05 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:32:05 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:32:05 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:32:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:32:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:32:05 --> Encryption Class Initialized
INFO - 2020-07-07 11:32:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:32:07 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:32:07 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:32:46 --> Config Class Initialized
INFO - 2020-07-07 11:32:46 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:32:46 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:32:46 --> Utf8 Class Initialized
INFO - 2020-07-07 11:32:46 --> URI Class Initialized
INFO - 2020-07-07 11:32:46 --> Router Class Initialized
INFO - 2020-07-07 11:32:46 --> Output Class Initialized
INFO - 2020-07-07 11:32:46 --> Security Class Initialized
DEBUG - 2020-07-07 11:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:32:46 --> Input Class Initialized
INFO - 2020-07-07 11:32:46 --> Language Class Initialized
INFO - 2020-07-07 11:32:46 --> Language Class Initialized
INFO - 2020-07-07 11:32:46 --> Config Class Initialized
INFO - 2020-07-07 11:32:46 --> Loader Class Initialized
INFO - 2020-07-07 11:32:46 --> Helper loaded: url_helper
INFO - 2020-07-07 11:32:46 --> Helper loaded: main_helper
INFO - 2020-07-07 11:32:46 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:32:46 --> Controller Class Initialized
INFO - 2020-07-07 11:32:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:32:46 --> Pagination Class Initialized
ERROR - 2020-07-07 11:32:46 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:32:46 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:32:46 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:32:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:32:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:32:46 --> Encryption Class Initialized
INFO - 2020-07-07 11:32:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:32:47 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 11:32:47 --> Final output sent to browser
DEBUG - 2020-07-07 11:32:47 --> Total execution time: 1.2442
INFO - 2020-07-07 11:33:25 --> Config Class Initialized
INFO - 2020-07-07 11:33:25 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:33:25 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:33:25 --> Utf8 Class Initialized
INFO - 2020-07-07 11:33:25 --> URI Class Initialized
INFO - 2020-07-07 11:33:25 --> Router Class Initialized
INFO - 2020-07-07 11:33:25 --> Output Class Initialized
INFO - 2020-07-07 11:33:25 --> Security Class Initialized
DEBUG - 2020-07-07 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:33:25 --> Input Class Initialized
INFO - 2020-07-07 11:33:25 --> Language Class Initialized
INFO - 2020-07-07 11:33:25 --> Language Class Initialized
INFO - 2020-07-07 11:33:25 --> Config Class Initialized
INFO - 2020-07-07 11:33:25 --> Loader Class Initialized
INFO - 2020-07-07 11:33:25 --> Helper loaded: url_helper
INFO - 2020-07-07 11:33:25 --> Helper loaded: main_helper
INFO - 2020-07-07 11:33:25 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:33:25 --> Controller Class Initialized
INFO - 2020-07-07 11:33:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:33:25 --> Pagination Class Initialized
ERROR - 2020-07-07 11:33:25 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:33:25 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:33:25 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:33:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:33:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:33:25 --> Encryption Class Initialized
INFO - 2020-07-07 11:33:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:33:26 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:33:26 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:34:17 --> Config Class Initialized
INFO - 2020-07-07 11:34:17 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:34:17 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:34:17 --> Utf8 Class Initialized
INFO - 2020-07-07 11:34:17 --> URI Class Initialized
INFO - 2020-07-07 11:34:17 --> Router Class Initialized
INFO - 2020-07-07 11:34:17 --> Output Class Initialized
INFO - 2020-07-07 11:34:17 --> Security Class Initialized
DEBUG - 2020-07-07 11:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:34:17 --> Input Class Initialized
INFO - 2020-07-07 11:34:17 --> Language Class Initialized
INFO - 2020-07-07 11:34:17 --> Language Class Initialized
INFO - 2020-07-07 11:34:17 --> Config Class Initialized
INFO - 2020-07-07 11:34:17 --> Loader Class Initialized
INFO - 2020-07-07 11:34:17 --> Helper loaded: url_helper
INFO - 2020-07-07 11:34:17 --> Helper loaded: main_helper
INFO - 2020-07-07 11:34:17 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:34:17 --> Controller Class Initialized
INFO - 2020-07-07 11:34:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:34:17 --> Pagination Class Initialized
ERROR - 2020-07-07 11:34:17 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:34:17 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:34:17 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:34:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:34:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:34:17 --> Encryption Class Initialized
INFO - 2020-07-07 11:34:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:34:18 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:34:18 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:34:33 --> Config Class Initialized
INFO - 2020-07-07 11:34:33 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:34:33 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:34:33 --> Utf8 Class Initialized
INFO - 2020-07-07 11:34:33 --> URI Class Initialized
INFO - 2020-07-07 11:34:33 --> Router Class Initialized
INFO - 2020-07-07 11:34:33 --> Output Class Initialized
INFO - 2020-07-07 11:34:33 --> Security Class Initialized
DEBUG - 2020-07-07 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:34:33 --> Input Class Initialized
INFO - 2020-07-07 11:34:33 --> Language Class Initialized
INFO - 2020-07-07 11:34:33 --> Language Class Initialized
INFO - 2020-07-07 11:34:33 --> Config Class Initialized
INFO - 2020-07-07 11:34:33 --> Loader Class Initialized
INFO - 2020-07-07 11:34:33 --> Helper loaded: url_helper
INFO - 2020-07-07 11:34:33 --> Helper loaded: main_helper
INFO - 2020-07-07 11:34:33 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:34:33 --> Controller Class Initialized
INFO - 2020-07-07 11:34:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:34:33 --> Pagination Class Initialized
ERROR - 2020-07-07 11:34:33 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:34:33 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:34:33 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:34:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:34:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:34:33 --> Encryption Class Initialized
INFO - 2020-07-07 11:34:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:34:34 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:34:34 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:34:49 --> Config Class Initialized
INFO - 2020-07-07 11:34:49 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:34:49 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:34:49 --> Utf8 Class Initialized
INFO - 2020-07-07 11:34:49 --> URI Class Initialized
INFO - 2020-07-07 11:34:49 --> Router Class Initialized
INFO - 2020-07-07 11:34:49 --> Output Class Initialized
INFO - 2020-07-07 11:34:49 --> Security Class Initialized
DEBUG - 2020-07-07 11:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:34:49 --> Input Class Initialized
INFO - 2020-07-07 11:34:49 --> Language Class Initialized
INFO - 2020-07-07 11:34:49 --> Language Class Initialized
INFO - 2020-07-07 11:34:49 --> Config Class Initialized
INFO - 2020-07-07 11:34:49 --> Loader Class Initialized
INFO - 2020-07-07 11:34:49 --> Helper loaded: url_helper
INFO - 2020-07-07 11:34:49 --> Helper loaded: main_helper
INFO - 2020-07-07 11:34:49 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:34:49 --> Controller Class Initialized
INFO - 2020-07-07 11:34:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:34:49 --> Pagination Class Initialized
ERROR - 2020-07-07 11:34:49 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:34:49 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:34:49 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:34:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:34:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:34:49 --> Encryption Class Initialized
INFO - 2020-07-07 11:34:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:34:50 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:34:50 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:35:01 --> Config Class Initialized
INFO - 2020-07-07 11:35:01 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:35:01 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:35:01 --> Utf8 Class Initialized
INFO - 2020-07-07 11:35:01 --> URI Class Initialized
INFO - 2020-07-07 11:35:01 --> Router Class Initialized
INFO - 2020-07-07 11:35:01 --> Output Class Initialized
INFO - 2020-07-07 11:35:01 --> Security Class Initialized
DEBUG - 2020-07-07 11:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:35:01 --> Input Class Initialized
INFO - 2020-07-07 11:35:01 --> Language Class Initialized
INFO - 2020-07-07 11:35:01 --> Language Class Initialized
INFO - 2020-07-07 11:35:01 --> Config Class Initialized
INFO - 2020-07-07 11:35:01 --> Loader Class Initialized
INFO - 2020-07-07 11:35:01 --> Helper loaded: url_helper
INFO - 2020-07-07 11:35:01 --> Helper loaded: main_helper
INFO - 2020-07-07 11:35:01 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:35:01 --> Controller Class Initialized
INFO - 2020-07-07 11:35:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:35:01 --> Pagination Class Initialized
ERROR - 2020-07-07 11:35:01 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:35:01 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:35:01 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:35:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:35:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:35:01 --> Encryption Class Initialized
INFO - 2020-07-07 11:35:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:35:02 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:35:02 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:35:18 --> Config Class Initialized
INFO - 2020-07-07 11:35:18 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:35:18 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:35:18 --> Utf8 Class Initialized
INFO - 2020-07-07 11:35:18 --> URI Class Initialized
INFO - 2020-07-07 11:35:18 --> Router Class Initialized
INFO - 2020-07-07 11:35:18 --> Output Class Initialized
INFO - 2020-07-07 11:35:18 --> Security Class Initialized
DEBUG - 2020-07-07 11:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:35:18 --> Input Class Initialized
INFO - 2020-07-07 11:35:18 --> Language Class Initialized
INFO - 2020-07-07 11:35:18 --> Language Class Initialized
INFO - 2020-07-07 11:35:18 --> Config Class Initialized
INFO - 2020-07-07 11:35:18 --> Loader Class Initialized
INFO - 2020-07-07 11:35:18 --> Helper loaded: url_helper
INFO - 2020-07-07 11:35:18 --> Helper loaded: main_helper
INFO - 2020-07-07 11:35:18 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:35:18 --> Controller Class Initialized
INFO - 2020-07-07 11:35:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:35:18 --> Pagination Class Initialized
ERROR - 2020-07-07 11:35:18 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:35:18 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:35:18 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:35:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:35:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:35:18 --> Encryption Class Initialized
INFO - 2020-07-07 11:35:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:35:20 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:35:20 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:36:16 --> Config Class Initialized
INFO - 2020-07-07 11:36:16 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:36:16 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:36:16 --> Utf8 Class Initialized
INFO - 2020-07-07 11:36:16 --> URI Class Initialized
INFO - 2020-07-07 11:36:16 --> Router Class Initialized
INFO - 2020-07-07 11:36:16 --> Output Class Initialized
INFO - 2020-07-07 11:36:16 --> Security Class Initialized
DEBUG - 2020-07-07 11:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:36:16 --> Input Class Initialized
INFO - 2020-07-07 11:36:16 --> Language Class Initialized
INFO - 2020-07-07 11:36:16 --> Language Class Initialized
INFO - 2020-07-07 11:36:16 --> Config Class Initialized
INFO - 2020-07-07 11:36:16 --> Loader Class Initialized
INFO - 2020-07-07 11:36:16 --> Helper loaded: url_helper
INFO - 2020-07-07 11:36:16 --> Helper loaded: main_helper
INFO - 2020-07-07 11:36:16 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:36:16 --> Controller Class Initialized
INFO - 2020-07-07 11:36:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:36:16 --> Pagination Class Initialized
ERROR - 2020-07-07 11:36:16 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:36:16 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:36:16 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:36:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:36:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:36:16 --> Encryption Class Initialized
INFO - 2020-07-07 11:36:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:36:17 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 11:36:17 --> Final output sent to browser
DEBUG - 2020-07-07 11:36:17 --> Total execution time: 1.3095
INFO - 2020-07-07 11:36:47 --> Config Class Initialized
INFO - 2020-07-07 11:36:47 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:36:47 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:36:47 --> Utf8 Class Initialized
INFO - 2020-07-07 11:36:47 --> URI Class Initialized
INFO - 2020-07-07 11:36:47 --> Router Class Initialized
INFO - 2020-07-07 11:36:47 --> Output Class Initialized
INFO - 2020-07-07 11:36:47 --> Security Class Initialized
DEBUG - 2020-07-07 11:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:36:47 --> Input Class Initialized
INFO - 2020-07-07 11:36:47 --> Language Class Initialized
INFO - 2020-07-07 11:36:47 --> Language Class Initialized
INFO - 2020-07-07 11:36:47 --> Config Class Initialized
INFO - 2020-07-07 11:36:47 --> Loader Class Initialized
INFO - 2020-07-07 11:36:47 --> Helper loaded: url_helper
INFO - 2020-07-07 11:36:47 --> Helper loaded: main_helper
INFO - 2020-07-07 11:36:47 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:36:47 --> Controller Class Initialized
INFO - 2020-07-07 11:36:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:36:47 --> Pagination Class Initialized
ERROR - 2020-07-07 11:36:47 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:36:47 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:36:47 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:36:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:36:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:36:47 --> Encryption Class Initialized
INFO - 2020-07-07 11:36:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:36:49 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:36:49 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:38:34 --> Config Class Initialized
INFO - 2020-07-07 11:38:34 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:38:34 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:38:34 --> Utf8 Class Initialized
INFO - 2020-07-07 11:38:34 --> URI Class Initialized
INFO - 2020-07-07 11:38:34 --> Router Class Initialized
INFO - 2020-07-07 11:38:34 --> Output Class Initialized
INFO - 2020-07-07 11:38:34 --> Security Class Initialized
DEBUG - 2020-07-07 11:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:38:34 --> Input Class Initialized
INFO - 2020-07-07 11:38:34 --> Language Class Initialized
INFO - 2020-07-07 11:38:34 --> Language Class Initialized
INFO - 2020-07-07 11:38:34 --> Config Class Initialized
INFO - 2020-07-07 11:38:34 --> Loader Class Initialized
INFO - 2020-07-07 11:38:34 --> Helper loaded: url_helper
INFO - 2020-07-07 11:38:34 --> Helper loaded: main_helper
INFO - 2020-07-07 11:38:34 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:38:34 --> Controller Class Initialized
INFO - 2020-07-07 11:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:38:34 --> Pagination Class Initialized
ERROR - 2020-07-07 11:38:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:38:34 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:38:34 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:38:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:38:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:38:34 --> Encryption Class Initialized
INFO - 2020-07-07 11:38:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:38:35 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:38:35 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:39:06 --> Config Class Initialized
INFO - 2020-07-07 11:39:06 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:39:06 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:39:06 --> Utf8 Class Initialized
INFO - 2020-07-07 11:39:06 --> URI Class Initialized
INFO - 2020-07-07 11:39:06 --> Router Class Initialized
INFO - 2020-07-07 11:39:06 --> Output Class Initialized
INFO - 2020-07-07 11:39:06 --> Security Class Initialized
DEBUG - 2020-07-07 11:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:39:06 --> Input Class Initialized
INFO - 2020-07-07 11:39:06 --> Language Class Initialized
INFO - 2020-07-07 11:39:06 --> Language Class Initialized
INFO - 2020-07-07 11:39:06 --> Config Class Initialized
INFO - 2020-07-07 11:39:06 --> Loader Class Initialized
INFO - 2020-07-07 11:39:06 --> Helper loaded: url_helper
INFO - 2020-07-07 11:39:06 --> Helper loaded: main_helper
INFO - 2020-07-07 11:39:06 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:39:06 --> Controller Class Initialized
INFO - 2020-07-07 11:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:39:06 --> Pagination Class Initialized
ERROR - 2020-07-07 11:39:06 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:39:06 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:39:06 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:39:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:39:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:39:06 --> Encryption Class Initialized
INFO - 2020-07-07 11:39:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:39:07 --> Severity: Notice --> Undefined variable: issn /var/www/journal/application/modules/landing/views/xml_export_v.php 28
ERROR - 2020-07-07 11:39:07 --> Severity: error --> Exception: Argument 1 passed to DOMNode::appendChild() must be an instance of DOMNode, null given /var/www/journal/application/modules/landing/views/xml_export_v.php 28
INFO - 2020-07-07 11:39:36 --> Config Class Initialized
INFO - 2020-07-07 11:39:36 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:39:36 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:39:36 --> Utf8 Class Initialized
INFO - 2020-07-07 11:39:36 --> URI Class Initialized
INFO - 2020-07-07 11:39:36 --> Router Class Initialized
INFO - 2020-07-07 11:39:36 --> Output Class Initialized
INFO - 2020-07-07 11:39:36 --> Security Class Initialized
DEBUG - 2020-07-07 11:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:39:36 --> Input Class Initialized
INFO - 2020-07-07 11:39:36 --> Language Class Initialized
INFO - 2020-07-07 11:39:36 --> Language Class Initialized
INFO - 2020-07-07 11:39:36 --> Config Class Initialized
INFO - 2020-07-07 11:39:36 --> Loader Class Initialized
INFO - 2020-07-07 11:39:36 --> Helper loaded: url_helper
INFO - 2020-07-07 11:39:36 --> Helper loaded: main_helper
INFO - 2020-07-07 11:39:36 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:39:36 --> Controller Class Initialized
INFO - 2020-07-07 11:39:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:39:36 --> Pagination Class Initialized
ERROR - 2020-07-07 11:39:36 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:39:36 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:39:36 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:39:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:39:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:39:36 --> Encryption Class Initialized
INFO - 2020-07-07 11:39:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:39:37 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 11:39:37 --> Final output sent to browser
DEBUG - 2020-07-07 11:39:37 --> Total execution time: 1.2168
INFO - 2020-07-07 11:39:52 --> Config Class Initialized
INFO - 2020-07-07 11:39:52 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:39:52 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:39:52 --> Utf8 Class Initialized
INFO - 2020-07-07 11:39:52 --> URI Class Initialized
INFO - 2020-07-07 11:39:52 --> Router Class Initialized
INFO - 2020-07-07 11:39:52 --> Output Class Initialized
INFO - 2020-07-07 11:39:52 --> Security Class Initialized
DEBUG - 2020-07-07 11:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:39:52 --> Input Class Initialized
INFO - 2020-07-07 11:39:52 --> Language Class Initialized
INFO - 2020-07-07 11:39:52 --> Language Class Initialized
INFO - 2020-07-07 11:39:52 --> Config Class Initialized
INFO - 2020-07-07 11:39:52 --> Loader Class Initialized
INFO - 2020-07-07 11:39:52 --> Helper loaded: url_helper
INFO - 2020-07-07 11:39:52 --> Helper loaded: main_helper
INFO - 2020-07-07 11:39:52 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:39:52 --> Controller Class Initialized
INFO - 2020-07-07 11:39:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:39:52 --> Pagination Class Initialized
ERROR - 2020-07-07 11:39:52 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:39:52 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:39:52 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:39:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:39:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:39:52 --> Encryption Class Initialized
INFO - 2020-07-07 11:39:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:39:53 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 11:39:53 --> Final output sent to browser
DEBUG - 2020-07-07 11:39:53 --> Total execution time: 1.2581
INFO - 2020-07-07 11:40:01 --> Config Class Initialized
INFO - 2020-07-07 11:40:01 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:40:01 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:40:01 --> Utf8 Class Initialized
INFO - 2020-07-07 11:40:01 --> URI Class Initialized
INFO - 2020-07-07 11:40:01 --> Router Class Initialized
INFO - 2020-07-07 11:40:01 --> Output Class Initialized
INFO - 2020-07-07 11:40:01 --> Security Class Initialized
DEBUG - 2020-07-07 11:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:40:01 --> Input Class Initialized
INFO - 2020-07-07 11:40:01 --> Language Class Initialized
INFO - 2020-07-07 11:40:01 --> Language Class Initialized
INFO - 2020-07-07 11:40:01 --> Config Class Initialized
INFO - 2020-07-07 11:40:01 --> Loader Class Initialized
INFO - 2020-07-07 11:40:01 --> Helper loaded: url_helper
INFO - 2020-07-07 11:40:01 --> Helper loaded: main_helper
INFO - 2020-07-07 11:40:01 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:40:01 --> Controller Class Initialized
INFO - 2020-07-07 11:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:40:01 --> Pagination Class Initialized
ERROR - 2020-07-07 11:40:01 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:40:01 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:40:01 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:40:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:40:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:40:01 --> Encryption Class Initialized
INFO - 2020-07-07 11:40:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:40:02 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 11:40:02 --> Final output sent to browser
DEBUG - 2020-07-07 11:40:02 --> Total execution time: 1.2135
INFO - 2020-07-07 11:41:22 --> Config Class Initialized
INFO - 2020-07-07 11:41:22 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:41:22 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:41:22 --> Utf8 Class Initialized
INFO - 2020-07-07 11:41:22 --> URI Class Initialized
INFO - 2020-07-07 11:41:22 --> Router Class Initialized
INFO - 2020-07-07 11:41:22 --> Output Class Initialized
INFO - 2020-07-07 11:41:22 --> Security Class Initialized
DEBUG - 2020-07-07 11:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:41:22 --> Input Class Initialized
INFO - 2020-07-07 11:41:22 --> Language Class Initialized
INFO - 2020-07-07 11:41:22 --> Language Class Initialized
INFO - 2020-07-07 11:41:22 --> Config Class Initialized
INFO - 2020-07-07 11:41:22 --> Loader Class Initialized
INFO - 2020-07-07 11:41:22 --> Helper loaded: url_helper
INFO - 2020-07-07 11:41:22 --> Helper loaded: main_helper
INFO - 2020-07-07 11:41:22 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:41:22 --> Controller Class Initialized
INFO - 2020-07-07 11:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:41:22 --> Pagination Class Initialized
ERROR - 2020-07-07 11:41:22 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:41:22 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:41:22 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:41:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:41:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:41:22 --> Encryption Class Initialized
INFO - 2020-07-07 11:41:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:41:23 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 11:41:23 --> Final output sent to browser
DEBUG - 2020-07-07 11:41:23 --> Total execution time: 1.2344
INFO - 2020-07-07 11:53:35 --> Config Class Initialized
INFO - 2020-07-07 11:53:35 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:53:35 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:53:35 --> Utf8 Class Initialized
INFO - 2020-07-07 11:53:35 --> URI Class Initialized
INFO - 2020-07-07 11:53:35 --> Router Class Initialized
INFO - 2020-07-07 11:53:35 --> Output Class Initialized
INFO - 2020-07-07 11:53:35 --> Security Class Initialized
DEBUG - 2020-07-07 11:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:53:35 --> Input Class Initialized
INFO - 2020-07-07 11:53:35 --> Language Class Initialized
INFO - 2020-07-07 11:53:35 --> Language Class Initialized
INFO - 2020-07-07 11:53:35 --> Config Class Initialized
INFO - 2020-07-07 11:53:35 --> Loader Class Initialized
INFO - 2020-07-07 11:53:35 --> Helper loaded: url_helper
INFO - 2020-07-07 11:53:35 --> Helper loaded: main_helper
INFO - 2020-07-07 11:53:35 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:53:35 --> Controller Class Initialized
INFO - 2020-07-07 11:53:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:53:35 --> Pagination Class Initialized
ERROR - 2020-07-07 11:53:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:53:35 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:53:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:53:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:53:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:53:35 --> Encryption Class Initialized
INFO - 2020-07-07 11:53:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:53:36 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 11:53:36 --> Final output sent to browser
DEBUG - 2020-07-07 11:53:36 --> Total execution time: 1.1972
INFO - 2020-07-07 11:54:04 --> Config Class Initialized
INFO - 2020-07-07 11:54:04 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:54:04 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:54:04 --> Utf8 Class Initialized
INFO - 2020-07-07 11:54:04 --> URI Class Initialized
INFO - 2020-07-07 11:54:04 --> Router Class Initialized
INFO - 2020-07-07 11:54:04 --> Output Class Initialized
INFO - 2020-07-07 11:54:04 --> Security Class Initialized
DEBUG - 2020-07-07 11:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:54:04 --> Input Class Initialized
INFO - 2020-07-07 11:54:04 --> Language Class Initialized
INFO - 2020-07-07 11:54:04 --> Language Class Initialized
INFO - 2020-07-07 11:54:04 --> Config Class Initialized
INFO - 2020-07-07 11:54:04 --> Loader Class Initialized
INFO - 2020-07-07 11:54:04 --> Helper loaded: url_helper
INFO - 2020-07-07 11:54:04 --> Helper loaded: main_helper
INFO - 2020-07-07 11:54:04 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:54:04 --> Controller Class Initialized
INFO - 2020-07-07 11:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:54:04 --> Pagination Class Initialized
ERROR - 2020-07-07 11:54:04 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:54:04 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:54:04 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:54:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:54:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:54:04 --> Encryption Class Initialized
INFO - 2020-07-07 11:54:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:54:06 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 11:54:06 --> Final output sent to browser
DEBUG - 2020-07-07 11:54:06 --> Total execution time: 1.3667
INFO - 2020-07-07 11:54:32 --> Config Class Initialized
INFO - 2020-07-07 11:54:32 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:54:32 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:54:32 --> Utf8 Class Initialized
INFO - 2020-07-07 11:54:32 --> URI Class Initialized
INFO - 2020-07-07 11:54:32 --> Router Class Initialized
INFO - 2020-07-07 11:54:32 --> Output Class Initialized
INFO - 2020-07-07 11:54:32 --> Security Class Initialized
DEBUG - 2020-07-07 11:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:54:32 --> Input Class Initialized
INFO - 2020-07-07 11:54:32 --> Language Class Initialized
INFO - 2020-07-07 11:54:32 --> Language Class Initialized
INFO - 2020-07-07 11:54:32 --> Config Class Initialized
INFO - 2020-07-07 11:54:32 --> Loader Class Initialized
INFO - 2020-07-07 11:54:32 --> Helper loaded: url_helper
INFO - 2020-07-07 11:54:32 --> Helper loaded: main_helper
INFO - 2020-07-07 11:54:32 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:54:32 --> Controller Class Initialized
INFO - 2020-07-07 11:54:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:54:32 --> Pagination Class Initialized
ERROR - 2020-07-07 11:54:32 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:54:32 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:54:32 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:54:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:54:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:54:32 --> Encryption Class Initialized
INFO - 2020-07-07 11:54:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:54:33 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 11:54:33 --> Final output sent to browser
DEBUG - 2020-07-07 11:54:33 --> Total execution time: 1.2607
INFO - 2020-07-07 11:54:43 --> Config Class Initialized
INFO - 2020-07-07 11:54:43 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:54:43 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:54:43 --> Utf8 Class Initialized
INFO - 2020-07-07 11:54:43 --> URI Class Initialized
INFO - 2020-07-07 11:54:43 --> Router Class Initialized
INFO - 2020-07-07 11:54:43 --> Output Class Initialized
INFO - 2020-07-07 11:54:43 --> Security Class Initialized
DEBUG - 2020-07-07 11:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:54:43 --> Input Class Initialized
INFO - 2020-07-07 11:54:43 --> Language Class Initialized
INFO - 2020-07-07 11:54:43 --> Language Class Initialized
INFO - 2020-07-07 11:54:43 --> Config Class Initialized
INFO - 2020-07-07 11:54:43 --> Loader Class Initialized
INFO - 2020-07-07 11:54:43 --> Helper loaded: url_helper
INFO - 2020-07-07 11:54:43 --> Helper loaded: main_helper
INFO - 2020-07-07 11:54:43 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:54:43 --> Controller Class Initialized
INFO - 2020-07-07 11:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:54:43 --> Pagination Class Initialized
ERROR - 2020-07-07 11:54:43 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:54:43 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:54:43 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:54:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:54:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:54:43 --> Encryption Class Initialized
INFO - 2020-07-07 11:54:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:54:44 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 11:54:44 --> Final output sent to browser
DEBUG - 2020-07-07 11:54:44 --> Total execution time: 1.3132
INFO - 2020-07-07 11:54:55 --> Config Class Initialized
INFO - 2020-07-07 11:54:55 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:54:55 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:54:55 --> Utf8 Class Initialized
INFO - 2020-07-07 11:54:55 --> URI Class Initialized
INFO - 2020-07-07 11:54:55 --> Router Class Initialized
INFO - 2020-07-07 11:54:55 --> Output Class Initialized
INFO - 2020-07-07 11:54:55 --> Security Class Initialized
DEBUG - 2020-07-07 11:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:54:55 --> Input Class Initialized
INFO - 2020-07-07 11:54:55 --> Language Class Initialized
INFO - 2020-07-07 11:54:55 --> Language Class Initialized
INFO - 2020-07-07 11:54:55 --> Config Class Initialized
INFO - 2020-07-07 11:54:55 --> Loader Class Initialized
INFO - 2020-07-07 11:54:55 --> Helper loaded: url_helper
INFO - 2020-07-07 11:54:55 --> Helper loaded: main_helper
INFO - 2020-07-07 11:54:55 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:54:55 --> Controller Class Initialized
INFO - 2020-07-07 11:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:54:55 --> Pagination Class Initialized
ERROR - 2020-07-07 11:54:55 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:54:55 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:54:55 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:54:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:54:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:54:55 --> Encryption Class Initialized
INFO - 2020-07-07 11:54:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 11:54:56 --> Severity: Warning --> DOMDocument::createElement() expects parameter 2 to be string, array given /var/www/journal/application/modules/landing/views/xml_export_v.php 87
ERROR - 2020-07-07 11:54:56 --> Severity: Notice --> Undefined property: stdClass::$doi /var/www/journal/application/modules/landing/views/xml_export_v.php 89
ERROR - 2020-07-07 11:54:56 --> Severity: error --> Exception: Call to a member function appendChild() on null /var/www/journal/application/modules/landing/views/xml_export_v.php 90
INFO - 2020-07-07 11:55:48 --> Config Class Initialized
INFO - 2020-07-07 11:55:48 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:55:48 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:55:48 --> Utf8 Class Initialized
INFO - 2020-07-07 11:55:48 --> URI Class Initialized
INFO - 2020-07-07 11:55:48 --> Router Class Initialized
INFO - 2020-07-07 11:55:48 --> Output Class Initialized
INFO - 2020-07-07 11:55:48 --> Security Class Initialized
DEBUG - 2020-07-07 11:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:55:48 --> Input Class Initialized
INFO - 2020-07-07 11:55:48 --> Language Class Initialized
INFO - 2020-07-07 11:55:48 --> Language Class Initialized
INFO - 2020-07-07 11:55:48 --> Config Class Initialized
INFO - 2020-07-07 11:55:48 --> Loader Class Initialized
INFO - 2020-07-07 11:55:48 --> Helper loaded: url_helper
INFO - 2020-07-07 11:55:48 --> Helper loaded: main_helper
INFO - 2020-07-07 11:55:48 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:55:48 --> Controller Class Initialized
INFO - 2020-07-07 11:55:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:55:48 --> Pagination Class Initialized
ERROR - 2020-07-07 11:55:48 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:55:48 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:55:48 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:55:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:55:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:55:48 --> Encryption Class Initialized
INFO - 2020-07-07 11:55:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:55:49 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 11:55:49 --> Final output sent to browser
DEBUG - 2020-07-07 11:55:49 --> Total execution time: 1.2296
INFO - 2020-07-07 11:56:35 --> Config Class Initialized
INFO - 2020-07-07 11:56:35 --> Hooks Class Initialized
DEBUG - 2020-07-07 11:56:35 --> UTF-8 Support Enabled
INFO - 2020-07-07 11:56:35 --> Utf8 Class Initialized
INFO - 2020-07-07 11:56:35 --> URI Class Initialized
INFO - 2020-07-07 11:56:35 --> Router Class Initialized
INFO - 2020-07-07 11:56:35 --> Output Class Initialized
INFO - 2020-07-07 11:56:35 --> Security Class Initialized
DEBUG - 2020-07-07 11:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 11:56:35 --> Input Class Initialized
INFO - 2020-07-07 11:56:35 --> Language Class Initialized
INFO - 2020-07-07 11:56:35 --> Language Class Initialized
INFO - 2020-07-07 11:56:35 --> Config Class Initialized
INFO - 2020-07-07 11:56:35 --> Loader Class Initialized
INFO - 2020-07-07 11:56:35 --> Helper loaded: url_helper
INFO - 2020-07-07 11:56:35 --> Helper loaded: main_helper
INFO - 2020-07-07 11:56:35 --> Database Driver Class Initialized
DEBUG - 2020-07-07 11:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 11:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 11:56:35 --> Controller Class Initialized
INFO - 2020-07-07 11:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 11:56:35 --> Pagination Class Initialized
ERROR - 2020-07-07 11:56:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 11:56:35 --> Helper loaded: file_helper
DEBUG - 2020-07-07 11:56:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 11:56:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 11:56:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 11:56:35 --> Encryption Class Initialized
INFO - 2020-07-07 11:56:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 11:56:36 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 11:56:36 --> Final output sent to browser
DEBUG - 2020-07-07 11:56:36 --> Total execution time: 1.4884
INFO - 2020-07-07 13:33:32 --> Config Class Initialized
INFO - 2020-07-07 13:33:32 --> Hooks Class Initialized
DEBUG - 2020-07-07 13:33:32 --> UTF-8 Support Enabled
INFO - 2020-07-07 13:33:32 --> Utf8 Class Initialized
INFO - 2020-07-07 13:33:32 --> URI Class Initialized
INFO - 2020-07-07 13:33:32 --> Router Class Initialized
INFO - 2020-07-07 13:33:32 --> Output Class Initialized
INFO - 2020-07-07 13:33:32 --> Security Class Initialized
DEBUG - 2020-07-07 13:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 13:33:32 --> Input Class Initialized
INFO - 2020-07-07 13:33:32 --> Language Class Initialized
INFO - 2020-07-07 13:33:32 --> Language Class Initialized
INFO - 2020-07-07 13:33:32 --> Config Class Initialized
INFO - 2020-07-07 13:33:32 --> Loader Class Initialized
INFO - 2020-07-07 13:33:32 --> Helper loaded: url_helper
INFO - 2020-07-07 13:33:32 --> Helper loaded: main_helper
INFO - 2020-07-07 13:33:32 --> Database Driver Class Initialized
DEBUG - 2020-07-07 13:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 13:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 13:33:32 --> Controller Class Initialized
DEBUG - 2020-07-07 13:33:32 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-07 13:33:32 --> Final output sent to browser
DEBUG - 2020-07-07 13:33:32 --> Total execution time: 0.0038
INFO - 2020-07-07 13:33:34 --> Config Class Initialized
INFO - 2020-07-07 13:33:34 --> Hooks Class Initialized
DEBUG - 2020-07-07 13:33:34 --> UTF-8 Support Enabled
INFO - 2020-07-07 13:33:34 --> Utf8 Class Initialized
INFO - 2020-07-07 13:33:34 --> URI Class Initialized
INFO - 2020-07-07 13:33:34 --> Router Class Initialized
INFO - 2020-07-07 13:33:34 --> Output Class Initialized
INFO - 2020-07-07 13:33:34 --> Security Class Initialized
DEBUG - 2020-07-07 13:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 13:33:34 --> Input Class Initialized
INFO - 2020-07-07 13:33:34 --> Language Class Initialized
INFO - 2020-07-07 13:33:34 --> Language Class Initialized
INFO - 2020-07-07 13:33:34 --> Config Class Initialized
INFO - 2020-07-07 13:33:34 --> Loader Class Initialized
INFO - 2020-07-07 13:33:34 --> Helper loaded: url_helper
INFO - 2020-07-07 13:33:34 --> Helper loaded: main_helper
INFO - 2020-07-07 13:33:34 --> Database Driver Class Initialized
DEBUG - 2020-07-07 13:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 13:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 13:33:34 --> Controller Class Initialized
INFO - 2020-07-07 13:33:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 13:33:34 --> Pagination Class Initialized
ERROR - 2020-07-07 13:33:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 13:33:34 --> Helper loaded: file_helper
DEBUG - 2020-07-07 13:33:34 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 13:33:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 13:33:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 13:33:34 --> Encryption Class Initialized
INFO - 2020-07-07 13:33:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 13:33:34 --> Severity: Notice --> Trying to get property 'message' of non-object /var/www/journal/application/modules/landing/controllers/Search.php 98
ERROR - 2020-07-07 13:33:34 --> Severity: Notice --> Trying to get property 'total-results' of non-object /var/www/journal/application/modules/landing/controllers/Search.php 98
ERROR - 2020-07-07 13:33:34 --> Severity: Notice --> Trying to get property 'message' of non-object /var/www/journal/application/modules/landing/controllers/Search.php 99
ERROR - 2020-07-07 13:33:34 --> Severity: Notice --> Trying to get property 'items' of non-object /var/www/journal/application/modules/landing/controllers/Search.php 99
ERROR - 2020-07-07 13:33:34 --> Severity: error --> Exception: Argument 2 passed to ConvertResponse::convert() must be of the type array, null given, called in /var/www/journal/application/modules/landing/controllers/Search.php on line 99 /var/www/journal/application/libraries/ConvertResponse.php 13
INFO - 2020-07-07 13:34:04 --> Config Class Initialized
INFO - 2020-07-07 13:34:04 --> Hooks Class Initialized
DEBUG - 2020-07-07 13:34:04 --> UTF-8 Support Enabled
INFO - 2020-07-07 13:34:04 --> Utf8 Class Initialized
INFO - 2020-07-07 13:34:04 --> URI Class Initialized
INFO - 2020-07-07 13:34:04 --> Router Class Initialized
INFO - 2020-07-07 13:34:04 --> Output Class Initialized
INFO - 2020-07-07 13:34:04 --> Security Class Initialized
DEBUG - 2020-07-07 13:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 13:34:04 --> Input Class Initialized
INFO - 2020-07-07 13:34:04 --> Language Class Initialized
INFO - 2020-07-07 13:34:04 --> Language Class Initialized
INFO - 2020-07-07 13:34:04 --> Config Class Initialized
INFO - 2020-07-07 13:34:04 --> Loader Class Initialized
INFO - 2020-07-07 13:34:04 --> Helper loaded: url_helper
INFO - 2020-07-07 13:34:04 --> Helper loaded: main_helper
INFO - 2020-07-07 13:34:04 --> Database Driver Class Initialized
DEBUG - 2020-07-07 13:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 13:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 13:34:04 --> Controller Class Initialized
DEBUG - 2020-07-07 13:34:04 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-07 13:34:04 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 13:34:04 --> Final output sent to browser
DEBUG - 2020-07-07 13:34:04 --> Total execution time: 0.0080
INFO - 2020-07-07 13:34:05 --> Config Class Initialized
INFO - 2020-07-07 13:34:05 --> Hooks Class Initialized
DEBUG - 2020-07-07 13:34:05 --> UTF-8 Support Enabled
INFO - 2020-07-07 13:34:05 --> Utf8 Class Initialized
INFO - 2020-07-07 13:34:05 --> URI Class Initialized
INFO - 2020-07-07 13:34:05 --> Router Class Initialized
INFO - 2020-07-07 13:34:05 --> Output Class Initialized
INFO - 2020-07-07 13:34:05 --> Security Class Initialized
DEBUG - 2020-07-07 13:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 13:34:05 --> Input Class Initialized
INFO - 2020-07-07 13:34:05 --> Language Class Initialized
INFO - 2020-07-07 13:34:05 --> Language Class Initialized
INFO - 2020-07-07 13:34:05 --> Config Class Initialized
INFO - 2020-07-07 13:34:05 --> Loader Class Initialized
INFO - 2020-07-07 13:34:05 --> Helper loaded: url_helper
INFO - 2020-07-07 13:34:05 --> Helper loaded: main_helper
INFO - 2020-07-07 13:34:05 --> Database Driver Class Initialized
DEBUG - 2020-07-07 13:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 13:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 13:34:05 --> Controller Class Initialized
INFO - 2020-07-07 13:34:05 --> Final output sent to browser
DEBUG - 2020-07-07 13:34:05 --> Total execution time: 0.0180
INFO - 2020-07-07 15:54:49 --> Config Class Initialized
INFO - 2020-07-07 15:54:49 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:54:49 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:54:49 --> Utf8 Class Initialized
INFO - 2020-07-07 15:54:49 --> URI Class Initialized
INFO - 2020-07-07 15:54:49 --> Router Class Initialized
INFO - 2020-07-07 15:54:49 --> Output Class Initialized
INFO - 2020-07-07 15:54:49 --> Security Class Initialized
DEBUG - 2020-07-07 15:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:54:49 --> Input Class Initialized
INFO - 2020-07-07 15:54:49 --> Language Class Initialized
INFO - 2020-07-07 15:54:49 --> Language Class Initialized
INFO - 2020-07-07 15:54:49 --> Config Class Initialized
INFO - 2020-07-07 15:54:49 --> Loader Class Initialized
INFO - 2020-07-07 15:54:49 --> Helper loaded: url_helper
INFO - 2020-07-07 15:54:49 --> Helper loaded: main_helper
INFO - 2020-07-07 15:54:49 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:54:49 --> Controller Class Initialized
DEBUG - 2020-07-07 15:54:49 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-07 15:54:49 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 15:54:49 --> Final output sent to browser
DEBUG - 2020-07-07 15:54:49 --> Total execution time: 0.0059
INFO - 2020-07-07 15:54:49 --> Config Class Initialized
INFO - 2020-07-07 15:54:49 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:54:49 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:54:49 --> Utf8 Class Initialized
INFO - 2020-07-07 15:54:49 --> URI Class Initialized
INFO - 2020-07-07 15:54:49 --> Router Class Initialized
INFO - 2020-07-07 15:54:49 --> Output Class Initialized
INFO - 2020-07-07 15:54:49 --> Security Class Initialized
DEBUG - 2020-07-07 15:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:54:49 --> Input Class Initialized
INFO - 2020-07-07 15:54:49 --> Language Class Initialized
INFO - 2020-07-07 15:54:49 --> Language Class Initialized
INFO - 2020-07-07 15:54:49 --> Config Class Initialized
INFO - 2020-07-07 15:54:49 --> Loader Class Initialized
INFO - 2020-07-07 15:54:49 --> Helper loaded: url_helper
INFO - 2020-07-07 15:54:49 --> Helper loaded: main_helper
INFO - 2020-07-07 15:54:49 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:54:49 --> Controller Class Initialized
INFO - 2020-07-07 15:54:49 --> Final output sent to browser
DEBUG - 2020-07-07 15:54:49 --> Total execution time: 0.0043
INFO - 2020-07-07 15:54:59 --> Config Class Initialized
INFO - 2020-07-07 15:54:59 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:54:59 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:54:59 --> Utf8 Class Initialized
INFO - 2020-07-07 15:54:59 --> URI Class Initialized
INFO - 2020-07-07 15:54:59 --> Router Class Initialized
INFO - 2020-07-07 15:54:59 --> Output Class Initialized
INFO - 2020-07-07 15:54:59 --> Security Class Initialized
DEBUG - 2020-07-07 15:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:54:59 --> Input Class Initialized
INFO - 2020-07-07 15:54:59 --> Language Class Initialized
INFO - 2020-07-07 15:54:59 --> Language Class Initialized
INFO - 2020-07-07 15:54:59 --> Config Class Initialized
INFO - 2020-07-07 15:54:59 --> Loader Class Initialized
INFO - 2020-07-07 15:54:59 --> Helper loaded: url_helper
INFO - 2020-07-07 15:54:59 --> Helper loaded: main_helper
INFO - 2020-07-07 15:54:59 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:54:59 --> Controller Class Initialized
DEBUG - 2020-07-07 15:54:59 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-07 15:54:59 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 15:54:59 --> Final output sent to browser
DEBUG - 2020-07-07 15:54:59 --> Total execution time: 0.0041
INFO - 2020-07-07 15:55:00 --> Config Class Initialized
INFO - 2020-07-07 15:55:00 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:55:00 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:55:00 --> Utf8 Class Initialized
INFO - 2020-07-07 15:55:00 --> URI Class Initialized
INFO - 2020-07-07 15:55:00 --> Router Class Initialized
INFO - 2020-07-07 15:55:00 --> Output Class Initialized
INFO - 2020-07-07 15:55:00 --> Security Class Initialized
DEBUG - 2020-07-07 15:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:55:00 --> Input Class Initialized
INFO - 2020-07-07 15:55:00 --> Language Class Initialized
INFO - 2020-07-07 15:55:00 --> Language Class Initialized
INFO - 2020-07-07 15:55:00 --> Config Class Initialized
INFO - 2020-07-07 15:55:00 --> Loader Class Initialized
INFO - 2020-07-07 15:55:00 --> Helper loaded: url_helper
INFO - 2020-07-07 15:55:00 --> Helper loaded: main_helper
INFO - 2020-07-07 15:55:00 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:55:00 --> Controller Class Initialized
INFO - 2020-07-07 15:55:00 --> Final output sent to browser
DEBUG - 2020-07-07 15:55:00 --> Total execution time: 0.0063
INFO - 2020-07-07 15:55:17 --> Config Class Initialized
INFO - 2020-07-07 15:55:17 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:55:17 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:55:17 --> Utf8 Class Initialized
INFO - 2020-07-07 15:55:17 --> URI Class Initialized
DEBUG - 2020-07-07 15:55:17 --> No URI present. Default controller set.
INFO - 2020-07-07 15:55:17 --> Router Class Initialized
INFO - 2020-07-07 15:55:17 --> Output Class Initialized
INFO - 2020-07-07 15:55:17 --> Security Class Initialized
DEBUG - 2020-07-07 15:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:55:17 --> Input Class Initialized
INFO - 2020-07-07 15:55:17 --> Language Class Initialized
INFO - 2020-07-07 15:55:17 --> Language Class Initialized
INFO - 2020-07-07 15:55:17 --> Config Class Initialized
INFO - 2020-07-07 15:55:17 --> Loader Class Initialized
INFO - 2020-07-07 15:55:17 --> Helper loaded: url_helper
INFO - 2020-07-07 15:55:17 --> Helper loaded: main_helper
INFO - 2020-07-07 15:55:17 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:55:17 --> Controller Class Initialized
DEBUG - 2020-07-07 15:55:17 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-07 15:55:17 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 15:55:17 --> Final output sent to browser
DEBUG - 2020-07-07 15:55:17 --> Total execution time: 0.0045
INFO - 2020-07-07 15:55:35 --> Config Class Initialized
INFO - 2020-07-07 15:55:35 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:55:35 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:55:35 --> Utf8 Class Initialized
INFO - 2020-07-07 15:55:35 --> URI Class Initialized
INFO - 2020-07-07 15:55:35 --> Router Class Initialized
INFO - 2020-07-07 15:55:35 --> Output Class Initialized
INFO - 2020-07-07 15:55:35 --> Security Class Initialized
DEBUG - 2020-07-07 15:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:55:35 --> Input Class Initialized
INFO - 2020-07-07 15:55:35 --> Language Class Initialized
INFO - 2020-07-07 15:55:35 --> Language Class Initialized
INFO - 2020-07-07 15:55:35 --> Config Class Initialized
INFO - 2020-07-07 15:55:35 --> Loader Class Initialized
INFO - 2020-07-07 15:55:35 --> Helper loaded: url_helper
INFO - 2020-07-07 15:55:35 --> Helper loaded: main_helper
INFO - 2020-07-07 15:55:35 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:55:35 --> Controller Class Initialized
INFO - 2020-07-07 15:55:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:55:35 --> Pagination Class Initialized
ERROR - 2020-07-07 15:55:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:55:35 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:55:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:55:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:55:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:55:35 --> Encryption Class Initialized
INFO - 2020-07-07 15:55:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:55:37 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-07 15:55:37 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 15:55:37 --> Final output sent to browser
DEBUG - 2020-07-07 15:55:37 --> Total execution time: 2.0383
INFO - 2020-07-07 15:55:43 --> Config Class Initialized
INFO - 2020-07-07 15:55:43 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:55:43 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:55:43 --> Utf8 Class Initialized
INFO - 2020-07-07 15:55:43 --> URI Class Initialized
INFO - 2020-07-07 15:55:43 --> Router Class Initialized
INFO - 2020-07-07 15:55:43 --> Output Class Initialized
INFO - 2020-07-07 15:55:43 --> Security Class Initialized
DEBUG - 2020-07-07 15:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:55:43 --> Input Class Initialized
INFO - 2020-07-07 15:55:43 --> Language Class Initialized
INFO - 2020-07-07 15:55:43 --> Language Class Initialized
INFO - 2020-07-07 15:55:43 --> Config Class Initialized
INFO - 2020-07-07 15:55:43 --> Loader Class Initialized
INFO - 2020-07-07 15:55:43 --> Helper loaded: url_helper
INFO - 2020-07-07 15:55:43 --> Helper loaded: main_helper
INFO - 2020-07-07 15:55:43 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:55:43 --> Controller Class Initialized
INFO - 2020-07-07 15:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:55:43 --> Pagination Class Initialized
ERROR - 2020-07-07 15:55:43 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:55:43 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:55:43 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:55:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:55:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:55:43 --> Encryption Class Initialized
INFO - 2020-07-07 15:55:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:55:45 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 15:55:45 --> Final output sent to browser
DEBUG - 2020-07-07 15:55:45 --> Total execution time: 1.6497
INFO - 2020-07-07 15:55:51 --> Config Class Initialized
INFO - 2020-07-07 15:55:51 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:55:51 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:55:51 --> Utf8 Class Initialized
INFO - 2020-07-07 15:55:51 --> URI Class Initialized
INFO - 2020-07-07 15:55:51 --> Router Class Initialized
INFO - 2020-07-07 15:55:51 --> Output Class Initialized
INFO - 2020-07-07 15:55:51 --> Security Class Initialized
DEBUG - 2020-07-07 15:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:55:51 --> Input Class Initialized
INFO - 2020-07-07 15:55:51 --> Language Class Initialized
INFO - 2020-07-07 15:55:51 --> Language Class Initialized
INFO - 2020-07-07 15:55:51 --> Config Class Initialized
INFO - 2020-07-07 15:55:51 --> Loader Class Initialized
INFO - 2020-07-07 15:55:51 --> Helper loaded: url_helper
INFO - 2020-07-07 15:55:51 --> Helper loaded: main_helper
INFO - 2020-07-07 15:55:51 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:55:51 --> Controller Class Initialized
INFO - 2020-07-07 15:55:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:55:51 --> Pagination Class Initialized
ERROR - 2020-07-07 15:55:51 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:55:51 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:55:51 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:55:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:55:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:55:51 --> Encryption Class Initialized
INFO - 2020-07-07 15:55:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:55:53 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 15:55:53 --> Final output sent to browser
DEBUG - 2020-07-07 15:55:53 --> Total execution time: 2.0033
INFO - 2020-07-07 15:56:26 --> Config Class Initialized
INFO - 2020-07-07 15:56:26 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:56:26 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:56:26 --> Utf8 Class Initialized
INFO - 2020-07-07 15:56:26 --> URI Class Initialized
INFO - 2020-07-07 15:56:26 --> Router Class Initialized
INFO - 2020-07-07 15:56:26 --> Output Class Initialized
INFO - 2020-07-07 15:56:26 --> Security Class Initialized
DEBUG - 2020-07-07 15:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:56:26 --> Input Class Initialized
INFO - 2020-07-07 15:56:26 --> Language Class Initialized
INFO - 2020-07-07 15:56:26 --> Language Class Initialized
INFO - 2020-07-07 15:56:26 --> Config Class Initialized
INFO - 2020-07-07 15:56:26 --> Loader Class Initialized
INFO - 2020-07-07 15:56:26 --> Helper loaded: url_helper
INFO - 2020-07-07 15:56:26 --> Helper loaded: main_helper
INFO - 2020-07-07 15:56:26 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:56:26 --> Controller Class Initialized
INFO - 2020-07-07 15:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:56:26 --> Pagination Class Initialized
ERROR - 2020-07-07 15:56:26 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:56:26 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:56:26 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:56:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:56:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:56:26 --> Encryption Class Initialized
INFO - 2020-07-07 15:56:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:56:28 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 15:56:28 --> Final output sent to browser
DEBUG - 2020-07-07 15:56:28 --> Total execution time: 1.8864
INFO - 2020-07-07 15:56:38 --> Config Class Initialized
INFO - 2020-07-07 15:56:38 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:56:38 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:56:38 --> Utf8 Class Initialized
INFO - 2020-07-07 15:56:38 --> URI Class Initialized
INFO - 2020-07-07 15:56:38 --> Router Class Initialized
INFO - 2020-07-07 15:56:38 --> Output Class Initialized
INFO - 2020-07-07 15:56:38 --> Security Class Initialized
DEBUG - 2020-07-07 15:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:56:38 --> Input Class Initialized
INFO - 2020-07-07 15:56:38 --> Language Class Initialized
INFO - 2020-07-07 15:56:38 --> Language Class Initialized
INFO - 2020-07-07 15:56:38 --> Config Class Initialized
INFO - 2020-07-07 15:56:38 --> Loader Class Initialized
INFO - 2020-07-07 15:56:38 --> Helper loaded: url_helper
INFO - 2020-07-07 15:56:38 --> Helper loaded: main_helper
INFO - 2020-07-07 15:56:38 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:56:38 --> Controller Class Initialized
INFO - 2020-07-07 15:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:56:38 --> Pagination Class Initialized
ERROR - 2020-07-07 15:56:38 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:56:38 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:56:38 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:56:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:56:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:56:38 --> Encryption Class Initialized
INFO - 2020-07-07 15:56:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:56:39 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 15:56:39 --> Final output sent to browser
DEBUG - 2020-07-07 15:56:39 --> Total execution time: 1.1830
INFO - 2020-07-07 15:56:45 --> Config Class Initialized
INFO - 2020-07-07 15:56:45 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:56:45 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:56:45 --> Utf8 Class Initialized
INFO - 2020-07-07 15:56:45 --> URI Class Initialized
INFO - 2020-07-07 15:56:45 --> Router Class Initialized
INFO - 2020-07-07 15:56:45 --> Output Class Initialized
INFO - 2020-07-07 15:56:45 --> Security Class Initialized
DEBUG - 2020-07-07 15:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:56:45 --> Input Class Initialized
INFO - 2020-07-07 15:56:45 --> Language Class Initialized
INFO - 2020-07-07 15:56:45 --> Language Class Initialized
INFO - 2020-07-07 15:56:45 --> Config Class Initialized
INFO - 2020-07-07 15:56:45 --> Loader Class Initialized
INFO - 2020-07-07 15:56:45 --> Helper loaded: url_helper
INFO - 2020-07-07 15:56:45 --> Helper loaded: main_helper
INFO - 2020-07-07 15:56:45 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:56:45 --> Controller Class Initialized
INFO - 2020-07-07 15:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:56:45 --> Pagination Class Initialized
ERROR - 2020-07-07 15:56:45 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:56:45 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:56:45 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:56:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:56:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:56:45 --> Encryption Class Initialized
INFO - 2020-07-07 15:56:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:56:46 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 15:56:46 --> Final output sent to browser
DEBUG - 2020-07-07 15:56:46 --> Total execution time: 1.2772
INFO - 2020-07-07 15:57:14 --> Config Class Initialized
INFO - 2020-07-07 15:57:14 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:57:14 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:57:14 --> Utf8 Class Initialized
INFO - 2020-07-07 15:57:14 --> URI Class Initialized
INFO - 2020-07-07 15:57:14 --> Router Class Initialized
INFO - 2020-07-07 15:57:14 --> Output Class Initialized
INFO - 2020-07-07 15:57:14 --> Security Class Initialized
DEBUG - 2020-07-07 15:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:57:14 --> Input Class Initialized
INFO - 2020-07-07 15:57:14 --> Language Class Initialized
INFO - 2020-07-07 15:57:14 --> Language Class Initialized
INFO - 2020-07-07 15:57:14 --> Config Class Initialized
INFO - 2020-07-07 15:57:14 --> Loader Class Initialized
INFO - 2020-07-07 15:57:14 --> Helper loaded: url_helper
INFO - 2020-07-07 15:57:14 --> Helper loaded: main_helper
INFO - 2020-07-07 15:57:14 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:57:14 --> Controller Class Initialized
INFO - 2020-07-07 15:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:57:14 --> Pagination Class Initialized
ERROR - 2020-07-07 15:57:14 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:57:14 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:57:14 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:57:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:57:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:57:14 --> Encryption Class Initialized
INFO - 2020-07-07 15:57:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:57:15 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 15:57:15 --> Final output sent to browser
DEBUG - 2020-07-07 15:57:15 --> Total execution time: 1.1969
INFO - 2020-07-07 15:57:17 --> Config Class Initialized
INFO - 2020-07-07 15:57:17 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:57:17 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:57:17 --> Utf8 Class Initialized
INFO - 2020-07-07 15:57:17 --> URI Class Initialized
INFO - 2020-07-07 15:57:17 --> Router Class Initialized
INFO - 2020-07-07 15:57:17 --> Output Class Initialized
INFO - 2020-07-07 15:57:17 --> Security Class Initialized
DEBUG - 2020-07-07 15:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:57:17 --> Input Class Initialized
INFO - 2020-07-07 15:57:17 --> Language Class Initialized
INFO - 2020-07-07 15:57:17 --> Language Class Initialized
INFO - 2020-07-07 15:57:17 --> Config Class Initialized
INFO - 2020-07-07 15:57:17 --> Loader Class Initialized
INFO - 2020-07-07 15:57:17 --> Helper loaded: url_helper
INFO - 2020-07-07 15:57:17 --> Helper loaded: main_helper
INFO - 2020-07-07 15:57:17 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:57:17 --> Controller Class Initialized
INFO - 2020-07-07 15:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:57:17 --> Pagination Class Initialized
ERROR - 2020-07-07 15:57:17 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:57:17 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:57:17 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:57:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:57:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:57:17 --> Encryption Class Initialized
INFO - 2020-07-07 15:57:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:57:19 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-07 15:57:19 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 15:57:19 --> Final output sent to browser
DEBUG - 2020-07-07 15:57:19 --> Total execution time: 1.5485
INFO - 2020-07-07 15:57:30 --> Config Class Initialized
INFO - 2020-07-07 15:57:30 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:57:30 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:57:30 --> Utf8 Class Initialized
INFO - 2020-07-07 15:57:30 --> URI Class Initialized
INFO - 2020-07-07 15:57:30 --> Router Class Initialized
INFO - 2020-07-07 15:57:30 --> Output Class Initialized
INFO - 2020-07-07 15:57:30 --> Security Class Initialized
DEBUG - 2020-07-07 15:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:57:30 --> Input Class Initialized
INFO - 2020-07-07 15:57:30 --> Language Class Initialized
INFO - 2020-07-07 15:57:30 --> Language Class Initialized
INFO - 2020-07-07 15:57:30 --> Config Class Initialized
INFO - 2020-07-07 15:57:30 --> Loader Class Initialized
INFO - 2020-07-07 15:57:30 --> Helper loaded: url_helper
INFO - 2020-07-07 15:57:30 --> Helper loaded: main_helper
INFO - 2020-07-07 15:57:30 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:57:30 --> Controller Class Initialized
INFO - 2020-07-07 15:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:57:30 --> Pagination Class Initialized
ERROR - 2020-07-07 15:57:30 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:57:30 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:57:30 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:57:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:57:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:57:30 --> Encryption Class Initialized
INFO - 2020-07-07 15:57:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:57:32 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 15:57:32 --> Final output sent to browser
DEBUG - 2020-07-07 15:57:32 --> Total execution time: 1.3282
INFO - 2020-07-07 15:57:39 --> Config Class Initialized
INFO - 2020-07-07 15:57:39 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:57:39 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:57:39 --> Utf8 Class Initialized
INFO - 2020-07-07 15:57:39 --> URI Class Initialized
INFO - 2020-07-07 15:57:39 --> Router Class Initialized
INFO - 2020-07-07 15:57:39 --> Output Class Initialized
INFO - 2020-07-07 15:57:39 --> Security Class Initialized
DEBUG - 2020-07-07 15:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:57:39 --> Input Class Initialized
INFO - 2020-07-07 15:57:39 --> Language Class Initialized
INFO - 2020-07-07 15:57:39 --> Language Class Initialized
INFO - 2020-07-07 15:57:39 --> Config Class Initialized
INFO - 2020-07-07 15:57:39 --> Loader Class Initialized
INFO - 2020-07-07 15:57:39 --> Helper loaded: url_helper
INFO - 2020-07-07 15:57:39 --> Helper loaded: main_helper
INFO - 2020-07-07 15:57:39 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:57:39 --> Controller Class Initialized
INFO - 2020-07-07 15:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:57:39 --> Pagination Class Initialized
ERROR - 2020-07-07 15:57:39 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:57:39 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:57:39 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:57:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:57:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:57:39 --> Encryption Class Initialized
INFO - 2020-07-07 15:57:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:57:40 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 15:57:40 --> Final output sent to browser
DEBUG - 2020-07-07 15:57:40 --> Total execution time: 1.2994
INFO - 2020-07-07 15:57:51 --> Config Class Initialized
INFO - 2020-07-07 15:57:51 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:57:51 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:57:51 --> Utf8 Class Initialized
INFO - 2020-07-07 15:57:51 --> URI Class Initialized
INFO - 2020-07-07 15:57:51 --> Router Class Initialized
INFO - 2020-07-07 15:57:51 --> Output Class Initialized
INFO - 2020-07-07 15:57:51 --> Security Class Initialized
DEBUG - 2020-07-07 15:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:57:51 --> Input Class Initialized
INFO - 2020-07-07 15:57:51 --> Language Class Initialized
INFO - 2020-07-07 15:57:51 --> Language Class Initialized
INFO - 2020-07-07 15:57:51 --> Config Class Initialized
INFO - 2020-07-07 15:57:51 --> Loader Class Initialized
INFO - 2020-07-07 15:57:51 --> Helper loaded: url_helper
INFO - 2020-07-07 15:57:51 --> Helper loaded: main_helper
INFO - 2020-07-07 15:57:51 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:57:51 --> Controller Class Initialized
INFO - 2020-07-07 15:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:57:51 --> Pagination Class Initialized
ERROR - 2020-07-07 15:57:51 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:57:51 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:57:51 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:57:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:57:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:57:51 --> Encryption Class Initialized
INFO - 2020-07-07 15:57:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:57:52 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 15:57:52 --> Final output sent to browser
DEBUG - 2020-07-07 15:57:52 --> Total execution time: 1.2561
INFO - 2020-07-07 15:58:01 --> Config Class Initialized
INFO - 2020-07-07 15:58:01 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:58:01 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:58:01 --> Utf8 Class Initialized
INFO - 2020-07-07 15:58:01 --> URI Class Initialized
INFO - 2020-07-07 15:58:01 --> Router Class Initialized
INFO - 2020-07-07 15:58:01 --> Output Class Initialized
INFO - 2020-07-07 15:58:01 --> Security Class Initialized
DEBUG - 2020-07-07 15:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:58:01 --> Input Class Initialized
INFO - 2020-07-07 15:58:01 --> Language Class Initialized
INFO - 2020-07-07 15:58:01 --> Language Class Initialized
INFO - 2020-07-07 15:58:01 --> Config Class Initialized
INFO - 2020-07-07 15:58:01 --> Loader Class Initialized
INFO - 2020-07-07 15:58:01 --> Helper loaded: url_helper
INFO - 2020-07-07 15:58:01 --> Helper loaded: main_helper
INFO - 2020-07-07 15:58:01 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:58:01 --> Controller Class Initialized
INFO - 2020-07-07 15:58:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:58:01 --> Pagination Class Initialized
ERROR - 2020-07-07 15:58:01 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:58:01 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:58:01 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:58:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:58:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:58:01 --> Encryption Class Initialized
INFO - 2020-07-07 15:58:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:58:02 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-07 15:58:02 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 15:58:02 --> Final output sent to browser
DEBUG - 2020-07-07 15:58:02 --> Total execution time: 1.4195
INFO - 2020-07-07 15:58:12 --> Config Class Initialized
INFO - 2020-07-07 15:58:12 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:58:12 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:58:12 --> Utf8 Class Initialized
INFO - 2020-07-07 15:58:12 --> URI Class Initialized
INFO - 2020-07-07 15:58:12 --> Router Class Initialized
INFO - 2020-07-07 15:58:12 --> Output Class Initialized
INFO - 2020-07-07 15:58:12 --> Security Class Initialized
DEBUG - 2020-07-07 15:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:58:12 --> Input Class Initialized
INFO - 2020-07-07 15:58:12 --> Language Class Initialized
INFO - 2020-07-07 15:58:12 --> Language Class Initialized
INFO - 2020-07-07 15:58:12 --> Config Class Initialized
INFO - 2020-07-07 15:58:12 --> Loader Class Initialized
INFO - 2020-07-07 15:58:12 --> Helper loaded: url_helper
INFO - 2020-07-07 15:58:12 --> Helper loaded: main_helper
INFO - 2020-07-07 15:58:12 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:58:12 --> Controller Class Initialized
INFO - 2020-07-07 15:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:58:12 --> Pagination Class Initialized
ERROR - 2020-07-07 15:58:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:58:12 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:58:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:58:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:58:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:58:12 --> Encryption Class Initialized
INFO - 2020-07-07 15:58:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:58:14 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 15:58:14 --> Final output sent to browser
DEBUG - 2020-07-07 15:58:14 --> Total execution time: 2.0959
INFO - 2020-07-07 15:58:20 --> Config Class Initialized
INFO - 2020-07-07 15:58:20 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:58:20 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:58:20 --> Utf8 Class Initialized
INFO - 2020-07-07 15:58:20 --> URI Class Initialized
INFO - 2020-07-07 15:58:20 --> Router Class Initialized
INFO - 2020-07-07 15:58:20 --> Output Class Initialized
INFO - 2020-07-07 15:58:20 --> Security Class Initialized
DEBUG - 2020-07-07 15:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:58:20 --> Input Class Initialized
INFO - 2020-07-07 15:58:20 --> Language Class Initialized
INFO - 2020-07-07 15:58:20 --> Language Class Initialized
INFO - 2020-07-07 15:58:20 --> Config Class Initialized
INFO - 2020-07-07 15:58:20 --> Loader Class Initialized
INFO - 2020-07-07 15:58:20 --> Helper loaded: url_helper
INFO - 2020-07-07 15:58:20 --> Helper loaded: main_helper
INFO - 2020-07-07 15:58:20 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:58:20 --> Controller Class Initialized
INFO - 2020-07-07 15:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:58:20 --> Pagination Class Initialized
ERROR - 2020-07-07 15:58:20 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:58:20 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:58:20 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:58:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:58:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:58:20 --> Encryption Class Initialized
INFO - 2020-07-07 15:58:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:58:21 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 15:58:21 --> Final output sent to browser
DEBUG - 2020-07-07 15:58:21 --> Total execution time: 1.1755
INFO - 2020-07-07 15:59:35 --> Config Class Initialized
INFO - 2020-07-07 15:59:35 --> Hooks Class Initialized
DEBUG - 2020-07-07 15:59:35 --> UTF-8 Support Enabled
INFO - 2020-07-07 15:59:35 --> Utf8 Class Initialized
INFO - 2020-07-07 15:59:35 --> URI Class Initialized
INFO - 2020-07-07 15:59:35 --> Router Class Initialized
INFO - 2020-07-07 15:59:35 --> Output Class Initialized
INFO - 2020-07-07 15:59:35 --> Security Class Initialized
DEBUG - 2020-07-07 15:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 15:59:35 --> Input Class Initialized
INFO - 2020-07-07 15:59:35 --> Language Class Initialized
INFO - 2020-07-07 15:59:35 --> Language Class Initialized
INFO - 2020-07-07 15:59:35 --> Config Class Initialized
INFO - 2020-07-07 15:59:35 --> Loader Class Initialized
INFO - 2020-07-07 15:59:35 --> Helper loaded: url_helper
INFO - 2020-07-07 15:59:35 --> Helper loaded: main_helper
INFO - 2020-07-07 15:59:35 --> Database Driver Class Initialized
DEBUG - 2020-07-07 15:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 15:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 15:59:35 --> Controller Class Initialized
INFO - 2020-07-07 15:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 15:59:35 --> Pagination Class Initialized
ERROR - 2020-07-07 15:59:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 15:59:35 --> Helper loaded: file_helper
DEBUG - 2020-07-07 15:59:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 15:59:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 15:59:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 15:59:35 --> Encryption Class Initialized
INFO - 2020-07-07 15:59:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 15:59:37 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-07 15:59:37 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 15:59:37 --> Final output sent to browser
DEBUG - 2020-07-07 15:59:37 --> Total execution time: 2.3913
INFO - 2020-07-07 16:00:50 --> Config Class Initialized
INFO - 2020-07-07 16:00:50 --> Hooks Class Initialized
DEBUG - 2020-07-07 16:00:50 --> UTF-8 Support Enabled
INFO - 2020-07-07 16:00:50 --> Utf8 Class Initialized
INFO - 2020-07-07 16:00:50 --> URI Class Initialized
INFO - 2020-07-07 16:00:50 --> Router Class Initialized
INFO - 2020-07-07 16:00:50 --> Output Class Initialized
INFO - 2020-07-07 16:00:50 --> Security Class Initialized
DEBUG - 2020-07-07 16:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 16:00:50 --> Input Class Initialized
INFO - 2020-07-07 16:00:50 --> Language Class Initialized
INFO - 2020-07-07 16:00:50 --> Language Class Initialized
INFO - 2020-07-07 16:00:50 --> Config Class Initialized
INFO - 2020-07-07 16:00:50 --> Loader Class Initialized
INFO - 2020-07-07 16:00:50 --> Helper loaded: url_helper
INFO - 2020-07-07 16:00:50 --> Helper loaded: main_helper
INFO - 2020-07-07 16:00:50 --> Database Driver Class Initialized
DEBUG - 2020-07-07 16:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 16:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 16:00:50 --> Controller Class Initialized
INFO - 2020-07-07 16:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 16:00:50 --> Pagination Class Initialized
ERROR - 2020-07-07 16:00:50 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 16:00:50 --> Helper loaded: file_helper
DEBUG - 2020-07-07 16:00:50 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 16:00:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 16:00:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 16:00:50 --> Encryption Class Initialized
INFO - 2020-07-07 16:00:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 16:00:52 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-07 16:00:52 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 16:00:52 --> Final output sent to browser
DEBUG - 2020-07-07 16:00:52 --> Total execution time: 1.3914
INFO - 2020-07-07 16:01:05 --> Config Class Initialized
INFO - 2020-07-07 16:01:05 --> Hooks Class Initialized
DEBUG - 2020-07-07 16:01:05 --> UTF-8 Support Enabled
INFO - 2020-07-07 16:01:05 --> Utf8 Class Initialized
INFO - 2020-07-07 16:01:05 --> URI Class Initialized
INFO - 2020-07-07 16:01:05 --> Router Class Initialized
INFO - 2020-07-07 16:01:05 --> Output Class Initialized
INFO - 2020-07-07 16:01:05 --> Security Class Initialized
DEBUG - 2020-07-07 16:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 16:01:05 --> Input Class Initialized
INFO - 2020-07-07 16:01:05 --> Language Class Initialized
INFO - 2020-07-07 16:01:05 --> Language Class Initialized
INFO - 2020-07-07 16:01:05 --> Config Class Initialized
INFO - 2020-07-07 16:01:05 --> Loader Class Initialized
INFO - 2020-07-07 16:01:05 --> Helper loaded: url_helper
INFO - 2020-07-07 16:01:05 --> Helper loaded: main_helper
INFO - 2020-07-07 16:01:05 --> Database Driver Class Initialized
DEBUG - 2020-07-07 16:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 16:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 16:01:05 --> Controller Class Initialized
INFO - 2020-07-07 16:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 16:01:05 --> Pagination Class Initialized
ERROR - 2020-07-07 16:01:05 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 16:01:05 --> Helper loaded: file_helper
DEBUG - 2020-07-07 16:01:05 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 16:01:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 16:01:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 16:01:05 --> Encryption Class Initialized
INFO - 2020-07-07 16:01:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 16:01:07 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 16:01:07 --> Final output sent to browser
DEBUG - 2020-07-07 16:01:07 --> Total execution time: 1.2993
INFO - 2020-07-07 16:01:21 --> Config Class Initialized
INFO - 2020-07-07 16:01:21 --> Hooks Class Initialized
DEBUG - 2020-07-07 16:01:21 --> UTF-8 Support Enabled
INFO - 2020-07-07 16:01:21 --> Utf8 Class Initialized
INFO - 2020-07-07 16:01:21 --> URI Class Initialized
INFO - 2020-07-07 16:01:21 --> Router Class Initialized
INFO - 2020-07-07 16:01:21 --> Output Class Initialized
INFO - 2020-07-07 16:01:21 --> Security Class Initialized
DEBUG - 2020-07-07 16:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 16:01:21 --> Input Class Initialized
INFO - 2020-07-07 16:01:21 --> Language Class Initialized
INFO - 2020-07-07 16:01:21 --> Language Class Initialized
INFO - 2020-07-07 16:01:21 --> Config Class Initialized
INFO - 2020-07-07 16:01:21 --> Loader Class Initialized
INFO - 2020-07-07 16:01:21 --> Helper loaded: url_helper
INFO - 2020-07-07 16:01:21 --> Helper loaded: main_helper
INFO - 2020-07-07 16:01:21 --> Database Driver Class Initialized
DEBUG - 2020-07-07 16:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 16:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 16:01:21 --> Controller Class Initialized
INFO - 2020-07-07 16:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 16:01:21 --> Pagination Class Initialized
ERROR - 2020-07-07 16:01:21 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 16:01:21 --> Helper loaded: file_helper
DEBUG - 2020-07-07 16:01:21 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 16:01:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 16:01:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 16:01:21 --> Encryption Class Initialized
INFO - 2020-07-07 16:01:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 16:01:23 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 16:01:23 --> Final output sent to browser
DEBUG - 2020-07-07 16:01:23 --> Total execution time: 1.3210
INFO - 2020-07-07 16:01:28 --> Config Class Initialized
INFO - 2020-07-07 16:01:28 --> Hooks Class Initialized
DEBUG - 2020-07-07 16:01:28 --> UTF-8 Support Enabled
INFO - 2020-07-07 16:01:28 --> Utf8 Class Initialized
INFO - 2020-07-07 16:01:28 --> URI Class Initialized
INFO - 2020-07-07 16:01:28 --> Router Class Initialized
INFO - 2020-07-07 16:01:28 --> Output Class Initialized
INFO - 2020-07-07 16:01:28 --> Security Class Initialized
DEBUG - 2020-07-07 16:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 16:01:28 --> Input Class Initialized
INFO - 2020-07-07 16:01:28 --> Language Class Initialized
INFO - 2020-07-07 16:01:28 --> Language Class Initialized
INFO - 2020-07-07 16:01:28 --> Config Class Initialized
INFO - 2020-07-07 16:01:28 --> Loader Class Initialized
INFO - 2020-07-07 16:01:28 --> Helper loaded: url_helper
INFO - 2020-07-07 16:01:28 --> Helper loaded: main_helper
INFO - 2020-07-07 16:01:28 --> Database Driver Class Initialized
DEBUG - 2020-07-07 16:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 16:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 16:01:28 --> Controller Class Initialized
INFO - 2020-07-07 16:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 16:01:28 --> Pagination Class Initialized
ERROR - 2020-07-07 16:01:28 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 16:01:28 --> Helper loaded: file_helper
DEBUG - 2020-07-07 16:01:28 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 16:01:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 16:01:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 16:01:28 --> Encryption Class Initialized
INFO - 2020-07-07 16:01:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-07 16:01:29 --> Severity: Warning --> DOMDocument::createElement(): unterminated entity reference         Francis /var/www/journal/application/modules/landing/views/xml_export_v.php 42
DEBUG - 2020-07-07 16:01:29 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 16:01:29 --> Final output sent to browser
DEBUG - 2020-07-07 16:01:29 --> Total execution time: 1.1758
INFO - 2020-07-07 16:03:12 --> Config Class Initialized
INFO - 2020-07-07 16:03:12 --> Hooks Class Initialized
DEBUG - 2020-07-07 16:03:12 --> UTF-8 Support Enabled
INFO - 2020-07-07 16:03:12 --> Utf8 Class Initialized
INFO - 2020-07-07 16:03:12 --> URI Class Initialized
INFO - 2020-07-07 16:03:12 --> Router Class Initialized
INFO - 2020-07-07 16:03:12 --> Output Class Initialized
INFO - 2020-07-07 16:03:12 --> Security Class Initialized
DEBUG - 2020-07-07 16:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 16:03:12 --> Input Class Initialized
INFO - 2020-07-07 16:03:12 --> Language Class Initialized
INFO - 2020-07-07 16:03:12 --> Language Class Initialized
INFO - 2020-07-07 16:03:12 --> Config Class Initialized
INFO - 2020-07-07 16:03:12 --> Loader Class Initialized
INFO - 2020-07-07 16:03:12 --> Helper loaded: url_helper
INFO - 2020-07-07 16:03:12 --> Helper loaded: main_helper
INFO - 2020-07-07 16:03:12 --> Database Driver Class Initialized
DEBUG - 2020-07-07 16:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 16:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 16:03:12 --> Controller Class Initialized
INFO - 2020-07-07 16:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 16:03:12 --> Pagination Class Initialized
ERROR - 2020-07-07 16:03:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 16:03:12 --> Helper loaded: file_helper
DEBUG - 2020-07-07 16:03:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 16:03:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 16:03:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 16:03:12 --> Encryption Class Initialized
INFO - 2020-07-07 16:03:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 16:03:13 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 16:03:13 --> Final output sent to browser
DEBUG - 2020-07-07 16:03:13 --> Total execution time: 1.2927
INFO - 2020-07-07 16:03:29 --> Config Class Initialized
INFO - 2020-07-07 16:03:29 --> Hooks Class Initialized
DEBUG - 2020-07-07 16:03:29 --> UTF-8 Support Enabled
INFO - 2020-07-07 16:03:29 --> Utf8 Class Initialized
INFO - 2020-07-07 16:03:29 --> URI Class Initialized
INFO - 2020-07-07 16:03:29 --> Router Class Initialized
INFO - 2020-07-07 16:03:29 --> Output Class Initialized
INFO - 2020-07-07 16:03:29 --> Security Class Initialized
DEBUG - 2020-07-07 16:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 16:03:29 --> Input Class Initialized
INFO - 2020-07-07 16:03:29 --> Language Class Initialized
INFO - 2020-07-07 16:03:29 --> Language Class Initialized
INFO - 2020-07-07 16:03:29 --> Config Class Initialized
INFO - 2020-07-07 16:03:29 --> Loader Class Initialized
INFO - 2020-07-07 16:03:29 --> Helper loaded: url_helper
INFO - 2020-07-07 16:03:29 --> Helper loaded: main_helper
INFO - 2020-07-07 16:03:29 --> Database Driver Class Initialized
DEBUG - 2020-07-07 16:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 16:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 16:03:29 --> Controller Class Initialized
INFO - 2020-07-07 16:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 16:03:29 --> Pagination Class Initialized
ERROR - 2020-07-07 16:03:29 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 16:03:29 --> Helper loaded: file_helper
DEBUG - 2020-07-07 16:03:29 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 16:03:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 16:03:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 16:03:29 --> Encryption Class Initialized
INFO - 2020-07-07 16:03:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 16:03:30 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 16:03:30 --> Final output sent to browser
DEBUG - 2020-07-07 16:03:30 --> Total execution time: 1.2149
INFO - 2020-07-07 16:03:39 --> Config Class Initialized
INFO - 2020-07-07 16:03:39 --> Hooks Class Initialized
DEBUG - 2020-07-07 16:03:39 --> UTF-8 Support Enabled
INFO - 2020-07-07 16:03:39 --> Utf8 Class Initialized
INFO - 2020-07-07 16:03:39 --> URI Class Initialized
INFO - 2020-07-07 16:03:39 --> Router Class Initialized
INFO - 2020-07-07 16:03:39 --> Output Class Initialized
INFO - 2020-07-07 16:03:39 --> Security Class Initialized
DEBUG - 2020-07-07 16:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 16:03:39 --> Input Class Initialized
INFO - 2020-07-07 16:03:39 --> Language Class Initialized
INFO - 2020-07-07 16:03:39 --> Language Class Initialized
INFO - 2020-07-07 16:03:39 --> Config Class Initialized
INFO - 2020-07-07 16:03:39 --> Loader Class Initialized
INFO - 2020-07-07 16:03:39 --> Helper loaded: url_helper
INFO - 2020-07-07 16:03:39 --> Helper loaded: main_helper
INFO - 2020-07-07 16:03:39 --> Database Driver Class Initialized
DEBUG - 2020-07-07 16:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 16:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 16:03:39 --> Controller Class Initialized
INFO - 2020-07-07 16:03:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 16:03:39 --> Pagination Class Initialized
ERROR - 2020-07-07 16:03:39 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 16:03:39 --> Helper loaded: file_helper
DEBUG - 2020-07-07 16:03:39 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 16:03:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 16:03:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 16:03:39 --> Encryption Class Initialized
INFO - 2020-07-07 16:03:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 16:03:40 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 16:03:40 --> Final output sent to browser
DEBUG - 2020-07-07 16:03:40 --> Total execution time: 1.2052
INFO - 2020-07-07 16:06:02 --> Config Class Initialized
INFO - 2020-07-07 16:06:02 --> Hooks Class Initialized
DEBUG - 2020-07-07 16:06:02 --> UTF-8 Support Enabled
INFO - 2020-07-07 16:06:02 --> Utf8 Class Initialized
INFO - 2020-07-07 16:06:02 --> URI Class Initialized
INFO - 2020-07-07 16:06:02 --> Router Class Initialized
INFO - 2020-07-07 16:06:02 --> Output Class Initialized
INFO - 2020-07-07 16:06:02 --> Security Class Initialized
DEBUG - 2020-07-07 16:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 16:06:02 --> Input Class Initialized
INFO - 2020-07-07 16:06:02 --> Language Class Initialized
INFO - 2020-07-07 16:06:02 --> Language Class Initialized
INFO - 2020-07-07 16:06:02 --> Config Class Initialized
INFO - 2020-07-07 16:06:02 --> Loader Class Initialized
INFO - 2020-07-07 16:06:02 --> Helper loaded: url_helper
INFO - 2020-07-07 16:06:02 --> Helper loaded: main_helper
INFO - 2020-07-07 16:06:02 --> Database Driver Class Initialized
DEBUG - 2020-07-07 16:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 16:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 16:06:02 --> Controller Class Initialized
INFO - 2020-07-07 16:06:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 16:06:02 --> Pagination Class Initialized
ERROR - 2020-07-07 16:06:02 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 16:06:02 --> Helper loaded: file_helper
DEBUG - 2020-07-07 16:06:02 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 16:06:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 16:06:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 16:06:02 --> Encryption Class Initialized
INFO - 2020-07-07 16:06:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 16:06:04 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 16:06:04 --> Final output sent to browser
DEBUG - 2020-07-07 16:06:04 --> Total execution time: 1.3874
INFO - 2020-07-07 16:06:35 --> Config Class Initialized
INFO - 2020-07-07 16:06:35 --> Hooks Class Initialized
DEBUG - 2020-07-07 16:06:35 --> UTF-8 Support Enabled
INFO - 2020-07-07 16:06:35 --> Utf8 Class Initialized
INFO - 2020-07-07 16:06:35 --> URI Class Initialized
INFO - 2020-07-07 16:06:35 --> Router Class Initialized
INFO - 2020-07-07 16:06:35 --> Output Class Initialized
INFO - 2020-07-07 16:06:35 --> Security Class Initialized
DEBUG - 2020-07-07 16:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 16:06:35 --> Input Class Initialized
INFO - 2020-07-07 16:06:35 --> Language Class Initialized
INFO - 2020-07-07 16:06:35 --> Language Class Initialized
INFO - 2020-07-07 16:06:35 --> Config Class Initialized
INFO - 2020-07-07 16:06:35 --> Loader Class Initialized
INFO - 2020-07-07 16:06:35 --> Helper loaded: url_helper
INFO - 2020-07-07 16:06:35 --> Helper loaded: main_helper
INFO - 2020-07-07 16:06:35 --> Database Driver Class Initialized
DEBUG - 2020-07-07 16:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 16:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 16:06:35 --> Controller Class Initialized
INFO - 2020-07-07 16:06:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 16:06:35 --> Pagination Class Initialized
ERROR - 2020-07-07 16:06:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 16:06:35 --> Helper loaded: file_helper
DEBUG - 2020-07-07 16:06:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 16:06:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 16:06:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 16:06:35 --> Encryption Class Initialized
INFO - 2020-07-07 16:06:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 16:06:36 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 16:06:36 --> Final output sent to browser
DEBUG - 2020-07-07 16:06:36 --> Total execution time: 1.1923
INFO - 2020-07-07 16:54:37 --> Config Class Initialized
INFO - 2020-07-07 16:54:37 --> Hooks Class Initialized
DEBUG - 2020-07-07 16:54:37 --> UTF-8 Support Enabled
INFO - 2020-07-07 16:54:37 --> Utf8 Class Initialized
INFO - 2020-07-07 16:54:37 --> URI Class Initialized
INFO - 2020-07-07 16:54:37 --> Router Class Initialized
INFO - 2020-07-07 16:54:37 --> Output Class Initialized
INFO - 2020-07-07 16:54:37 --> Security Class Initialized
DEBUG - 2020-07-07 16:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 16:54:37 --> Input Class Initialized
INFO - 2020-07-07 16:54:37 --> Language Class Initialized
INFO - 2020-07-07 16:54:37 --> Language Class Initialized
INFO - 2020-07-07 16:54:37 --> Config Class Initialized
INFO - 2020-07-07 16:54:37 --> Loader Class Initialized
INFO - 2020-07-07 16:54:37 --> Helper loaded: url_helper
INFO - 2020-07-07 16:54:37 --> Helper loaded: main_helper
INFO - 2020-07-07 16:54:37 --> Database Driver Class Initialized
DEBUG - 2020-07-07 16:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 16:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 16:54:37 --> Controller Class Initialized
INFO - 2020-07-07 16:54:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 16:54:37 --> Pagination Class Initialized
ERROR - 2020-07-07 16:54:37 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 16:54:37 --> Helper loaded: file_helper
DEBUG - 2020-07-07 16:54:37 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 16:54:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 16:54:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 16:54:37 --> Encryption Class Initialized
INFO - 2020-07-07 16:54:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 16:54:39 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-07 16:54:39 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-07 16:54:39 --> Final output sent to browser
DEBUG - 2020-07-07 16:54:39 --> Total execution time: 1.5293
INFO - 2020-07-07 16:54:53 --> Config Class Initialized
INFO - 2020-07-07 16:54:53 --> Hooks Class Initialized
DEBUG - 2020-07-07 16:54:53 --> UTF-8 Support Enabled
INFO - 2020-07-07 16:54:53 --> Utf8 Class Initialized
INFO - 2020-07-07 16:54:53 --> URI Class Initialized
INFO - 2020-07-07 16:54:53 --> Router Class Initialized
INFO - 2020-07-07 16:54:53 --> Output Class Initialized
INFO - 2020-07-07 16:54:53 --> Security Class Initialized
DEBUG - 2020-07-07 16:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 16:54:53 --> Input Class Initialized
INFO - 2020-07-07 16:54:53 --> Language Class Initialized
INFO - 2020-07-07 16:54:53 --> Language Class Initialized
INFO - 2020-07-07 16:54:53 --> Config Class Initialized
INFO - 2020-07-07 16:54:53 --> Loader Class Initialized
INFO - 2020-07-07 16:54:53 --> Helper loaded: url_helper
INFO - 2020-07-07 16:54:53 --> Helper loaded: main_helper
INFO - 2020-07-07 16:54:53 --> Database Driver Class Initialized
DEBUG - 2020-07-07 16:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 16:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 16:54:53 --> Controller Class Initialized
INFO - 2020-07-07 16:54:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 16:54:53 --> Pagination Class Initialized
ERROR - 2020-07-07 16:54:53 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 16:54:53 --> Helper loaded: file_helper
DEBUG - 2020-07-07 16:54:53 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 16:54:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 16:54:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 16:54:53 --> Encryption Class Initialized
INFO - 2020-07-07 16:54:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 16:54:54 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-07 16:54:54 --> Final output sent to browser
DEBUG - 2020-07-07 16:54:54 --> Total execution time: 1.3791
INFO - 2020-07-07 16:55:00 --> Config Class Initialized
INFO - 2020-07-07 16:55:00 --> Hooks Class Initialized
DEBUG - 2020-07-07 16:55:00 --> UTF-8 Support Enabled
INFO - 2020-07-07 16:55:00 --> Utf8 Class Initialized
INFO - 2020-07-07 16:55:00 --> URI Class Initialized
INFO - 2020-07-07 16:55:00 --> Router Class Initialized
INFO - 2020-07-07 16:55:00 --> Output Class Initialized
INFO - 2020-07-07 16:55:00 --> Security Class Initialized
DEBUG - 2020-07-07 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-07 16:55:00 --> Input Class Initialized
INFO - 2020-07-07 16:55:00 --> Language Class Initialized
INFO - 2020-07-07 16:55:00 --> Language Class Initialized
INFO - 2020-07-07 16:55:00 --> Config Class Initialized
INFO - 2020-07-07 16:55:00 --> Loader Class Initialized
INFO - 2020-07-07 16:55:00 --> Helper loaded: url_helper
INFO - 2020-07-07 16:55:00 --> Helper loaded: main_helper
INFO - 2020-07-07 16:55:00 --> Database Driver Class Initialized
DEBUG - 2020-07-07 16:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-07 16:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-07 16:55:00 --> Controller Class Initialized
INFO - 2020-07-07 16:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-07 16:55:00 --> Pagination Class Initialized
ERROR - 2020-07-07 16:55:00 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-07 16:55:00 --> Helper loaded: file_helper
DEBUG - 2020-07-07 16:55:00 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-07 16:55:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-07 16:55:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-07 16:55:00 --> Encryption Class Initialized
INFO - 2020-07-07 16:55:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-07 16:55:01 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-07 16:55:01 --> Final output sent to browser
DEBUG - 2020-07-07 16:55:01 --> Total execution time: 1.2967
