<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-07-10 08:56:38 --> Config Class Initialized
INFO - 2020-07-10 08:56:38 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:56:38 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:56:38 --> Utf8 Class Initialized
INFO - 2020-07-10 08:56:38 --> URI Class Initialized
INFO - 2020-07-10 08:56:38 --> Router Class Initialized
INFO - 2020-07-10 08:56:38 --> Output Class Initialized
INFO - 2020-07-10 08:56:38 --> Security Class Initialized
DEBUG - 2020-07-10 08:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:56:38 --> Input Class Initialized
INFO - 2020-07-10 08:56:38 --> Language Class Initialized
INFO - 2020-07-10 08:56:38 --> Language Class Initialized
INFO - 2020-07-10 08:56:38 --> Config Class Initialized
INFO - 2020-07-10 08:56:38 --> Loader Class Initialized
INFO - 2020-07-10 08:56:38 --> Helper loaded: url_helper
INFO - 2020-07-10 08:56:38 --> Helper loaded: main_helper
INFO - 2020-07-10 08:56:38 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:56:38 --> Controller Class Initialized
INFO - 2020-07-10 08:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-10 08:56:38 --> Pagination Class Initialized
ERROR - 2020-07-10 08:56:38 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-10 08:56:38 --> Helper loaded: file_helper
DEBUG - 2020-07-10 08:56:38 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-10 08:56:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-10 08:56:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-10 08:56:38 --> Encryption Class Initialized
INFO - 2020-07-10 08:56:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-10 08:56:39 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-10 08:56:39 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-10 08:56:39 --> Final output sent to browser
DEBUG - 2020-07-10 08:56:39 --> Total execution time: 1.6190
INFO - 2020-07-10 08:56:42 --> Config Class Initialized
INFO - 2020-07-10 08:56:42 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:56:42 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:56:42 --> Utf8 Class Initialized
INFO - 2020-07-10 08:56:42 --> URI Class Initialized
DEBUG - 2020-07-10 08:56:42 --> No URI present. Default controller set.
INFO - 2020-07-10 08:56:42 --> Router Class Initialized
INFO - 2020-07-10 08:56:42 --> Output Class Initialized
INFO - 2020-07-10 08:56:42 --> Security Class Initialized
DEBUG - 2020-07-10 08:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:56:42 --> Input Class Initialized
INFO - 2020-07-10 08:56:42 --> Language Class Initialized
INFO - 2020-07-10 08:56:42 --> Language Class Initialized
INFO - 2020-07-10 08:56:42 --> Config Class Initialized
INFO - 2020-07-10 08:56:42 --> Loader Class Initialized
INFO - 2020-07-10 08:56:42 --> Helper loaded: url_helper
INFO - 2020-07-10 08:56:42 --> Helper loaded: main_helper
INFO - 2020-07-10 08:56:42 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:56:42 --> Controller Class Initialized
DEBUG - 2020-07-10 08:56:42 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-10 08:56:42 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-10 08:56:42 --> Final output sent to browser
DEBUG - 2020-07-10 08:56:42 --> Total execution time: 0.0055
INFO - 2020-07-10 08:56:52 --> Config Class Initialized
INFO - 2020-07-10 08:56:52 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:56:52 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:56:52 --> Utf8 Class Initialized
INFO - 2020-07-10 08:56:52 --> URI Class Initialized
INFO - 2020-07-10 08:56:52 --> Router Class Initialized
INFO - 2020-07-10 08:56:52 --> Output Class Initialized
INFO - 2020-07-10 08:56:52 --> Security Class Initialized
DEBUG - 2020-07-10 08:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:56:52 --> Input Class Initialized
INFO - 2020-07-10 08:56:52 --> Language Class Initialized
INFO - 2020-07-10 08:56:52 --> Language Class Initialized
INFO - 2020-07-10 08:56:52 --> Config Class Initialized
INFO - 2020-07-10 08:56:52 --> Loader Class Initialized
INFO - 2020-07-10 08:56:52 --> Helper loaded: url_helper
INFO - 2020-07-10 08:56:52 --> Helper loaded: main_helper
INFO - 2020-07-10 08:56:52 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:56:52 --> Controller Class Initialized
INFO - 2020-07-10 08:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-10 08:56:52 --> Pagination Class Initialized
ERROR - 2020-07-10 08:56:52 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-10 08:56:52 --> Helper loaded: file_helper
DEBUG - 2020-07-10 08:56:52 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-10 08:56:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-10 08:56:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-10 08:56:52 --> Encryption Class Initialized
INFO - 2020-07-10 08:56:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-10 08:56:52 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-10 08:56:52 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-10 08:56:52 --> Final output sent to browser
DEBUG - 2020-07-10 08:56:52 --> Total execution time: 0.0069
INFO - 2020-07-10 08:56:56 --> Config Class Initialized
INFO - 2020-07-10 08:56:56 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:56:56 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:56:56 --> Utf8 Class Initialized
INFO - 2020-07-10 08:56:56 --> URI Class Initialized
INFO - 2020-07-10 08:56:56 --> Router Class Initialized
INFO - 2020-07-10 08:56:56 --> Output Class Initialized
INFO - 2020-07-10 08:56:56 --> Security Class Initialized
DEBUG - 2020-07-10 08:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:56:56 --> Input Class Initialized
INFO - 2020-07-10 08:56:56 --> Language Class Initialized
INFO - 2020-07-10 08:56:56 --> Language Class Initialized
INFO - 2020-07-10 08:56:56 --> Config Class Initialized
INFO - 2020-07-10 08:56:56 --> Loader Class Initialized
INFO - 2020-07-10 08:56:56 --> Helper loaded: url_helper
INFO - 2020-07-10 08:56:56 --> Helper loaded: main_helper
INFO - 2020-07-10 08:56:56 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:56:56 --> Controller Class Initialized
DEBUG - 2020-07-10 08:56:56 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-10 08:56:56 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-10 08:56:56 --> Final output sent to browser
DEBUG - 2020-07-10 08:56:56 --> Total execution time: 0.0043
INFO - 2020-07-10 08:56:58 --> Config Class Initialized
INFO - 2020-07-10 08:56:58 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:56:58 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:56:58 --> Utf8 Class Initialized
INFO - 2020-07-10 08:56:58 --> URI Class Initialized
INFO - 2020-07-10 08:56:58 --> Router Class Initialized
INFO - 2020-07-10 08:56:58 --> Output Class Initialized
INFO - 2020-07-10 08:56:58 --> Security Class Initialized
DEBUG - 2020-07-10 08:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:56:58 --> Input Class Initialized
INFO - 2020-07-10 08:56:58 --> Language Class Initialized
INFO - 2020-07-10 08:56:58 --> Language Class Initialized
INFO - 2020-07-10 08:56:58 --> Config Class Initialized
INFO - 2020-07-10 08:56:58 --> Loader Class Initialized
INFO - 2020-07-10 08:56:58 --> Helper loaded: url_helper
INFO - 2020-07-10 08:56:58 --> Helper loaded: main_helper
INFO - 2020-07-10 08:56:58 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:56:58 --> Controller Class Initialized
INFO - 2020-07-10 08:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-10 08:56:58 --> Pagination Class Initialized
ERROR - 2020-07-10 08:56:58 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-10 08:56:58 --> Helper loaded: file_helper
DEBUG - 2020-07-10 08:56:58 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-10 08:56:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-10 08:56:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-10 08:56:58 --> Encryption Class Initialized
INFO - 2020-07-10 08:56:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-10 08:56:58 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-10 08:56:58 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-10 08:56:58 --> Final output sent to browser
DEBUG - 2020-07-10 08:56:58 --> Total execution time: 0.0043
INFO - 2020-07-10 08:57:04 --> Config Class Initialized
INFO - 2020-07-10 08:57:04 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:57:04 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:57:04 --> Utf8 Class Initialized
INFO - 2020-07-10 08:57:04 --> URI Class Initialized
INFO - 2020-07-10 08:57:04 --> Router Class Initialized
INFO - 2020-07-10 08:57:04 --> Output Class Initialized
INFO - 2020-07-10 08:57:04 --> Security Class Initialized
DEBUG - 2020-07-10 08:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:57:04 --> Input Class Initialized
INFO - 2020-07-10 08:57:04 --> Language Class Initialized
INFO - 2020-07-10 08:57:04 --> Language Class Initialized
INFO - 2020-07-10 08:57:04 --> Config Class Initialized
INFO - 2020-07-10 08:57:04 --> Loader Class Initialized
INFO - 2020-07-10 08:57:04 --> Helper loaded: url_helper
INFO - 2020-07-10 08:57:04 --> Helper loaded: main_helper
INFO - 2020-07-10 08:57:04 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:57:04 --> Controller Class Initialized
INFO - 2020-07-10 08:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-10 08:57:04 --> Pagination Class Initialized
ERROR - 2020-07-10 08:57:04 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-10 08:57:04 --> Helper loaded: file_helper
DEBUG - 2020-07-10 08:57:04 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-10 08:57:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-10 08:57:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-10 08:57:04 --> Encryption Class Initialized
INFO - 2020-07-10 08:57:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-10 08:57:06 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-10 08:57:06 --> Final output sent to browser
DEBUG - 2020-07-10 08:57:06 --> Total execution time: 2.3072
INFO - 2020-07-10 08:58:41 --> Config Class Initialized
INFO - 2020-07-10 08:58:41 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:58:41 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:58:41 --> Utf8 Class Initialized
INFO - 2020-07-10 08:58:41 --> URI Class Initialized
INFO - 2020-07-10 08:58:41 --> Router Class Initialized
INFO - 2020-07-10 08:58:41 --> Output Class Initialized
INFO - 2020-07-10 08:58:41 --> Security Class Initialized
DEBUG - 2020-07-10 08:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:58:41 --> Input Class Initialized
INFO - 2020-07-10 08:58:41 --> Language Class Initialized
INFO - 2020-07-10 08:58:41 --> Language Class Initialized
INFO - 2020-07-10 08:58:41 --> Config Class Initialized
INFO - 2020-07-10 08:58:41 --> Loader Class Initialized
INFO - 2020-07-10 08:58:41 --> Helper loaded: url_helper
INFO - 2020-07-10 08:58:41 --> Helper loaded: main_helper
INFO - 2020-07-10 08:58:41 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:58:41 --> Controller Class Initialized
DEBUG - 2020-07-10 08:58:41 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-10 08:58:41 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-10 08:58:41 --> Final output sent to browser
DEBUG - 2020-07-10 08:58:41 --> Total execution time: 0.0041
INFO - 2020-07-10 08:58:57 --> Config Class Initialized
INFO - 2020-07-10 08:58:57 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:58:57 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:58:57 --> Utf8 Class Initialized
INFO - 2020-07-10 08:58:57 --> URI Class Initialized
INFO - 2020-07-10 08:58:57 --> Router Class Initialized
INFO - 2020-07-10 08:58:57 --> Output Class Initialized
INFO - 2020-07-10 08:58:57 --> Security Class Initialized
DEBUG - 2020-07-10 08:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:58:57 --> Input Class Initialized
INFO - 2020-07-10 08:58:57 --> Language Class Initialized
INFO - 2020-07-10 08:58:57 --> Language Class Initialized
INFO - 2020-07-10 08:58:57 --> Config Class Initialized
INFO - 2020-07-10 08:58:57 --> Loader Class Initialized
INFO - 2020-07-10 08:58:57 --> Helper loaded: url_helper
INFO - 2020-07-10 08:58:57 --> Helper loaded: main_helper
INFO - 2020-07-10 08:58:57 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:58:57 --> Controller Class Initialized
DEBUG - 2020-07-10 08:58:57 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-10 08:58:57 --> Config Class Initialized
INFO - 2020-07-10 08:58:57 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:58:57 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:58:57 --> Utf8 Class Initialized
INFO - 2020-07-10 08:58:57 --> URI Class Initialized
DEBUG - 2020-07-10 08:58:57 --> No URI present. Default controller set.
INFO - 2020-07-10 08:58:57 --> Router Class Initialized
INFO - 2020-07-10 08:58:57 --> Output Class Initialized
INFO - 2020-07-10 08:58:57 --> Security Class Initialized
DEBUG - 2020-07-10 08:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:58:57 --> Input Class Initialized
INFO - 2020-07-10 08:58:57 --> Language Class Initialized
INFO - 2020-07-10 08:58:57 --> Language Class Initialized
INFO - 2020-07-10 08:58:57 --> Config Class Initialized
INFO - 2020-07-10 08:58:57 --> Loader Class Initialized
INFO - 2020-07-10 08:58:57 --> Helper loaded: url_helper
INFO - 2020-07-10 08:58:57 --> Helper loaded: main_helper
INFO - 2020-07-10 08:58:57 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:58:57 --> Controller Class Initialized
DEBUG - 2020-07-10 08:58:57 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-10 08:58:57 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-10 08:58:57 --> Final output sent to browser
DEBUG - 2020-07-10 08:58:57 --> Total execution time: 0.0045
INFO - 2020-07-10 08:59:03 --> Config Class Initialized
INFO - 2020-07-10 08:59:03 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:59:03 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:59:03 --> Utf8 Class Initialized
INFO - 2020-07-10 08:59:03 --> URI Class Initialized
INFO - 2020-07-10 08:59:03 --> Router Class Initialized
INFO - 2020-07-10 08:59:03 --> Output Class Initialized
INFO - 2020-07-10 08:59:03 --> Security Class Initialized
DEBUG - 2020-07-10 08:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:59:03 --> Input Class Initialized
INFO - 2020-07-10 08:59:03 --> Language Class Initialized
INFO - 2020-07-10 08:59:03 --> Language Class Initialized
INFO - 2020-07-10 08:59:03 --> Config Class Initialized
INFO - 2020-07-10 08:59:03 --> Loader Class Initialized
INFO - 2020-07-10 08:59:03 --> Helper loaded: url_helper
INFO - 2020-07-10 08:59:03 --> Helper loaded: main_helper
INFO - 2020-07-10 08:59:03 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:59:03 --> Controller Class Initialized
INFO - 2020-07-10 08:59:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-10 08:59:03 --> Pagination Class Initialized
ERROR - 2020-07-10 08:59:03 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-10 08:59:03 --> Helper loaded: file_helper
DEBUG - 2020-07-10 08:59:03 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-10 08:59:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-10 08:59:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-10 08:59:03 --> Encryption Class Initialized
INFO - 2020-07-10 08:59:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-10 08:59:03 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-10 08:59:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-10 08:59:03 --> Final output sent to browser
DEBUG - 2020-07-10 08:59:03 --> Total execution time: 0.0048
INFO - 2020-07-10 08:59:16 --> Config Class Initialized
INFO - 2020-07-10 08:59:16 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:59:16 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:59:16 --> Utf8 Class Initialized
INFO - 2020-07-10 08:59:16 --> URI Class Initialized
INFO - 2020-07-10 08:59:16 --> Router Class Initialized
INFO - 2020-07-10 08:59:16 --> Output Class Initialized
INFO - 2020-07-10 08:59:16 --> Security Class Initialized
DEBUG - 2020-07-10 08:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:59:16 --> Input Class Initialized
INFO - 2020-07-10 08:59:16 --> Language Class Initialized
INFO - 2020-07-10 08:59:16 --> Language Class Initialized
INFO - 2020-07-10 08:59:16 --> Config Class Initialized
INFO - 2020-07-10 08:59:16 --> Loader Class Initialized
INFO - 2020-07-10 08:59:16 --> Helper loaded: url_helper
INFO - 2020-07-10 08:59:16 --> Helper loaded: main_helper
INFO - 2020-07-10 08:59:16 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:59:16 --> Controller Class Initialized
DEBUG - 2020-07-10 08:59:16 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-10 08:59:16 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-10 08:59:16 --> Final output sent to browser
DEBUG - 2020-07-10 08:59:16 --> Total execution time: 0.0057
INFO - 2020-07-10 08:59:17 --> Config Class Initialized
INFO - 2020-07-10 08:59:17 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:59:17 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:59:17 --> Utf8 Class Initialized
INFO - 2020-07-10 08:59:17 --> URI Class Initialized
INFO - 2020-07-10 08:59:17 --> Router Class Initialized
INFO - 2020-07-10 08:59:17 --> Output Class Initialized
INFO - 2020-07-10 08:59:17 --> Security Class Initialized
DEBUG - 2020-07-10 08:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:59:17 --> Input Class Initialized
INFO - 2020-07-10 08:59:17 --> Language Class Initialized
INFO - 2020-07-10 08:59:17 --> Language Class Initialized
INFO - 2020-07-10 08:59:17 --> Config Class Initialized
INFO - 2020-07-10 08:59:17 --> Loader Class Initialized
INFO - 2020-07-10 08:59:17 --> Helper loaded: url_helper
INFO - 2020-07-10 08:59:17 --> Helper loaded: main_helper
INFO - 2020-07-10 08:59:17 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:59:17 --> Controller Class Initialized
INFO - 2020-07-10 08:59:17 --> Final output sent to browser
DEBUG - 2020-07-10 08:59:17 --> Total execution time: 0.0071
INFO - 2020-07-10 08:59:32 --> Config Class Initialized
INFO - 2020-07-10 08:59:32 --> Hooks Class Initialized
DEBUG - 2020-07-10 08:59:32 --> UTF-8 Support Enabled
INFO - 2020-07-10 08:59:32 --> Utf8 Class Initialized
INFO - 2020-07-10 08:59:32 --> URI Class Initialized
INFO - 2020-07-10 08:59:32 --> Router Class Initialized
INFO - 2020-07-10 08:59:32 --> Output Class Initialized
INFO - 2020-07-10 08:59:32 --> Security Class Initialized
DEBUG - 2020-07-10 08:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 08:59:32 --> Input Class Initialized
INFO - 2020-07-10 08:59:32 --> Language Class Initialized
INFO - 2020-07-10 08:59:32 --> Language Class Initialized
INFO - 2020-07-10 08:59:32 --> Config Class Initialized
INFO - 2020-07-10 08:59:32 --> Loader Class Initialized
INFO - 2020-07-10 08:59:32 --> Helper loaded: url_helper
INFO - 2020-07-10 08:59:32 --> Helper loaded: main_helper
INFO - 2020-07-10 08:59:32 --> Database Driver Class Initialized
DEBUG - 2020-07-10 08:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 08:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 08:59:32 --> Controller Class Initialized
INFO - 2020-07-10 08:59:32 --> Final output sent to browser
DEBUG - 2020-07-10 08:59:32 --> Total execution time: 0.0068
INFO - 2020-07-10 09:00:03 --> Config Class Initialized
INFO - 2020-07-10 09:00:03 --> Hooks Class Initialized
DEBUG - 2020-07-10 09:00:03 --> UTF-8 Support Enabled
INFO - 2020-07-10 09:00:03 --> Utf8 Class Initialized
INFO - 2020-07-10 09:00:03 --> URI Class Initialized
DEBUG - 2020-07-10 09:00:03 --> No URI present. Default controller set.
INFO - 2020-07-10 09:00:03 --> Router Class Initialized
INFO - 2020-07-10 09:00:03 --> Output Class Initialized
INFO - 2020-07-10 09:00:03 --> Security Class Initialized
DEBUG - 2020-07-10 09:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 09:00:03 --> Input Class Initialized
INFO - 2020-07-10 09:00:03 --> Language Class Initialized
INFO - 2020-07-10 09:00:03 --> Language Class Initialized
INFO - 2020-07-10 09:00:03 --> Config Class Initialized
INFO - 2020-07-10 09:00:03 --> Loader Class Initialized
INFO - 2020-07-10 09:00:03 --> Helper loaded: url_helper
INFO - 2020-07-10 09:00:03 --> Helper loaded: main_helper
INFO - 2020-07-10 09:00:03 --> Database Driver Class Initialized
DEBUG - 2020-07-10 09:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 09:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 09:00:03 --> Controller Class Initialized
DEBUG - 2020-07-10 09:00:03 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-10 09:00:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-10 09:00:03 --> Final output sent to browser
DEBUG - 2020-07-10 09:00:03 --> Total execution time: 0.0037
INFO - 2020-07-10 09:00:10 --> Config Class Initialized
INFO - 2020-07-10 09:00:10 --> Hooks Class Initialized
DEBUG - 2020-07-10 09:00:10 --> UTF-8 Support Enabled
INFO - 2020-07-10 09:00:10 --> Utf8 Class Initialized
INFO - 2020-07-10 09:00:10 --> URI Class Initialized
INFO - 2020-07-10 09:00:10 --> Router Class Initialized
INFO - 2020-07-10 09:00:10 --> Output Class Initialized
INFO - 2020-07-10 09:00:10 --> Security Class Initialized
DEBUG - 2020-07-10 09:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 09:00:10 --> Input Class Initialized
INFO - 2020-07-10 09:00:10 --> Language Class Initialized
INFO - 2020-07-10 09:00:10 --> Language Class Initialized
INFO - 2020-07-10 09:00:10 --> Config Class Initialized
INFO - 2020-07-10 09:00:10 --> Loader Class Initialized
INFO - 2020-07-10 09:00:10 --> Helper loaded: url_helper
INFO - 2020-07-10 09:00:10 --> Helper loaded: main_helper
INFO - 2020-07-10 09:00:10 --> Database Driver Class Initialized
DEBUG - 2020-07-10 09:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 09:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 09:00:10 --> Controller Class Initialized
INFO - 2020-07-10 09:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-10 09:00:10 --> Pagination Class Initialized
ERROR - 2020-07-10 09:00:10 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-10 09:00:10 --> Helper loaded: file_helper
DEBUG - 2020-07-10 09:00:10 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-10 09:00:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-10 09:00:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-10 09:00:10 --> Encryption Class Initialized
INFO - 2020-07-10 09:00:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-10 09:00:10 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-10 09:00:10 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-10 09:00:10 --> Final output sent to browser
DEBUG - 2020-07-10 09:00:10 --> Total execution time: 0.0046
INFO - 2020-07-10 09:00:20 --> Config Class Initialized
INFO - 2020-07-10 09:00:20 --> Hooks Class Initialized
DEBUG - 2020-07-10 09:00:20 --> UTF-8 Support Enabled
INFO - 2020-07-10 09:00:20 --> Utf8 Class Initialized
INFO - 2020-07-10 09:00:20 --> URI Class Initialized
INFO - 2020-07-10 09:00:20 --> Router Class Initialized
INFO - 2020-07-10 09:00:20 --> Output Class Initialized
INFO - 2020-07-10 09:00:20 --> Security Class Initialized
DEBUG - 2020-07-10 09:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 09:00:20 --> Input Class Initialized
INFO - 2020-07-10 09:00:20 --> Language Class Initialized
INFO - 2020-07-10 09:00:20 --> Language Class Initialized
INFO - 2020-07-10 09:00:20 --> Config Class Initialized
INFO - 2020-07-10 09:00:20 --> Loader Class Initialized
INFO - 2020-07-10 09:00:20 --> Helper loaded: url_helper
INFO - 2020-07-10 09:00:20 --> Helper loaded: main_helper
INFO - 2020-07-10 09:00:20 --> Database Driver Class Initialized
DEBUG - 2020-07-10 09:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 09:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 09:00:20 --> Controller Class Initialized
DEBUG - 2020-07-10 09:00:20 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-10 09:00:20 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-10 09:00:20 --> Final output sent to browser
DEBUG - 2020-07-10 09:00:20 --> Total execution time: 0.0043
INFO - 2020-07-10 09:00:21 --> Config Class Initialized
INFO - 2020-07-10 09:00:21 --> Hooks Class Initialized
DEBUG - 2020-07-10 09:00:21 --> UTF-8 Support Enabled
INFO - 2020-07-10 09:00:21 --> Utf8 Class Initialized
INFO - 2020-07-10 09:00:21 --> URI Class Initialized
INFO - 2020-07-10 09:00:21 --> Router Class Initialized
INFO - 2020-07-10 09:00:21 --> Output Class Initialized
INFO - 2020-07-10 09:00:21 --> Security Class Initialized
DEBUG - 2020-07-10 09:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 09:00:21 --> Input Class Initialized
INFO - 2020-07-10 09:00:21 --> Language Class Initialized
INFO - 2020-07-10 09:00:21 --> Language Class Initialized
INFO - 2020-07-10 09:00:21 --> Config Class Initialized
INFO - 2020-07-10 09:00:21 --> Loader Class Initialized
INFO - 2020-07-10 09:00:21 --> Helper loaded: url_helper
INFO - 2020-07-10 09:00:21 --> Helper loaded: main_helper
INFO - 2020-07-10 09:00:21 --> Database Driver Class Initialized
DEBUG - 2020-07-10 09:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 09:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 09:00:21 --> Controller Class Initialized
INFO - 2020-07-10 09:00:21 --> Final output sent to browser
DEBUG - 2020-07-10 09:00:21 --> Total execution time: 0.0055
INFO - 2020-07-10 09:00:25 --> Config Class Initialized
INFO - 2020-07-10 09:00:25 --> Hooks Class Initialized
DEBUG - 2020-07-10 09:00:25 --> UTF-8 Support Enabled
INFO - 2020-07-10 09:00:25 --> Utf8 Class Initialized
INFO - 2020-07-10 09:00:25 --> URI Class Initialized
INFO - 2020-07-10 09:00:25 --> Router Class Initialized
INFO - 2020-07-10 09:00:25 --> Output Class Initialized
INFO - 2020-07-10 09:00:25 --> Security Class Initialized
DEBUG - 2020-07-10 09:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 09:00:25 --> Input Class Initialized
INFO - 2020-07-10 09:00:25 --> Language Class Initialized
INFO - 2020-07-10 09:00:25 --> Language Class Initialized
INFO - 2020-07-10 09:00:25 --> Config Class Initialized
INFO - 2020-07-10 09:00:25 --> Loader Class Initialized
INFO - 2020-07-10 09:00:25 --> Helper loaded: url_helper
INFO - 2020-07-10 09:00:25 --> Helper loaded: main_helper
INFO - 2020-07-10 09:00:25 --> Database Driver Class Initialized
DEBUG - 2020-07-10 09:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 09:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 09:00:25 --> Controller Class Initialized
INFO - 2020-07-10 09:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-10 09:00:25 --> Pagination Class Initialized
ERROR - 2020-07-10 09:00:25 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-10 09:00:25 --> Helper loaded: file_helper
DEBUG - 2020-07-10 09:00:25 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-10 09:00:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-10 09:00:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-10 09:00:25 --> Encryption Class Initialized
INFO - 2020-07-10 09:00:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-10 09:00:25 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-10 09:00:25 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-10 09:00:25 --> Final output sent to browser
DEBUG - 2020-07-10 09:00:25 --> Total execution time: 0.0040
INFO - 2020-07-10 09:00:44 --> Config Class Initialized
INFO - 2020-07-10 09:00:44 --> Hooks Class Initialized
DEBUG - 2020-07-10 09:00:44 --> UTF-8 Support Enabled
INFO - 2020-07-10 09:00:44 --> Utf8 Class Initialized
INFO - 2020-07-10 09:00:44 --> URI Class Initialized
INFO - 2020-07-10 09:00:44 --> Router Class Initialized
INFO - 2020-07-10 09:00:44 --> Output Class Initialized
INFO - 2020-07-10 09:00:44 --> Security Class Initialized
DEBUG - 2020-07-10 09:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 09:00:44 --> Input Class Initialized
INFO - 2020-07-10 09:00:44 --> Language Class Initialized
INFO - 2020-07-10 09:00:44 --> Language Class Initialized
INFO - 2020-07-10 09:00:44 --> Config Class Initialized
INFO - 2020-07-10 09:00:44 --> Loader Class Initialized
INFO - 2020-07-10 09:00:44 --> Helper loaded: url_helper
INFO - 2020-07-10 09:00:44 --> Helper loaded: main_helper
INFO - 2020-07-10 09:00:44 --> Database Driver Class Initialized
DEBUG - 2020-07-10 09:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 09:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 09:00:44 --> Controller Class Initialized
INFO - 2020-07-10 09:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-10 09:00:44 --> Pagination Class Initialized
ERROR - 2020-07-10 09:00:44 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-10 09:00:44 --> Helper loaded: file_helper
DEBUG - 2020-07-10 09:00:44 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-10 09:00:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-10 09:00:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-10 09:00:44 --> Encryption Class Initialized
INFO - 2020-07-10 09:00:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-10 09:00:46 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-10 09:00:46 --> Final output sent to browser
DEBUG - 2020-07-10 09:00:46 --> Total execution time: 1.8068
INFO - 2020-07-10 09:02:08 --> Config Class Initialized
INFO - 2020-07-10 09:02:08 --> Hooks Class Initialized
DEBUG - 2020-07-10 09:02:08 --> UTF-8 Support Enabled
INFO - 2020-07-10 09:02:08 --> Utf8 Class Initialized
INFO - 2020-07-10 09:02:08 --> URI Class Initialized
INFO - 2020-07-10 09:02:08 --> Router Class Initialized
INFO - 2020-07-10 09:02:08 --> Output Class Initialized
INFO - 2020-07-10 09:02:08 --> Security Class Initialized
DEBUG - 2020-07-10 09:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-10 09:02:08 --> Input Class Initialized
INFO - 2020-07-10 09:02:08 --> Language Class Initialized
INFO - 2020-07-10 09:02:08 --> Language Class Initialized
INFO - 2020-07-10 09:02:08 --> Config Class Initialized
INFO - 2020-07-10 09:02:08 --> Loader Class Initialized
INFO - 2020-07-10 09:02:08 --> Helper loaded: url_helper
INFO - 2020-07-10 09:02:08 --> Helper loaded: main_helper
INFO - 2020-07-10 09:02:08 --> Database Driver Class Initialized
DEBUG - 2020-07-10 09:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-10 09:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-10 09:02:08 --> Controller Class Initialized
INFO - 2020-07-10 09:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-10 09:02:08 --> Pagination Class Initialized
ERROR - 2020-07-10 09:02:08 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-10 09:02:08 --> Helper loaded: file_helper
DEBUG - 2020-07-10 09:02:08 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-10 09:02:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-10 09:02:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-10 09:02:08 --> Encryption Class Initialized
INFO - 2020-07-10 09:02:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-10 09:02:10 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-10 09:02:10 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-10 09:02:10 --> Final output sent to browser
DEBUG - 2020-07-10 09:02:10 --> Total execution time: 1.6390
