<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-07-06 07:44:07 --> Config Class Initialized
INFO - 2020-07-06 07:44:07 --> Hooks Class Initialized
DEBUG - 2020-07-06 07:44:07 --> UTF-8 Support Enabled
INFO - 2020-07-06 07:44:07 --> Utf8 Class Initialized
INFO - 2020-07-06 07:44:07 --> URI Class Initialized
INFO - 2020-07-06 07:44:07 --> Router Class Initialized
INFO - 2020-07-06 07:44:07 --> Output Class Initialized
INFO - 2020-07-06 07:44:07 --> Security Class Initialized
DEBUG - 2020-07-06 07:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 07:44:07 --> Input Class Initialized
INFO - 2020-07-06 07:44:07 --> Language Class Initialized
INFO - 2020-07-06 07:44:07 --> Language Class Initialized
INFO - 2020-07-06 07:44:07 --> Config Class Initialized
INFO - 2020-07-06 07:44:07 --> Loader Class Initialized
INFO - 2020-07-06 07:44:07 --> Helper loaded: url_helper
INFO - 2020-07-06 07:44:07 --> Helper loaded: main_helper
INFO - 2020-07-06 07:44:07 --> Database Driver Class Initialized
DEBUG - 2020-07-06 07:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 07:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 07:44:07 --> Controller Class Initialized
INFO - 2020-07-06 07:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 07:44:07 --> Pagination Class Initialized
ERROR - 2020-07-06 07:44:07 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 07:44:07 --> Helper loaded: file_helper
DEBUG - 2020-07-06 07:44:07 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 07:44:09 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 07:44:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 07:44:09 --> Final output sent to browser
DEBUG - 2020-07-06 07:44:09 --> Total execution time: 1.6108
INFO - 2020-07-06 07:55:29 --> Config Class Initialized
INFO - 2020-07-06 07:55:29 --> Hooks Class Initialized
DEBUG - 2020-07-06 07:55:29 --> UTF-8 Support Enabled
INFO - 2020-07-06 07:55:29 --> Utf8 Class Initialized
INFO - 2020-07-06 07:55:29 --> URI Class Initialized
INFO - 2020-07-06 07:55:29 --> Router Class Initialized
INFO - 2020-07-06 07:55:29 --> Output Class Initialized
INFO - 2020-07-06 07:55:29 --> Security Class Initialized
DEBUG - 2020-07-06 07:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 07:55:29 --> Input Class Initialized
INFO - 2020-07-06 07:55:29 --> Language Class Initialized
ERROR - 2020-07-06 07:55:29 --> Severity: Compile Error --> A void function must not return a value (did you mean "return;" instead of "return null;"?) /var/www/journal/application/modules/landing/controllers/Search.php 114
INFO - 2020-07-06 07:55:54 --> Config Class Initialized
INFO - 2020-07-06 07:55:54 --> Hooks Class Initialized
DEBUG - 2020-07-06 07:55:54 --> UTF-8 Support Enabled
INFO - 2020-07-06 07:55:54 --> Utf8 Class Initialized
INFO - 2020-07-06 07:55:54 --> URI Class Initialized
INFO - 2020-07-06 07:55:54 --> Router Class Initialized
INFO - 2020-07-06 07:55:54 --> Output Class Initialized
INFO - 2020-07-06 07:55:54 --> Security Class Initialized
DEBUG - 2020-07-06 07:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 07:55:54 --> Input Class Initialized
INFO - 2020-07-06 07:55:54 --> Language Class Initialized
ERROR - 2020-07-06 07:55:54 --> Severity: Compile Error --> A void function must not return a value /var/www/journal/application/modules/landing/controllers/Search.php 139
INFO - 2020-07-06 07:56:50 --> Config Class Initialized
INFO - 2020-07-06 07:56:50 --> Hooks Class Initialized
DEBUG - 2020-07-06 07:56:50 --> UTF-8 Support Enabled
INFO - 2020-07-06 07:56:50 --> Utf8 Class Initialized
INFO - 2020-07-06 07:56:50 --> URI Class Initialized
INFO - 2020-07-06 07:56:50 --> Router Class Initialized
INFO - 2020-07-06 07:56:50 --> Output Class Initialized
INFO - 2020-07-06 07:56:50 --> Security Class Initialized
DEBUG - 2020-07-06 07:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 07:56:50 --> Input Class Initialized
INFO - 2020-07-06 07:56:50 --> Language Class Initialized
INFO - 2020-07-06 07:56:50 --> Language Class Initialized
INFO - 2020-07-06 07:56:50 --> Config Class Initialized
INFO - 2020-07-06 07:56:50 --> Loader Class Initialized
INFO - 2020-07-06 07:56:50 --> Helper loaded: url_helper
INFO - 2020-07-06 07:56:50 --> Helper loaded: main_helper
INFO - 2020-07-06 07:56:50 --> Database Driver Class Initialized
DEBUG - 2020-07-06 07:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 07:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 07:56:50 --> Controller Class Initialized
INFO - 2020-07-06 07:56:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 07:56:50 --> Pagination Class Initialized
ERROR - 2020-07-06 07:56:50 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 07:56:50 --> Helper loaded: file_helper
DEBUG - 2020-07-06 07:56:50 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 07:56:51 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 07:56:51 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 07:56:51 --> Final output sent to browser
DEBUG - 2020-07-06 07:56:51 --> Total execution time: 1.4265
INFO - 2020-07-06 07:56:56 --> Config Class Initialized
INFO - 2020-07-06 07:56:56 --> Hooks Class Initialized
DEBUG - 2020-07-06 07:56:56 --> UTF-8 Support Enabled
INFO - 2020-07-06 07:56:56 --> Utf8 Class Initialized
INFO - 2020-07-06 07:56:56 --> URI Class Initialized
INFO - 2020-07-06 07:56:56 --> Router Class Initialized
INFO - 2020-07-06 07:56:56 --> Output Class Initialized
INFO - 2020-07-06 07:56:56 --> Security Class Initialized
DEBUG - 2020-07-06 07:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 07:56:56 --> Input Class Initialized
INFO - 2020-07-06 07:56:56 --> Language Class Initialized
INFO - 2020-07-06 07:56:56 --> Language Class Initialized
INFO - 2020-07-06 07:56:56 --> Config Class Initialized
INFO - 2020-07-06 07:56:56 --> Loader Class Initialized
INFO - 2020-07-06 07:56:56 --> Helper loaded: url_helper
INFO - 2020-07-06 07:56:56 --> Helper loaded: main_helper
INFO - 2020-07-06 07:56:56 --> Database Driver Class Initialized
DEBUG - 2020-07-06 07:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 07:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 07:56:56 --> Controller Class Initialized
INFO - 2020-07-06 07:56:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 07:56:56 --> Pagination Class Initialized
ERROR - 2020-07-06 07:56:56 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 07:56:56 --> Helper loaded: file_helper
DEBUG - 2020-07-06 07:56:56 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 07:56:57 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-06 07:56:57 --> Final output sent to browser
DEBUG - 2020-07-06 07:56:57 --> Total execution time: 1.3219
INFO - 2020-07-06 07:57:05 --> Config Class Initialized
INFO - 2020-07-06 07:57:05 --> Hooks Class Initialized
DEBUG - 2020-07-06 07:57:05 --> UTF-8 Support Enabled
INFO - 2020-07-06 07:57:05 --> Utf8 Class Initialized
INFO - 2020-07-06 07:57:05 --> URI Class Initialized
INFO - 2020-07-06 07:57:05 --> Router Class Initialized
INFO - 2020-07-06 07:57:05 --> Output Class Initialized
INFO - 2020-07-06 07:57:05 --> Security Class Initialized
DEBUG - 2020-07-06 07:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 07:57:05 --> Input Class Initialized
INFO - 2020-07-06 07:57:05 --> Language Class Initialized
INFO - 2020-07-06 07:57:05 --> Language Class Initialized
INFO - 2020-07-06 07:57:05 --> Config Class Initialized
INFO - 2020-07-06 07:57:05 --> Loader Class Initialized
INFO - 2020-07-06 07:57:05 --> Helper loaded: url_helper
INFO - 2020-07-06 07:57:05 --> Helper loaded: main_helper
INFO - 2020-07-06 07:57:05 --> Database Driver Class Initialized
DEBUG - 2020-07-06 07:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 07:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 07:57:05 --> Controller Class Initialized
INFO - 2020-07-06 07:57:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 07:57:05 --> Pagination Class Initialized
ERROR - 2020-07-06 07:57:05 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 07:57:05 --> Helper loaded: file_helper
DEBUG - 2020-07-06 07:57:05 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 07:57:07 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-06 07:57:07 --> Final output sent to browser
DEBUG - 2020-07-06 07:57:07 --> Total execution time: 1.2887
INFO - 2020-07-06 07:57:26 --> Config Class Initialized
INFO - 2020-07-06 07:57:26 --> Hooks Class Initialized
DEBUG - 2020-07-06 07:57:26 --> UTF-8 Support Enabled
INFO - 2020-07-06 07:57:26 --> Utf8 Class Initialized
INFO - 2020-07-06 07:57:26 --> URI Class Initialized
INFO - 2020-07-06 07:57:26 --> Router Class Initialized
INFO - 2020-07-06 07:57:26 --> Output Class Initialized
INFO - 2020-07-06 07:57:26 --> Security Class Initialized
DEBUG - 2020-07-06 07:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 07:57:26 --> Input Class Initialized
INFO - 2020-07-06 07:57:26 --> Language Class Initialized
INFO - 2020-07-06 07:57:26 --> Language Class Initialized
INFO - 2020-07-06 07:57:26 --> Config Class Initialized
INFO - 2020-07-06 07:57:26 --> Loader Class Initialized
INFO - 2020-07-06 07:57:26 --> Helper loaded: url_helper
INFO - 2020-07-06 07:57:26 --> Helper loaded: main_helper
INFO - 2020-07-06 07:57:26 --> Database Driver Class Initialized
DEBUG - 2020-07-06 07:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 07:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 07:57:26 --> Controller Class Initialized
INFO - 2020-07-06 07:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 07:57:26 --> Pagination Class Initialized
ERROR - 2020-07-06 07:57:26 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 07:57:26 --> Helper loaded: file_helper
DEBUG - 2020-07-06 07:57:26 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 07:57:27 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 07:57:27 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 07:57:27 --> Final output sent to browser
DEBUG - 2020-07-06 07:57:27 --> Total execution time: 1.3951
INFO - 2020-07-06 07:57:37 --> Config Class Initialized
INFO - 2020-07-06 07:57:37 --> Hooks Class Initialized
DEBUG - 2020-07-06 07:57:37 --> UTF-8 Support Enabled
INFO - 2020-07-06 07:57:37 --> Utf8 Class Initialized
INFO - 2020-07-06 07:57:37 --> URI Class Initialized
INFO - 2020-07-06 07:57:37 --> Router Class Initialized
INFO - 2020-07-06 07:57:37 --> Output Class Initialized
INFO - 2020-07-06 07:57:37 --> Security Class Initialized
DEBUG - 2020-07-06 07:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 07:57:37 --> Input Class Initialized
INFO - 2020-07-06 07:57:37 --> Language Class Initialized
INFO - 2020-07-06 07:57:37 --> Language Class Initialized
INFO - 2020-07-06 07:57:37 --> Config Class Initialized
INFO - 2020-07-06 07:57:37 --> Loader Class Initialized
INFO - 2020-07-06 07:57:37 --> Helper loaded: url_helper
INFO - 2020-07-06 07:57:37 --> Helper loaded: main_helper
INFO - 2020-07-06 07:57:37 --> Database Driver Class Initialized
DEBUG - 2020-07-06 07:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 07:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 07:57:37 --> Controller Class Initialized
INFO - 2020-07-06 07:57:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 07:57:37 --> Pagination Class Initialized
ERROR - 2020-07-06 07:57:37 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 07:57:37 --> Helper loaded: file_helper
DEBUG - 2020-07-06 07:57:37 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 07:57:38 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-06 07:57:38 --> Final output sent to browser
DEBUG - 2020-07-06 07:57:38 --> Total execution time: 1.3543
INFO - 2020-07-06 08:00:22 --> Config Class Initialized
INFO - 2020-07-06 08:00:22 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:00:22 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:00:22 --> Utf8 Class Initialized
INFO - 2020-07-06 08:00:22 --> URI Class Initialized
INFO - 2020-07-06 08:00:22 --> Router Class Initialized
INFO - 2020-07-06 08:00:22 --> Output Class Initialized
INFO - 2020-07-06 08:00:22 --> Security Class Initialized
DEBUG - 2020-07-06 08:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:00:22 --> Input Class Initialized
INFO - 2020-07-06 08:00:22 --> Language Class Initialized
INFO - 2020-07-06 08:00:22 --> Language Class Initialized
INFO - 2020-07-06 08:00:22 --> Config Class Initialized
INFO - 2020-07-06 08:00:22 --> Loader Class Initialized
INFO - 2020-07-06 08:00:22 --> Helper loaded: url_helper
INFO - 2020-07-06 08:00:22 --> Helper loaded: main_helper
INFO - 2020-07-06 08:00:22 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:00:22 --> Controller Class Initialized
INFO - 2020-07-06 08:00:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:00:22 --> Pagination Class Initialized
ERROR - 2020-07-06 08:00:22 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:00:22 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:00:22 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:00:22 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:00:22 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:00:22 --> Final output sent to browser
DEBUG - 2020-07-06 08:00:22 --> Total execution time: 0.0055
INFO - 2020-07-06 08:00:28 --> Config Class Initialized
INFO - 2020-07-06 08:00:28 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:00:28 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:00:28 --> Utf8 Class Initialized
INFO - 2020-07-06 08:00:28 --> URI Class Initialized
INFO - 2020-07-06 08:00:28 --> Router Class Initialized
INFO - 2020-07-06 08:00:28 --> Output Class Initialized
INFO - 2020-07-06 08:00:28 --> Security Class Initialized
DEBUG - 2020-07-06 08:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:00:28 --> Input Class Initialized
INFO - 2020-07-06 08:00:28 --> Language Class Initialized
INFO - 2020-07-06 08:00:28 --> Language Class Initialized
INFO - 2020-07-06 08:00:28 --> Config Class Initialized
INFO - 2020-07-06 08:00:28 --> Loader Class Initialized
INFO - 2020-07-06 08:00:28 --> Helper loaded: url_helper
INFO - 2020-07-06 08:00:28 --> Helper loaded: main_helper
INFO - 2020-07-06 08:00:28 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:00:28 --> Controller Class Initialized
INFO - 2020-07-06 08:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:00:28 --> Pagination Class Initialized
ERROR - 2020-07-06 08:00:28 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:00:28 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:00:28 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:00:30 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-06 08:00:30 --> Final output sent to browser
DEBUG - 2020-07-06 08:00:30 --> Total execution time: 1.3659
INFO - 2020-07-06 08:11:36 --> Config Class Initialized
INFO - 2020-07-06 08:11:36 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:11:36 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:11:36 --> Utf8 Class Initialized
INFO - 2020-07-06 08:11:36 --> URI Class Initialized
INFO - 2020-07-06 08:11:36 --> Router Class Initialized
INFO - 2020-07-06 08:11:36 --> Output Class Initialized
INFO - 2020-07-06 08:11:36 --> Security Class Initialized
DEBUG - 2020-07-06 08:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:11:36 --> Input Class Initialized
INFO - 2020-07-06 08:11:36 --> Language Class Initialized
INFO - 2020-07-06 08:11:36 --> Language Class Initialized
INFO - 2020-07-06 08:11:36 --> Config Class Initialized
INFO - 2020-07-06 08:11:36 --> Loader Class Initialized
INFO - 2020-07-06 08:11:36 --> Helper loaded: url_helper
INFO - 2020-07-06 08:11:36 --> Helper loaded: main_helper
INFO - 2020-07-06 08:11:36 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:11:36 --> Controller Class Initialized
INFO - 2020-07-06 08:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:11:36 --> Pagination Class Initialized
ERROR - 2020-07-06 08:11:36 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:11:36 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:11:36 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:11:37 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-06 08:11:37 --> Final output sent to browser
DEBUG - 2020-07-06 08:11:37 --> Total execution time: 1.2136
INFO - 2020-07-06 08:20:22 --> Config Class Initialized
INFO - 2020-07-06 08:20:22 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:20:22 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:20:22 --> Utf8 Class Initialized
INFO - 2020-07-06 08:20:22 --> URI Class Initialized
INFO - 2020-07-06 08:20:22 --> Router Class Initialized
INFO - 2020-07-06 08:20:22 --> Output Class Initialized
INFO - 2020-07-06 08:20:22 --> Security Class Initialized
DEBUG - 2020-07-06 08:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:20:22 --> Input Class Initialized
INFO - 2020-07-06 08:20:22 --> Language Class Initialized
INFO - 2020-07-06 08:20:22 --> Language Class Initialized
INFO - 2020-07-06 08:20:22 --> Config Class Initialized
INFO - 2020-07-06 08:20:22 --> Loader Class Initialized
INFO - 2020-07-06 08:20:22 --> Helper loaded: url_helper
INFO - 2020-07-06 08:20:22 --> Helper loaded: main_helper
INFO - 2020-07-06 08:20:22 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:20:22 --> Controller Class Initialized
INFO - 2020-07-06 08:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:20:22 --> Pagination Class Initialized
ERROR - 2020-07-06 08:20:22 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:20:22 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:20:22 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:20:23 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:20:23 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:20:23 --> Final output sent to browser
DEBUG - 2020-07-06 08:20:23 --> Total execution time: 1.5658
INFO - 2020-07-06 08:20:34 --> Config Class Initialized
INFO - 2020-07-06 08:20:34 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:20:34 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:20:34 --> Utf8 Class Initialized
INFO - 2020-07-06 08:20:34 --> URI Class Initialized
INFO - 2020-07-06 08:20:34 --> Router Class Initialized
INFO - 2020-07-06 08:20:34 --> Output Class Initialized
INFO - 2020-07-06 08:20:34 --> Security Class Initialized
DEBUG - 2020-07-06 08:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:20:34 --> Input Class Initialized
INFO - 2020-07-06 08:20:34 --> Language Class Initialized
INFO - 2020-07-06 08:20:34 --> Language Class Initialized
INFO - 2020-07-06 08:20:34 --> Config Class Initialized
INFO - 2020-07-06 08:20:34 --> Loader Class Initialized
INFO - 2020-07-06 08:20:34 --> Helper loaded: url_helper
INFO - 2020-07-06 08:20:34 --> Helper loaded: main_helper
INFO - 2020-07-06 08:20:34 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:20:34 --> Controller Class Initialized
INFO - 2020-07-06 08:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:20:34 --> Pagination Class Initialized
ERROR - 2020-07-06 08:20:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:20:34 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:20:34 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:20:34 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:20:34 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:20:34 --> Final output sent to browser
DEBUG - 2020-07-06 08:20:34 --> Total execution time: 0.0074
INFO - 2020-07-06 08:20:56 --> Config Class Initialized
INFO - 2020-07-06 08:20:56 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:20:56 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:20:56 --> Utf8 Class Initialized
INFO - 2020-07-06 08:20:56 --> URI Class Initialized
INFO - 2020-07-06 08:20:56 --> Router Class Initialized
INFO - 2020-07-06 08:20:56 --> Output Class Initialized
INFO - 2020-07-06 08:20:56 --> Security Class Initialized
DEBUG - 2020-07-06 08:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:20:56 --> Input Class Initialized
INFO - 2020-07-06 08:20:56 --> Language Class Initialized
INFO - 2020-07-06 08:20:56 --> Language Class Initialized
INFO - 2020-07-06 08:20:56 --> Config Class Initialized
INFO - 2020-07-06 08:20:56 --> Loader Class Initialized
INFO - 2020-07-06 08:20:56 --> Helper loaded: url_helper
INFO - 2020-07-06 08:20:56 --> Helper loaded: main_helper
INFO - 2020-07-06 08:20:56 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:20:56 --> Controller Class Initialized
INFO - 2020-07-06 08:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:20:56 --> Pagination Class Initialized
ERROR - 2020-07-06 08:20:56 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:20:56 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:20:56 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:20:56 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:20:56 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:20:56 --> Final output sent to browser
DEBUG - 2020-07-06 08:20:56 --> Total execution time: 0.0065
INFO - 2020-07-06 08:21:27 --> Config Class Initialized
INFO - 2020-07-06 08:21:27 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:21:27 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:21:27 --> Utf8 Class Initialized
INFO - 2020-07-06 08:21:27 --> URI Class Initialized
INFO - 2020-07-06 08:21:27 --> Router Class Initialized
INFO - 2020-07-06 08:21:27 --> Output Class Initialized
INFO - 2020-07-06 08:21:27 --> Security Class Initialized
DEBUG - 2020-07-06 08:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:21:27 --> Input Class Initialized
INFO - 2020-07-06 08:21:27 --> Language Class Initialized
INFO - 2020-07-06 08:21:27 --> Language Class Initialized
INFO - 2020-07-06 08:21:27 --> Config Class Initialized
INFO - 2020-07-06 08:21:27 --> Loader Class Initialized
INFO - 2020-07-06 08:21:27 --> Helper loaded: url_helper
INFO - 2020-07-06 08:21:27 --> Helper loaded: main_helper
INFO - 2020-07-06 08:21:27 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:21:27 --> Controller Class Initialized
INFO - 2020-07-06 08:21:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:21:27 --> Pagination Class Initialized
ERROR - 2020-07-06 08:21:27 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:21:27 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:21:27 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:21:27 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:21:27 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:21:27 --> Final output sent to browser
DEBUG - 2020-07-06 08:21:27 --> Total execution time: 0.0147
INFO - 2020-07-06 08:22:27 --> Config Class Initialized
INFO - 2020-07-06 08:22:27 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:22:27 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:22:27 --> Utf8 Class Initialized
INFO - 2020-07-06 08:22:27 --> URI Class Initialized
INFO - 2020-07-06 08:22:27 --> Router Class Initialized
INFO - 2020-07-06 08:22:27 --> Output Class Initialized
INFO - 2020-07-06 08:22:27 --> Security Class Initialized
DEBUG - 2020-07-06 08:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:22:27 --> Input Class Initialized
INFO - 2020-07-06 08:22:27 --> Language Class Initialized
INFO - 2020-07-06 08:22:27 --> Language Class Initialized
INFO - 2020-07-06 08:22:27 --> Config Class Initialized
INFO - 2020-07-06 08:22:27 --> Loader Class Initialized
INFO - 2020-07-06 08:22:27 --> Helper loaded: url_helper
INFO - 2020-07-06 08:22:27 --> Helper loaded: main_helper
INFO - 2020-07-06 08:22:27 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:22:27 --> Controller Class Initialized
INFO - 2020-07-06 08:22:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:22:27 --> Pagination Class Initialized
ERROR - 2020-07-06 08:22:27 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:22:27 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:22:27 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:22:28 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:22:28 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:22:28 --> Final output sent to browser
DEBUG - 2020-07-06 08:22:28 --> Total execution time: 1.2719
INFO - 2020-07-06 08:23:12 --> Config Class Initialized
INFO - 2020-07-06 08:23:12 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:23:12 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:23:12 --> Utf8 Class Initialized
INFO - 2020-07-06 08:23:12 --> URI Class Initialized
INFO - 2020-07-06 08:23:12 --> Router Class Initialized
INFO - 2020-07-06 08:23:12 --> Output Class Initialized
INFO - 2020-07-06 08:23:12 --> Security Class Initialized
DEBUG - 2020-07-06 08:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:23:12 --> Input Class Initialized
INFO - 2020-07-06 08:23:12 --> Language Class Initialized
INFO - 2020-07-06 08:23:12 --> Language Class Initialized
INFO - 2020-07-06 08:23:12 --> Config Class Initialized
INFO - 2020-07-06 08:23:12 --> Loader Class Initialized
INFO - 2020-07-06 08:23:12 --> Helper loaded: url_helper
INFO - 2020-07-06 08:23:12 --> Helper loaded: main_helper
INFO - 2020-07-06 08:23:12 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:23:12 --> Controller Class Initialized
INFO - 2020-07-06 08:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:23:12 --> Pagination Class Initialized
ERROR - 2020-07-06 08:23:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:23:12 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:23:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:23:14 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-06 08:23:14 --> Final output sent to browser
DEBUG - 2020-07-06 08:23:14 --> Total execution time: 1.3125
INFO - 2020-07-06 08:26:09 --> Config Class Initialized
INFO - 2020-07-06 08:26:09 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:26:09 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:26:09 --> Utf8 Class Initialized
INFO - 2020-07-06 08:26:09 --> URI Class Initialized
INFO - 2020-07-06 08:26:09 --> Router Class Initialized
INFO - 2020-07-06 08:26:09 --> Output Class Initialized
INFO - 2020-07-06 08:26:09 --> Security Class Initialized
DEBUG - 2020-07-06 08:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:26:09 --> Input Class Initialized
INFO - 2020-07-06 08:26:09 --> Language Class Initialized
INFO - 2020-07-06 08:26:09 --> Language Class Initialized
INFO - 2020-07-06 08:26:09 --> Config Class Initialized
INFO - 2020-07-06 08:26:09 --> Loader Class Initialized
INFO - 2020-07-06 08:26:09 --> Helper loaded: url_helper
INFO - 2020-07-06 08:26:09 --> Helper loaded: main_helper
INFO - 2020-07-06 08:26:09 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:26:09 --> Controller Class Initialized
INFO - 2020-07-06 08:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:26:09 --> Pagination Class Initialized
ERROR - 2020-07-06 08:26:09 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:26:09 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:26:09 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:26:09 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:26:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:26:09 --> Final output sent to browser
DEBUG - 2020-07-06 08:26:09 --> Total execution time: 0.0169
INFO - 2020-07-06 08:27:35 --> Config Class Initialized
INFO - 2020-07-06 08:27:35 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:27:35 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:27:35 --> Utf8 Class Initialized
INFO - 2020-07-06 08:27:35 --> URI Class Initialized
INFO - 2020-07-06 08:27:35 --> Router Class Initialized
INFO - 2020-07-06 08:27:35 --> Output Class Initialized
INFO - 2020-07-06 08:27:35 --> Security Class Initialized
DEBUG - 2020-07-06 08:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:27:35 --> Input Class Initialized
INFO - 2020-07-06 08:27:35 --> Language Class Initialized
INFO - 2020-07-06 08:27:35 --> Language Class Initialized
INFO - 2020-07-06 08:27:35 --> Config Class Initialized
INFO - 2020-07-06 08:27:35 --> Loader Class Initialized
INFO - 2020-07-06 08:27:35 --> Helper loaded: url_helper
INFO - 2020-07-06 08:27:35 --> Helper loaded: main_helper
INFO - 2020-07-06 08:27:35 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:27:35 --> Controller Class Initialized
INFO - 2020-07-06 08:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:27:35 --> Pagination Class Initialized
ERROR - 2020-07-06 08:27:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:27:35 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:27:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:27:37 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:27:37 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:27:37 --> Final output sent to browser
DEBUG - 2020-07-06 08:27:37 --> Total execution time: 1.3988
INFO - 2020-07-06 08:27:40 --> Config Class Initialized
INFO - 2020-07-06 08:27:40 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:27:40 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:27:40 --> Utf8 Class Initialized
INFO - 2020-07-06 08:27:40 --> URI Class Initialized
INFO - 2020-07-06 08:27:40 --> Router Class Initialized
INFO - 2020-07-06 08:27:40 --> Output Class Initialized
INFO - 2020-07-06 08:27:40 --> Security Class Initialized
DEBUG - 2020-07-06 08:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:27:40 --> Input Class Initialized
INFO - 2020-07-06 08:27:40 --> Language Class Initialized
INFO - 2020-07-06 08:27:40 --> Language Class Initialized
INFO - 2020-07-06 08:27:40 --> Config Class Initialized
INFO - 2020-07-06 08:27:40 --> Loader Class Initialized
INFO - 2020-07-06 08:27:40 --> Helper loaded: url_helper
INFO - 2020-07-06 08:27:40 --> Helper loaded: main_helper
INFO - 2020-07-06 08:27:40 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:27:40 --> Controller Class Initialized
DEBUG - 2020-07-06 08:27:40 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-06 08:27:40 --> Final output sent to browser
DEBUG - 2020-07-06 08:27:40 --> Total execution time: 0.0154
INFO - 2020-07-06 08:28:05 --> Config Class Initialized
INFO - 2020-07-06 08:28:05 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:28:05 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:28:05 --> Utf8 Class Initialized
INFO - 2020-07-06 08:28:05 --> URI Class Initialized
DEBUG - 2020-07-06 08:28:05 --> No URI present. Default controller set.
INFO - 2020-07-06 08:28:05 --> Router Class Initialized
INFO - 2020-07-06 08:28:05 --> Output Class Initialized
INFO - 2020-07-06 08:28:05 --> Security Class Initialized
DEBUG - 2020-07-06 08:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:28:05 --> Input Class Initialized
INFO - 2020-07-06 08:28:05 --> Language Class Initialized
INFO - 2020-07-06 08:28:05 --> Language Class Initialized
INFO - 2020-07-06 08:28:05 --> Config Class Initialized
INFO - 2020-07-06 08:28:05 --> Loader Class Initialized
INFO - 2020-07-06 08:28:05 --> Helper loaded: url_helper
INFO - 2020-07-06 08:28:05 --> Helper loaded: main_helper
INFO - 2020-07-06 08:28:05 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:28:05 --> Controller Class Initialized
DEBUG - 2020-07-06 08:28:05 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-06 08:28:05 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:28:05 --> Final output sent to browser
DEBUG - 2020-07-06 08:28:05 --> Total execution time: 0.0051
INFO - 2020-07-06 08:29:26 --> Config Class Initialized
INFO - 2020-07-06 08:29:26 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:29:26 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:29:26 --> Utf8 Class Initialized
INFO - 2020-07-06 08:29:26 --> URI Class Initialized
INFO - 2020-07-06 08:29:26 --> Router Class Initialized
INFO - 2020-07-06 08:29:26 --> Output Class Initialized
INFO - 2020-07-06 08:29:26 --> Security Class Initialized
DEBUG - 2020-07-06 08:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:29:26 --> Input Class Initialized
INFO - 2020-07-06 08:29:26 --> Language Class Initialized
INFO - 2020-07-06 08:29:26 --> Language Class Initialized
INFO - 2020-07-06 08:29:26 --> Config Class Initialized
INFO - 2020-07-06 08:29:26 --> Loader Class Initialized
INFO - 2020-07-06 08:29:26 --> Helper loaded: url_helper
INFO - 2020-07-06 08:29:26 --> Helper loaded: main_helper
INFO - 2020-07-06 08:29:26 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:29:26 --> Controller Class Initialized
INFO - 2020-07-06 08:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:29:26 --> Pagination Class Initialized
ERROR - 2020-07-06 08:29:26 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:29:26 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:29:26 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:29:26 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:29:26 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:29:26 --> Final output sent to browser
DEBUG - 2020-07-06 08:29:26 --> Total execution time: 0.0045
INFO - 2020-07-06 08:35:48 --> Config Class Initialized
INFO - 2020-07-06 08:35:48 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:35:48 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:35:48 --> Utf8 Class Initialized
INFO - 2020-07-06 08:35:48 --> URI Class Initialized
INFO - 2020-07-06 08:35:48 --> Router Class Initialized
INFO - 2020-07-06 08:35:48 --> Output Class Initialized
INFO - 2020-07-06 08:35:48 --> Security Class Initialized
DEBUG - 2020-07-06 08:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:35:48 --> Input Class Initialized
INFO - 2020-07-06 08:35:48 --> Language Class Initialized
INFO - 2020-07-06 08:35:48 --> Language Class Initialized
INFO - 2020-07-06 08:35:48 --> Config Class Initialized
INFO - 2020-07-06 08:35:48 --> Loader Class Initialized
INFO - 2020-07-06 08:35:48 --> Helper loaded: url_helper
INFO - 2020-07-06 08:35:48 --> Helper loaded: main_helper
INFO - 2020-07-06 08:35:48 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:35:48 --> Controller Class Initialized
INFO - 2020-07-06 08:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:35:48 --> Pagination Class Initialized
ERROR - 2020-07-06 08:35:48 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:35:48 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:35:48 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:35:49 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:35:49 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:35:49 --> Final output sent to browser
DEBUG - 2020-07-06 08:35:49 --> Total execution time: 1.3891
INFO - 2020-07-06 08:37:06 --> Config Class Initialized
INFO - 2020-07-06 08:37:06 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:37:06 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:37:06 --> Utf8 Class Initialized
INFO - 2020-07-06 08:37:06 --> URI Class Initialized
INFO - 2020-07-06 08:37:06 --> Router Class Initialized
INFO - 2020-07-06 08:37:06 --> Output Class Initialized
INFO - 2020-07-06 08:37:06 --> Security Class Initialized
DEBUG - 2020-07-06 08:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:37:06 --> Input Class Initialized
INFO - 2020-07-06 08:37:06 --> Language Class Initialized
INFO - 2020-07-06 08:37:06 --> Language Class Initialized
INFO - 2020-07-06 08:37:06 --> Config Class Initialized
INFO - 2020-07-06 08:37:06 --> Loader Class Initialized
INFO - 2020-07-06 08:37:06 --> Helper loaded: url_helper
INFO - 2020-07-06 08:37:06 --> Helper loaded: main_helper
INFO - 2020-07-06 08:37:06 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:37:06 --> Controller Class Initialized
INFO - 2020-07-06 08:37:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:37:06 --> Pagination Class Initialized
ERROR - 2020-07-06 08:37:06 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:37:06 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:37:06 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:37:06 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:37:06 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:37:06 --> Final output sent to browser
DEBUG - 2020-07-06 08:37:06 --> Total execution time: 0.0052
INFO - 2020-07-06 08:37:10 --> Config Class Initialized
INFO - 2020-07-06 08:37:10 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:37:10 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:37:10 --> Utf8 Class Initialized
INFO - 2020-07-06 08:37:10 --> URI Class Initialized
INFO - 2020-07-06 08:37:10 --> Router Class Initialized
INFO - 2020-07-06 08:37:10 --> Output Class Initialized
INFO - 2020-07-06 08:37:10 --> Security Class Initialized
DEBUG - 2020-07-06 08:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:37:10 --> Input Class Initialized
INFO - 2020-07-06 08:37:10 --> Language Class Initialized
INFO - 2020-07-06 08:37:10 --> Language Class Initialized
INFO - 2020-07-06 08:37:10 --> Config Class Initialized
INFO - 2020-07-06 08:37:10 --> Loader Class Initialized
INFO - 2020-07-06 08:37:10 --> Helper loaded: url_helper
INFO - 2020-07-06 08:37:10 --> Helper loaded: main_helper
INFO - 2020-07-06 08:37:10 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:37:10 --> Controller Class Initialized
DEBUG - 2020-07-06 08:37:10 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-06 08:37:10 --> Final output sent to browser
DEBUG - 2020-07-06 08:37:10 --> Total execution time: 0.0097
INFO - 2020-07-06 08:37:15 --> Config Class Initialized
INFO - 2020-07-06 08:37:15 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:37:15 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:37:15 --> Utf8 Class Initialized
INFO - 2020-07-06 08:37:15 --> URI Class Initialized
INFO - 2020-07-06 08:37:15 --> Router Class Initialized
INFO - 2020-07-06 08:37:15 --> Output Class Initialized
INFO - 2020-07-06 08:37:15 --> Security Class Initialized
DEBUG - 2020-07-06 08:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:37:15 --> Input Class Initialized
INFO - 2020-07-06 08:37:15 --> Language Class Initialized
INFO - 2020-07-06 08:37:15 --> Language Class Initialized
INFO - 2020-07-06 08:37:15 --> Config Class Initialized
INFO - 2020-07-06 08:37:15 --> Loader Class Initialized
INFO - 2020-07-06 08:37:15 --> Helper loaded: url_helper
INFO - 2020-07-06 08:37:15 --> Helper loaded: main_helper
INFO - 2020-07-06 08:37:15 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:37:15 --> Controller Class Initialized
INFO - 2020-07-06 08:37:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:37:15 --> Pagination Class Initialized
ERROR - 2020-07-06 08:37:15 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:37:15 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:37:15 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:37:15 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:37:15 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:37:15 --> Final output sent to browser
DEBUG - 2020-07-06 08:37:15 --> Total execution time: 0.0063
INFO - 2020-07-06 08:37:21 --> Config Class Initialized
INFO - 2020-07-06 08:37:21 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:37:21 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:37:21 --> Utf8 Class Initialized
INFO - 2020-07-06 08:37:21 --> URI Class Initialized
INFO - 2020-07-06 08:37:21 --> Router Class Initialized
INFO - 2020-07-06 08:37:21 --> Output Class Initialized
INFO - 2020-07-06 08:37:21 --> Security Class Initialized
DEBUG - 2020-07-06 08:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:37:21 --> Input Class Initialized
INFO - 2020-07-06 08:37:21 --> Language Class Initialized
INFO - 2020-07-06 08:37:21 --> Language Class Initialized
INFO - 2020-07-06 08:37:21 --> Config Class Initialized
INFO - 2020-07-06 08:37:21 --> Loader Class Initialized
INFO - 2020-07-06 08:37:21 --> Helper loaded: url_helper
INFO - 2020-07-06 08:37:21 --> Helper loaded: main_helper
INFO - 2020-07-06 08:37:21 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:37:21 --> Controller Class Initialized
DEBUG - 2020-07-06 08:37:21 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-06 08:37:21 --> Final output sent to browser
DEBUG - 2020-07-06 08:37:21 --> Total execution time: 0.0055
INFO - 2020-07-06 08:54:23 --> Config Class Initialized
INFO - 2020-07-06 08:54:23 --> Hooks Class Initialized
DEBUG - 2020-07-06 08:54:23 --> UTF-8 Support Enabled
INFO - 2020-07-06 08:54:23 --> Utf8 Class Initialized
INFO - 2020-07-06 08:54:23 --> URI Class Initialized
INFO - 2020-07-06 08:54:23 --> Router Class Initialized
INFO - 2020-07-06 08:54:23 --> Output Class Initialized
INFO - 2020-07-06 08:54:23 --> Security Class Initialized
DEBUG - 2020-07-06 08:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 08:54:23 --> Input Class Initialized
INFO - 2020-07-06 08:54:23 --> Language Class Initialized
INFO - 2020-07-06 08:54:23 --> Language Class Initialized
INFO - 2020-07-06 08:54:23 --> Config Class Initialized
INFO - 2020-07-06 08:54:23 --> Loader Class Initialized
INFO - 2020-07-06 08:54:23 --> Helper loaded: url_helper
INFO - 2020-07-06 08:54:23 --> Helper loaded: main_helper
INFO - 2020-07-06 08:54:23 --> Database Driver Class Initialized
DEBUG - 2020-07-06 08:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 08:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 08:54:23 --> Controller Class Initialized
INFO - 2020-07-06 08:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 08:54:23 --> Pagination Class Initialized
ERROR - 2020-07-06 08:54:23 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 08:54:23 --> Helper loaded: file_helper
DEBUG - 2020-07-06 08:54:23 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 08:54:24 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 08:54:24 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 08:54:24 --> Final output sent to browser
DEBUG - 2020-07-06 08:54:24 --> Total execution time: 1.3329
INFO - 2020-07-06 12:46:22 --> Config Class Initialized
INFO - 2020-07-06 12:46:22 --> Hooks Class Initialized
DEBUG - 2020-07-06 12:46:22 --> UTF-8 Support Enabled
INFO - 2020-07-06 12:46:22 --> Utf8 Class Initialized
INFO - 2020-07-06 12:46:22 --> URI Class Initialized
INFO - 2020-07-06 12:46:22 --> Router Class Initialized
INFO - 2020-07-06 12:46:22 --> Output Class Initialized
INFO - 2020-07-06 12:46:22 --> Security Class Initialized
DEBUG - 2020-07-06 12:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 12:46:22 --> Input Class Initialized
INFO - 2020-07-06 12:46:22 --> Language Class Initialized
INFO - 2020-07-06 12:46:22 --> Language Class Initialized
INFO - 2020-07-06 12:46:22 --> Config Class Initialized
INFO - 2020-07-06 12:46:22 --> Loader Class Initialized
INFO - 2020-07-06 12:46:22 --> Helper loaded: url_helper
INFO - 2020-07-06 12:46:22 --> Helper loaded: main_helper
INFO - 2020-07-06 12:46:22 --> Database Driver Class Initialized
DEBUG - 2020-07-06 12:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 12:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 12:46:22 --> Controller Class Initialized
INFO - 2020-07-06 12:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 12:46:22 --> Pagination Class Initialized
ERROR - 2020-07-06 12:46:22 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 12:46:22 --> Helper loaded: file_helper
DEBUG - 2020-07-06 12:46:22 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 12:46:23 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 12:46:23 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 12:46:23 --> Final output sent to browser
DEBUG - 2020-07-06 12:46:23 --> Total execution time: 1.5311
INFO - 2020-07-06 13:09:24 --> Config Class Initialized
INFO - 2020-07-06 13:09:24 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:09:24 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:09:24 --> Utf8 Class Initialized
INFO - 2020-07-06 13:09:24 --> URI Class Initialized
INFO - 2020-07-06 13:09:24 --> Router Class Initialized
INFO - 2020-07-06 13:09:24 --> Output Class Initialized
INFO - 2020-07-06 13:09:24 --> Security Class Initialized
DEBUG - 2020-07-06 13:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:09:24 --> Input Class Initialized
INFO - 2020-07-06 13:09:24 --> Language Class Initialized
INFO - 2020-07-06 13:09:24 --> Language Class Initialized
INFO - 2020-07-06 13:09:24 --> Config Class Initialized
INFO - 2020-07-06 13:09:24 --> Loader Class Initialized
INFO - 2020-07-06 13:09:24 --> Helper loaded: url_helper
INFO - 2020-07-06 13:09:24 --> Helper loaded: main_helper
INFO - 2020-07-06 13:09:24 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:09:24 --> Controller Class Initialized
INFO - 2020-07-06 13:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:09:24 --> Pagination Class Initialized
ERROR - 2020-07-06 13:09:24 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:09:24 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:09:24 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:09:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:09:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:09:24 --> Encryption Class Initialized
INFO - 2020-07-06 13:09:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:11:41 --> Config Class Initialized
INFO - 2020-07-06 13:11:41 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:11:41 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:11:41 --> Utf8 Class Initialized
INFO - 2020-07-06 13:11:41 --> URI Class Initialized
INFO - 2020-07-06 13:11:41 --> Router Class Initialized
INFO - 2020-07-06 13:11:41 --> Output Class Initialized
INFO - 2020-07-06 13:11:41 --> Security Class Initialized
DEBUG - 2020-07-06 13:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:11:41 --> Input Class Initialized
INFO - 2020-07-06 13:11:41 --> Language Class Initialized
INFO - 2020-07-06 13:11:41 --> Language Class Initialized
INFO - 2020-07-06 13:11:41 --> Config Class Initialized
INFO - 2020-07-06 13:11:41 --> Loader Class Initialized
INFO - 2020-07-06 13:11:41 --> Helper loaded: url_helper
INFO - 2020-07-06 13:11:41 --> Helper loaded: main_helper
INFO - 2020-07-06 13:11:41 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:11:41 --> Controller Class Initialized
INFO - 2020-07-06 13:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:11:41 --> Pagination Class Initialized
ERROR - 2020-07-06 13:11:41 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:11:41 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:11:41 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:11:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:11:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:11:41 --> Encryption Class Initialized
INFO - 2020-07-06 13:11:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:12:02 --> Config Class Initialized
INFO - 2020-07-06 13:12:02 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:12:02 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:12:02 --> Utf8 Class Initialized
INFO - 2020-07-06 13:12:02 --> URI Class Initialized
INFO - 2020-07-06 13:12:02 --> Router Class Initialized
INFO - 2020-07-06 13:12:02 --> Output Class Initialized
INFO - 2020-07-06 13:12:02 --> Security Class Initialized
DEBUG - 2020-07-06 13:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:12:02 --> Input Class Initialized
INFO - 2020-07-06 13:12:02 --> Language Class Initialized
INFO - 2020-07-06 13:12:02 --> Language Class Initialized
INFO - 2020-07-06 13:12:02 --> Config Class Initialized
INFO - 2020-07-06 13:12:02 --> Loader Class Initialized
INFO - 2020-07-06 13:12:02 --> Helper loaded: url_helper
INFO - 2020-07-06 13:12:02 --> Helper loaded: main_helper
INFO - 2020-07-06 13:12:02 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:12:02 --> Controller Class Initialized
INFO - 2020-07-06 13:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:12:02 --> Pagination Class Initialized
ERROR - 2020-07-06 13:12:02 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:12:02 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:12:02 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:12:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:12:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:12:02 --> Encryption Class Initialized
INFO - 2020-07-06 13:12:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:14:22 --> Config Class Initialized
INFO - 2020-07-06 13:14:22 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:14:22 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:14:22 --> Utf8 Class Initialized
INFO - 2020-07-06 13:14:22 --> URI Class Initialized
INFO - 2020-07-06 13:14:22 --> Router Class Initialized
INFO - 2020-07-06 13:14:22 --> Output Class Initialized
INFO - 2020-07-06 13:14:22 --> Security Class Initialized
DEBUG - 2020-07-06 13:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:14:22 --> Input Class Initialized
INFO - 2020-07-06 13:14:22 --> Language Class Initialized
INFO - 2020-07-06 13:14:22 --> Language Class Initialized
INFO - 2020-07-06 13:14:22 --> Config Class Initialized
INFO - 2020-07-06 13:14:22 --> Loader Class Initialized
INFO - 2020-07-06 13:14:22 --> Helper loaded: url_helper
INFO - 2020-07-06 13:14:22 --> Helper loaded: main_helper
INFO - 2020-07-06 13:14:22 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:14:22 --> Controller Class Initialized
INFO - 2020-07-06 13:14:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:14:22 --> Pagination Class Initialized
ERROR - 2020-07-06 13:14:22 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:14:22 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:14:22 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:14:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:14:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:14:22 --> Encryption Class Initialized
INFO - 2020-07-06 13:14:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 13:14:24 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 13:14:24 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 13:14:24 --> Final output sent to browser
DEBUG - 2020-07-06 13:14:24 --> Total execution time: 1.4117
INFO - 2020-07-06 13:16:02 --> Config Class Initialized
INFO - 2020-07-06 13:16:02 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:16:02 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:16:02 --> Utf8 Class Initialized
INFO - 2020-07-06 13:16:02 --> URI Class Initialized
INFO - 2020-07-06 13:16:02 --> Router Class Initialized
INFO - 2020-07-06 13:16:02 --> Output Class Initialized
INFO - 2020-07-06 13:16:02 --> Security Class Initialized
DEBUG - 2020-07-06 13:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:16:02 --> Input Class Initialized
INFO - 2020-07-06 13:16:02 --> Language Class Initialized
INFO - 2020-07-06 13:16:02 --> Language Class Initialized
INFO - 2020-07-06 13:16:02 --> Config Class Initialized
INFO - 2020-07-06 13:16:02 --> Loader Class Initialized
INFO - 2020-07-06 13:16:02 --> Helper loaded: url_helper
INFO - 2020-07-06 13:16:02 --> Helper loaded: main_helper
INFO - 2020-07-06 13:16:02 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:16:02 --> Controller Class Initialized
INFO - 2020-07-06 13:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:16:02 --> Pagination Class Initialized
ERROR - 2020-07-06 13:16:02 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:16:02 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:16:02 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:16:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:16:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:16:02 --> Encryption Class Initialized
INFO - 2020-07-06 13:16:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 13:16:02 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 13:16:02 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 13:16:02 --> Final output sent to browser
DEBUG - 2020-07-06 13:16:02 --> Total execution time: 0.0059
INFO - 2020-07-06 13:16:05 --> Config Class Initialized
INFO - 2020-07-06 13:16:05 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:16:05 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:16:05 --> Utf8 Class Initialized
INFO - 2020-07-06 13:34:16 --> Config Class Initialized
INFO - 2020-07-06 13:34:16 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:34:16 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:34:16 --> Utf8 Class Initialized
INFO - 2020-07-06 13:34:26 --> Config Class Initialized
INFO - 2020-07-06 13:34:26 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:34:26 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:34:26 --> Utf8 Class Initialized
INFO - 2020-07-06 13:34:26 --> URI Class Initialized
INFO - 2020-07-06 13:34:26 --> Router Class Initialized
INFO - 2020-07-06 13:34:26 --> Output Class Initialized
INFO - 2020-07-06 13:34:26 --> Security Class Initialized
DEBUG - 2020-07-06 13:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:34:26 --> Input Class Initialized
INFO - 2020-07-06 13:34:26 --> Language Class Initialized
INFO - 2020-07-06 13:34:26 --> Language Class Initialized
INFO - 2020-07-06 13:34:26 --> Config Class Initialized
INFO - 2020-07-06 13:34:26 --> Loader Class Initialized
INFO - 2020-07-06 13:34:26 --> Helper loaded: url_helper
INFO - 2020-07-06 13:34:26 --> Helper loaded: main_helper
INFO - 2020-07-06 13:34:26 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:34:26 --> Controller Class Initialized
INFO - 2020-07-06 13:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:34:26 --> Pagination Class Initialized
ERROR - 2020-07-06 13:34:26 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:34:26 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:34:26 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:34:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:34:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:34:26 --> Encryption Class Initialized
INFO - 2020-07-06 13:34:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 13:34:27 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 13:34:27 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 13:34:27 --> Final output sent to browser
DEBUG - 2020-07-06 13:34:27 --> Total execution time: 1.4075
INFO - 2020-07-06 13:34:37 --> Config Class Initialized
INFO - 2020-07-06 13:34:37 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:34:37 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:34:37 --> Utf8 Class Initialized
INFO - 2020-07-06 13:34:37 --> URI Class Initialized
INFO - 2020-07-06 13:34:37 --> Router Class Initialized
INFO - 2020-07-06 13:34:37 --> Output Class Initialized
INFO - 2020-07-06 13:34:37 --> Security Class Initialized
DEBUG - 2020-07-06 13:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:34:37 --> Input Class Initialized
INFO - 2020-07-06 13:34:37 --> Language Class Initialized
INFO - 2020-07-06 13:34:37 --> Language Class Initialized
INFO - 2020-07-06 13:34:37 --> Config Class Initialized
INFO - 2020-07-06 13:34:37 --> Loader Class Initialized
INFO - 2020-07-06 13:34:37 --> Helper loaded: url_helper
INFO - 2020-07-06 13:34:37 --> Helper loaded: main_helper
INFO - 2020-07-06 13:34:37 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:34:37 --> Controller Class Initialized
DEBUG - 2020-07-06 13:34:37 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-06 13:34:37 --> Final output sent to browser
DEBUG - 2020-07-06 13:34:37 --> Total execution time: 0.0070
INFO - 2020-07-06 13:35:34 --> Config Class Initialized
INFO - 2020-07-06 13:35:34 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:35:34 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:35:34 --> Utf8 Class Initialized
INFO - 2020-07-06 13:35:34 --> URI Class Initialized
INFO - 2020-07-06 13:35:34 --> Router Class Initialized
INFO - 2020-07-06 13:35:34 --> Output Class Initialized
INFO - 2020-07-06 13:35:34 --> Security Class Initialized
DEBUG - 2020-07-06 13:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:35:34 --> Input Class Initialized
INFO - 2020-07-06 13:35:34 --> Language Class Initialized
INFO - 2020-07-06 13:35:34 --> Language Class Initialized
INFO - 2020-07-06 13:35:34 --> Config Class Initialized
INFO - 2020-07-06 13:35:34 --> Loader Class Initialized
INFO - 2020-07-06 13:35:34 --> Helper loaded: url_helper
INFO - 2020-07-06 13:35:34 --> Helper loaded: main_helper
INFO - 2020-07-06 13:35:34 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:35:34 --> Controller Class Initialized
INFO - 2020-07-06 13:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:35:34 --> Pagination Class Initialized
ERROR - 2020-07-06 13:35:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:35:34 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:35:34 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:35:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:35:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:35:34 --> Encryption Class Initialized
INFO - 2020-07-06 13:35:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 13:35:34 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 13:35:34 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 13:35:34 --> Final output sent to browser
DEBUG - 2020-07-06 13:35:34 --> Total execution time: 0.0061
INFO - 2020-07-06 13:35:37 --> Config Class Initialized
INFO - 2020-07-06 13:35:37 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:35:37 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:35:37 --> Utf8 Class Initialized
INFO - 2020-07-06 13:35:37 --> URI Class Initialized
INFO - 2020-07-06 13:35:37 --> Router Class Initialized
INFO - 2020-07-06 13:35:37 --> Output Class Initialized
INFO - 2020-07-06 13:35:37 --> Security Class Initialized
DEBUG - 2020-07-06 13:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:35:37 --> Input Class Initialized
INFO - 2020-07-06 13:35:37 --> Language Class Initialized
INFO - 2020-07-06 13:35:37 --> Language Class Initialized
INFO - 2020-07-06 13:35:37 --> Config Class Initialized
INFO - 2020-07-06 13:35:37 --> Loader Class Initialized
INFO - 2020-07-06 13:35:37 --> Helper loaded: url_helper
INFO - 2020-07-06 13:35:37 --> Helper loaded: main_helper
INFO - 2020-07-06 13:35:37 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:35:37 --> Controller Class Initialized
INFO - 2020-07-06 13:35:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:35:37 --> Pagination Class Initialized
ERROR - 2020-07-06 13:35:37 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:35:37 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:35:37 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:35:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:35:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:35:37 --> Encryption Class Initialized
INFO - 2020-07-06 13:35:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-06 13:35:42 --> Severity: Notice --> Undefined property: stdClass::$title /var/www/journal/application/libraries/ConvertResponse.php 104
ERROR - 2020-07-06 13:35:42 --> Severity: error --> Exception: Argument 1 passed to ConvertResponse::_resolve_title_crf() must be of the type array, null given, called in /var/www/journal/application/libraries/ConvertResponse.php on line 104 /var/www/journal/application/libraries/ConvertResponse.php 48
INFO - 2020-07-06 13:36:35 --> Config Class Initialized
INFO - 2020-07-06 13:36:35 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:36:35 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:36:35 --> Utf8 Class Initialized
INFO - 2020-07-06 13:36:35 --> URI Class Initialized
INFO - 2020-07-06 13:36:35 --> Router Class Initialized
INFO - 2020-07-06 13:36:35 --> Output Class Initialized
INFO - 2020-07-06 13:36:35 --> Security Class Initialized
DEBUG - 2020-07-06 13:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:36:35 --> Input Class Initialized
INFO - 2020-07-06 13:36:35 --> Language Class Initialized
INFO - 2020-07-06 13:36:35 --> Language Class Initialized
INFO - 2020-07-06 13:36:35 --> Config Class Initialized
INFO - 2020-07-06 13:36:35 --> Loader Class Initialized
INFO - 2020-07-06 13:36:35 --> Helper loaded: url_helper
INFO - 2020-07-06 13:36:35 --> Helper loaded: main_helper
INFO - 2020-07-06 13:36:35 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:36:35 --> Controller Class Initialized
INFO - 2020-07-06 13:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:36:35 --> Pagination Class Initialized
ERROR - 2020-07-06 13:36:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:36:35 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:36:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:36:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:36:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:36:35 --> Encryption Class Initialized
INFO - 2020-07-06 13:36:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-06 13:36:40 --> Severity: Notice --> Undefined property: stdClass::$DOI /var/www/journal/application/libraries/ConvertResponse.php 105
ERROR - 2020-07-06 13:36:40 --> Severity: Notice --> Undefined property: DOMDocument::$createElement /var/www/journal/application/modules/landing/views/xml_export_v.php 11
ERROR - 2020-07-06 13:36:40 --> Severity: error --> Exception: Class name must be a valid object or a string /var/www/journal/application/modules/landing/views/xml_export_v.php 11
INFO - 2020-07-06 13:37:29 --> Config Class Initialized
INFO - 2020-07-06 13:37:29 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:37:29 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:37:29 --> Utf8 Class Initialized
INFO - 2020-07-06 13:37:29 --> URI Class Initialized
INFO - 2020-07-06 13:37:29 --> Router Class Initialized
INFO - 2020-07-06 13:37:29 --> Output Class Initialized
INFO - 2020-07-06 13:37:29 --> Security Class Initialized
DEBUG - 2020-07-06 13:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:37:29 --> Input Class Initialized
INFO - 2020-07-06 13:37:29 --> Language Class Initialized
INFO - 2020-07-06 13:37:29 --> Language Class Initialized
INFO - 2020-07-06 13:37:29 --> Config Class Initialized
INFO - 2020-07-06 13:37:29 --> Loader Class Initialized
INFO - 2020-07-06 13:37:29 --> Helper loaded: url_helper
INFO - 2020-07-06 13:37:29 --> Helper loaded: main_helper
INFO - 2020-07-06 13:37:29 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:37:29 --> Controller Class Initialized
INFO - 2020-07-06 13:37:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:37:29 --> Pagination Class Initialized
ERROR - 2020-07-06 13:37:29 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:37:29 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:37:29 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:37:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:37:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:37:29 --> Encryption Class Initialized
INFO - 2020-07-06 13:37:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:37:56 --> Config Class Initialized
INFO - 2020-07-06 13:37:56 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:37:56 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:37:56 --> Utf8 Class Initialized
INFO - 2020-07-06 13:37:56 --> URI Class Initialized
INFO - 2020-07-06 13:37:56 --> Router Class Initialized
INFO - 2020-07-06 13:37:56 --> Output Class Initialized
INFO - 2020-07-06 13:37:56 --> Security Class Initialized
DEBUG - 2020-07-06 13:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:37:56 --> Input Class Initialized
INFO - 2020-07-06 13:37:56 --> Language Class Initialized
INFO - 2020-07-06 13:37:56 --> Language Class Initialized
INFO - 2020-07-06 13:37:56 --> Config Class Initialized
INFO - 2020-07-06 13:37:56 --> Loader Class Initialized
INFO - 2020-07-06 13:37:56 --> Helper loaded: url_helper
INFO - 2020-07-06 13:37:56 --> Helper loaded: main_helper
INFO - 2020-07-06 13:37:56 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:37:56 --> Controller Class Initialized
INFO - 2020-07-06 13:37:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:37:56 --> Pagination Class Initialized
ERROR - 2020-07-06 13:37:56 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:37:56 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:37:56 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:37:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:37:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:37:56 --> Encryption Class Initialized
INFO - 2020-07-06 13:37:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:40:11 --> Config Class Initialized
INFO - 2020-07-06 13:40:11 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:40:11 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:40:11 --> Utf8 Class Initialized
INFO - 2020-07-06 13:40:11 --> URI Class Initialized
INFO - 2020-07-06 13:40:11 --> Router Class Initialized
INFO - 2020-07-06 13:40:11 --> Output Class Initialized
INFO - 2020-07-06 13:40:11 --> Security Class Initialized
DEBUG - 2020-07-06 13:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:40:11 --> Input Class Initialized
INFO - 2020-07-06 13:40:11 --> Language Class Initialized
INFO - 2020-07-06 13:40:11 --> Language Class Initialized
INFO - 2020-07-06 13:40:11 --> Config Class Initialized
INFO - 2020-07-06 13:40:11 --> Loader Class Initialized
INFO - 2020-07-06 13:40:11 --> Helper loaded: url_helper
INFO - 2020-07-06 13:40:11 --> Helper loaded: main_helper
INFO - 2020-07-06 13:40:11 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:40:11 --> Controller Class Initialized
INFO - 2020-07-06 13:40:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:40:11 --> Pagination Class Initialized
ERROR - 2020-07-06 13:40:11 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:40:11 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:40:11 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:40:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:40:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:40:11 --> Encryption Class Initialized
INFO - 2020-07-06 13:40:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:40:49 --> Config Class Initialized
INFO - 2020-07-06 13:40:49 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:40:49 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:40:49 --> Utf8 Class Initialized
INFO - 2020-07-06 13:40:49 --> URI Class Initialized
INFO - 2020-07-06 13:40:49 --> Router Class Initialized
INFO - 2020-07-06 13:40:49 --> Output Class Initialized
INFO - 2020-07-06 13:40:49 --> Security Class Initialized
DEBUG - 2020-07-06 13:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:40:49 --> Input Class Initialized
INFO - 2020-07-06 13:40:49 --> Language Class Initialized
INFO - 2020-07-06 13:40:49 --> Language Class Initialized
INFO - 2020-07-06 13:40:49 --> Config Class Initialized
INFO - 2020-07-06 13:40:49 --> Loader Class Initialized
INFO - 2020-07-06 13:40:49 --> Helper loaded: url_helper
INFO - 2020-07-06 13:40:49 --> Helper loaded: main_helper
INFO - 2020-07-06 13:40:49 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:40:49 --> Controller Class Initialized
INFO - 2020-07-06 13:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:40:49 --> Pagination Class Initialized
ERROR - 2020-07-06 13:40:49 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:40:49 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:40:49 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:40:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:40:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:40:49 --> Encryption Class Initialized
INFO - 2020-07-06 13:40:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:41:03 --> Config Class Initialized
INFO - 2020-07-06 13:41:03 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:41:03 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:41:03 --> Utf8 Class Initialized
INFO - 2020-07-06 13:41:03 --> URI Class Initialized
INFO - 2020-07-06 13:41:03 --> Router Class Initialized
INFO - 2020-07-06 13:41:03 --> Output Class Initialized
INFO - 2020-07-06 13:41:03 --> Security Class Initialized
DEBUG - 2020-07-06 13:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:41:03 --> Input Class Initialized
INFO - 2020-07-06 13:41:03 --> Language Class Initialized
INFO - 2020-07-06 13:41:03 --> Language Class Initialized
INFO - 2020-07-06 13:41:03 --> Config Class Initialized
INFO - 2020-07-06 13:41:03 --> Loader Class Initialized
INFO - 2020-07-06 13:41:03 --> Helper loaded: url_helper
INFO - 2020-07-06 13:41:03 --> Helper loaded: main_helper
INFO - 2020-07-06 13:41:03 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:41:03 --> Controller Class Initialized
INFO - 2020-07-06 13:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:41:03 --> Pagination Class Initialized
ERROR - 2020-07-06 13:41:03 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:41:03 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:41:03 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:41:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:41:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:41:03 --> Encryption Class Initialized
INFO - 2020-07-06 13:41:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:42:12 --> Config Class Initialized
INFO - 2020-07-06 13:42:12 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:42:12 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:42:12 --> Utf8 Class Initialized
INFO - 2020-07-06 13:42:12 --> URI Class Initialized
INFO - 2020-07-06 13:42:12 --> Router Class Initialized
INFO - 2020-07-06 13:42:12 --> Output Class Initialized
INFO - 2020-07-06 13:42:12 --> Security Class Initialized
DEBUG - 2020-07-06 13:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:42:12 --> Input Class Initialized
INFO - 2020-07-06 13:42:12 --> Language Class Initialized
INFO - 2020-07-06 13:42:12 --> Language Class Initialized
INFO - 2020-07-06 13:42:12 --> Config Class Initialized
INFO - 2020-07-06 13:42:12 --> Loader Class Initialized
INFO - 2020-07-06 13:42:12 --> Helper loaded: url_helper
INFO - 2020-07-06 13:42:12 --> Helper loaded: main_helper
INFO - 2020-07-06 13:42:12 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:42:12 --> Controller Class Initialized
INFO - 2020-07-06 13:42:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:42:12 --> Pagination Class Initialized
ERROR - 2020-07-06 13:42:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:42:12 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:42:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:42:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:42:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:42:12 --> Encryption Class Initialized
INFO - 2020-07-06 13:42:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 13:42:14 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 13:42:14 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 13:42:14 --> Final output sent to browser
DEBUG - 2020-07-06 13:42:14 --> Total execution time: 1.3463
INFO - 2020-07-06 13:42:41 --> Config Class Initialized
INFO - 2020-07-06 13:42:41 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:42:41 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:42:41 --> Utf8 Class Initialized
INFO - 2020-07-06 13:42:41 --> URI Class Initialized
INFO - 2020-07-06 13:42:41 --> Router Class Initialized
INFO - 2020-07-06 13:42:41 --> Output Class Initialized
INFO - 2020-07-06 13:42:41 --> Security Class Initialized
DEBUG - 2020-07-06 13:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:42:41 --> Input Class Initialized
INFO - 2020-07-06 13:42:41 --> Language Class Initialized
INFO - 2020-07-06 13:42:41 --> Language Class Initialized
INFO - 2020-07-06 13:42:41 --> Config Class Initialized
INFO - 2020-07-06 13:42:41 --> Loader Class Initialized
INFO - 2020-07-06 13:42:41 --> Helper loaded: url_helper
INFO - 2020-07-06 13:42:41 --> Helper loaded: main_helper
INFO - 2020-07-06 13:42:41 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:42:41 --> Controller Class Initialized
INFO - 2020-07-06 13:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:42:41 --> Pagination Class Initialized
ERROR - 2020-07-06 13:42:41 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:42:41 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:42:41 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:42:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:42:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:42:41 --> Encryption Class Initialized
INFO - 2020-07-06 13:42:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-06 13:42:42 --> Severity: Notice --> Trying to get property 'message' of non-object /var/www/journal/application/modules/landing/controllers/Search.php 175
ERROR - 2020-07-06 13:42:42 --> Severity: error --> Exception: Argument 2 passed to ConvertResponse::convert_detail() must be an object, null given, called in /var/www/journal/application/modules/landing/controllers/Search.php on line 175 /var/www/journal/application/libraries/ConvertResponse.php 89
INFO - 2020-07-06 13:43:31 --> Config Class Initialized
INFO - 2020-07-06 13:43:31 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:43:31 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:43:31 --> Utf8 Class Initialized
INFO - 2020-07-06 13:43:31 --> URI Class Initialized
INFO - 2020-07-06 13:43:31 --> Router Class Initialized
INFO - 2020-07-06 13:43:31 --> Output Class Initialized
INFO - 2020-07-06 13:43:31 --> Security Class Initialized
DEBUG - 2020-07-06 13:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:43:31 --> Input Class Initialized
INFO - 2020-07-06 13:43:31 --> Language Class Initialized
INFO - 2020-07-06 13:43:31 --> Language Class Initialized
INFO - 2020-07-06 13:43:31 --> Config Class Initialized
INFO - 2020-07-06 13:43:31 --> Loader Class Initialized
INFO - 2020-07-06 13:43:31 --> Helper loaded: url_helper
INFO - 2020-07-06 13:43:31 --> Helper loaded: main_helper
INFO - 2020-07-06 13:43:31 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:43:31 --> Controller Class Initialized
INFO - 2020-07-06 13:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:43:31 --> Pagination Class Initialized
ERROR - 2020-07-06 13:43:31 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:43:31 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:43:31 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:43:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:43:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:43:31 --> Encryption Class Initialized
INFO - 2020-07-06 13:43:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 13:43:31 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 13:43:31 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 13:43:31 --> Final output sent to browser
DEBUG - 2020-07-06 13:43:31 --> Total execution time: 0.0048
INFO - 2020-07-06 13:43:43 --> Config Class Initialized
INFO - 2020-07-06 13:43:43 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:43:43 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:43:43 --> Utf8 Class Initialized
INFO - 2020-07-06 13:43:43 --> URI Class Initialized
INFO - 2020-07-06 13:43:43 --> Router Class Initialized
INFO - 2020-07-06 13:43:43 --> Output Class Initialized
INFO - 2020-07-06 13:43:43 --> Security Class Initialized
DEBUG - 2020-07-06 13:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:43:43 --> Input Class Initialized
INFO - 2020-07-06 13:43:43 --> Language Class Initialized
INFO - 2020-07-06 13:43:43 --> Language Class Initialized
INFO - 2020-07-06 13:43:43 --> Config Class Initialized
INFO - 2020-07-06 13:43:43 --> Loader Class Initialized
INFO - 2020-07-06 13:43:43 --> Helper loaded: url_helper
INFO - 2020-07-06 13:43:43 --> Helper loaded: main_helper
INFO - 2020-07-06 13:43:43 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:43:43 --> Controller Class Initialized
INFO - 2020-07-06 13:43:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:43:43 --> Pagination Class Initialized
ERROR - 2020-07-06 13:43:43 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:43:43 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:43:43 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:43:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:43:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:43:43 --> Encryption Class Initialized
INFO - 2020-07-06 13:43:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-06 13:43:45 --> Severity: Notice --> Undefined property: DOMDocument::$createElement /var/www/journal/application/modules/landing/views/xml_export_v.php 11
ERROR - 2020-07-06 13:43:45 --> Severity: error --> Exception: Class name must be a valid object or a string /var/www/journal/application/modules/landing/views/xml_export_v.php 11
INFO - 2020-07-06 13:44:06 --> Config Class Initialized
INFO - 2020-07-06 13:44:06 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:44:06 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:44:06 --> Utf8 Class Initialized
INFO - 2020-07-06 13:44:06 --> URI Class Initialized
INFO - 2020-07-06 13:44:06 --> Router Class Initialized
INFO - 2020-07-06 13:44:06 --> Output Class Initialized
INFO - 2020-07-06 13:44:06 --> Security Class Initialized
DEBUG - 2020-07-06 13:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:44:06 --> Input Class Initialized
INFO - 2020-07-06 13:44:06 --> Language Class Initialized
INFO - 2020-07-06 13:44:06 --> Language Class Initialized
INFO - 2020-07-06 13:44:06 --> Config Class Initialized
INFO - 2020-07-06 13:44:06 --> Loader Class Initialized
INFO - 2020-07-06 13:44:06 --> Helper loaded: url_helper
INFO - 2020-07-06 13:44:06 --> Helper loaded: main_helper
INFO - 2020-07-06 13:44:06 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:44:06 --> Controller Class Initialized
INFO - 2020-07-06 13:44:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:44:06 --> Pagination Class Initialized
ERROR - 2020-07-06 13:44:06 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:44:06 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:44:06 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:44:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:44:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:44:06 --> Encryption Class Initialized
INFO - 2020-07-06 13:44:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:44:23 --> Config Class Initialized
INFO - 2020-07-06 13:44:23 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:44:23 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:44:23 --> Utf8 Class Initialized
INFO - 2020-07-06 13:44:23 --> URI Class Initialized
INFO - 2020-07-06 13:44:23 --> Router Class Initialized
INFO - 2020-07-06 13:44:23 --> Output Class Initialized
INFO - 2020-07-06 13:44:23 --> Security Class Initialized
DEBUG - 2020-07-06 13:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:44:23 --> Input Class Initialized
INFO - 2020-07-06 13:44:23 --> Language Class Initialized
INFO - 2020-07-06 13:44:23 --> Language Class Initialized
INFO - 2020-07-06 13:44:23 --> Config Class Initialized
INFO - 2020-07-06 13:44:23 --> Loader Class Initialized
INFO - 2020-07-06 13:44:23 --> Helper loaded: url_helper
INFO - 2020-07-06 13:44:23 --> Helper loaded: main_helper
INFO - 2020-07-06 13:44:23 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:44:23 --> Controller Class Initialized
INFO - 2020-07-06 13:44:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:44:23 --> Pagination Class Initialized
ERROR - 2020-07-06 13:44:23 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:44:23 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:44:23 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:44:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:44:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:44:23 --> Encryption Class Initialized
INFO - 2020-07-06 13:44:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-06 13:44:24 --> Severity: Notice --> Undefined property: DOMDocument::$createElement /var/www/journal/application/modules/landing/views/xml_export_v.php 11
ERROR - 2020-07-06 13:44:24 --> Severity: error --> Exception: Class name must be a valid object or a string /var/www/journal/application/modules/landing/views/xml_export_v.php 11
INFO - 2020-07-06 13:47:17 --> Config Class Initialized
INFO - 2020-07-06 13:47:17 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:47:17 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:47:17 --> Utf8 Class Initialized
INFO - 2020-07-06 13:47:17 --> URI Class Initialized
INFO - 2020-07-06 13:47:17 --> Router Class Initialized
INFO - 2020-07-06 13:47:17 --> Output Class Initialized
INFO - 2020-07-06 13:47:17 --> Security Class Initialized
DEBUG - 2020-07-06 13:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:47:17 --> Input Class Initialized
INFO - 2020-07-06 13:47:17 --> Language Class Initialized
INFO - 2020-07-06 13:47:17 --> Language Class Initialized
INFO - 2020-07-06 13:47:17 --> Config Class Initialized
INFO - 2020-07-06 13:47:17 --> Loader Class Initialized
INFO - 2020-07-06 13:47:17 --> Helper loaded: url_helper
INFO - 2020-07-06 13:47:17 --> Helper loaded: main_helper
INFO - 2020-07-06 13:47:17 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:47:17 --> Controller Class Initialized
INFO - 2020-07-06 13:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:47:17 --> Pagination Class Initialized
ERROR - 2020-07-06 13:47:17 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:47:17 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:47:17 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:47:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:47:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:47:17 --> Encryption Class Initialized
INFO - 2020-07-06 13:47:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 13:47:19 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 13:47:19 --> Final output sent to browser
DEBUG - 2020-07-06 13:47:19 --> Total execution time: 1.3408
INFO - 2020-07-06 13:48:15 --> Config Class Initialized
INFO - 2020-07-06 13:48:15 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:48:15 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:48:15 --> Utf8 Class Initialized
INFO - 2020-07-06 13:48:15 --> URI Class Initialized
INFO - 2020-07-06 13:48:15 --> Router Class Initialized
INFO - 2020-07-06 13:48:15 --> Output Class Initialized
INFO - 2020-07-06 13:48:15 --> Security Class Initialized
DEBUG - 2020-07-06 13:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:48:15 --> Input Class Initialized
INFO - 2020-07-06 13:48:15 --> Language Class Initialized
INFO - 2020-07-06 13:48:15 --> Language Class Initialized
INFO - 2020-07-06 13:48:15 --> Config Class Initialized
INFO - 2020-07-06 13:48:15 --> Loader Class Initialized
INFO - 2020-07-06 13:48:15 --> Helper loaded: url_helper
INFO - 2020-07-06 13:48:15 --> Helper loaded: main_helper
INFO - 2020-07-06 13:48:15 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:48:15 --> Controller Class Initialized
INFO - 2020-07-06 13:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:48:15 --> Pagination Class Initialized
ERROR - 2020-07-06 13:48:15 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:48:15 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:48:15 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:48:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:48:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:48:15 --> Encryption Class Initialized
INFO - 2020-07-06 13:48:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 13:48:17 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 13:48:17 --> Final output sent to browser
DEBUG - 2020-07-06 13:48:17 --> Total execution time: 1.2340
INFO - 2020-07-06 13:49:03 --> Config Class Initialized
INFO - 2020-07-06 13:49:03 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:49:03 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:49:03 --> Utf8 Class Initialized
INFO - 2020-07-06 13:49:03 --> URI Class Initialized
INFO - 2020-07-06 13:49:03 --> Router Class Initialized
INFO - 2020-07-06 13:49:03 --> Output Class Initialized
INFO - 2020-07-06 13:49:03 --> Security Class Initialized
DEBUG - 2020-07-06 13:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:49:03 --> Input Class Initialized
INFO - 2020-07-06 13:49:03 --> Language Class Initialized
INFO - 2020-07-06 13:49:03 --> Language Class Initialized
INFO - 2020-07-06 13:49:03 --> Config Class Initialized
INFO - 2020-07-06 13:49:03 --> Loader Class Initialized
INFO - 2020-07-06 13:49:03 --> Helper loaded: url_helper
INFO - 2020-07-06 13:49:03 --> Helper loaded: main_helper
INFO - 2020-07-06 13:49:03 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:49:03 --> Controller Class Initialized
INFO - 2020-07-06 13:49:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:49:03 --> Pagination Class Initialized
ERROR - 2020-07-06 13:49:03 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:49:03 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:49:03 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:49:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:49:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:49:04 --> Encryption Class Initialized
INFO - 2020-07-06 13:49:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 13:49:05 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 13:49:05 --> Final output sent to browser
DEBUG - 2020-07-06 13:49:05 --> Total execution time: 1.2990
INFO - 2020-07-06 13:50:01 --> Config Class Initialized
INFO - 2020-07-06 13:50:01 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:50:01 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:50:01 --> Utf8 Class Initialized
INFO - 2020-07-06 13:50:01 --> URI Class Initialized
INFO - 2020-07-06 13:50:01 --> Router Class Initialized
INFO - 2020-07-06 13:50:01 --> Output Class Initialized
INFO - 2020-07-06 13:50:01 --> Security Class Initialized
DEBUG - 2020-07-06 13:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:50:01 --> Input Class Initialized
INFO - 2020-07-06 13:50:01 --> Language Class Initialized
INFO - 2020-07-06 13:50:01 --> Language Class Initialized
INFO - 2020-07-06 13:50:01 --> Config Class Initialized
INFO - 2020-07-06 13:50:01 --> Loader Class Initialized
INFO - 2020-07-06 13:50:01 --> Helper loaded: url_helper
INFO - 2020-07-06 13:50:01 --> Helper loaded: main_helper
INFO - 2020-07-06 13:50:01 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:50:01 --> Controller Class Initialized
INFO - 2020-07-06 13:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:50:01 --> Pagination Class Initialized
ERROR - 2020-07-06 13:50:01 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:50:01 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:50:01 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:50:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:50:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:50:01 --> Encryption Class Initialized
INFO - 2020-07-06 13:50:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 13:50:02 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 13:50:02 --> Final output sent to browser
DEBUG - 2020-07-06 13:50:02 --> Total execution time: 1.2150
INFO - 2020-07-06 13:50:29 --> Config Class Initialized
INFO - 2020-07-06 13:50:29 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:50:29 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:50:29 --> Utf8 Class Initialized
INFO - 2020-07-06 13:50:29 --> URI Class Initialized
INFO - 2020-07-06 13:50:29 --> Router Class Initialized
INFO - 2020-07-06 13:50:29 --> Output Class Initialized
INFO - 2020-07-06 13:50:29 --> Security Class Initialized
DEBUG - 2020-07-06 13:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:50:29 --> Input Class Initialized
INFO - 2020-07-06 13:50:29 --> Language Class Initialized
INFO - 2020-07-06 13:50:29 --> Language Class Initialized
INFO - 2020-07-06 13:50:29 --> Config Class Initialized
INFO - 2020-07-06 13:50:29 --> Loader Class Initialized
INFO - 2020-07-06 13:50:29 --> Helper loaded: url_helper
INFO - 2020-07-06 13:50:29 --> Helper loaded: main_helper
INFO - 2020-07-06 13:50:29 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:50:29 --> Controller Class Initialized
INFO - 2020-07-06 13:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:50:29 --> Pagination Class Initialized
ERROR - 2020-07-06 13:50:29 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:50:29 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:50:29 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:50:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:50:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:50:29 --> Encryption Class Initialized
INFO - 2020-07-06 13:50:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:50:29 --> Final output sent to browser
DEBUG - 2020-07-06 13:50:29 --> Total execution time: 0.0045
INFO - 2020-07-06 13:50:31 --> Config Class Initialized
INFO - 2020-07-06 13:50:31 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:50:31 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:50:31 --> Utf8 Class Initialized
INFO - 2020-07-06 13:50:31 --> URI Class Initialized
INFO - 2020-07-06 13:50:31 --> Router Class Initialized
INFO - 2020-07-06 13:50:31 --> Output Class Initialized
INFO - 2020-07-06 13:50:31 --> Security Class Initialized
DEBUG - 2020-07-06 13:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:50:31 --> Input Class Initialized
INFO - 2020-07-06 13:50:31 --> Language Class Initialized
INFO - 2020-07-06 13:50:31 --> Language Class Initialized
INFO - 2020-07-06 13:50:31 --> Config Class Initialized
INFO - 2020-07-06 13:50:31 --> Loader Class Initialized
INFO - 2020-07-06 13:50:31 --> Helper loaded: url_helper
INFO - 2020-07-06 13:50:31 --> Helper loaded: main_helper
INFO - 2020-07-06 13:50:31 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:50:31 --> Controller Class Initialized
INFO - 2020-07-06 13:50:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:50:31 --> Pagination Class Initialized
ERROR - 2020-07-06 13:50:31 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:50:31 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:50:31 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:50:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:50:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:50:31 --> Encryption Class Initialized
INFO - 2020-07-06 13:50:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:50:31 --> Final output sent to browser
DEBUG - 2020-07-06 13:50:31 --> Total execution time: 0.0039
INFO - 2020-07-06 13:50:31 --> Config Class Initialized
INFO - 2020-07-06 13:50:31 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:50:31 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:50:31 --> Utf8 Class Initialized
INFO - 2020-07-06 13:50:31 --> URI Class Initialized
INFO - 2020-07-06 13:50:31 --> Router Class Initialized
INFO - 2020-07-06 13:50:31 --> Output Class Initialized
INFO - 2020-07-06 13:50:31 --> Security Class Initialized
DEBUG - 2020-07-06 13:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:50:31 --> Input Class Initialized
INFO - 2020-07-06 13:50:31 --> Language Class Initialized
INFO - 2020-07-06 13:50:31 --> Language Class Initialized
INFO - 2020-07-06 13:50:31 --> Config Class Initialized
INFO - 2020-07-06 13:50:31 --> Loader Class Initialized
INFO - 2020-07-06 13:50:31 --> Helper loaded: url_helper
INFO - 2020-07-06 13:50:31 --> Helper loaded: main_helper
INFO - 2020-07-06 13:50:31 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:50:31 --> Controller Class Initialized
INFO - 2020-07-06 13:50:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:50:31 --> Pagination Class Initialized
ERROR - 2020-07-06 13:50:31 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:50:31 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:50:31 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:50:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:50:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:50:31 --> Encryption Class Initialized
INFO - 2020-07-06 13:50:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:50:31 --> Final output sent to browser
DEBUG - 2020-07-06 13:50:31 --> Total execution time: 0.0042
INFO - 2020-07-06 13:52:08 --> Config Class Initialized
INFO - 2020-07-06 13:52:08 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:52:08 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:52:08 --> Utf8 Class Initialized
INFO - 2020-07-06 13:52:08 --> URI Class Initialized
INFO - 2020-07-06 13:52:08 --> Router Class Initialized
INFO - 2020-07-06 13:52:08 --> Output Class Initialized
INFO - 2020-07-06 13:52:08 --> Security Class Initialized
DEBUG - 2020-07-06 13:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:52:08 --> Input Class Initialized
INFO - 2020-07-06 13:52:08 --> Language Class Initialized
INFO - 2020-07-06 13:52:08 --> Language Class Initialized
INFO - 2020-07-06 13:52:08 --> Config Class Initialized
INFO - 2020-07-06 13:52:08 --> Loader Class Initialized
INFO - 2020-07-06 13:52:08 --> Helper loaded: url_helper
INFO - 2020-07-06 13:52:08 --> Helper loaded: main_helper
INFO - 2020-07-06 13:52:08 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:52:08 --> Controller Class Initialized
INFO - 2020-07-06 13:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:52:08 --> Pagination Class Initialized
ERROR - 2020-07-06 13:52:08 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:52:08 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:52:08 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:52:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:52:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:52:08 --> Encryption Class Initialized
INFO - 2020-07-06 13:52:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:52:08 --> Final output sent to browser
DEBUG - 2020-07-06 13:52:08 --> Total execution time: 0.0054
INFO - 2020-07-06 13:52:09 --> Config Class Initialized
INFO - 2020-07-06 13:52:09 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:52:09 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:52:09 --> Utf8 Class Initialized
INFO - 2020-07-06 13:52:09 --> URI Class Initialized
INFO - 2020-07-06 13:52:09 --> Router Class Initialized
INFO - 2020-07-06 13:52:09 --> Output Class Initialized
INFO - 2020-07-06 13:52:09 --> Security Class Initialized
DEBUG - 2020-07-06 13:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:52:09 --> Input Class Initialized
INFO - 2020-07-06 13:52:09 --> Language Class Initialized
INFO - 2020-07-06 13:52:09 --> Language Class Initialized
INFO - 2020-07-06 13:52:09 --> Config Class Initialized
INFO - 2020-07-06 13:52:09 --> Loader Class Initialized
INFO - 2020-07-06 13:52:09 --> Helper loaded: url_helper
INFO - 2020-07-06 13:52:09 --> Helper loaded: main_helper
INFO - 2020-07-06 13:52:09 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:52:09 --> Controller Class Initialized
INFO - 2020-07-06 13:52:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:52:09 --> Pagination Class Initialized
ERROR - 2020-07-06 13:52:09 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:52:09 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:52:09 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:52:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:52:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:52:09 --> Encryption Class Initialized
INFO - 2020-07-06 13:52:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:52:09 --> Final output sent to browser
DEBUG - 2020-07-06 13:52:09 --> Total execution time: 0.0039
INFO - 2020-07-06 13:53:51 --> Config Class Initialized
INFO - 2020-07-06 13:53:51 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:53:51 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:53:51 --> Utf8 Class Initialized
INFO - 2020-07-06 13:53:51 --> URI Class Initialized
INFO - 2020-07-06 13:53:51 --> Router Class Initialized
INFO - 2020-07-06 13:53:51 --> Output Class Initialized
INFO - 2020-07-06 13:53:51 --> Security Class Initialized
DEBUG - 2020-07-06 13:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:53:51 --> Input Class Initialized
INFO - 2020-07-06 13:53:51 --> Language Class Initialized
INFO - 2020-07-06 13:53:51 --> Language Class Initialized
INFO - 2020-07-06 13:53:51 --> Config Class Initialized
INFO - 2020-07-06 13:53:51 --> Loader Class Initialized
INFO - 2020-07-06 13:53:51 --> Helper loaded: url_helper
INFO - 2020-07-06 13:53:51 --> Helper loaded: main_helper
INFO - 2020-07-06 13:53:51 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:53:51 --> Controller Class Initialized
INFO - 2020-07-06 13:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:53:51 --> Pagination Class Initialized
ERROR - 2020-07-06 13:53:51 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:53:51 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:53:51 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:53:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:53:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:53:51 --> Encryption Class Initialized
INFO - 2020-07-06 13:53:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:53:51 --> Final output sent to browser
DEBUG - 2020-07-06 13:53:51 --> Total execution time: 0.0045
INFO - 2020-07-06 13:53:52 --> Config Class Initialized
INFO - 2020-07-06 13:53:52 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:53:52 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:53:52 --> Utf8 Class Initialized
INFO - 2020-07-06 13:53:52 --> URI Class Initialized
INFO - 2020-07-06 13:53:52 --> Router Class Initialized
INFO - 2020-07-06 13:53:52 --> Output Class Initialized
INFO - 2020-07-06 13:53:52 --> Security Class Initialized
DEBUG - 2020-07-06 13:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:53:52 --> Input Class Initialized
INFO - 2020-07-06 13:53:52 --> Language Class Initialized
INFO - 2020-07-06 13:53:52 --> Language Class Initialized
INFO - 2020-07-06 13:53:52 --> Config Class Initialized
INFO - 2020-07-06 13:53:52 --> Loader Class Initialized
INFO - 2020-07-06 13:53:52 --> Helper loaded: url_helper
INFO - 2020-07-06 13:53:52 --> Helper loaded: main_helper
INFO - 2020-07-06 13:53:52 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:53:52 --> Controller Class Initialized
INFO - 2020-07-06 13:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:53:52 --> Pagination Class Initialized
ERROR - 2020-07-06 13:53:52 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:53:52 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:53:52 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:53:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:53:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:53:52 --> Encryption Class Initialized
INFO - 2020-07-06 13:53:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:53:52 --> Final output sent to browser
DEBUG - 2020-07-06 13:53:52 --> Total execution time: 0.0044
INFO - 2020-07-06 13:53:53 --> Config Class Initialized
INFO - 2020-07-06 13:53:53 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:53:53 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:53:53 --> Utf8 Class Initialized
INFO - 2020-07-06 13:53:53 --> URI Class Initialized
INFO - 2020-07-06 13:53:53 --> Router Class Initialized
INFO - 2020-07-06 13:53:53 --> Output Class Initialized
INFO - 2020-07-06 13:53:53 --> Security Class Initialized
DEBUG - 2020-07-06 13:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:53:53 --> Input Class Initialized
INFO - 2020-07-06 13:53:53 --> Language Class Initialized
INFO - 2020-07-06 13:53:53 --> Language Class Initialized
INFO - 2020-07-06 13:53:53 --> Config Class Initialized
INFO - 2020-07-06 13:53:53 --> Loader Class Initialized
INFO - 2020-07-06 13:53:53 --> Helper loaded: url_helper
INFO - 2020-07-06 13:53:53 --> Helper loaded: main_helper
INFO - 2020-07-06 13:53:53 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:53:53 --> Controller Class Initialized
INFO - 2020-07-06 13:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:53:53 --> Pagination Class Initialized
ERROR - 2020-07-06 13:53:53 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:53:53 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:53:53 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:53:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:53:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:53:53 --> Encryption Class Initialized
INFO - 2020-07-06 13:53:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:53:53 --> Final output sent to browser
DEBUG - 2020-07-06 13:53:53 --> Total execution time: 0.0038
INFO - 2020-07-06 13:54:16 --> Config Class Initialized
INFO - 2020-07-06 13:54:16 --> Hooks Class Initialized
DEBUG - 2020-07-06 13:54:16 --> UTF-8 Support Enabled
INFO - 2020-07-06 13:54:16 --> Utf8 Class Initialized
INFO - 2020-07-06 13:54:16 --> URI Class Initialized
INFO - 2020-07-06 13:54:16 --> Router Class Initialized
INFO - 2020-07-06 13:54:16 --> Output Class Initialized
INFO - 2020-07-06 13:54:16 --> Security Class Initialized
DEBUG - 2020-07-06 13:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 13:54:16 --> Input Class Initialized
INFO - 2020-07-06 13:54:16 --> Language Class Initialized
INFO - 2020-07-06 13:54:16 --> Language Class Initialized
INFO - 2020-07-06 13:54:16 --> Config Class Initialized
INFO - 2020-07-06 13:54:16 --> Loader Class Initialized
INFO - 2020-07-06 13:54:16 --> Helper loaded: url_helper
INFO - 2020-07-06 13:54:16 --> Helper loaded: main_helper
INFO - 2020-07-06 13:54:16 --> Database Driver Class Initialized
DEBUG - 2020-07-06 13:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 13:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 13:54:16 --> Controller Class Initialized
INFO - 2020-07-06 13:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 13:54:16 --> Pagination Class Initialized
ERROR - 2020-07-06 13:54:16 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 13:54:16 --> Helper loaded: file_helper
DEBUG - 2020-07-06 13:54:16 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 13:54:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 13:54:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 13:54:16 --> Encryption Class Initialized
INFO - 2020-07-06 13:54:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-06 13:54:16 --> Severity: error --> Exception: Call to undefined method DOMDocument::saveXL() /var/www/journal/application/modules/landing/controllers/Search.php 153
INFO - 2020-07-06 15:50:18 --> Config Class Initialized
INFO - 2020-07-06 15:50:18 --> Hooks Class Initialized
DEBUG - 2020-07-06 15:50:18 --> UTF-8 Support Enabled
INFO - 2020-07-06 15:50:18 --> Utf8 Class Initialized
INFO - 2020-07-06 15:50:18 --> URI Class Initialized
INFO - 2020-07-06 15:50:18 --> Router Class Initialized
INFO - 2020-07-06 15:50:18 --> Output Class Initialized
INFO - 2020-07-06 15:50:18 --> Security Class Initialized
DEBUG - 2020-07-06 15:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 15:50:18 --> Input Class Initialized
INFO - 2020-07-06 15:50:18 --> Language Class Initialized
INFO - 2020-07-06 15:50:18 --> Language Class Initialized
INFO - 2020-07-06 15:50:18 --> Config Class Initialized
INFO - 2020-07-06 15:50:18 --> Loader Class Initialized
INFO - 2020-07-06 15:50:18 --> Helper loaded: url_helper
INFO - 2020-07-06 15:50:18 --> Helper loaded: main_helper
INFO - 2020-07-06 15:50:18 --> Database Driver Class Initialized
DEBUG - 2020-07-06 15:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 15:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 15:50:18 --> Controller Class Initialized
INFO - 2020-07-06 15:50:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 15:50:18 --> Pagination Class Initialized
ERROR - 2020-07-06 15:50:18 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 15:50:18 --> Helper loaded: file_helper
DEBUG - 2020-07-06 15:50:18 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 15:50:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 15:50:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 15:50:18 --> Encryption Class Initialized
INFO - 2020-07-06 15:50:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 15:51:31 --> Config Class Initialized
INFO - 2020-07-06 15:51:31 --> Hooks Class Initialized
DEBUG - 2020-07-06 15:51:31 --> UTF-8 Support Enabled
INFO - 2020-07-06 15:51:31 --> Utf8 Class Initialized
INFO - 2020-07-06 15:51:31 --> URI Class Initialized
INFO - 2020-07-06 15:51:31 --> Router Class Initialized
INFO - 2020-07-06 15:51:31 --> Output Class Initialized
INFO - 2020-07-06 15:51:31 --> Security Class Initialized
DEBUG - 2020-07-06 15:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 15:51:31 --> Input Class Initialized
INFO - 2020-07-06 15:51:31 --> Language Class Initialized
INFO - 2020-07-06 15:51:31 --> Language Class Initialized
INFO - 2020-07-06 15:51:31 --> Config Class Initialized
INFO - 2020-07-06 15:51:31 --> Loader Class Initialized
INFO - 2020-07-06 15:51:31 --> Helper loaded: url_helper
INFO - 2020-07-06 15:51:31 --> Helper loaded: main_helper
INFO - 2020-07-06 15:51:31 --> Database Driver Class Initialized
DEBUG - 2020-07-06 15:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 15:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 15:51:31 --> Controller Class Initialized
INFO - 2020-07-06 15:51:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 15:51:31 --> Pagination Class Initialized
ERROR - 2020-07-06 15:51:31 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 15:51:31 --> Helper loaded: file_helper
DEBUG - 2020-07-06 15:51:31 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 15:51:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 15:51:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 15:51:31 --> Encryption Class Initialized
INFO - 2020-07-06 15:51:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 15:51:32 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 15:51:32 --> Final output sent to browser
DEBUG - 2020-07-06 15:51:32 --> Total execution time: 1.2904
INFO - 2020-07-06 15:53:15 --> Config Class Initialized
INFO - 2020-07-06 15:53:15 --> Hooks Class Initialized
DEBUG - 2020-07-06 15:53:15 --> UTF-8 Support Enabled
INFO - 2020-07-06 15:53:15 --> Utf8 Class Initialized
INFO - 2020-07-06 15:53:15 --> URI Class Initialized
INFO - 2020-07-06 15:53:15 --> Router Class Initialized
INFO - 2020-07-06 15:53:15 --> Output Class Initialized
INFO - 2020-07-06 15:53:15 --> Security Class Initialized
DEBUG - 2020-07-06 15:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 15:53:15 --> Input Class Initialized
INFO - 2020-07-06 15:53:15 --> Language Class Initialized
INFO - 2020-07-06 15:53:15 --> Language Class Initialized
INFO - 2020-07-06 15:53:15 --> Config Class Initialized
INFO - 2020-07-06 15:53:15 --> Loader Class Initialized
INFO - 2020-07-06 15:53:15 --> Helper loaded: url_helper
INFO - 2020-07-06 15:53:15 --> Helper loaded: main_helper
INFO - 2020-07-06 15:53:15 --> Database Driver Class Initialized
DEBUG - 2020-07-06 15:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 15:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 15:53:15 --> Controller Class Initialized
INFO - 2020-07-06 15:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 15:53:15 --> Pagination Class Initialized
ERROR - 2020-07-06 15:53:15 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 15:53:15 --> Helper loaded: file_helper
DEBUG - 2020-07-06 15:53:15 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 15:53:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 15:53:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 15:53:15 --> Encryption Class Initialized
INFO - 2020-07-06 15:53:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 15:53:16 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 15:53:16 --> Final output sent to browser
DEBUG - 2020-07-06 15:53:16 --> Total execution time: 1.1922
INFO - 2020-07-06 16:00:34 --> Config Class Initialized
INFO - 2020-07-06 16:00:34 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:00:34 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:00:34 --> Utf8 Class Initialized
INFO - 2020-07-06 16:00:34 --> URI Class Initialized
INFO - 2020-07-06 16:00:34 --> Router Class Initialized
INFO - 2020-07-06 16:00:34 --> Output Class Initialized
INFO - 2020-07-06 16:00:34 --> Security Class Initialized
DEBUG - 2020-07-06 16:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:00:34 --> Input Class Initialized
INFO - 2020-07-06 16:00:34 --> Language Class Initialized
INFO - 2020-07-06 16:00:34 --> Language Class Initialized
INFO - 2020-07-06 16:00:34 --> Config Class Initialized
INFO - 2020-07-06 16:00:34 --> Loader Class Initialized
INFO - 2020-07-06 16:00:34 --> Helper loaded: url_helper
INFO - 2020-07-06 16:00:34 --> Helper loaded: main_helper
INFO - 2020-07-06 16:00:34 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:00:34 --> Controller Class Initialized
INFO - 2020-07-06 16:00:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:00:34 --> Pagination Class Initialized
ERROR - 2020-07-06 16:00:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:00:34 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:00:34 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:00:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:00:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:00:34 --> Encryption Class Initialized
INFO - 2020-07-06 16:00:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:00:34 --> Final output sent to browser
DEBUG - 2020-07-06 16:00:34 --> Total execution time: 0.0057
INFO - 2020-07-06 16:00:45 --> Config Class Initialized
INFO - 2020-07-06 16:00:45 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:00:45 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:00:45 --> Utf8 Class Initialized
INFO - 2020-07-06 16:00:45 --> URI Class Initialized
INFO - 2020-07-06 16:00:45 --> Router Class Initialized
INFO - 2020-07-06 16:00:45 --> Output Class Initialized
INFO - 2020-07-06 16:00:45 --> Security Class Initialized
DEBUG - 2020-07-06 16:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:00:45 --> Input Class Initialized
INFO - 2020-07-06 16:00:45 --> Language Class Initialized
INFO - 2020-07-06 16:00:45 --> Language Class Initialized
INFO - 2020-07-06 16:00:45 --> Config Class Initialized
INFO - 2020-07-06 16:00:45 --> Loader Class Initialized
INFO - 2020-07-06 16:00:45 --> Helper loaded: url_helper
INFO - 2020-07-06 16:00:45 --> Helper loaded: main_helper
INFO - 2020-07-06 16:00:45 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:00:45 --> Controller Class Initialized
INFO - 2020-07-06 16:00:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:00:45 --> Pagination Class Initialized
ERROR - 2020-07-06 16:00:45 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:00:45 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:00:45 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:00:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:00:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:00:45 --> Encryption Class Initialized
INFO - 2020-07-06 16:00:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:00:45 --> Final output sent to browser
DEBUG - 2020-07-06 16:00:45 --> Total execution time: 0.0045
INFO - 2020-07-06 16:01:52 --> Config Class Initialized
INFO - 2020-07-06 16:01:52 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:01:52 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:01:52 --> Utf8 Class Initialized
INFO - 2020-07-06 16:01:52 --> URI Class Initialized
INFO - 2020-07-06 16:01:52 --> Router Class Initialized
INFO - 2020-07-06 16:01:52 --> Output Class Initialized
INFO - 2020-07-06 16:01:52 --> Security Class Initialized
DEBUG - 2020-07-06 16:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:01:52 --> Input Class Initialized
INFO - 2020-07-06 16:01:52 --> Language Class Initialized
INFO - 2020-07-06 16:01:52 --> Language Class Initialized
INFO - 2020-07-06 16:01:52 --> Config Class Initialized
INFO - 2020-07-06 16:01:52 --> Loader Class Initialized
INFO - 2020-07-06 16:01:52 --> Helper loaded: url_helper
INFO - 2020-07-06 16:01:52 --> Helper loaded: main_helper
INFO - 2020-07-06 16:01:52 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:01:52 --> Controller Class Initialized
INFO - 2020-07-06 16:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:01:52 --> Pagination Class Initialized
ERROR - 2020-07-06 16:01:52 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:01:52 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:01:52 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:01:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:01:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:01:52 --> Encryption Class Initialized
INFO - 2020-07-06 16:01:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:01:52 --> Final output sent to browser
DEBUG - 2020-07-06 16:01:52 --> Total execution time: 0.0044
INFO - 2020-07-06 16:02:30 --> Config Class Initialized
INFO - 2020-07-06 16:02:30 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:02:30 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:02:30 --> Utf8 Class Initialized
INFO - 2020-07-06 16:02:30 --> URI Class Initialized
INFO - 2020-07-06 16:02:30 --> Router Class Initialized
INFO - 2020-07-06 16:02:30 --> Output Class Initialized
INFO - 2020-07-06 16:02:30 --> Security Class Initialized
DEBUG - 2020-07-06 16:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:02:30 --> Input Class Initialized
INFO - 2020-07-06 16:02:30 --> Language Class Initialized
INFO - 2020-07-06 16:02:30 --> Language Class Initialized
INFO - 2020-07-06 16:02:30 --> Config Class Initialized
INFO - 2020-07-06 16:02:30 --> Loader Class Initialized
INFO - 2020-07-06 16:02:30 --> Helper loaded: url_helper
INFO - 2020-07-06 16:02:30 --> Helper loaded: main_helper
INFO - 2020-07-06 16:02:30 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:02:30 --> Controller Class Initialized
INFO - 2020-07-06 16:02:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:02:30 --> Pagination Class Initialized
ERROR - 2020-07-06 16:02:30 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:02:30 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:02:30 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:02:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:02:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:02:30 --> Encryption Class Initialized
INFO - 2020-07-06 16:02:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:02:30 --> Final output sent to browser
DEBUG - 2020-07-06 16:02:30 --> Total execution time: 0.0048
INFO - 2020-07-06 16:05:12 --> Config Class Initialized
INFO - 2020-07-06 16:05:12 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:05:12 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:05:12 --> Utf8 Class Initialized
INFO - 2020-07-06 16:05:12 --> URI Class Initialized
INFO - 2020-07-06 16:05:12 --> Router Class Initialized
INFO - 2020-07-06 16:05:12 --> Output Class Initialized
INFO - 2020-07-06 16:05:12 --> Security Class Initialized
DEBUG - 2020-07-06 16:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:05:12 --> Input Class Initialized
INFO - 2020-07-06 16:05:12 --> Language Class Initialized
INFO - 2020-07-06 16:05:12 --> Language Class Initialized
INFO - 2020-07-06 16:05:12 --> Config Class Initialized
INFO - 2020-07-06 16:05:12 --> Loader Class Initialized
INFO - 2020-07-06 16:05:12 --> Helper loaded: url_helper
INFO - 2020-07-06 16:05:12 --> Helper loaded: main_helper
INFO - 2020-07-06 16:05:12 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:05:12 --> Controller Class Initialized
INFO - 2020-07-06 16:05:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:05:12 --> Pagination Class Initialized
ERROR - 2020-07-06 16:05:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:05:12 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:05:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:05:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:05:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:05:12 --> Encryption Class Initialized
INFO - 2020-07-06 16:05:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 16:05:13 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 16:05:13 --> Final output sent to browser
DEBUG - 2020-07-06 16:05:13 --> Total execution time: 1.2725
INFO - 2020-07-06 16:11:22 --> Config Class Initialized
INFO - 2020-07-06 16:11:22 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:11:22 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:11:22 --> Utf8 Class Initialized
INFO - 2020-07-06 16:11:22 --> URI Class Initialized
INFO - 2020-07-06 16:11:22 --> Router Class Initialized
INFO - 2020-07-06 16:11:22 --> Output Class Initialized
INFO - 2020-07-06 16:11:22 --> Security Class Initialized
DEBUG - 2020-07-06 16:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:11:22 --> Input Class Initialized
INFO - 2020-07-06 16:11:22 --> Language Class Initialized
INFO - 2020-07-06 16:11:22 --> Language Class Initialized
INFO - 2020-07-06 16:11:22 --> Config Class Initialized
INFO - 2020-07-06 16:11:22 --> Loader Class Initialized
INFO - 2020-07-06 16:11:22 --> Helper loaded: url_helper
INFO - 2020-07-06 16:11:22 --> Helper loaded: main_helper
INFO - 2020-07-06 16:11:22 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:11:22 --> Controller Class Initialized
INFO - 2020-07-06 16:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:11:22 --> Pagination Class Initialized
ERROR - 2020-07-06 16:11:22 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:11:22 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:11:22 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:11:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:11:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:11:22 --> Encryption Class Initialized
INFO - 2020-07-06 16:11:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 16:11:24 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 16:11:24 --> Final output sent to browser
DEBUG - 2020-07-06 16:11:24 --> Total execution time: 1.2207
INFO - 2020-07-06 16:12:16 --> Config Class Initialized
INFO - 2020-07-06 16:12:16 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:12:16 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:12:16 --> Utf8 Class Initialized
INFO - 2020-07-06 16:12:16 --> URI Class Initialized
INFO - 2020-07-06 16:12:16 --> Router Class Initialized
INFO - 2020-07-06 16:12:16 --> Output Class Initialized
INFO - 2020-07-06 16:12:16 --> Security Class Initialized
DEBUG - 2020-07-06 16:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:12:16 --> Input Class Initialized
INFO - 2020-07-06 16:12:16 --> Language Class Initialized
INFO - 2020-07-06 16:12:16 --> Language Class Initialized
INFO - 2020-07-06 16:12:16 --> Config Class Initialized
INFO - 2020-07-06 16:12:16 --> Loader Class Initialized
INFO - 2020-07-06 16:12:16 --> Helper loaded: url_helper
INFO - 2020-07-06 16:12:16 --> Helper loaded: main_helper
INFO - 2020-07-06 16:12:16 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:12:16 --> Controller Class Initialized
INFO - 2020-07-06 16:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:12:16 --> Pagination Class Initialized
ERROR - 2020-07-06 16:12:16 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:12:16 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:12:16 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:12:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:12:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:12:16 --> Encryption Class Initialized
INFO - 2020-07-06 16:12:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 16:12:17 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 16:12:17 --> Final output sent to browser
DEBUG - 2020-07-06 16:12:17 --> Total execution time: 1.2379
INFO - 2020-07-06 16:18:12 --> Config Class Initialized
INFO - 2020-07-06 16:18:12 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:18:12 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:18:12 --> Utf8 Class Initialized
INFO - 2020-07-06 16:18:12 --> URI Class Initialized
INFO - 2020-07-06 16:18:12 --> Router Class Initialized
INFO - 2020-07-06 16:18:12 --> Output Class Initialized
INFO - 2020-07-06 16:18:12 --> Security Class Initialized
DEBUG - 2020-07-06 16:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:18:12 --> Input Class Initialized
INFO - 2020-07-06 16:18:12 --> Language Class Initialized
INFO - 2020-07-06 16:18:12 --> Language Class Initialized
INFO - 2020-07-06 16:18:12 --> Config Class Initialized
INFO - 2020-07-06 16:18:12 --> Loader Class Initialized
INFO - 2020-07-06 16:18:12 --> Helper loaded: url_helper
INFO - 2020-07-06 16:18:12 --> Helper loaded: main_helper
INFO - 2020-07-06 16:18:12 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:18:12 --> Controller Class Initialized
INFO - 2020-07-06 16:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:18:12 --> Pagination Class Initialized
ERROR - 2020-07-06 16:18:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:18:12 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:18:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:18:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:18:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:18:12 --> Encryption Class Initialized
INFO - 2020-07-06 16:18:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 16:18:13 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 16:18:13 --> Final output sent to browser
DEBUG - 2020-07-06 16:18:13 --> Total execution time: 1.2978
INFO - 2020-07-06 16:19:52 --> Config Class Initialized
INFO - 2020-07-06 16:19:52 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:19:52 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:19:52 --> Utf8 Class Initialized
INFO - 2020-07-06 16:19:52 --> URI Class Initialized
INFO - 2020-07-06 16:19:52 --> Router Class Initialized
INFO - 2020-07-06 16:19:52 --> Output Class Initialized
INFO - 2020-07-06 16:19:52 --> Security Class Initialized
DEBUG - 2020-07-06 16:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:19:52 --> Input Class Initialized
INFO - 2020-07-06 16:19:52 --> Language Class Initialized
INFO - 2020-07-06 16:19:52 --> Language Class Initialized
INFO - 2020-07-06 16:19:52 --> Config Class Initialized
INFO - 2020-07-06 16:19:52 --> Loader Class Initialized
INFO - 2020-07-06 16:19:52 --> Helper loaded: url_helper
INFO - 2020-07-06 16:19:52 --> Helper loaded: main_helper
INFO - 2020-07-06 16:19:52 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:19:52 --> Controller Class Initialized
INFO - 2020-07-06 16:19:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:19:52 --> Pagination Class Initialized
ERROR - 2020-07-06 16:19:52 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:19:52 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:19:52 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:19:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:19:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:19:52 --> Encryption Class Initialized
INFO - 2020-07-06 16:19:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 16:19:54 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 16:19:54 --> Final output sent to browser
DEBUG - 2020-07-06 16:19:54 --> Total execution time: 1.4860
INFO - 2020-07-06 16:21:42 --> Config Class Initialized
INFO - 2020-07-06 16:21:42 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:21:42 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:21:42 --> Utf8 Class Initialized
INFO - 2020-07-06 16:21:42 --> URI Class Initialized
INFO - 2020-07-06 16:21:42 --> Router Class Initialized
INFO - 2020-07-06 16:21:42 --> Output Class Initialized
INFO - 2020-07-06 16:21:42 --> Security Class Initialized
DEBUG - 2020-07-06 16:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:21:42 --> Input Class Initialized
INFO - 2020-07-06 16:21:42 --> Language Class Initialized
INFO - 2020-07-06 16:21:42 --> Language Class Initialized
INFO - 2020-07-06 16:21:42 --> Config Class Initialized
INFO - 2020-07-06 16:21:42 --> Loader Class Initialized
INFO - 2020-07-06 16:21:42 --> Helper loaded: url_helper
INFO - 2020-07-06 16:21:42 --> Helper loaded: main_helper
INFO - 2020-07-06 16:21:42 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:21:42 --> Controller Class Initialized
INFO - 2020-07-06 16:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:21:42 --> Pagination Class Initialized
ERROR - 2020-07-06 16:21:42 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:21:42 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:21:42 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:21:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:21:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:21:42 --> Encryption Class Initialized
INFO - 2020-07-06 16:21:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 16:21:43 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 16:21:43 --> Final output sent to browser
DEBUG - 2020-07-06 16:21:43 --> Total execution time: 1.1722
INFO - 2020-07-06 16:28:52 --> Config Class Initialized
INFO - 2020-07-06 16:28:52 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:28:52 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:28:52 --> Utf8 Class Initialized
INFO - 2020-07-06 16:28:52 --> URI Class Initialized
INFO - 2020-07-06 16:28:52 --> Router Class Initialized
INFO - 2020-07-06 16:28:52 --> Output Class Initialized
INFO - 2020-07-06 16:28:52 --> Security Class Initialized
DEBUG - 2020-07-06 16:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:28:52 --> Input Class Initialized
INFO - 2020-07-06 16:28:52 --> Language Class Initialized
INFO - 2020-07-06 16:28:52 --> Language Class Initialized
INFO - 2020-07-06 16:28:52 --> Config Class Initialized
INFO - 2020-07-06 16:28:52 --> Loader Class Initialized
INFO - 2020-07-06 16:28:52 --> Helper loaded: url_helper
INFO - 2020-07-06 16:28:52 --> Helper loaded: main_helper
INFO - 2020-07-06 16:28:52 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:28:52 --> Controller Class Initialized
INFO - 2020-07-06 16:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:28:52 --> Pagination Class Initialized
ERROR - 2020-07-06 16:28:52 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:28:52 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:28:52 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:28:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:28:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:28:52 --> Encryption Class Initialized
INFO - 2020-07-06 16:28:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-06 16:28:53 --> Severity: error --> Exception: Call to undefined function array_key() /var/www/journal/application/modules/landing/views/xml_export_v.php 15
INFO - 2020-07-06 16:29:11 --> Config Class Initialized
INFO - 2020-07-06 16:29:11 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:29:11 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:29:11 --> Utf8 Class Initialized
INFO - 2020-07-06 16:29:11 --> URI Class Initialized
INFO - 2020-07-06 16:29:11 --> Router Class Initialized
INFO - 2020-07-06 16:29:11 --> Output Class Initialized
INFO - 2020-07-06 16:29:11 --> Security Class Initialized
DEBUG - 2020-07-06 16:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:29:11 --> Input Class Initialized
INFO - 2020-07-06 16:29:11 --> Language Class Initialized
INFO - 2020-07-06 16:29:11 --> Language Class Initialized
INFO - 2020-07-06 16:29:11 --> Config Class Initialized
INFO - 2020-07-06 16:29:11 --> Loader Class Initialized
INFO - 2020-07-06 16:29:11 --> Helper loaded: url_helper
INFO - 2020-07-06 16:29:11 --> Helper loaded: main_helper
INFO - 2020-07-06 16:29:11 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:29:11 --> Controller Class Initialized
INFO - 2020-07-06 16:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:29:11 --> Pagination Class Initialized
ERROR - 2020-07-06 16:29:11 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:29:11 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:29:11 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:29:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:29:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:29:11 --> Encryption Class Initialized
INFO - 2020-07-06 16:29:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-06 16:29:12 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /var/www/journal/application/modules/landing/views/xml_export_v.php 15
ERROR - 2020-07-06 16:29:12 --> Severity: error --> Exception: Invalid Character Error /var/www/journal/application/modules/landing/views/xml_export_v.php 15
INFO - 2020-07-06 16:30:07 --> Config Class Initialized
INFO - 2020-07-06 16:30:07 --> Hooks Class Initialized
DEBUG - 2020-07-06 16:30:07 --> UTF-8 Support Enabled
INFO - 2020-07-06 16:30:07 --> Utf8 Class Initialized
INFO - 2020-07-06 16:30:07 --> URI Class Initialized
INFO - 2020-07-06 16:30:07 --> Router Class Initialized
INFO - 2020-07-06 16:30:07 --> Output Class Initialized
INFO - 2020-07-06 16:30:07 --> Security Class Initialized
DEBUG - 2020-07-06 16:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 16:30:07 --> Input Class Initialized
INFO - 2020-07-06 16:30:07 --> Language Class Initialized
INFO - 2020-07-06 16:30:07 --> Language Class Initialized
INFO - 2020-07-06 16:30:07 --> Config Class Initialized
INFO - 2020-07-06 16:30:07 --> Loader Class Initialized
INFO - 2020-07-06 16:30:07 --> Helper loaded: url_helper
INFO - 2020-07-06 16:30:07 --> Helper loaded: main_helper
INFO - 2020-07-06 16:30:07 --> Database Driver Class Initialized
DEBUG - 2020-07-06 16:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 16:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 16:30:07 --> Controller Class Initialized
INFO - 2020-07-06 16:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 16:30:07 --> Pagination Class Initialized
ERROR - 2020-07-06 16:30:07 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 16:30:07 --> Helper loaded: file_helper
DEBUG - 2020-07-06 16:30:07 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 16:30:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 16:30:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 16:30:07 --> Encryption Class Initialized
INFO - 2020-07-06 16:30:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-06 16:30:08 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /var/www/journal/application/modules/landing/views/xml_export_v.php 15
ERROR - 2020-07-06 16:30:08 --> Severity: error --> Exception: Invalid Character Error /var/www/journal/application/modules/landing/views/xml_export_v.php 15
INFO - 2020-07-06 18:49:08 --> Config Class Initialized
INFO - 2020-07-06 18:49:08 --> Hooks Class Initialized
DEBUG - 2020-07-06 18:49:08 --> UTF-8 Support Enabled
INFO - 2020-07-06 18:49:08 --> Utf8 Class Initialized
INFO - 2020-07-06 18:49:08 --> URI Class Initialized
INFO - 2020-07-06 18:49:08 --> Router Class Initialized
INFO - 2020-07-06 18:49:08 --> Output Class Initialized
INFO - 2020-07-06 18:49:08 --> Security Class Initialized
DEBUG - 2020-07-06 18:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 18:49:08 --> Input Class Initialized
INFO - 2020-07-06 18:49:08 --> Language Class Initialized
INFO - 2020-07-06 18:49:08 --> Language Class Initialized
INFO - 2020-07-06 18:49:08 --> Config Class Initialized
INFO - 2020-07-06 18:49:08 --> Loader Class Initialized
INFO - 2020-07-06 18:49:08 --> Helper loaded: url_helper
INFO - 2020-07-06 18:49:08 --> Helper loaded: main_helper
INFO - 2020-07-06 18:49:08 --> Database Driver Class Initialized
DEBUG - 2020-07-06 18:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 18:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 18:49:08 --> Controller Class Initialized
INFO - 2020-07-06 18:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 18:49:08 --> Pagination Class Initialized
ERROR - 2020-07-06 18:49:08 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 18:49:08 --> Helper loaded: file_helper
DEBUG - 2020-07-06 18:49:08 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 18:49:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 18:49:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 18:49:08 --> Encryption Class Initialized
INFO - 2020-07-06 18:49:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 18:49:08 --> Final output sent to browser
DEBUG - 2020-07-06 18:49:08 --> Total execution time: 0.0057
INFO - 2020-07-06 18:49:10 --> Config Class Initialized
INFO - 2020-07-06 18:49:10 --> Hooks Class Initialized
DEBUG - 2020-07-06 18:49:10 --> UTF-8 Support Enabled
INFO - 2020-07-06 18:49:10 --> Utf8 Class Initialized
INFO - 2020-07-06 18:49:10 --> URI Class Initialized
INFO - 2020-07-06 18:49:10 --> Router Class Initialized
INFO - 2020-07-06 18:49:10 --> Output Class Initialized
INFO - 2020-07-06 18:49:10 --> Security Class Initialized
DEBUG - 2020-07-06 18:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 18:49:10 --> Input Class Initialized
INFO - 2020-07-06 18:49:10 --> Language Class Initialized
INFO - 2020-07-06 18:49:10 --> Language Class Initialized
INFO - 2020-07-06 18:49:10 --> Config Class Initialized
INFO - 2020-07-06 18:49:10 --> Loader Class Initialized
INFO - 2020-07-06 18:49:10 --> Helper loaded: url_helper
INFO - 2020-07-06 18:49:10 --> Helper loaded: main_helper
INFO - 2020-07-06 18:49:10 --> Database Driver Class Initialized
DEBUG - 2020-07-06 18:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 18:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 18:49:10 --> Controller Class Initialized
INFO - 2020-07-06 18:49:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 18:49:10 --> Pagination Class Initialized
ERROR - 2020-07-06 18:49:10 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 18:49:10 --> Helper loaded: file_helper
DEBUG - 2020-07-06 18:49:10 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 18:49:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 18:49:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 18:49:10 --> Encryption Class Initialized
INFO - 2020-07-06 18:49:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 18:49:10 --> Final output sent to browser
DEBUG - 2020-07-06 18:49:10 --> Total execution time: 0.0056
INFO - 2020-07-06 18:49:28 --> Config Class Initialized
INFO - 2020-07-06 18:49:28 --> Hooks Class Initialized
DEBUG - 2020-07-06 18:49:28 --> UTF-8 Support Enabled
INFO - 2020-07-06 18:49:28 --> Utf8 Class Initialized
INFO - 2020-07-06 18:49:28 --> URI Class Initialized
INFO - 2020-07-06 18:49:28 --> Router Class Initialized
INFO - 2020-07-06 18:49:28 --> Output Class Initialized
INFO - 2020-07-06 18:49:28 --> Security Class Initialized
DEBUG - 2020-07-06 18:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 18:49:28 --> Input Class Initialized
INFO - 2020-07-06 18:49:28 --> Language Class Initialized
INFO - 2020-07-06 18:49:28 --> Language Class Initialized
INFO - 2020-07-06 18:49:28 --> Config Class Initialized
INFO - 2020-07-06 18:49:28 --> Loader Class Initialized
INFO - 2020-07-06 18:49:28 --> Helper loaded: url_helper
INFO - 2020-07-06 18:49:28 --> Helper loaded: main_helper
INFO - 2020-07-06 18:49:28 --> Database Driver Class Initialized
DEBUG - 2020-07-06 18:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 18:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 18:49:28 --> Controller Class Initialized
INFO - 2020-07-06 18:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 18:49:28 --> Pagination Class Initialized
ERROR - 2020-07-06 18:49:28 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 18:49:28 --> Helper loaded: file_helper
DEBUG - 2020-07-06 18:49:28 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 18:49:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 18:49:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 18:49:28 --> Encryption Class Initialized
INFO - 2020-07-06 18:49:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 18:49:29 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 18:49:29 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 18:49:29 --> Final output sent to browser
DEBUG - 2020-07-06 18:49:29 --> Total execution time: 1.5342
INFO - 2020-07-06 18:49:36 --> Config Class Initialized
INFO - 2020-07-06 18:49:36 --> Hooks Class Initialized
DEBUG - 2020-07-06 18:49:36 --> UTF-8 Support Enabled
INFO - 2020-07-06 18:49:36 --> Utf8 Class Initialized
INFO - 2020-07-06 18:49:36 --> URI Class Initialized
INFO - 2020-07-06 18:49:36 --> Router Class Initialized
INFO - 2020-07-06 18:49:36 --> Output Class Initialized
INFO - 2020-07-06 18:49:36 --> Security Class Initialized
DEBUG - 2020-07-06 18:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 18:49:36 --> Input Class Initialized
INFO - 2020-07-06 18:49:36 --> Language Class Initialized
INFO - 2020-07-06 18:49:36 --> Language Class Initialized
INFO - 2020-07-06 18:49:36 --> Config Class Initialized
INFO - 2020-07-06 18:49:36 --> Loader Class Initialized
INFO - 2020-07-06 18:49:36 --> Helper loaded: url_helper
INFO - 2020-07-06 18:49:36 --> Helper loaded: main_helper
INFO - 2020-07-06 18:49:36 --> Database Driver Class Initialized
DEBUG - 2020-07-06 18:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 18:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 18:49:36 --> Controller Class Initialized
INFO - 2020-07-06 18:49:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 18:49:36 --> Pagination Class Initialized
ERROR - 2020-07-06 18:49:36 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 18:49:36 --> Helper loaded: file_helper
DEBUG - 2020-07-06 18:49:36 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 18:49:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 18:49:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 18:49:36 --> Encryption Class Initialized
INFO - 2020-07-06 18:49:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-06 18:49:37 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /var/www/journal/application/modules/landing/views/xml_export_v.php 15
ERROR - 2020-07-06 18:49:37 --> Severity: error --> Exception: Invalid Character Error /var/www/journal/application/modules/landing/views/xml_export_v.php 15
INFO - 2020-07-06 19:11:31 --> Config Class Initialized
INFO - 2020-07-06 19:11:31 --> Hooks Class Initialized
DEBUG - 2020-07-06 19:11:31 --> UTF-8 Support Enabled
INFO - 2020-07-06 19:11:31 --> Utf8 Class Initialized
INFO - 2020-07-06 19:11:31 --> URI Class Initialized
INFO - 2020-07-06 19:11:31 --> Router Class Initialized
INFO - 2020-07-06 19:11:31 --> Output Class Initialized
INFO - 2020-07-06 19:11:31 --> Security Class Initialized
DEBUG - 2020-07-06 19:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 19:11:31 --> Input Class Initialized
INFO - 2020-07-06 19:11:31 --> Language Class Initialized
INFO - 2020-07-06 19:11:31 --> Language Class Initialized
INFO - 2020-07-06 19:11:31 --> Config Class Initialized
INFO - 2020-07-06 19:11:31 --> Loader Class Initialized
INFO - 2020-07-06 19:11:31 --> Helper loaded: url_helper
INFO - 2020-07-06 19:11:31 --> Helper loaded: main_helper
INFO - 2020-07-06 19:11:31 --> Database Driver Class Initialized
DEBUG - 2020-07-06 19:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 19:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 19:11:31 --> Controller Class Initialized
INFO - 2020-07-06 19:11:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 19:11:31 --> Pagination Class Initialized
ERROR - 2020-07-06 19:11:31 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 19:11:31 --> Helper loaded: file_helper
DEBUG - 2020-07-06 19:11:31 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 19:11:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 19:11:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 19:11:31 --> Encryption Class Initialized
INFO - 2020-07-06 19:11:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 22:02:18 --> Config Class Initialized
INFO - 2020-07-06 22:02:18 --> Hooks Class Initialized
DEBUG - 2020-07-06 22:02:18 --> UTF-8 Support Enabled
INFO - 2020-07-06 22:02:18 --> Utf8 Class Initialized
INFO - 2020-07-06 22:02:18 --> URI Class Initialized
INFO - 2020-07-06 22:02:18 --> Router Class Initialized
INFO - 2020-07-06 22:02:18 --> Output Class Initialized
INFO - 2020-07-06 22:02:18 --> Security Class Initialized
DEBUG - 2020-07-06 22:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 22:02:18 --> Input Class Initialized
INFO - 2020-07-06 22:02:18 --> Language Class Initialized
INFO - 2020-07-06 22:02:18 --> Language Class Initialized
INFO - 2020-07-06 22:02:18 --> Config Class Initialized
INFO - 2020-07-06 22:02:18 --> Loader Class Initialized
INFO - 2020-07-06 22:02:18 --> Helper loaded: url_helper
INFO - 2020-07-06 22:02:18 --> Helper loaded: main_helper
INFO - 2020-07-06 22:02:18 --> Database Driver Class Initialized
DEBUG - 2020-07-06 22:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 22:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 22:02:18 --> Controller Class Initialized
INFO - 2020-07-06 22:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 22:02:18 --> Pagination Class Initialized
ERROR - 2020-07-06 22:02:18 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 22:02:18 --> Helper loaded: file_helper
DEBUG - 2020-07-06 22:02:18 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 22:02:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 22:02:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 22:02:18 --> Encryption Class Initialized
INFO - 2020-07-06 22:02:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 22:02:18 --> Final output sent to browser
DEBUG - 2020-07-06 22:02:18 --> Total execution time: 0.0069
INFO - 2020-07-06 23:58:35 --> Config Class Initialized
INFO - 2020-07-06 23:58:35 --> Hooks Class Initialized
DEBUG - 2020-07-06 23:58:35 --> UTF-8 Support Enabled
INFO - 2020-07-06 23:58:35 --> Utf8 Class Initialized
INFO - 2020-07-06 23:58:35 --> URI Class Initialized
INFO - 2020-07-06 23:58:35 --> Router Class Initialized
INFO - 2020-07-06 23:58:35 --> Output Class Initialized
INFO - 2020-07-06 23:58:35 --> Security Class Initialized
DEBUG - 2020-07-06 23:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 23:58:35 --> Input Class Initialized
INFO - 2020-07-06 23:58:35 --> Language Class Initialized
INFO - 2020-07-06 23:58:35 --> Language Class Initialized
INFO - 2020-07-06 23:58:35 --> Config Class Initialized
INFO - 2020-07-06 23:58:35 --> Loader Class Initialized
INFO - 2020-07-06 23:58:35 --> Helper loaded: url_helper
INFO - 2020-07-06 23:58:35 --> Helper loaded: main_helper
INFO - 2020-07-06 23:58:35 --> Database Driver Class Initialized
DEBUG - 2020-07-06 23:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 23:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 23:58:35 --> Controller Class Initialized
INFO - 2020-07-06 23:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 23:58:35 --> Pagination Class Initialized
ERROR - 2020-07-06 23:58:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 23:58:35 --> Helper loaded: file_helper
DEBUG - 2020-07-06 23:58:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 23:58:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 23:58:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 23:58:35 --> Encryption Class Initialized
INFO - 2020-07-06 23:58:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 23:58:35 --> Final output sent to browser
DEBUG - 2020-07-06 23:58:35 --> Total execution time: 0.0071
INFO - 2020-07-06 23:58:48 --> Config Class Initialized
INFO - 2020-07-06 23:58:48 --> Hooks Class Initialized
DEBUG - 2020-07-06 23:58:48 --> UTF-8 Support Enabled
INFO - 2020-07-06 23:58:48 --> Utf8 Class Initialized
INFO - 2020-07-06 23:58:48 --> URI Class Initialized
INFO - 2020-07-06 23:58:48 --> Router Class Initialized
INFO - 2020-07-06 23:58:48 --> Output Class Initialized
INFO - 2020-07-06 23:58:48 --> Security Class Initialized
DEBUG - 2020-07-06 23:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 23:58:48 --> Input Class Initialized
INFO - 2020-07-06 23:58:48 --> Language Class Initialized
INFO - 2020-07-06 23:58:48 --> Language Class Initialized
INFO - 2020-07-06 23:58:48 --> Config Class Initialized
INFO - 2020-07-06 23:58:48 --> Loader Class Initialized
INFO - 2020-07-06 23:58:48 --> Helper loaded: url_helper
INFO - 2020-07-06 23:58:48 --> Helper loaded: main_helper
INFO - 2020-07-06 23:58:48 --> Database Driver Class Initialized
DEBUG - 2020-07-06 23:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 23:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 23:58:48 --> Controller Class Initialized
INFO - 2020-07-06 23:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 23:58:48 --> Pagination Class Initialized
ERROR - 2020-07-06 23:58:48 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 23:58:48 --> Helper loaded: file_helper
DEBUG - 2020-07-06 23:58:48 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 23:58:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 23:58:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 23:58:48 --> Encryption Class Initialized
INFO - 2020-07-06 23:58:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 23:58:48 --> Final output sent to browser
DEBUG - 2020-07-06 23:58:48 --> Total execution time: 0.0065
INFO - 2020-07-06 23:59:09 --> Config Class Initialized
INFO - 2020-07-06 23:59:09 --> Hooks Class Initialized
DEBUG - 2020-07-06 23:59:09 --> UTF-8 Support Enabled
INFO - 2020-07-06 23:59:09 --> Utf8 Class Initialized
INFO - 2020-07-06 23:59:09 --> URI Class Initialized
INFO - 2020-07-06 23:59:09 --> Router Class Initialized
INFO - 2020-07-06 23:59:09 --> Output Class Initialized
INFO - 2020-07-06 23:59:09 --> Security Class Initialized
DEBUG - 2020-07-06 23:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 23:59:09 --> Input Class Initialized
INFO - 2020-07-06 23:59:09 --> Language Class Initialized
INFO - 2020-07-06 23:59:09 --> Language Class Initialized
INFO - 2020-07-06 23:59:09 --> Config Class Initialized
INFO - 2020-07-06 23:59:09 --> Loader Class Initialized
INFO - 2020-07-06 23:59:09 --> Helper loaded: url_helper
INFO - 2020-07-06 23:59:09 --> Helper loaded: main_helper
INFO - 2020-07-06 23:59:09 --> Database Driver Class Initialized
DEBUG - 2020-07-06 23:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 23:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 23:59:09 --> Controller Class Initialized
INFO - 2020-07-06 23:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 23:59:09 --> Pagination Class Initialized
ERROR - 2020-07-06 23:59:09 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 23:59:09 --> Helper loaded: file_helper
DEBUG - 2020-07-06 23:59:09 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 23:59:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 23:59:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 23:59:09 --> Encryption Class Initialized
INFO - 2020-07-06 23:59:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 23:59:11 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-06 23:59:11 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-06 23:59:11 --> Final output sent to browser
DEBUG - 2020-07-06 23:59:11 --> Total execution time: 1.8349
INFO - 2020-07-06 23:59:14 --> Config Class Initialized
INFO - 2020-07-06 23:59:14 --> Hooks Class Initialized
DEBUG - 2020-07-06 23:59:14 --> UTF-8 Support Enabled
INFO - 2020-07-06 23:59:14 --> Utf8 Class Initialized
INFO - 2020-07-06 23:59:14 --> URI Class Initialized
INFO - 2020-07-06 23:59:14 --> Router Class Initialized
INFO - 2020-07-06 23:59:14 --> Output Class Initialized
INFO - 2020-07-06 23:59:14 --> Security Class Initialized
DEBUG - 2020-07-06 23:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-06 23:59:14 --> Input Class Initialized
INFO - 2020-07-06 23:59:14 --> Language Class Initialized
INFO - 2020-07-06 23:59:14 --> Language Class Initialized
INFO - 2020-07-06 23:59:14 --> Config Class Initialized
INFO - 2020-07-06 23:59:14 --> Loader Class Initialized
INFO - 2020-07-06 23:59:14 --> Helper loaded: url_helper
INFO - 2020-07-06 23:59:14 --> Helper loaded: main_helper
INFO - 2020-07-06 23:59:14 --> Database Driver Class Initialized
DEBUG - 2020-07-06 23:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-06 23:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-06 23:59:14 --> Controller Class Initialized
INFO - 2020-07-06 23:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-06 23:59:14 --> Pagination Class Initialized
ERROR - 2020-07-06 23:59:14 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-06 23:59:14 --> Helper loaded: file_helper
DEBUG - 2020-07-06 23:59:14 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-06 23:59:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-06 23:59:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-06 23:59:14 --> Encryption Class Initialized
INFO - 2020-07-06 23:59:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-06 23:59:15 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-06 23:59:15 --> Final output sent to browser
DEBUG - 2020-07-06 23:59:15 --> Total execution time: 1.2108
