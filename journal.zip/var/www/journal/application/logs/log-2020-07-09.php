<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-07-09 06:18:49 --> Config Class Initialized
INFO - 2020-07-09 06:18:49 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:18:49 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:18:49 --> Utf8 Class Initialized
INFO - 2020-07-09 06:18:49 --> URI Class Initialized
INFO - 2020-07-09 06:18:49 --> Router Class Initialized
INFO - 2020-07-09 06:18:49 --> Output Class Initialized
INFO - 2020-07-09 06:18:49 --> Security Class Initialized
DEBUG - 2020-07-09 06:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:18:49 --> Input Class Initialized
INFO - 2020-07-09 06:18:49 --> Language Class Initialized
INFO - 2020-07-09 06:18:49 --> Language Class Initialized
INFO - 2020-07-09 06:18:49 --> Config Class Initialized
INFO - 2020-07-09 06:18:49 --> Loader Class Initialized
INFO - 2020-07-09 06:18:49 --> Helper loaded: url_helper
INFO - 2020-07-09 06:18:49 --> Helper loaded: main_helper
INFO - 2020-07-09 06:18:49 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:18:49 --> Controller Class Initialized
DEBUG - 2020-07-09 06:18:49 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 06:18:49 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 06:18:49 --> Final output sent to browser
DEBUG - 2020-07-09 06:18:49 --> Total execution time: 0.0039
INFO - 2020-07-09 06:22:08 --> Config Class Initialized
INFO - 2020-07-09 06:22:08 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:22:08 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:22:08 --> Utf8 Class Initialized
INFO - 2020-07-09 06:22:08 --> URI Class Initialized
INFO - 2020-07-09 06:22:08 --> Router Class Initialized
INFO - 2020-07-09 06:22:08 --> Output Class Initialized
INFO - 2020-07-09 06:22:08 --> Security Class Initialized
DEBUG - 2020-07-09 06:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:22:08 --> Input Class Initialized
INFO - 2020-07-09 06:22:08 --> Language Class Initialized
INFO - 2020-07-09 06:22:08 --> Language Class Initialized
INFO - 2020-07-09 06:22:08 --> Config Class Initialized
INFO - 2020-07-09 06:22:08 --> Loader Class Initialized
INFO - 2020-07-09 06:22:08 --> Helper loaded: url_helper
INFO - 2020-07-09 06:22:08 --> Helper loaded: main_helper
INFO - 2020-07-09 06:22:08 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:22:08 --> Controller Class Initialized
DEBUG - 2020-07-09 06:22:08 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 06:22:08 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 06:22:08 --> Final output sent to browser
DEBUG - 2020-07-09 06:22:08 --> Total execution time: 0.0037
INFO - 2020-07-09 06:22:22 --> Config Class Initialized
INFO - 2020-07-09 06:22:22 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:22:22 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:22:22 --> Utf8 Class Initialized
INFO - 2020-07-09 06:22:22 --> URI Class Initialized
DEBUG - 2020-07-09 06:22:22 --> No URI present. Default controller set.
INFO - 2020-07-09 06:22:22 --> Router Class Initialized
INFO - 2020-07-09 06:22:22 --> Output Class Initialized
INFO - 2020-07-09 06:22:22 --> Security Class Initialized
DEBUG - 2020-07-09 06:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:22:22 --> Input Class Initialized
INFO - 2020-07-09 06:22:22 --> Language Class Initialized
INFO - 2020-07-09 06:22:22 --> Language Class Initialized
INFO - 2020-07-09 06:22:22 --> Config Class Initialized
INFO - 2020-07-09 06:22:22 --> Loader Class Initialized
INFO - 2020-07-09 06:22:22 --> Helper loaded: url_helper
INFO - 2020-07-09 06:22:22 --> Helper loaded: main_helper
INFO - 2020-07-09 06:22:22 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:22:22 --> Controller Class Initialized
DEBUG - 2020-07-09 06:22:22 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:22:22 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:22:22 --> Final output sent to browser
DEBUG - 2020-07-09 06:22:22 --> Total execution time: 0.0054
INFO - 2020-07-09 06:23:01 --> Config Class Initialized
INFO - 2020-07-09 06:23:01 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:23:01 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:23:01 --> Utf8 Class Initialized
INFO - 2020-07-09 06:23:01 --> URI Class Initialized
DEBUG - 2020-07-09 06:23:01 --> No URI present. Default controller set.
INFO - 2020-07-09 06:23:01 --> Router Class Initialized
INFO - 2020-07-09 06:23:01 --> Output Class Initialized
INFO - 2020-07-09 06:23:01 --> Security Class Initialized
DEBUG - 2020-07-09 06:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:23:01 --> Input Class Initialized
INFO - 2020-07-09 06:23:01 --> Language Class Initialized
INFO - 2020-07-09 06:23:01 --> Language Class Initialized
INFO - 2020-07-09 06:23:01 --> Config Class Initialized
INFO - 2020-07-09 06:23:01 --> Loader Class Initialized
INFO - 2020-07-09 06:23:01 --> Helper loaded: url_helper
INFO - 2020-07-09 06:23:01 --> Helper loaded: main_helper
INFO - 2020-07-09 06:23:01 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:23:01 --> Controller Class Initialized
DEBUG - 2020-07-09 06:23:01 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:23:01 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:23:01 --> Final output sent to browser
DEBUG - 2020-07-09 06:23:01 --> Total execution time: 0.0034
INFO - 2020-07-09 06:24:17 --> Config Class Initialized
INFO - 2020-07-09 06:24:17 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:24:17 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:24:17 --> Utf8 Class Initialized
INFO - 2020-07-09 06:24:17 --> URI Class Initialized
DEBUG - 2020-07-09 06:24:17 --> No URI present. Default controller set.
INFO - 2020-07-09 06:24:17 --> Router Class Initialized
INFO - 2020-07-09 06:24:17 --> Output Class Initialized
INFO - 2020-07-09 06:24:17 --> Security Class Initialized
DEBUG - 2020-07-09 06:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:24:17 --> Input Class Initialized
INFO - 2020-07-09 06:24:17 --> Language Class Initialized
INFO - 2020-07-09 06:24:17 --> Language Class Initialized
INFO - 2020-07-09 06:24:17 --> Config Class Initialized
INFO - 2020-07-09 06:24:17 --> Loader Class Initialized
INFO - 2020-07-09 06:24:17 --> Helper loaded: url_helper
INFO - 2020-07-09 06:24:17 --> Helper loaded: main_helper
INFO - 2020-07-09 06:24:17 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:24:17 --> Controller Class Initialized
DEBUG - 2020-07-09 06:24:17 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:24:17 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:24:17 --> Final output sent to browser
DEBUG - 2020-07-09 06:24:17 --> Total execution time: 0.0040
INFO - 2020-07-09 06:24:26 --> Config Class Initialized
INFO - 2020-07-09 06:24:26 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:24:26 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:24:26 --> Utf8 Class Initialized
INFO - 2020-07-09 06:24:26 --> URI Class Initialized
INFO - 2020-07-09 06:24:26 --> Router Class Initialized
INFO - 2020-07-09 06:24:26 --> Output Class Initialized
INFO - 2020-07-09 06:24:26 --> Security Class Initialized
DEBUG - 2020-07-09 06:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:24:26 --> Input Class Initialized
INFO - 2020-07-09 06:24:26 --> Language Class Initialized
INFO - 2020-07-09 06:24:26 --> Language Class Initialized
INFO - 2020-07-09 06:24:26 --> Config Class Initialized
INFO - 2020-07-09 06:24:26 --> Loader Class Initialized
INFO - 2020-07-09 06:24:26 --> Helper loaded: url_helper
INFO - 2020-07-09 06:24:26 --> Helper loaded: main_helper
INFO - 2020-07-09 06:24:26 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:24:26 --> Controller Class Initialized
DEBUG - 2020-07-09 06:24:26 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 06:24:26 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 06:24:26 --> Final output sent to browser
DEBUG - 2020-07-09 06:24:26 --> Total execution time: 0.0038
INFO - 2020-07-09 06:24:39 --> Config Class Initialized
INFO - 2020-07-09 06:24:39 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:24:39 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:24:39 --> Utf8 Class Initialized
INFO - 2020-07-09 06:24:39 --> URI Class Initialized
DEBUG - 2020-07-09 06:24:39 --> No URI present. Default controller set.
INFO - 2020-07-09 06:24:39 --> Router Class Initialized
INFO - 2020-07-09 06:24:39 --> Output Class Initialized
INFO - 2020-07-09 06:24:39 --> Security Class Initialized
DEBUG - 2020-07-09 06:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:24:39 --> Input Class Initialized
INFO - 2020-07-09 06:24:39 --> Language Class Initialized
INFO - 2020-07-09 06:24:39 --> Language Class Initialized
INFO - 2020-07-09 06:24:39 --> Config Class Initialized
INFO - 2020-07-09 06:24:39 --> Loader Class Initialized
INFO - 2020-07-09 06:24:39 --> Helper loaded: url_helper
INFO - 2020-07-09 06:24:39 --> Helper loaded: main_helper
INFO - 2020-07-09 06:24:39 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:24:39 --> Controller Class Initialized
DEBUG - 2020-07-09 06:24:39 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:24:39 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:24:39 --> Final output sent to browser
DEBUG - 2020-07-09 06:24:39 --> Total execution time: 0.0055
INFO - 2020-07-09 06:33:05 --> Config Class Initialized
INFO - 2020-07-09 06:33:05 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:33:05 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:33:05 --> Utf8 Class Initialized
INFO - 2020-07-09 06:33:05 --> URI Class Initialized
DEBUG - 2020-07-09 06:33:05 --> No URI present. Default controller set.
INFO - 2020-07-09 06:33:05 --> Router Class Initialized
INFO - 2020-07-09 06:33:05 --> Output Class Initialized
INFO - 2020-07-09 06:33:05 --> Security Class Initialized
DEBUG - 2020-07-09 06:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:33:05 --> Input Class Initialized
INFO - 2020-07-09 06:33:05 --> Language Class Initialized
INFO - 2020-07-09 06:33:05 --> Language Class Initialized
INFO - 2020-07-09 06:33:05 --> Config Class Initialized
INFO - 2020-07-09 06:33:05 --> Loader Class Initialized
INFO - 2020-07-09 06:33:05 --> Helper loaded: url_helper
INFO - 2020-07-09 06:33:05 --> Helper loaded: main_helper
INFO - 2020-07-09 06:33:05 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:33:05 --> Controller Class Initialized
DEBUG - 2020-07-09 06:33:05 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:33:05 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:33:05 --> Final output sent to browser
DEBUG - 2020-07-09 06:33:05 --> Total execution time: 0.0066
INFO - 2020-07-09 06:33:37 --> Config Class Initialized
INFO - 2020-07-09 06:33:37 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:33:37 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:33:37 --> Utf8 Class Initialized
INFO - 2020-07-09 06:33:37 --> URI Class Initialized
DEBUG - 2020-07-09 06:33:37 --> No URI present. Default controller set.
INFO - 2020-07-09 06:33:37 --> Router Class Initialized
INFO - 2020-07-09 06:33:37 --> Output Class Initialized
INFO - 2020-07-09 06:33:37 --> Security Class Initialized
DEBUG - 2020-07-09 06:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:33:37 --> Input Class Initialized
INFO - 2020-07-09 06:33:37 --> Language Class Initialized
INFO - 2020-07-09 06:33:37 --> Language Class Initialized
INFO - 2020-07-09 06:33:37 --> Config Class Initialized
INFO - 2020-07-09 06:33:37 --> Loader Class Initialized
INFO - 2020-07-09 06:33:37 --> Helper loaded: url_helper
INFO - 2020-07-09 06:33:37 --> Helper loaded: main_helper
INFO - 2020-07-09 06:33:37 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:33:37 --> Controller Class Initialized
DEBUG - 2020-07-09 06:33:37 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:33:37 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:33:37 --> Final output sent to browser
DEBUG - 2020-07-09 06:33:37 --> Total execution time: 0.0044
INFO - 2020-07-09 06:35:01 --> Config Class Initialized
INFO - 2020-07-09 06:35:01 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:35:01 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:35:01 --> Utf8 Class Initialized
INFO - 2020-07-09 06:35:01 --> URI Class Initialized
DEBUG - 2020-07-09 06:35:01 --> No URI present. Default controller set.
INFO - 2020-07-09 06:35:01 --> Router Class Initialized
INFO - 2020-07-09 06:35:01 --> Output Class Initialized
INFO - 2020-07-09 06:35:01 --> Security Class Initialized
DEBUG - 2020-07-09 06:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:35:01 --> Input Class Initialized
INFO - 2020-07-09 06:35:01 --> Language Class Initialized
INFO - 2020-07-09 06:35:01 --> Language Class Initialized
INFO - 2020-07-09 06:35:01 --> Config Class Initialized
INFO - 2020-07-09 06:35:01 --> Loader Class Initialized
INFO - 2020-07-09 06:35:01 --> Helper loaded: url_helper
INFO - 2020-07-09 06:35:01 --> Helper loaded: main_helper
INFO - 2020-07-09 06:35:01 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:35:01 --> Controller Class Initialized
DEBUG - 2020-07-09 06:35:01 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:35:01 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:35:01 --> Final output sent to browser
DEBUG - 2020-07-09 06:35:01 --> Total execution time: 0.0051
INFO - 2020-07-09 06:35:41 --> Config Class Initialized
INFO - 2020-07-09 06:35:41 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:35:41 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:35:41 --> Utf8 Class Initialized
INFO - 2020-07-09 06:35:41 --> URI Class Initialized
DEBUG - 2020-07-09 06:35:41 --> No URI present. Default controller set.
INFO - 2020-07-09 06:35:41 --> Router Class Initialized
INFO - 2020-07-09 06:35:41 --> Output Class Initialized
INFO - 2020-07-09 06:35:41 --> Security Class Initialized
DEBUG - 2020-07-09 06:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:35:41 --> Input Class Initialized
INFO - 2020-07-09 06:35:41 --> Language Class Initialized
INFO - 2020-07-09 06:35:41 --> Language Class Initialized
INFO - 2020-07-09 06:35:41 --> Config Class Initialized
INFO - 2020-07-09 06:35:41 --> Loader Class Initialized
INFO - 2020-07-09 06:35:41 --> Helper loaded: url_helper
INFO - 2020-07-09 06:35:41 --> Helper loaded: main_helper
INFO - 2020-07-09 06:35:41 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:35:41 --> Controller Class Initialized
DEBUG - 2020-07-09 06:35:41 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:35:41 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:35:41 --> Final output sent to browser
DEBUG - 2020-07-09 06:35:41 --> Total execution time: 0.0037
INFO - 2020-07-09 06:48:43 --> Config Class Initialized
INFO - 2020-07-09 06:48:43 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:48:43 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:48:43 --> Utf8 Class Initialized
INFO - 2020-07-09 06:48:43 --> URI Class Initialized
DEBUG - 2020-07-09 06:48:43 --> No URI present. Default controller set.
INFO - 2020-07-09 06:48:43 --> Router Class Initialized
INFO - 2020-07-09 06:48:43 --> Output Class Initialized
INFO - 2020-07-09 06:48:43 --> Security Class Initialized
DEBUG - 2020-07-09 06:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:48:43 --> Input Class Initialized
INFO - 2020-07-09 06:48:43 --> Language Class Initialized
INFO - 2020-07-09 06:48:43 --> Language Class Initialized
INFO - 2020-07-09 06:48:43 --> Config Class Initialized
INFO - 2020-07-09 06:48:43 --> Loader Class Initialized
INFO - 2020-07-09 06:48:43 --> Helper loaded: url_helper
INFO - 2020-07-09 06:48:43 --> Helper loaded: main_helper
INFO - 2020-07-09 06:48:43 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:48:43 --> Controller Class Initialized
DEBUG - 2020-07-09 06:48:43 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:48:43 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:48:43 --> Final output sent to browser
DEBUG - 2020-07-09 06:48:43 --> Total execution time: 0.0048
INFO - 2020-07-09 06:49:05 --> Config Class Initialized
INFO - 2020-07-09 06:49:05 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:49:05 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:49:05 --> Utf8 Class Initialized
INFO - 2020-07-09 06:49:05 --> URI Class Initialized
DEBUG - 2020-07-09 06:49:05 --> No URI present. Default controller set.
INFO - 2020-07-09 06:49:05 --> Router Class Initialized
INFO - 2020-07-09 06:49:05 --> Output Class Initialized
INFO - 2020-07-09 06:49:05 --> Security Class Initialized
DEBUG - 2020-07-09 06:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:49:05 --> Input Class Initialized
INFO - 2020-07-09 06:49:05 --> Language Class Initialized
INFO - 2020-07-09 06:49:05 --> Language Class Initialized
INFO - 2020-07-09 06:49:05 --> Config Class Initialized
INFO - 2020-07-09 06:49:05 --> Loader Class Initialized
INFO - 2020-07-09 06:49:05 --> Helper loaded: url_helper
INFO - 2020-07-09 06:49:05 --> Helper loaded: main_helper
INFO - 2020-07-09 06:49:05 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:49:05 --> Controller Class Initialized
DEBUG - 2020-07-09 06:49:05 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:49:05 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:49:05 --> Final output sent to browser
DEBUG - 2020-07-09 06:49:05 --> Total execution time: 0.0040
INFO - 2020-07-09 06:53:07 --> Config Class Initialized
INFO - 2020-07-09 06:53:07 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:53:07 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:53:07 --> Utf8 Class Initialized
INFO - 2020-07-09 06:53:07 --> URI Class Initialized
DEBUG - 2020-07-09 06:53:07 --> No URI present. Default controller set.
INFO - 2020-07-09 06:53:07 --> Router Class Initialized
INFO - 2020-07-09 06:53:07 --> Output Class Initialized
INFO - 2020-07-09 06:53:07 --> Security Class Initialized
DEBUG - 2020-07-09 06:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:53:07 --> Input Class Initialized
INFO - 2020-07-09 06:53:07 --> Language Class Initialized
INFO - 2020-07-09 06:53:07 --> Language Class Initialized
INFO - 2020-07-09 06:53:07 --> Config Class Initialized
INFO - 2020-07-09 06:53:07 --> Loader Class Initialized
INFO - 2020-07-09 06:53:07 --> Helper loaded: url_helper
INFO - 2020-07-09 06:53:07 --> Helper loaded: main_helper
INFO - 2020-07-09 06:53:07 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:53:07 --> Controller Class Initialized
DEBUG - 2020-07-09 06:53:07 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:53:07 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:53:07 --> Final output sent to browser
DEBUG - 2020-07-09 06:53:07 --> Total execution time: 0.0042
INFO - 2020-07-09 06:53:13 --> Config Class Initialized
INFO - 2020-07-09 06:53:13 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:53:13 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:53:13 --> Utf8 Class Initialized
INFO - 2020-07-09 06:53:13 --> URI Class Initialized
DEBUG - 2020-07-09 06:53:13 --> No URI present. Default controller set.
INFO - 2020-07-09 06:53:13 --> Router Class Initialized
INFO - 2020-07-09 06:53:13 --> Output Class Initialized
INFO - 2020-07-09 06:53:13 --> Security Class Initialized
DEBUG - 2020-07-09 06:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:53:13 --> Input Class Initialized
INFO - 2020-07-09 06:53:13 --> Language Class Initialized
INFO - 2020-07-09 06:53:13 --> Language Class Initialized
INFO - 2020-07-09 06:53:13 --> Config Class Initialized
INFO - 2020-07-09 06:53:13 --> Loader Class Initialized
INFO - 2020-07-09 06:53:13 --> Helper loaded: url_helper
INFO - 2020-07-09 06:53:13 --> Helper loaded: main_helper
INFO - 2020-07-09 06:53:13 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:53:13 --> Controller Class Initialized
DEBUG - 2020-07-09 06:53:13 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:53:13 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:53:13 --> Final output sent to browser
DEBUG - 2020-07-09 06:53:13 --> Total execution time: 0.0038
INFO - 2020-07-09 06:57:39 --> Config Class Initialized
INFO - 2020-07-09 06:57:39 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:57:39 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:57:39 --> Utf8 Class Initialized
INFO - 2020-07-09 06:57:39 --> URI Class Initialized
DEBUG - 2020-07-09 06:57:39 --> No URI present. Default controller set.
INFO - 2020-07-09 06:57:39 --> Router Class Initialized
INFO - 2020-07-09 06:57:39 --> Output Class Initialized
INFO - 2020-07-09 06:57:39 --> Security Class Initialized
DEBUG - 2020-07-09 06:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:57:39 --> Input Class Initialized
INFO - 2020-07-09 06:57:39 --> Language Class Initialized
INFO - 2020-07-09 06:57:39 --> Language Class Initialized
INFO - 2020-07-09 06:57:39 --> Config Class Initialized
INFO - 2020-07-09 06:57:39 --> Loader Class Initialized
INFO - 2020-07-09 06:57:39 --> Helper loaded: url_helper
INFO - 2020-07-09 06:57:39 --> Helper loaded: main_helper
INFO - 2020-07-09 06:57:39 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:57:39 --> Controller Class Initialized
DEBUG - 2020-07-09 06:57:39 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:57:39 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:57:39 --> Final output sent to browser
DEBUG - 2020-07-09 06:57:39 --> Total execution time: 0.0070
INFO - 2020-07-09 06:57:43 --> Config Class Initialized
INFO - 2020-07-09 06:57:43 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:57:43 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:57:43 --> Utf8 Class Initialized
INFO - 2020-07-09 06:57:43 --> URI Class Initialized
INFO - 2020-07-09 06:57:43 --> Router Class Initialized
INFO - 2020-07-09 06:57:43 --> Output Class Initialized
INFO - 2020-07-09 06:57:43 --> Security Class Initialized
DEBUG - 2020-07-09 06:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:57:43 --> Input Class Initialized
INFO - 2020-07-09 06:57:43 --> Language Class Initialized
INFO - 2020-07-09 06:57:43 --> Language Class Initialized
INFO - 2020-07-09 06:57:43 --> Config Class Initialized
INFO - 2020-07-09 06:57:43 --> Loader Class Initialized
INFO - 2020-07-09 06:57:43 --> Helper loaded: url_helper
INFO - 2020-07-09 06:57:43 --> Helper loaded: main_helper
INFO - 2020-07-09 06:57:43 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:57:43 --> Controller Class Initialized
DEBUG - 2020-07-09 06:57:43 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 06:57:43 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 06:57:43 --> Final output sent to browser
DEBUG - 2020-07-09 06:57:43 --> Total execution time: 0.0032
INFO - 2020-07-09 06:57:53 --> Config Class Initialized
INFO - 2020-07-09 06:57:53 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:57:53 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:57:53 --> Utf8 Class Initialized
INFO - 2020-07-09 06:57:53 --> URI Class Initialized
DEBUG - 2020-07-09 06:57:53 --> No URI present. Default controller set.
INFO - 2020-07-09 06:57:53 --> Router Class Initialized
INFO - 2020-07-09 06:57:53 --> Output Class Initialized
INFO - 2020-07-09 06:57:53 --> Security Class Initialized
DEBUG - 2020-07-09 06:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:57:53 --> Input Class Initialized
INFO - 2020-07-09 06:57:53 --> Language Class Initialized
INFO - 2020-07-09 06:57:53 --> Language Class Initialized
INFO - 2020-07-09 06:57:53 --> Config Class Initialized
INFO - 2020-07-09 06:57:53 --> Loader Class Initialized
INFO - 2020-07-09 06:57:53 --> Helper loaded: url_helper
INFO - 2020-07-09 06:57:53 --> Helper loaded: main_helper
INFO - 2020-07-09 06:57:53 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:57:53 --> Controller Class Initialized
DEBUG - 2020-07-09 06:57:53 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:57:53 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:57:53 --> Final output sent to browser
DEBUG - 2020-07-09 06:57:53 --> Total execution time: 0.0059
INFO - 2020-07-09 06:58:02 --> Config Class Initialized
INFO - 2020-07-09 06:58:02 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:58:02 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:58:02 --> Utf8 Class Initialized
INFO - 2020-07-09 06:58:02 --> URI Class Initialized
INFO - 2020-07-09 06:58:02 --> Router Class Initialized
INFO - 2020-07-09 06:58:02 --> Output Class Initialized
INFO - 2020-07-09 06:58:02 --> Security Class Initialized
DEBUG - 2020-07-09 06:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:58:02 --> Input Class Initialized
INFO - 2020-07-09 06:58:02 --> Language Class Initialized
INFO - 2020-07-09 06:58:02 --> Language Class Initialized
INFO - 2020-07-09 06:58:02 --> Config Class Initialized
INFO - 2020-07-09 06:58:02 --> Loader Class Initialized
INFO - 2020-07-09 06:58:02 --> Helper loaded: url_helper
INFO - 2020-07-09 06:58:02 --> Helper loaded: main_helper
INFO - 2020-07-09 06:58:02 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:58:02 --> Controller Class Initialized
DEBUG - 2020-07-09 06:58:02 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 06:58:02 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 06:58:02 --> Final output sent to browser
DEBUG - 2020-07-09 06:58:02 --> Total execution time: 0.0053
INFO - 2020-07-09 06:58:04 --> Config Class Initialized
INFO - 2020-07-09 06:58:04 --> Hooks Class Initialized
DEBUG - 2020-07-09 06:58:04 --> UTF-8 Support Enabled
INFO - 2020-07-09 06:58:04 --> Utf8 Class Initialized
INFO - 2020-07-09 06:58:04 --> URI Class Initialized
DEBUG - 2020-07-09 06:58:04 --> No URI present. Default controller set.
INFO - 2020-07-09 06:58:04 --> Router Class Initialized
INFO - 2020-07-09 06:58:04 --> Output Class Initialized
INFO - 2020-07-09 06:58:04 --> Security Class Initialized
DEBUG - 2020-07-09 06:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 06:58:04 --> Input Class Initialized
INFO - 2020-07-09 06:58:04 --> Language Class Initialized
INFO - 2020-07-09 06:58:04 --> Language Class Initialized
INFO - 2020-07-09 06:58:04 --> Config Class Initialized
INFO - 2020-07-09 06:58:04 --> Loader Class Initialized
INFO - 2020-07-09 06:58:04 --> Helper loaded: url_helper
INFO - 2020-07-09 06:58:04 --> Helper loaded: main_helper
INFO - 2020-07-09 06:58:04 --> Database Driver Class Initialized
DEBUG - 2020-07-09 06:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 06:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 06:58:04 --> Controller Class Initialized
DEBUG - 2020-07-09 06:58:04 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 06:58:04 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 06:58:04 --> Final output sent to browser
DEBUG - 2020-07-09 06:58:04 --> Total execution time: 0.0034
INFO - 2020-07-09 07:01:19 --> Config Class Initialized
INFO - 2020-07-09 07:01:19 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:01:19 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:01:19 --> Utf8 Class Initialized
INFO - 2020-07-09 07:01:19 --> URI Class Initialized
INFO - 2020-07-09 07:01:19 --> Router Class Initialized
INFO - 2020-07-09 07:01:19 --> Output Class Initialized
INFO - 2020-07-09 07:01:19 --> Security Class Initialized
DEBUG - 2020-07-09 07:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:01:19 --> Input Class Initialized
INFO - 2020-07-09 07:01:19 --> Language Class Initialized
INFO - 2020-07-09 07:01:19 --> Language Class Initialized
INFO - 2020-07-09 07:01:19 --> Config Class Initialized
INFO - 2020-07-09 07:01:19 --> Loader Class Initialized
INFO - 2020-07-09 07:01:19 --> Helper loaded: url_helper
INFO - 2020-07-09 07:01:19 --> Helper loaded: main_helper
INFO - 2020-07-09 07:01:19 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:01:19 --> Controller Class Initialized
DEBUG - 2020-07-09 07:01:19 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:01:19 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:01:19 --> Final output sent to browser
DEBUG - 2020-07-09 07:01:19 --> Total execution time: 0.0035
INFO - 2020-07-09 07:03:53 --> Config Class Initialized
INFO - 2020-07-09 07:03:53 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:03:53 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:03:53 --> Utf8 Class Initialized
INFO - 2020-07-09 07:03:53 --> URI Class Initialized
INFO - 2020-07-09 07:03:53 --> Router Class Initialized
INFO - 2020-07-09 07:03:53 --> Output Class Initialized
INFO - 2020-07-09 07:03:53 --> Security Class Initialized
DEBUG - 2020-07-09 07:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:03:53 --> Input Class Initialized
INFO - 2020-07-09 07:03:53 --> Language Class Initialized
INFO - 2020-07-09 07:03:53 --> Language Class Initialized
INFO - 2020-07-09 07:03:53 --> Config Class Initialized
INFO - 2020-07-09 07:03:53 --> Loader Class Initialized
INFO - 2020-07-09 07:03:53 --> Helper loaded: url_helper
INFO - 2020-07-09 07:03:53 --> Helper loaded: main_helper
INFO - 2020-07-09 07:03:53 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:03:53 --> Controller Class Initialized
DEBUG - 2020-07-09 07:03:53 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:03:53 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:03:53 --> Final output sent to browser
DEBUG - 2020-07-09 07:03:53 --> Total execution time: 0.0042
INFO - 2020-07-09 07:04:03 --> Config Class Initialized
INFO - 2020-07-09 07:04:03 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:04:03 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:04:03 --> Utf8 Class Initialized
INFO - 2020-07-09 07:04:03 --> URI Class Initialized
INFO - 2020-07-09 07:04:03 --> Router Class Initialized
INFO - 2020-07-09 07:04:03 --> Output Class Initialized
INFO - 2020-07-09 07:04:03 --> Security Class Initialized
DEBUG - 2020-07-09 07:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:04:03 --> Input Class Initialized
INFO - 2020-07-09 07:04:03 --> Language Class Initialized
INFO - 2020-07-09 07:04:03 --> Language Class Initialized
INFO - 2020-07-09 07:04:03 --> Config Class Initialized
INFO - 2020-07-09 07:04:03 --> Loader Class Initialized
INFO - 2020-07-09 07:04:03 --> Helper loaded: url_helper
INFO - 2020-07-09 07:04:03 --> Helper loaded: main_helper
INFO - 2020-07-09 07:04:03 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:04:03 --> Controller Class Initialized
DEBUG - 2020-07-09 07:04:03 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:16:09 --> Config Class Initialized
INFO - 2020-07-09 07:16:09 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:16:09 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:16:09 --> Utf8 Class Initialized
INFO - 2020-07-09 07:16:09 --> URI Class Initialized
DEBUG - 2020-07-09 07:16:09 --> No URI present. Default controller set.
INFO - 2020-07-09 07:16:09 --> Router Class Initialized
INFO - 2020-07-09 07:16:09 --> Output Class Initialized
INFO - 2020-07-09 07:16:09 --> Security Class Initialized
DEBUG - 2020-07-09 07:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:16:09 --> Input Class Initialized
INFO - 2020-07-09 07:16:09 --> Language Class Initialized
INFO - 2020-07-09 07:16:09 --> Language Class Initialized
INFO - 2020-07-09 07:16:09 --> Config Class Initialized
INFO - 2020-07-09 07:16:09 --> Loader Class Initialized
INFO - 2020-07-09 07:16:09 --> Helper loaded: url_helper
INFO - 2020-07-09 07:16:09 --> Helper loaded: main_helper
INFO - 2020-07-09 07:16:09 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:16:09 --> Controller Class Initialized
DEBUG - 2020-07-09 07:16:09 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:16:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:16:09 --> Final output sent to browser
DEBUG - 2020-07-09 07:16:09 --> Total execution time: 0.0048
INFO - 2020-07-09 07:16:12 --> Config Class Initialized
INFO - 2020-07-09 07:16:12 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:16:12 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:16:12 --> Utf8 Class Initialized
INFO - 2020-07-09 07:16:12 --> URI Class Initialized
DEBUG - 2020-07-09 07:16:12 --> No URI present. Default controller set.
INFO - 2020-07-09 07:16:12 --> Router Class Initialized
INFO - 2020-07-09 07:16:12 --> Output Class Initialized
INFO - 2020-07-09 07:16:12 --> Security Class Initialized
DEBUG - 2020-07-09 07:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:16:12 --> Input Class Initialized
INFO - 2020-07-09 07:16:12 --> Language Class Initialized
INFO - 2020-07-09 07:16:12 --> Language Class Initialized
INFO - 2020-07-09 07:16:12 --> Config Class Initialized
INFO - 2020-07-09 07:16:12 --> Loader Class Initialized
INFO - 2020-07-09 07:16:12 --> Helper loaded: url_helper
INFO - 2020-07-09 07:16:12 --> Helper loaded: main_helper
INFO - 2020-07-09 07:16:12 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:16:12 --> Controller Class Initialized
DEBUG - 2020-07-09 07:16:12 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:16:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:16:12 --> Final output sent to browser
DEBUG - 2020-07-09 07:16:12 --> Total execution time: 0.0049
INFO - 2020-07-09 07:16:14 --> Config Class Initialized
INFO - 2020-07-09 07:16:14 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:16:14 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:16:14 --> Utf8 Class Initialized
INFO - 2020-07-09 07:16:14 --> URI Class Initialized
INFO - 2020-07-09 07:16:14 --> Router Class Initialized
INFO - 2020-07-09 07:16:14 --> Output Class Initialized
INFO - 2020-07-09 07:16:14 --> Security Class Initialized
DEBUG - 2020-07-09 07:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:16:14 --> Input Class Initialized
INFO - 2020-07-09 07:16:14 --> Language Class Initialized
INFO - 2020-07-09 07:16:14 --> Language Class Initialized
INFO - 2020-07-09 07:16:14 --> Config Class Initialized
INFO - 2020-07-09 07:16:14 --> Loader Class Initialized
INFO - 2020-07-09 07:16:14 --> Helper loaded: url_helper
INFO - 2020-07-09 07:16:14 --> Helper loaded: main_helper
INFO - 2020-07-09 07:16:14 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:16:14 --> Controller Class Initialized
DEBUG - 2020-07-09 07:16:14 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:16:14 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:16:14 --> Final output sent to browser
DEBUG - 2020-07-09 07:16:14 --> Total execution time: 0.0038
INFO - 2020-07-09 07:17:24 --> Config Class Initialized
INFO - 2020-07-09 07:17:24 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:17:24 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:17:24 --> Utf8 Class Initialized
INFO - 2020-07-09 07:17:24 --> URI Class Initialized
INFO - 2020-07-09 07:17:24 --> Router Class Initialized
INFO - 2020-07-09 07:17:24 --> Output Class Initialized
INFO - 2020-07-09 07:17:24 --> Security Class Initialized
DEBUG - 2020-07-09 07:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:17:24 --> Input Class Initialized
INFO - 2020-07-09 07:17:24 --> Language Class Initialized
INFO - 2020-07-09 07:17:24 --> Language Class Initialized
INFO - 2020-07-09 07:17:24 --> Config Class Initialized
INFO - 2020-07-09 07:17:24 --> Loader Class Initialized
INFO - 2020-07-09 07:17:24 --> Helper loaded: url_helper
INFO - 2020-07-09 07:17:24 --> Helper loaded: main_helper
INFO - 2020-07-09 07:17:24 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:17:24 --> Controller Class Initialized
DEBUG - 2020-07-09 07:17:24 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:17:24 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:17:24 --> Final output sent to browser
DEBUG - 2020-07-09 07:17:24 --> Total execution time: 0.0040
INFO - 2020-07-09 07:17:26 --> Config Class Initialized
INFO - 2020-07-09 07:17:26 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:17:26 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:17:26 --> Utf8 Class Initialized
INFO - 2020-07-09 07:17:26 --> URI Class Initialized
INFO - 2020-07-09 07:17:26 --> Router Class Initialized
INFO - 2020-07-09 07:17:26 --> Output Class Initialized
INFO - 2020-07-09 07:17:26 --> Security Class Initialized
DEBUG - 2020-07-09 07:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:17:26 --> Input Class Initialized
INFO - 2020-07-09 07:17:26 --> Language Class Initialized
INFO - 2020-07-09 07:17:26 --> Language Class Initialized
INFO - 2020-07-09 07:17:26 --> Config Class Initialized
INFO - 2020-07-09 07:17:26 --> Loader Class Initialized
INFO - 2020-07-09 07:17:26 --> Helper loaded: url_helper
INFO - 2020-07-09 07:17:26 --> Helper loaded: main_helper
INFO - 2020-07-09 07:17:26 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:17:26 --> Controller Class Initialized
DEBUG - 2020-07-09 07:17:26 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:17:26 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:17:26 --> Final output sent to browser
DEBUG - 2020-07-09 07:17:26 --> Total execution time: 0.0031
INFO - 2020-07-09 07:18:01 --> Config Class Initialized
INFO - 2020-07-09 07:18:01 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:18:01 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:18:01 --> Utf8 Class Initialized
INFO - 2020-07-09 07:18:01 --> URI Class Initialized
INFO - 2020-07-09 07:18:01 --> Router Class Initialized
INFO - 2020-07-09 07:18:01 --> Output Class Initialized
INFO - 2020-07-09 07:18:01 --> Security Class Initialized
DEBUG - 2020-07-09 07:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:18:01 --> Input Class Initialized
INFO - 2020-07-09 07:18:01 --> Language Class Initialized
INFO - 2020-07-09 07:18:01 --> Language Class Initialized
INFO - 2020-07-09 07:18:01 --> Config Class Initialized
INFO - 2020-07-09 07:18:01 --> Loader Class Initialized
INFO - 2020-07-09 07:18:01 --> Helper loaded: url_helper
INFO - 2020-07-09 07:18:01 --> Helper loaded: main_helper
INFO - 2020-07-09 07:18:01 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:18:01 --> Controller Class Initialized
DEBUG - 2020-07-09 07:18:01 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:18:01 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:18:01 --> Final output sent to browser
DEBUG - 2020-07-09 07:18:01 --> Total execution time: 0.0035
INFO - 2020-07-09 07:18:02 --> Config Class Initialized
INFO - 2020-07-09 07:18:02 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:18:02 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:18:02 --> Utf8 Class Initialized
INFO - 2020-07-09 07:18:02 --> URI Class Initialized
INFO - 2020-07-09 07:18:02 --> Router Class Initialized
INFO - 2020-07-09 07:18:02 --> Output Class Initialized
INFO - 2020-07-09 07:18:02 --> Security Class Initialized
DEBUG - 2020-07-09 07:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:18:02 --> Input Class Initialized
INFO - 2020-07-09 07:18:02 --> Language Class Initialized
INFO - 2020-07-09 07:18:02 --> Language Class Initialized
INFO - 2020-07-09 07:18:02 --> Config Class Initialized
INFO - 2020-07-09 07:18:02 --> Loader Class Initialized
INFO - 2020-07-09 07:18:02 --> Helper loaded: url_helper
INFO - 2020-07-09 07:18:02 --> Helper loaded: main_helper
INFO - 2020-07-09 07:18:02 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:18:02 --> Controller Class Initialized
DEBUG - 2020-07-09 07:18:02 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:18:02 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:18:02 --> Final output sent to browser
DEBUG - 2020-07-09 07:18:02 --> Total execution time: 0.0048
INFO - 2020-07-09 07:18:04 --> Config Class Initialized
INFO - 2020-07-09 07:18:04 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:18:04 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:18:04 --> Utf8 Class Initialized
INFO - 2020-07-09 07:18:04 --> URI Class Initialized
INFO - 2020-07-09 07:18:04 --> Router Class Initialized
INFO - 2020-07-09 07:18:04 --> Output Class Initialized
INFO - 2020-07-09 07:18:04 --> Security Class Initialized
DEBUG - 2020-07-09 07:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:18:04 --> Input Class Initialized
INFO - 2020-07-09 07:18:04 --> Language Class Initialized
INFO - 2020-07-09 07:18:04 --> Language Class Initialized
INFO - 2020-07-09 07:18:04 --> Config Class Initialized
INFO - 2020-07-09 07:18:04 --> Loader Class Initialized
INFO - 2020-07-09 07:18:04 --> Helper loaded: url_helper
INFO - 2020-07-09 07:18:04 --> Helper loaded: main_helper
INFO - 2020-07-09 07:18:04 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:18:04 --> Controller Class Initialized
DEBUG - 2020-07-09 07:18:04 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:18:04 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:18:04 --> Final output sent to browser
DEBUG - 2020-07-09 07:18:04 --> Total execution time: 0.0046
INFO - 2020-07-09 07:18:28 --> Config Class Initialized
INFO - 2020-07-09 07:18:28 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:18:28 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:18:28 --> Utf8 Class Initialized
INFO - 2020-07-09 07:18:28 --> URI Class Initialized
INFO - 2020-07-09 07:18:28 --> Router Class Initialized
INFO - 2020-07-09 07:18:28 --> Output Class Initialized
INFO - 2020-07-09 07:18:28 --> Security Class Initialized
DEBUG - 2020-07-09 07:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:18:28 --> Input Class Initialized
INFO - 2020-07-09 07:18:28 --> Language Class Initialized
INFO - 2020-07-09 07:18:28 --> Language Class Initialized
INFO - 2020-07-09 07:18:28 --> Config Class Initialized
INFO - 2020-07-09 07:18:28 --> Loader Class Initialized
INFO - 2020-07-09 07:18:28 --> Helper loaded: url_helper
INFO - 2020-07-09 07:18:28 --> Helper loaded: main_helper
INFO - 2020-07-09 07:18:28 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:18:28 --> Controller Class Initialized
DEBUG - 2020-07-09 07:18:28 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:18:28 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:18:28 --> Final output sent to browser
DEBUG - 2020-07-09 07:18:28 --> Total execution time: 0.0033
INFO - 2020-07-09 07:18:43 --> Config Class Initialized
INFO - 2020-07-09 07:18:43 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:18:43 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:18:43 --> Utf8 Class Initialized
INFO - 2020-07-09 07:18:43 --> URI Class Initialized
INFO - 2020-07-09 07:18:43 --> Router Class Initialized
INFO - 2020-07-09 07:18:43 --> Output Class Initialized
INFO - 2020-07-09 07:18:43 --> Security Class Initialized
DEBUG - 2020-07-09 07:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:18:43 --> Input Class Initialized
INFO - 2020-07-09 07:18:43 --> Language Class Initialized
INFO - 2020-07-09 07:18:43 --> Language Class Initialized
INFO - 2020-07-09 07:18:43 --> Config Class Initialized
INFO - 2020-07-09 07:18:43 --> Loader Class Initialized
INFO - 2020-07-09 07:18:43 --> Helper loaded: url_helper
INFO - 2020-07-09 07:18:43 --> Helper loaded: main_helper
INFO - 2020-07-09 07:18:43 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:18:43 --> Controller Class Initialized
DEBUG - 2020-07-09 07:18:43 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
ERROR - 2020-07-09 07:18:43 --> Severity: error --> Exception: Argument 1 passed to Auth_model::is_user_exist() must be of the type string, null given, called in /var/www/journal/application/modules/auth/controllers/Auth.php on line 26 /var/www/journal/application/modules/auth/models/Auth_model.php 6
INFO - 2020-07-09 07:19:56 --> Config Class Initialized
INFO - 2020-07-09 07:19:56 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:19:56 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:19:56 --> Utf8 Class Initialized
INFO - 2020-07-09 07:19:56 --> URI Class Initialized
INFO - 2020-07-09 07:19:56 --> Router Class Initialized
INFO - 2020-07-09 07:19:56 --> Output Class Initialized
INFO - 2020-07-09 07:19:56 --> Security Class Initialized
DEBUG - 2020-07-09 07:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:19:56 --> Input Class Initialized
INFO - 2020-07-09 07:19:56 --> Language Class Initialized
INFO - 2020-07-09 07:19:56 --> Language Class Initialized
INFO - 2020-07-09 07:19:56 --> Config Class Initialized
INFO - 2020-07-09 07:19:56 --> Loader Class Initialized
INFO - 2020-07-09 07:19:56 --> Helper loaded: url_helper
INFO - 2020-07-09 07:19:56 --> Helper loaded: main_helper
INFO - 2020-07-09 07:19:56 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:19:56 --> Controller Class Initialized
DEBUG - 2020-07-09 07:19:56 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:19:56 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:19:56 --> Final output sent to browser
DEBUG - 2020-07-09 07:19:56 --> Total execution time: 0.0149
INFO - 2020-07-09 07:20:12 --> Config Class Initialized
INFO - 2020-07-09 07:20:12 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:20:12 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:20:12 --> Utf8 Class Initialized
INFO - 2020-07-09 07:20:12 --> URI Class Initialized
INFO - 2020-07-09 07:20:12 --> Router Class Initialized
INFO - 2020-07-09 07:20:12 --> Output Class Initialized
INFO - 2020-07-09 07:20:12 --> Security Class Initialized
DEBUG - 2020-07-09 07:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:20:12 --> Input Class Initialized
INFO - 2020-07-09 07:20:12 --> Language Class Initialized
INFO - 2020-07-09 07:20:12 --> Language Class Initialized
INFO - 2020-07-09 07:20:12 --> Config Class Initialized
INFO - 2020-07-09 07:20:12 --> Loader Class Initialized
INFO - 2020-07-09 07:20:12 --> Helper loaded: url_helper
INFO - 2020-07-09 07:20:12 --> Helper loaded: main_helper
INFO - 2020-07-09 07:20:12 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:20:12 --> Controller Class Initialized
DEBUG - 2020-07-09 07:20:12 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:20:12 --> Config Class Initialized
INFO - 2020-07-09 07:20:12 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:20:12 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:20:12 --> Utf8 Class Initialized
INFO - 2020-07-09 07:20:12 --> URI Class Initialized
DEBUG - 2020-07-09 07:20:12 --> No URI present. Default controller set.
INFO - 2020-07-09 07:20:12 --> Router Class Initialized
INFO - 2020-07-09 07:20:12 --> Output Class Initialized
INFO - 2020-07-09 07:20:12 --> Security Class Initialized
DEBUG - 2020-07-09 07:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:20:12 --> Input Class Initialized
INFO - 2020-07-09 07:20:12 --> Language Class Initialized
INFO - 2020-07-09 07:20:12 --> Language Class Initialized
INFO - 2020-07-09 07:20:12 --> Config Class Initialized
INFO - 2020-07-09 07:20:12 --> Loader Class Initialized
INFO - 2020-07-09 07:20:12 --> Helper loaded: url_helper
INFO - 2020-07-09 07:20:12 --> Helper loaded: main_helper
INFO - 2020-07-09 07:20:12 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:20:12 --> Controller Class Initialized
DEBUG - 2020-07-09 07:20:12 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:20:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:20:12 --> Final output sent to browser
DEBUG - 2020-07-09 07:20:12 --> Total execution time: 0.0044
INFO - 2020-07-09 07:20:59 --> Config Class Initialized
INFO - 2020-07-09 07:20:59 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:20:59 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:20:59 --> Utf8 Class Initialized
INFO - 2020-07-09 07:20:59 --> URI Class Initialized
DEBUG - 2020-07-09 07:20:59 --> No URI present. Default controller set.
INFO - 2020-07-09 07:20:59 --> Router Class Initialized
INFO - 2020-07-09 07:20:59 --> Output Class Initialized
INFO - 2020-07-09 07:20:59 --> Security Class Initialized
DEBUG - 2020-07-09 07:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:20:59 --> Input Class Initialized
INFO - 2020-07-09 07:20:59 --> Language Class Initialized
INFO - 2020-07-09 07:20:59 --> Language Class Initialized
INFO - 2020-07-09 07:20:59 --> Config Class Initialized
INFO - 2020-07-09 07:20:59 --> Loader Class Initialized
INFO - 2020-07-09 07:20:59 --> Helper loaded: url_helper
INFO - 2020-07-09 07:20:59 --> Helper loaded: main_helper
INFO - 2020-07-09 07:20:59 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:20:59 --> Controller Class Initialized
DEBUG - 2020-07-09 07:20:59 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:20:59 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:20:59 --> Final output sent to browser
DEBUG - 2020-07-09 07:20:59 --> Total execution time: 0.0033
INFO - 2020-07-09 07:21:47 --> Config Class Initialized
INFO - 2020-07-09 07:21:47 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:21:47 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:21:47 --> Utf8 Class Initialized
INFO - 2020-07-09 07:21:47 --> URI Class Initialized
INFO - 2020-07-09 07:21:47 --> Router Class Initialized
INFO - 2020-07-09 07:21:47 --> Output Class Initialized
INFO - 2020-07-09 07:21:47 --> Security Class Initialized
DEBUG - 2020-07-09 07:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:21:47 --> Input Class Initialized
INFO - 2020-07-09 07:21:47 --> Language Class Initialized
INFO - 2020-07-09 07:21:47 --> Language Class Initialized
INFO - 2020-07-09 07:21:47 --> Config Class Initialized
INFO - 2020-07-09 07:21:47 --> Loader Class Initialized
INFO - 2020-07-09 07:21:47 --> Helper loaded: url_helper
INFO - 2020-07-09 07:21:47 --> Helper loaded: main_helper
INFO - 2020-07-09 07:21:47 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:21:47 --> Controller Class Initialized
INFO - 2020-07-09 07:21:47 --> Config Class Initialized
INFO - 2020-07-09 07:21:47 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:21:47 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:21:47 --> Utf8 Class Initialized
INFO - 2020-07-09 07:21:47 --> URI Class Initialized
INFO - 2020-07-09 07:21:47 --> Router Class Initialized
INFO - 2020-07-09 07:21:47 --> Output Class Initialized
INFO - 2020-07-09 07:21:47 --> Security Class Initialized
DEBUG - 2020-07-09 07:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:21:47 --> Input Class Initialized
INFO - 2020-07-09 07:21:47 --> Language Class Initialized
INFO - 2020-07-09 07:21:47 --> Language Class Initialized
INFO - 2020-07-09 07:21:47 --> Config Class Initialized
INFO - 2020-07-09 07:21:47 --> Loader Class Initialized
INFO - 2020-07-09 07:21:47 --> Helper loaded: url_helper
INFO - 2020-07-09 07:21:47 --> Helper loaded: main_helper
INFO - 2020-07-09 07:21:47 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:21:47 --> Controller Class Initialized
DEBUG - 2020-07-09 07:21:47 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-09 07:21:47 --> Final output sent to browser
DEBUG - 2020-07-09 07:21:47 --> Total execution time: 0.0046
INFO - 2020-07-09 07:22:07 --> Config Class Initialized
INFO - 2020-07-09 07:22:07 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:22:07 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:22:07 --> Utf8 Class Initialized
INFO - 2020-07-09 07:22:07 --> URI Class Initialized
DEBUG - 2020-07-09 07:22:07 --> No URI present. Default controller set.
INFO - 2020-07-09 07:22:07 --> Router Class Initialized
INFO - 2020-07-09 07:22:07 --> Output Class Initialized
INFO - 2020-07-09 07:22:07 --> Security Class Initialized
DEBUG - 2020-07-09 07:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:22:07 --> Input Class Initialized
INFO - 2020-07-09 07:22:07 --> Language Class Initialized
INFO - 2020-07-09 07:22:07 --> Language Class Initialized
INFO - 2020-07-09 07:22:07 --> Config Class Initialized
INFO - 2020-07-09 07:22:07 --> Loader Class Initialized
INFO - 2020-07-09 07:22:07 --> Helper loaded: url_helper
INFO - 2020-07-09 07:22:07 --> Helper loaded: main_helper
INFO - 2020-07-09 07:22:07 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:22:07 --> Controller Class Initialized
DEBUG - 2020-07-09 07:22:07 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:22:07 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:22:07 --> Final output sent to browser
DEBUG - 2020-07-09 07:22:07 --> Total execution time: 0.0036
INFO - 2020-07-09 07:22:11 --> Config Class Initialized
INFO - 2020-07-09 07:22:11 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:22:11 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:22:11 --> Utf8 Class Initialized
INFO - 2020-07-09 07:22:11 --> URI Class Initialized
INFO - 2020-07-09 07:22:11 --> Router Class Initialized
INFO - 2020-07-09 07:22:11 --> Output Class Initialized
INFO - 2020-07-09 07:22:11 --> Security Class Initialized
DEBUG - 2020-07-09 07:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:22:11 --> Input Class Initialized
INFO - 2020-07-09 07:22:11 --> Language Class Initialized
INFO - 2020-07-09 07:22:11 --> Language Class Initialized
INFO - 2020-07-09 07:22:11 --> Config Class Initialized
INFO - 2020-07-09 07:22:11 --> Loader Class Initialized
INFO - 2020-07-09 07:22:11 --> Helper loaded: url_helper
INFO - 2020-07-09 07:22:11 --> Helper loaded: main_helper
INFO - 2020-07-09 07:22:11 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:22:11 --> Controller Class Initialized
INFO - 2020-07-09 07:22:11 --> Config Class Initialized
INFO - 2020-07-09 07:22:11 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:22:11 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:22:11 --> Utf8 Class Initialized
INFO - 2020-07-09 07:22:11 --> URI Class Initialized
DEBUG - 2020-07-09 07:22:11 --> No URI present. Default controller set.
INFO - 2020-07-09 07:22:11 --> Router Class Initialized
INFO - 2020-07-09 07:22:11 --> Output Class Initialized
INFO - 2020-07-09 07:22:11 --> Security Class Initialized
DEBUG - 2020-07-09 07:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:22:11 --> Input Class Initialized
INFO - 2020-07-09 07:22:11 --> Language Class Initialized
INFO - 2020-07-09 07:22:11 --> Language Class Initialized
INFO - 2020-07-09 07:22:11 --> Config Class Initialized
INFO - 2020-07-09 07:22:11 --> Loader Class Initialized
INFO - 2020-07-09 07:22:11 --> Helper loaded: url_helper
INFO - 2020-07-09 07:22:12 --> Helper loaded: main_helper
INFO - 2020-07-09 07:22:12 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:22:12 --> Controller Class Initialized
DEBUG - 2020-07-09 07:22:12 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:22:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:22:12 --> Final output sent to browser
DEBUG - 2020-07-09 07:22:12 --> Total execution time: 0.0041
INFO - 2020-07-09 07:23:16 --> Config Class Initialized
INFO - 2020-07-09 07:23:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:23:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:23:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:23:16 --> URI Class Initialized
DEBUG - 2020-07-09 07:23:16 --> No URI present. Default controller set.
INFO - 2020-07-09 07:23:16 --> Router Class Initialized
INFO - 2020-07-09 07:23:16 --> Output Class Initialized
INFO - 2020-07-09 07:23:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:23:16 --> Input Class Initialized
INFO - 2020-07-09 07:23:16 --> Language Class Initialized
INFO - 2020-07-09 07:23:16 --> Language Class Initialized
INFO - 2020-07-09 07:23:16 --> Config Class Initialized
INFO - 2020-07-09 07:23:16 --> Loader Class Initialized
INFO - 2020-07-09 07:23:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:23:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:23:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:23:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:23:16 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:23:16 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:23:16 --> Final output sent to browser
DEBUG - 2020-07-09 07:23:16 --> Total execution time: 0.0036
INFO - 2020-07-09 07:23:18 --> Config Class Initialized
INFO - 2020-07-09 07:23:18 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:23:18 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:23:18 --> Utf8 Class Initialized
INFO - 2020-07-09 07:23:18 --> URI Class Initialized
DEBUG - 2020-07-09 07:23:18 --> No URI present. Default controller set.
INFO - 2020-07-09 07:23:18 --> Router Class Initialized
INFO - 2020-07-09 07:23:18 --> Output Class Initialized
INFO - 2020-07-09 07:23:18 --> Security Class Initialized
DEBUG - 2020-07-09 07:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:23:18 --> Input Class Initialized
INFO - 2020-07-09 07:23:18 --> Language Class Initialized
INFO - 2020-07-09 07:23:18 --> Language Class Initialized
INFO - 2020-07-09 07:23:18 --> Config Class Initialized
INFO - 2020-07-09 07:23:18 --> Loader Class Initialized
INFO - 2020-07-09 07:23:18 --> Helper loaded: url_helper
INFO - 2020-07-09 07:23:18 --> Helper loaded: main_helper
INFO - 2020-07-09 07:23:18 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:23:18 --> Controller Class Initialized
DEBUG - 2020-07-09 07:23:18 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:23:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:23:18 --> Final output sent to browser
DEBUG - 2020-07-09 07:23:18 --> Total execution time: 0.0047
INFO - 2020-07-09 07:23:44 --> Config Class Initialized
INFO - 2020-07-09 07:23:44 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:23:44 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:23:44 --> Utf8 Class Initialized
INFO - 2020-07-09 07:23:44 --> URI Class Initialized
DEBUG - 2020-07-09 07:23:44 --> No URI present. Default controller set.
INFO - 2020-07-09 07:23:44 --> Router Class Initialized
INFO - 2020-07-09 07:23:44 --> Output Class Initialized
INFO - 2020-07-09 07:23:44 --> Security Class Initialized
DEBUG - 2020-07-09 07:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:23:44 --> Input Class Initialized
INFO - 2020-07-09 07:23:44 --> Language Class Initialized
INFO - 2020-07-09 07:23:44 --> Language Class Initialized
INFO - 2020-07-09 07:23:44 --> Config Class Initialized
INFO - 2020-07-09 07:23:44 --> Loader Class Initialized
INFO - 2020-07-09 07:23:44 --> Helper loaded: url_helper
INFO - 2020-07-09 07:23:44 --> Helper loaded: main_helper
INFO - 2020-07-09 07:23:44 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:23:44 --> Controller Class Initialized
DEBUG - 2020-07-09 07:23:44 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:23:44 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:23:44 --> Final output sent to browser
DEBUG - 2020-07-09 07:23:44 --> Total execution time: 0.0038
INFO - 2020-07-09 07:26:43 --> Config Class Initialized
INFO - 2020-07-09 07:26:43 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:26:43 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:26:43 --> Utf8 Class Initialized
INFO - 2020-07-09 07:26:43 --> URI Class Initialized
DEBUG - 2020-07-09 07:26:43 --> No URI present. Default controller set.
INFO - 2020-07-09 07:26:43 --> Router Class Initialized
INFO - 2020-07-09 07:26:43 --> Output Class Initialized
INFO - 2020-07-09 07:26:43 --> Security Class Initialized
DEBUG - 2020-07-09 07:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:26:43 --> Input Class Initialized
INFO - 2020-07-09 07:26:43 --> Language Class Initialized
INFO - 2020-07-09 07:26:43 --> Language Class Initialized
INFO - 2020-07-09 07:26:43 --> Config Class Initialized
INFO - 2020-07-09 07:26:43 --> Loader Class Initialized
INFO - 2020-07-09 07:26:43 --> Helper loaded: url_helper
INFO - 2020-07-09 07:26:43 --> Helper loaded: main_helper
INFO - 2020-07-09 07:26:43 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:26:43 --> Controller Class Initialized
DEBUG - 2020-07-09 07:26:43 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:26:43 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:26:43 --> Final output sent to browser
DEBUG - 2020-07-09 07:26:43 --> Total execution time: 0.0037
INFO - 2020-07-09 07:27:53 --> Config Class Initialized
INFO - 2020-07-09 07:27:53 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:27:53 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:27:53 --> Utf8 Class Initialized
INFO - 2020-07-09 07:27:53 --> URI Class Initialized
DEBUG - 2020-07-09 07:27:53 --> No URI present. Default controller set.
INFO - 2020-07-09 07:27:53 --> Router Class Initialized
INFO - 2020-07-09 07:27:53 --> Output Class Initialized
INFO - 2020-07-09 07:27:53 --> Security Class Initialized
DEBUG - 2020-07-09 07:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:27:53 --> Input Class Initialized
INFO - 2020-07-09 07:27:53 --> Language Class Initialized
INFO - 2020-07-09 07:27:53 --> Language Class Initialized
INFO - 2020-07-09 07:27:53 --> Config Class Initialized
INFO - 2020-07-09 07:27:53 --> Loader Class Initialized
INFO - 2020-07-09 07:27:53 --> Helper loaded: url_helper
INFO - 2020-07-09 07:27:53 --> Helper loaded: main_helper
INFO - 2020-07-09 07:27:53 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:27:53 --> Controller Class Initialized
DEBUG - 2020-07-09 07:27:53 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:27:53 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:27:53 --> Final output sent to browser
DEBUG - 2020-07-09 07:27:53 --> Total execution time: 0.0046
INFO - 2020-07-09 07:28:56 --> Config Class Initialized
INFO - 2020-07-09 07:28:56 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:28:56 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:28:56 --> Utf8 Class Initialized
INFO - 2020-07-09 07:28:56 --> URI Class Initialized
DEBUG - 2020-07-09 07:28:56 --> No URI present. Default controller set.
INFO - 2020-07-09 07:28:56 --> Router Class Initialized
INFO - 2020-07-09 07:28:56 --> Output Class Initialized
INFO - 2020-07-09 07:28:56 --> Security Class Initialized
DEBUG - 2020-07-09 07:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:28:56 --> Input Class Initialized
INFO - 2020-07-09 07:28:56 --> Language Class Initialized
INFO - 2020-07-09 07:28:56 --> Language Class Initialized
INFO - 2020-07-09 07:28:56 --> Config Class Initialized
INFO - 2020-07-09 07:28:56 --> Loader Class Initialized
INFO - 2020-07-09 07:28:56 --> Helper loaded: url_helper
INFO - 2020-07-09 07:28:56 --> Helper loaded: main_helper
INFO - 2020-07-09 07:28:56 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:28:56 --> Controller Class Initialized
DEBUG - 2020-07-09 07:28:56 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:28:56 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:28:56 --> Final output sent to browser
DEBUG - 2020-07-09 07:28:56 --> Total execution time: 0.0043
INFO - 2020-07-09 07:29:43 --> Config Class Initialized
INFO - 2020-07-09 07:29:43 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:29:43 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:29:43 --> Utf8 Class Initialized
INFO - 2020-07-09 07:29:43 --> URI Class Initialized
DEBUG - 2020-07-09 07:29:43 --> No URI present. Default controller set.
INFO - 2020-07-09 07:29:43 --> Router Class Initialized
INFO - 2020-07-09 07:29:43 --> Output Class Initialized
INFO - 2020-07-09 07:29:43 --> Security Class Initialized
DEBUG - 2020-07-09 07:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:29:43 --> Input Class Initialized
INFO - 2020-07-09 07:29:43 --> Language Class Initialized
INFO - 2020-07-09 07:29:43 --> Language Class Initialized
INFO - 2020-07-09 07:29:43 --> Config Class Initialized
INFO - 2020-07-09 07:29:43 --> Loader Class Initialized
INFO - 2020-07-09 07:29:43 --> Helper loaded: url_helper
INFO - 2020-07-09 07:29:43 --> Helper loaded: main_helper
INFO - 2020-07-09 07:29:43 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:29:43 --> Controller Class Initialized
DEBUG - 2020-07-09 07:29:43 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:29:43 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:29:43 --> Final output sent to browser
DEBUG - 2020-07-09 07:29:43 --> Total execution time: 0.0037
INFO - 2020-07-09 07:30:21 --> Config Class Initialized
INFO - 2020-07-09 07:30:21 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:30:21 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:30:21 --> Utf8 Class Initialized
INFO - 2020-07-09 07:30:21 --> URI Class Initialized
DEBUG - 2020-07-09 07:30:21 --> No URI present. Default controller set.
INFO - 2020-07-09 07:30:21 --> Router Class Initialized
INFO - 2020-07-09 07:30:21 --> Output Class Initialized
INFO - 2020-07-09 07:30:21 --> Security Class Initialized
DEBUG - 2020-07-09 07:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:30:21 --> Input Class Initialized
INFO - 2020-07-09 07:30:21 --> Language Class Initialized
INFO - 2020-07-09 07:30:21 --> Language Class Initialized
INFO - 2020-07-09 07:30:21 --> Config Class Initialized
INFO - 2020-07-09 07:30:21 --> Loader Class Initialized
INFO - 2020-07-09 07:30:21 --> Helper loaded: url_helper
INFO - 2020-07-09 07:30:21 --> Helper loaded: main_helper
INFO - 2020-07-09 07:30:21 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:30:21 --> Controller Class Initialized
DEBUG - 2020-07-09 07:30:21 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:30:21 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:30:21 --> Final output sent to browser
DEBUG - 2020-07-09 07:30:21 --> Total execution time: 0.0047
INFO - 2020-07-09 07:30:32 --> Config Class Initialized
INFO - 2020-07-09 07:30:32 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:30:32 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:30:32 --> Utf8 Class Initialized
INFO - 2020-07-09 07:30:32 --> URI Class Initialized
DEBUG - 2020-07-09 07:30:32 --> No URI present. Default controller set.
INFO - 2020-07-09 07:30:32 --> Router Class Initialized
INFO - 2020-07-09 07:30:32 --> Output Class Initialized
INFO - 2020-07-09 07:30:32 --> Security Class Initialized
DEBUG - 2020-07-09 07:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:30:32 --> Input Class Initialized
INFO - 2020-07-09 07:30:32 --> Language Class Initialized
INFO - 2020-07-09 07:30:32 --> Language Class Initialized
INFO - 2020-07-09 07:30:32 --> Config Class Initialized
INFO - 2020-07-09 07:30:32 --> Loader Class Initialized
INFO - 2020-07-09 07:30:32 --> Helper loaded: url_helper
INFO - 2020-07-09 07:30:32 --> Helper loaded: main_helper
INFO - 2020-07-09 07:30:32 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:30:32 --> Controller Class Initialized
DEBUG - 2020-07-09 07:30:32 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:30:32 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:30:32 --> Final output sent to browser
DEBUG - 2020-07-09 07:30:32 --> Total execution time: 0.0040
INFO - 2020-07-09 07:30:40 --> Config Class Initialized
INFO - 2020-07-09 07:30:40 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:30:40 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:30:40 --> Utf8 Class Initialized
INFO - 2020-07-09 07:30:40 --> URI Class Initialized
DEBUG - 2020-07-09 07:30:40 --> No URI present. Default controller set.
INFO - 2020-07-09 07:30:40 --> Router Class Initialized
INFO - 2020-07-09 07:30:40 --> Output Class Initialized
INFO - 2020-07-09 07:30:40 --> Security Class Initialized
DEBUG - 2020-07-09 07:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:30:40 --> Input Class Initialized
INFO - 2020-07-09 07:30:40 --> Language Class Initialized
INFO - 2020-07-09 07:30:40 --> Language Class Initialized
INFO - 2020-07-09 07:30:40 --> Config Class Initialized
INFO - 2020-07-09 07:30:40 --> Loader Class Initialized
INFO - 2020-07-09 07:30:40 --> Helper loaded: url_helper
INFO - 2020-07-09 07:30:40 --> Helper loaded: main_helper
INFO - 2020-07-09 07:30:40 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:30:40 --> Controller Class Initialized
DEBUG - 2020-07-09 07:30:40 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:30:40 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:30:40 --> Final output sent to browser
DEBUG - 2020-07-09 07:30:40 --> Total execution time: 0.0039
INFO - 2020-07-09 07:30:49 --> Config Class Initialized
INFO - 2020-07-09 07:30:49 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:30:49 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:30:49 --> Utf8 Class Initialized
INFO - 2020-07-09 07:30:49 --> URI Class Initialized
DEBUG - 2020-07-09 07:30:49 --> No URI present. Default controller set.
INFO - 2020-07-09 07:30:49 --> Router Class Initialized
INFO - 2020-07-09 07:30:49 --> Output Class Initialized
INFO - 2020-07-09 07:30:49 --> Security Class Initialized
DEBUG - 2020-07-09 07:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:30:49 --> Input Class Initialized
INFO - 2020-07-09 07:30:49 --> Language Class Initialized
INFO - 2020-07-09 07:30:49 --> Language Class Initialized
INFO - 2020-07-09 07:30:49 --> Config Class Initialized
INFO - 2020-07-09 07:30:49 --> Loader Class Initialized
INFO - 2020-07-09 07:30:49 --> Helper loaded: url_helper
INFO - 2020-07-09 07:30:49 --> Helper loaded: main_helper
INFO - 2020-07-09 07:30:49 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:30:49 --> Controller Class Initialized
DEBUG - 2020-07-09 07:30:49 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:30:49 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:30:49 --> Final output sent to browser
DEBUG - 2020-07-09 07:30:49 --> Total execution time: 0.0054
INFO - 2020-07-09 07:32:12 --> Config Class Initialized
INFO - 2020-07-09 07:32:12 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:32:12 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:32:12 --> Utf8 Class Initialized
INFO - 2020-07-09 07:32:12 --> URI Class Initialized
INFO - 2020-07-09 07:32:12 --> Router Class Initialized
INFO - 2020-07-09 07:32:12 --> Output Class Initialized
INFO - 2020-07-09 07:32:12 --> Security Class Initialized
DEBUG - 2020-07-09 07:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:32:12 --> Input Class Initialized
INFO - 2020-07-09 07:32:12 --> Language Class Initialized
INFO - 2020-07-09 07:32:12 --> Language Class Initialized
INFO - 2020-07-09 07:32:12 --> Config Class Initialized
INFO - 2020-07-09 07:32:12 --> Loader Class Initialized
INFO - 2020-07-09 07:32:12 --> Helper loaded: url_helper
INFO - 2020-07-09 07:32:12 --> Helper loaded: main_helper
INFO - 2020-07-09 07:32:12 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:32:12 --> Controller Class Initialized
INFO - 2020-07-09 07:32:12 --> Config Class Initialized
INFO - 2020-07-09 07:32:12 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:32:12 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:32:12 --> Utf8 Class Initialized
INFO - 2020-07-09 07:32:12 --> URI Class Initialized
DEBUG - 2020-07-09 07:32:12 --> No URI present. Default controller set.
INFO - 2020-07-09 07:32:12 --> Router Class Initialized
INFO - 2020-07-09 07:32:12 --> Output Class Initialized
INFO - 2020-07-09 07:32:12 --> Security Class Initialized
DEBUG - 2020-07-09 07:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:32:12 --> Input Class Initialized
INFO - 2020-07-09 07:32:12 --> Language Class Initialized
INFO - 2020-07-09 07:32:12 --> Language Class Initialized
INFO - 2020-07-09 07:32:12 --> Config Class Initialized
INFO - 2020-07-09 07:32:12 --> Loader Class Initialized
INFO - 2020-07-09 07:32:12 --> Helper loaded: url_helper
INFO - 2020-07-09 07:32:12 --> Helper loaded: main_helper
INFO - 2020-07-09 07:32:12 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:32:12 --> Controller Class Initialized
DEBUG - 2020-07-09 07:32:12 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:32:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:32:12 --> Final output sent to browser
DEBUG - 2020-07-09 07:32:12 --> Total execution time: 0.0038
INFO - 2020-07-09 07:32:21 --> Config Class Initialized
INFO - 2020-07-09 07:32:21 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:32:21 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:32:21 --> Utf8 Class Initialized
INFO - 2020-07-09 07:32:21 --> URI Class Initialized
DEBUG - 2020-07-09 07:32:21 --> No URI present. Default controller set.
INFO - 2020-07-09 07:32:21 --> Router Class Initialized
INFO - 2020-07-09 07:32:21 --> Output Class Initialized
INFO - 2020-07-09 07:32:21 --> Security Class Initialized
DEBUG - 2020-07-09 07:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:32:21 --> Input Class Initialized
INFO - 2020-07-09 07:32:21 --> Language Class Initialized
INFO - 2020-07-09 07:32:21 --> Language Class Initialized
INFO - 2020-07-09 07:32:21 --> Config Class Initialized
INFO - 2020-07-09 07:32:21 --> Loader Class Initialized
INFO - 2020-07-09 07:32:21 --> Helper loaded: url_helper
INFO - 2020-07-09 07:32:21 --> Helper loaded: main_helper
INFO - 2020-07-09 07:32:21 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:32:21 --> Controller Class Initialized
DEBUG - 2020-07-09 07:32:21 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:32:21 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:32:21 --> Final output sent to browser
DEBUG - 2020-07-09 07:32:21 --> Total execution time: 0.0037
INFO - 2020-07-09 07:32:24 --> Config Class Initialized
INFO - 2020-07-09 07:32:24 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:32:24 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:32:24 --> Utf8 Class Initialized
INFO - 2020-07-09 07:32:24 --> URI Class Initialized
INFO - 2020-07-09 07:32:24 --> Router Class Initialized
INFO - 2020-07-09 07:32:24 --> Output Class Initialized
INFO - 2020-07-09 07:32:24 --> Security Class Initialized
DEBUG - 2020-07-09 07:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:32:24 --> Input Class Initialized
INFO - 2020-07-09 07:32:24 --> Language Class Initialized
INFO - 2020-07-09 07:32:24 --> Language Class Initialized
INFO - 2020-07-09 07:32:24 --> Config Class Initialized
INFO - 2020-07-09 07:32:24 --> Loader Class Initialized
INFO - 2020-07-09 07:32:24 --> Helper loaded: url_helper
INFO - 2020-07-09 07:32:24 --> Helper loaded: main_helper
INFO - 2020-07-09 07:32:24 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:32:24 --> Controller Class Initialized
INFO - 2020-07-09 07:32:24 --> Config Class Initialized
INFO - 2020-07-09 07:32:24 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:32:24 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:32:24 --> Utf8 Class Initialized
INFO - 2020-07-09 07:32:24 --> URI Class Initialized
DEBUG - 2020-07-09 07:32:24 --> No URI present. Default controller set.
INFO - 2020-07-09 07:32:24 --> Router Class Initialized
INFO - 2020-07-09 07:32:24 --> Output Class Initialized
INFO - 2020-07-09 07:32:24 --> Security Class Initialized
DEBUG - 2020-07-09 07:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:32:24 --> Input Class Initialized
INFO - 2020-07-09 07:32:24 --> Language Class Initialized
INFO - 2020-07-09 07:32:24 --> Language Class Initialized
INFO - 2020-07-09 07:32:24 --> Config Class Initialized
INFO - 2020-07-09 07:32:24 --> Loader Class Initialized
INFO - 2020-07-09 07:32:24 --> Helper loaded: url_helper
INFO - 2020-07-09 07:32:24 --> Helper loaded: main_helper
INFO - 2020-07-09 07:32:24 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:32:24 --> Controller Class Initialized
DEBUG - 2020-07-09 07:32:24 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:32:24 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:32:24 --> Final output sent to browser
DEBUG - 2020-07-09 07:32:24 --> Total execution time: 0.0035
INFO - 2020-07-09 07:33:18 --> Config Class Initialized
INFO - 2020-07-09 07:33:18 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:33:18 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:33:18 --> Utf8 Class Initialized
INFO - 2020-07-09 07:33:18 --> URI Class Initialized
INFO - 2020-07-09 07:33:18 --> Router Class Initialized
INFO - 2020-07-09 07:33:18 --> Output Class Initialized
INFO - 2020-07-09 07:33:18 --> Security Class Initialized
DEBUG - 2020-07-09 07:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:33:18 --> Input Class Initialized
INFO - 2020-07-09 07:33:18 --> Language Class Initialized
INFO - 2020-07-09 07:33:18 --> Language Class Initialized
INFO - 2020-07-09 07:33:18 --> Config Class Initialized
INFO - 2020-07-09 07:33:18 --> Loader Class Initialized
INFO - 2020-07-09 07:33:18 --> Helper loaded: url_helper
INFO - 2020-07-09 07:33:18 --> Helper loaded: main_helper
INFO - 2020-07-09 07:33:18 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:33:18 --> Controller Class Initialized
INFO - 2020-07-09 07:33:18 --> Config Class Initialized
INFO - 2020-07-09 07:33:18 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:33:18 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:33:18 --> Utf8 Class Initialized
INFO - 2020-07-09 07:33:18 --> URI Class Initialized
DEBUG - 2020-07-09 07:33:18 --> No URI present. Default controller set.
INFO - 2020-07-09 07:33:18 --> Router Class Initialized
INFO - 2020-07-09 07:33:18 --> Output Class Initialized
INFO - 2020-07-09 07:33:18 --> Security Class Initialized
DEBUG - 2020-07-09 07:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:33:18 --> Input Class Initialized
INFO - 2020-07-09 07:33:18 --> Language Class Initialized
INFO - 2020-07-09 07:33:18 --> Language Class Initialized
INFO - 2020-07-09 07:33:18 --> Config Class Initialized
INFO - 2020-07-09 07:33:18 --> Loader Class Initialized
INFO - 2020-07-09 07:33:18 --> Helper loaded: url_helper
INFO - 2020-07-09 07:33:18 --> Helper loaded: main_helper
INFO - 2020-07-09 07:33:18 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:33:18 --> Controller Class Initialized
DEBUG - 2020-07-09 07:33:18 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:33:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:33:18 --> Final output sent to browser
DEBUG - 2020-07-09 07:33:18 --> Total execution time: 0.0032
INFO - 2020-07-09 07:34:17 --> Config Class Initialized
INFO - 2020-07-09 07:34:17 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:34:17 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:34:17 --> Utf8 Class Initialized
INFO - 2020-07-09 07:34:17 --> URI Class Initialized
DEBUG - 2020-07-09 07:34:17 --> No URI present. Default controller set.
INFO - 2020-07-09 07:34:17 --> Router Class Initialized
INFO - 2020-07-09 07:34:17 --> Output Class Initialized
INFO - 2020-07-09 07:34:17 --> Security Class Initialized
DEBUG - 2020-07-09 07:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:34:17 --> Input Class Initialized
INFO - 2020-07-09 07:34:17 --> Language Class Initialized
INFO - 2020-07-09 07:34:17 --> Language Class Initialized
INFO - 2020-07-09 07:34:17 --> Config Class Initialized
INFO - 2020-07-09 07:34:17 --> Loader Class Initialized
INFO - 2020-07-09 07:34:17 --> Helper loaded: url_helper
INFO - 2020-07-09 07:34:17 --> Helper loaded: main_helper
INFO - 2020-07-09 07:34:17 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:34:17 --> Controller Class Initialized
DEBUG - 2020-07-09 07:34:17 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:34:17 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:34:17 --> Final output sent to browser
DEBUG - 2020-07-09 07:34:17 --> Total execution time: 0.0044
INFO - 2020-07-09 07:34:19 --> Config Class Initialized
INFO - 2020-07-09 07:34:19 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:34:19 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:34:19 --> Utf8 Class Initialized
INFO - 2020-07-09 07:34:19 --> URI Class Initialized
DEBUG - 2020-07-09 07:34:19 --> No URI present. Default controller set.
INFO - 2020-07-09 07:34:19 --> Router Class Initialized
INFO - 2020-07-09 07:34:19 --> Output Class Initialized
INFO - 2020-07-09 07:34:19 --> Security Class Initialized
DEBUG - 2020-07-09 07:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:34:19 --> Input Class Initialized
INFO - 2020-07-09 07:34:19 --> Language Class Initialized
INFO - 2020-07-09 07:34:19 --> Language Class Initialized
INFO - 2020-07-09 07:34:19 --> Config Class Initialized
INFO - 2020-07-09 07:34:19 --> Loader Class Initialized
INFO - 2020-07-09 07:34:19 --> Helper loaded: url_helper
INFO - 2020-07-09 07:34:19 --> Helper loaded: main_helper
INFO - 2020-07-09 07:34:19 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:34:19 --> Controller Class Initialized
DEBUG - 2020-07-09 07:34:19 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:34:19 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:34:19 --> Final output sent to browser
DEBUG - 2020-07-09 07:34:19 --> Total execution time: 0.0050
INFO - 2020-07-09 07:34:22 --> Config Class Initialized
INFO - 2020-07-09 07:34:22 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:34:22 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:34:22 --> Utf8 Class Initialized
INFO - 2020-07-09 07:34:22 --> URI Class Initialized
INFO - 2020-07-09 07:34:22 --> Router Class Initialized
INFO - 2020-07-09 07:34:22 --> Output Class Initialized
INFO - 2020-07-09 07:34:22 --> Security Class Initialized
DEBUG - 2020-07-09 07:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:34:22 --> Input Class Initialized
INFO - 2020-07-09 07:34:22 --> Language Class Initialized
INFO - 2020-07-09 07:34:22 --> Language Class Initialized
INFO - 2020-07-09 07:34:22 --> Config Class Initialized
INFO - 2020-07-09 07:34:22 --> Loader Class Initialized
INFO - 2020-07-09 07:34:22 --> Helper loaded: url_helper
INFO - 2020-07-09 07:34:22 --> Helper loaded: main_helper
INFO - 2020-07-09 07:34:22 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:34:22 --> Controller Class Initialized
INFO - 2020-07-09 07:34:22 --> Config Class Initialized
INFO - 2020-07-09 07:34:22 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:34:22 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:34:22 --> Utf8 Class Initialized
INFO - 2020-07-09 07:34:22 --> URI Class Initialized
DEBUG - 2020-07-09 07:34:22 --> No URI present. Default controller set.
INFO - 2020-07-09 07:34:22 --> Router Class Initialized
INFO - 2020-07-09 07:34:22 --> Output Class Initialized
INFO - 2020-07-09 07:34:22 --> Security Class Initialized
DEBUG - 2020-07-09 07:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:34:22 --> Input Class Initialized
INFO - 2020-07-09 07:34:22 --> Language Class Initialized
INFO - 2020-07-09 07:34:22 --> Language Class Initialized
INFO - 2020-07-09 07:34:22 --> Config Class Initialized
INFO - 2020-07-09 07:34:22 --> Loader Class Initialized
INFO - 2020-07-09 07:34:22 --> Helper loaded: url_helper
INFO - 2020-07-09 07:34:22 --> Helper loaded: main_helper
INFO - 2020-07-09 07:34:22 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:34:22 --> Controller Class Initialized
DEBUG - 2020-07-09 07:34:22 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:34:22 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:34:22 --> Final output sent to browser
DEBUG - 2020-07-09 07:34:22 --> Total execution time: 0.0037
INFO - 2020-07-09 07:35:10 --> Config Class Initialized
INFO - 2020-07-09 07:35:10 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:35:10 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:35:10 --> Utf8 Class Initialized
INFO - 2020-07-09 07:35:10 --> URI Class Initialized
DEBUG - 2020-07-09 07:35:10 --> No URI present. Default controller set.
INFO - 2020-07-09 07:35:10 --> Router Class Initialized
INFO - 2020-07-09 07:35:10 --> Output Class Initialized
INFO - 2020-07-09 07:35:10 --> Security Class Initialized
DEBUG - 2020-07-09 07:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:35:10 --> Input Class Initialized
INFO - 2020-07-09 07:35:10 --> Language Class Initialized
INFO - 2020-07-09 07:35:10 --> Language Class Initialized
INFO - 2020-07-09 07:35:10 --> Config Class Initialized
INFO - 2020-07-09 07:35:10 --> Loader Class Initialized
INFO - 2020-07-09 07:35:10 --> Helper loaded: url_helper
INFO - 2020-07-09 07:35:10 --> Helper loaded: main_helper
INFO - 2020-07-09 07:35:10 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:35:10 --> Controller Class Initialized
DEBUG - 2020-07-09 07:35:10 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:35:10 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:35:10 --> Final output sent to browser
DEBUG - 2020-07-09 07:35:10 --> Total execution time: 0.0041
INFO - 2020-07-09 07:35:13 --> Config Class Initialized
INFO - 2020-07-09 07:35:13 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:35:13 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:35:13 --> Utf8 Class Initialized
INFO - 2020-07-09 07:35:13 --> URI Class Initialized
INFO - 2020-07-09 07:35:13 --> Router Class Initialized
INFO - 2020-07-09 07:35:13 --> Output Class Initialized
INFO - 2020-07-09 07:35:13 --> Security Class Initialized
DEBUG - 2020-07-09 07:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:35:13 --> Input Class Initialized
INFO - 2020-07-09 07:35:13 --> Language Class Initialized
INFO - 2020-07-09 07:35:13 --> Language Class Initialized
INFO - 2020-07-09 07:35:13 --> Config Class Initialized
INFO - 2020-07-09 07:35:13 --> Loader Class Initialized
INFO - 2020-07-09 07:35:13 --> Helper loaded: url_helper
INFO - 2020-07-09 07:35:13 --> Helper loaded: main_helper
INFO - 2020-07-09 07:35:13 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:35:13 --> Controller Class Initialized
INFO - 2020-07-09 07:35:13 --> Config Class Initialized
INFO - 2020-07-09 07:35:13 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:35:13 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:35:13 --> Utf8 Class Initialized
INFO - 2020-07-09 07:35:13 --> URI Class Initialized
DEBUG - 2020-07-09 07:35:13 --> No URI present. Default controller set.
INFO - 2020-07-09 07:35:13 --> Router Class Initialized
INFO - 2020-07-09 07:35:13 --> Output Class Initialized
INFO - 2020-07-09 07:35:13 --> Security Class Initialized
DEBUG - 2020-07-09 07:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:35:13 --> Input Class Initialized
INFO - 2020-07-09 07:35:13 --> Language Class Initialized
INFO - 2020-07-09 07:35:13 --> Language Class Initialized
INFO - 2020-07-09 07:35:13 --> Config Class Initialized
INFO - 2020-07-09 07:35:13 --> Loader Class Initialized
INFO - 2020-07-09 07:35:13 --> Helper loaded: url_helper
INFO - 2020-07-09 07:35:13 --> Helper loaded: main_helper
INFO - 2020-07-09 07:35:13 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:35:13 --> Controller Class Initialized
DEBUG - 2020-07-09 07:35:13 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:35:13 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:35:13 --> Final output sent to browser
DEBUG - 2020-07-09 07:35:13 --> Total execution time: 0.0035
INFO - 2020-07-09 07:36:22 --> Config Class Initialized
INFO - 2020-07-09 07:36:22 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:36:22 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:36:22 --> Utf8 Class Initialized
INFO - 2020-07-09 07:36:22 --> URI Class Initialized
INFO - 2020-07-09 07:36:22 --> Router Class Initialized
INFO - 2020-07-09 07:36:22 --> Output Class Initialized
INFO - 2020-07-09 07:36:22 --> Security Class Initialized
DEBUG - 2020-07-09 07:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:36:22 --> Input Class Initialized
INFO - 2020-07-09 07:36:22 --> Language Class Initialized
INFO - 2020-07-09 07:36:22 --> Language Class Initialized
INFO - 2020-07-09 07:36:22 --> Config Class Initialized
INFO - 2020-07-09 07:36:22 --> Loader Class Initialized
INFO - 2020-07-09 07:36:22 --> Helper loaded: url_helper
INFO - 2020-07-09 07:36:22 --> Helper loaded: main_helper
INFO - 2020-07-09 07:36:22 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:36:22 --> Controller Class Initialized
INFO - 2020-07-09 07:36:22 --> Config Class Initialized
INFO - 2020-07-09 07:36:22 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:36:22 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:36:22 --> Utf8 Class Initialized
INFO - 2020-07-09 07:36:22 --> URI Class Initialized
DEBUG - 2020-07-09 07:36:22 --> No URI present. Default controller set.
INFO - 2020-07-09 07:36:22 --> Router Class Initialized
INFO - 2020-07-09 07:36:22 --> Output Class Initialized
INFO - 2020-07-09 07:36:22 --> Security Class Initialized
DEBUG - 2020-07-09 07:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:36:22 --> Input Class Initialized
INFO - 2020-07-09 07:36:22 --> Language Class Initialized
INFO - 2020-07-09 07:36:22 --> Language Class Initialized
INFO - 2020-07-09 07:36:22 --> Config Class Initialized
INFO - 2020-07-09 07:36:22 --> Loader Class Initialized
INFO - 2020-07-09 07:36:22 --> Helper loaded: url_helper
INFO - 2020-07-09 07:36:22 --> Helper loaded: main_helper
INFO - 2020-07-09 07:36:22 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:36:22 --> Controller Class Initialized
DEBUG - 2020-07-09 07:36:22 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:36:22 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:36:22 --> Final output sent to browser
DEBUG - 2020-07-09 07:36:22 --> Total execution time: 0.0039
INFO - 2020-07-09 07:36:25 --> Config Class Initialized
INFO - 2020-07-09 07:36:25 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:36:25 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:36:25 --> Utf8 Class Initialized
INFO - 2020-07-09 07:36:25 --> URI Class Initialized
DEBUG - 2020-07-09 07:36:25 --> No URI present. Default controller set.
INFO - 2020-07-09 07:36:25 --> Router Class Initialized
INFO - 2020-07-09 07:36:25 --> Output Class Initialized
INFO - 2020-07-09 07:36:25 --> Security Class Initialized
DEBUG - 2020-07-09 07:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:36:25 --> Input Class Initialized
INFO - 2020-07-09 07:36:25 --> Language Class Initialized
INFO - 2020-07-09 07:36:25 --> Language Class Initialized
INFO - 2020-07-09 07:36:25 --> Config Class Initialized
INFO - 2020-07-09 07:36:25 --> Loader Class Initialized
INFO - 2020-07-09 07:36:25 --> Helper loaded: url_helper
INFO - 2020-07-09 07:36:25 --> Helper loaded: main_helper
INFO - 2020-07-09 07:36:25 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:36:25 --> Controller Class Initialized
DEBUG - 2020-07-09 07:36:25 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:36:25 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:36:25 --> Final output sent to browser
DEBUG - 2020-07-09 07:36:25 --> Total execution time: 0.0034
INFO - 2020-07-09 07:47:25 --> Config Class Initialized
INFO - 2020-07-09 07:47:25 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:47:25 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:47:25 --> Utf8 Class Initialized
INFO - 2020-07-09 07:47:25 --> URI Class Initialized
DEBUG - 2020-07-09 07:47:25 --> No URI present. Default controller set.
INFO - 2020-07-09 07:47:25 --> Router Class Initialized
INFO - 2020-07-09 07:47:25 --> Output Class Initialized
INFO - 2020-07-09 07:47:25 --> Security Class Initialized
DEBUG - 2020-07-09 07:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:47:25 --> Input Class Initialized
INFO - 2020-07-09 07:47:25 --> Language Class Initialized
INFO - 2020-07-09 07:47:25 --> Language Class Initialized
INFO - 2020-07-09 07:47:25 --> Config Class Initialized
INFO - 2020-07-09 07:47:25 --> Loader Class Initialized
INFO - 2020-07-09 07:47:25 --> Helper loaded: url_helper
INFO - 2020-07-09 07:47:25 --> Helper loaded: main_helper
INFO - 2020-07-09 07:47:25 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:47:25 --> Controller Class Initialized
DEBUG - 2020-07-09 07:47:25 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:47:25 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:47:25 --> Final output sent to browser
DEBUG - 2020-07-09 07:47:25 --> Total execution time: 0.0070
INFO - 2020-07-09 07:47:27 --> Config Class Initialized
INFO - 2020-07-09 07:47:27 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:47:27 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:47:27 --> Utf8 Class Initialized
INFO - 2020-07-09 07:47:27 --> URI Class Initialized
DEBUG - 2020-07-09 07:47:27 --> No URI present. Default controller set.
INFO - 2020-07-09 07:47:27 --> Router Class Initialized
INFO - 2020-07-09 07:47:27 --> Output Class Initialized
INFO - 2020-07-09 07:47:27 --> Security Class Initialized
DEBUG - 2020-07-09 07:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:47:27 --> Input Class Initialized
INFO - 2020-07-09 07:47:27 --> Language Class Initialized
INFO - 2020-07-09 07:47:27 --> Language Class Initialized
INFO - 2020-07-09 07:47:27 --> Config Class Initialized
INFO - 2020-07-09 07:47:27 --> Loader Class Initialized
INFO - 2020-07-09 07:47:27 --> Helper loaded: url_helper
INFO - 2020-07-09 07:47:27 --> Helper loaded: main_helper
INFO - 2020-07-09 07:47:27 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:47:27 --> Controller Class Initialized
DEBUG - 2020-07-09 07:47:27 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:47:27 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:47:27 --> Final output sent to browser
DEBUG - 2020-07-09 07:47:27 --> Total execution time: 0.0041
INFO - 2020-07-09 07:47:32 --> Config Class Initialized
INFO - 2020-07-09 07:47:32 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:47:32 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:47:32 --> Utf8 Class Initialized
INFO - 2020-07-09 07:47:32 --> URI Class Initialized
INFO - 2020-07-09 07:47:32 --> Router Class Initialized
INFO - 2020-07-09 07:47:32 --> Output Class Initialized
INFO - 2020-07-09 07:47:32 --> Security Class Initialized
DEBUG - 2020-07-09 07:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:47:32 --> Input Class Initialized
INFO - 2020-07-09 07:47:32 --> Language Class Initialized
INFO - 2020-07-09 07:47:32 --> Language Class Initialized
INFO - 2020-07-09 07:47:32 --> Config Class Initialized
INFO - 2020-07-09 07:47:32 --> Loader Class Initialized
INFO - 2020-07-09 07:47:32 --> Helper loaded: url_helper
INFO - 2020-07-09 07:47:32 --> Helper loaded: main_helper
INFO - 2020-07-09 07:47:32 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:47:32 --> Controller Class Initialized
DEBUG - 2020-07-09 07:47:32 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:47:32 --> Config Class Initialized
INFO - 2020-07-09 07:47:32 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:47:32 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:47:32 --> Utf8 Class Initialized
INFO - 2020-07-09 07:47:32 --> URI Class Initialized
DEBUG - 2020-07-09 07:47:32 --> No URI present. Default controller set.
INFO - 2020-07-09 07:47:32 --> Router Class Initialized
INFO - 2020-07-09 07:47:32 --> Output Class Initialized
INFO - 2020-07-09 07:47:32 --> Security Class Initialized
DEBUG - 2020-07-09 07:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:47:32 --> Input Class Initialized
INFO - 2020-07-09 07:47:32 --> Language Class Initialized
INFO - 2020-07-09 07:47:32 --> Language Class Initialized
INFO - 2020-07-09 07:47:32 --> Config Class Initialized
INFO - 2020-07-09 07:47:32 --> Loader Class Initialized
INFO - 2020-07-09 07:47:32 --> Helper loaded: url_helper
INFO - 2020-07-09 07:47:32 --> Helper loaded: main_helper
INFO - 2020-07-09 07:47:32 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:47:32 --> Controller Class Initialized
DEBUG - 2020-07-09 07:47:32 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:47:32 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:47:32 --> Final output sent to browser
DEBUG - 2020-07-09 07:47:32 --> Total execution time: 0.0053
INFO - 2020-07-09 07:53:55 --> Config Class Initialized
INFO - 2020-07-09 07:53:55 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:53:55 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:53:55 --> Utf8 Class Initialized
INFO - 2020-07-09 07:53:55 --> URI Class Initialized
INFO - 2020-07-09 07:53:55 --> Router Class Initialized
INFO - 2020-07-09 07:53:55 --> Output Class Initialized
INFO - 2020-07-09 07:53:55 --> Security Class Initialized
DEBUG - 2020-07-09 07:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:53:55 --> Input Class Initialized
INFO - 2020-07-09 07:53:55 --> Language Class Initialized
INFO - 2020-07-09 07:53:55 --> Language Class Initialized
INFO - 2020-07-09 07:53:55 --> Config Class Initialized
INFO - 2020-07-09 07:53:55 --> Loader Class Initialized
INFO - 2020-07-09 07:53:55 --> Helper loaded: url_helper
INFO - 2020-07-09 07:53:55 --> Helper loaded: main_helper
INFO - 2020-07-09 07:53:55 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:53:55 --> Controller Class Initialized
DEBUG - 2020-07-09 07:53:55 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:53:55 --> Config Class Initialized
INFO - 2020-07-09 07:53:55 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:53:55 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:53:55 --> Utf8 Class Initialized
INFO - 2020-07-09 07:53:55 --> URI Class Initialized
DEBUG - 2020-07-09 07:53:55 --> No URI present. Default controller set.
INFO - 2020-07-09 07:53:55 --> Router Class Initialized
INFO - 2020-07-09 07:53:55 --> Output Class Initialized
INFO - 2020-07-09 07:53:55 --> Security Class Initialized
DEBUG - 2020-07-09 07:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:53:55 --> Input Class Initialized
INFO - 2020-07-09 07:53:55 --> Language Class Initialized
INFO - 2020-07-09 07:53:55 --> Language Class Initialized
INFO - 2020-07-09 07:53:55 --> Config Class Initialized
INFO - 2020-07-09 07:53:55 --> Loader Class Initialized
INFO - 2020-07-09 07:53:55 --> Helper loaded: url_helper
INFO - 2020-07-09 07:53:55 --> Helper loaded: main_helper
INFO - 2020-07-09 07:53:55 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:53:55 --> Controller Class Initialized
DEBUG - 2020-07-09 07:53:55 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:53:55 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:53:55 --> Final output sent to browser
DEBUG - 2020-07-09 07:53:55 --> Total execution time: 0.0042
INFO - 2020-07-09 07:53:57 --> Config Class Initialized
INFO - 2020-07-09 07:53:57 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:53:57 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:53:57 --> Utf8 Class Initialized
INFO - 2020-07-09 07:53:57 --> URI Class Initialized
INFO - 2020-07-09 07:53:57 --> Router Class Initialized
INFO - 2020-07-09 07:53:57 --> Output Class Initialized
INFO - 2020-07-09 07:53:57 --> Security Class Initialized
DEBUG - 2020-07-09 07:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:53:57 --> Input Class Initialized
INFO - 2020-07-09 07:53:57 --> Language Class Initialized
INFO - 2020-07-09 07:53:57 --> Language Class Initialized
INFO - 2020-07-09 07:53:57 --> Config Class Initialized
INFO - 2020-07-09 07:53:57 --> Loader Class Initialized
INFO - 2020-07-09 07:53:57 --> Helper loaded: url_helper
INFO - 2020-07-09 07:53:57 --> Helper loaded: main_helper
INFO - 2020-07-09 07:53:57 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:53:57 --> Controller Class Initialized
DEBUG - 2020-07-09 07:53:57 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:53:57 --> Config Class Initialized
INFO - 2020-07-09 07:53:57 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:53:57 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:53:57 --> Utf8 Class Initialized
INFO - 2020-07-09 07:53:57 --> URI Class Initialized
DEBUG - 2020-07-09 07:53:57 --> No URI present. Default controller set.
INFO - 2020-07-09 07:53:57 --> Router Class Initialized
INFO - 2020-07-09 07:53:57 --> Output Class Initialized
INFO - 2020-07-09 07:53:57 --> Security Class Initialized
DEBUG - 2020-07-09 07:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:53:57 --> Input Class Initialized
INFO - 2020-07-09 07:53:57 --> Language Class Initialized
INFO - 2020-07-09 07:53:57 --> Language Class Initialized
INFO - 2020-07-09 07:53:57 --> Config Class Initialized
INFO - 2020-07-09 07:53:57 --> Loader Class Initialized
INFO - 2020-07-09 07:53:57 --> Helper loaded: url_helper
INFO - 2020-07-09 07:53:57 --> Helper loaded: main_helper
INFO - 2020-07-09 07:53:57 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:53:57 --> Controller Class Initialized
DEBUG - 2020-07-09 07:53:57 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:53:57 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:53:57 --> Final output sent to browser
DEBUG - 2020-07-09 07:53:57 --> Total execution time: 0.0032
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:16 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:16 --> URI Class Initialized
INFO - 2020-07-09 07:55:16 --> Router Class Initialized
INFO - 2020-07-09 07:55:16 --> Output Class Initialized
INFO - 2020-07-09 07:55:16 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:16 --> Input Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Language Class Initialized
INFO - 2020-07-09 07:55:16 --> Config Class Initialized
INFO - 2020-07-09 07:55:16 --> Loader Class Initialized
INFO - 2020-07-09 07:55:16 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:16 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:16 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:16 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:27 --> Config Class Initialized
INFO - 2020-07-09 07:55:27 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:27 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:27 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:27 --> URI Class Initialized
DEBUG - 2020-07-09 07:55:27 --> No URI present. Default controller set.
INFO - 2020-07-09 07:55:27 --> Router Class Initialized
INFO - 2020-07-09 07:55:27 --> Output Class Initialized
INFO - 2020-07-09 07:55:27 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:27 --> Input Class Initialized
INFO - 2020-07-09 07:55:27 --> Language Class Initialized
INFO - 2020-07-09 07:55:27 --> Language Class Initialized
INFO - 2020-07-09 07:55:27 --> Config Class Initialized
INFO - 2020-07-09 07:55:27 --> Loader Class Initialized
INFO - 2020-07-09 07:55:27 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:27 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:27 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:27 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:27 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:55:27 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:55:27 --> Final output sent to browser
DEBUG - 2020-07-09 07:55:27 --> Total execution time: 0.0041
INFO - 2020-07-09 07:55:29 --> Config Class Initialized
INFO - 2020-07-09 07:55:29 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:29 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:29 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:29 --> URI Class Initialized
DEBUG - 2020-07-09 07:55:29 --> No URI present. Default controller set.
INFO - 2020-07-09 07:55:29 --> Router Class Initialized
INFO - 2020-07-09 07:55:29 --> Output Class Initialized
INFO - 2020-07-09 07:55:29 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:29 --> Input Class Initialized
INFO - 2020-07-09 07:55:29 --> Language Class Initialized
INFO - 2020-07-09 07:55:29 --> Language Class Initialized
INFO - 2020-07-09 07:55:29 --> Config Class Initialized
INFO - 2020-07-09 07:55:29 --> Loader Class Initialized
INFO - 2020-07-09 07:55:29 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:29 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:29 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:29 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:29 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:55:29 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:55:29 --> Final output sent to browser
DEBUG - 2020-07-09 07:55:29 --> Total execution time: 0.0046
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:30 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:30 --> URI Class Initialized
INFO - 2020-07-09 07:55:30 --> Router Class Initialized
INFO - 2020-07-09 07:55:30 --> Output Class Initialized
INFO - 2020-07-09 07:55:30 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:30 --> Input Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Language Class Initialized
INFO - 2020-07-09 07:55:30 --> Config Class Initialized
INFO - 2020-07-09 07:55:30 --> Loader Class Initialized
INFO - 2020-07-09 07:55:30 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:30 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:30 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:31 --> Config Class Initialized
INFO - 2020-07-09 07:55:31 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:31 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:31 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:31 --> URI Class Initialized
INFO - 2020-07-09 07:55:31 --> Router Class Initialized
INFO - 2020-07-09 07:55:31 --> Output Class Initialized
INFO - 2020-07-09 07:55:31 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:31 --> Input Class Initialized
INFO - 2020-07-09 07:55:31 --> Language Class Initialized
INFO - 2020-07-09 07:55:31 --> Language Class Initialized
INFO - 2020-07-09 07:55:31 --> Config Class Initialized
INFO - 2020-07-09 07:55:31 --> Loader Class Initialized
INFO - 2020-07-09 07:55:31 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:31 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:31 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:31 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:31 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:31 --> Config Class Initialized
INFO - 2020-07-09 07:55:31 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:31 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:31 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:31 --> URI Class Initialized
INFO - 2020-07-09 07:55:31 --> Router Class Initialized
INFO - 2020-07-09 07:55:31 --> Output Class Initialized
INFO - 2020-07-09 07:55:31 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:31 --> Input Class Initialized
INFO - 2020-07-09 07:55:31 --> Language Class Initialized
INFO - 2020-07-09 07:55:31 --> Language Class Initialized
INFO - 2020-07-09 07:55:31 --> Config Class Initialized
INFO - 2020-07-09 07:55:31 --> Loader Class Initialized
INFO - 2020-07-09 07:55:31 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:31 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:31 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:31 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:31 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:31 --> Config Class Initialized
INFO - 2020-07-09 07:55:31 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:31 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:31 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:31 --> URI Class Initialized
INFO - 2020-07-09 07:55:31 --> Router Class Initialized
INFO - 2020-07-09 07:55:31 --> Output Class Initialized
INFO - 2020-07-09 07:55:31 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:31 --> Input Class Initialized
INFO - 2020-07-09 07:55:31 --> Language Class Initialized
INFO - 2020-07-09 07:55:31 --> Language Class Initialized
INFO - 2020-07-09 07:55:31 --> Config Class Initialized
INFO - 2020-07-09 07:55:31 --> Loader Class Initialized
INFO - 2020-07-09 07:55:31 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:31 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:31 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:31 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:31 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:31 --> Config Class Initialized
INFO - 2020-07-09 07:55:31 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:31 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:31 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:31 --> URI Class Initialized
INFO - 2020-07-09 07:55:31 --> Router Class Initialized
INFO - 2020-07-09 07:55:31 --> Output Class Initialized
INFO - 2020-07-09 07:55:31 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:31 --> Input Class Initialized
INFO - 2020-07-09 07:55:31 --> Language Class Initialized
INFO - 2020-07-09 07:55:31 --> Language Class Initialized
INFO - 2020-07-09 07:55:31 --> Config Class Initialized
INFO - 2020-07-09 07:55:31 --> Loader Class Initialized
INFO - 2020-07-09 07:55:31 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:31 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:31 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:31 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:31 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:31 --> Config Class Initialized
INFO - 2020-07-09 07:55:31 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:31 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:31 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:31 --> URI Class Initialized
INFO - 2020-07-09 07:55:31 --> Router Class Initialized
INFO - 2020-07-09 07:55:31 --> Output Class Initialized
INFO - 2020-07-09 07:55:31 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:31 --> Input Class Initialized
INFO - 2020-07-09 07:55:31 --> Language Class Initialized
INFO - 2020-07-09 07:55:31 --> Language Class Initialized
INFO - 2020-07-09 07:55:31 --> Config Class Initialized
INFO - 2020-07-09 07:55:31 --> Loader Class Initialized
INFO - 2020-07-09 07:55:31 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:31 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:31 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:31 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:31 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:55:31 --> Config Class Initialized
INFO - 2020-07-09 07:55:31 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:55:31 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:55:31 --> Utf8 Class Initialized
INFO - 2020-07-09 07:55:31 --> URI Class Initialized
INFO - 2020-07-09 07:55:31 --> Router Class Initialized
INFO - 2020-07-09 07:55:31 --> Output Class Initialized
INFO - 2020-07-09 07:55:31 --> Security Class Initialized
DEBUG - 2020-07-09 07:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:55:31 --> Input Class Initialized
INFO - 2020-07-09 07:55:31 --> Language Class Initialized
INFO - 2020-07-09 07:55:31 --> Language Class Initialized
INFO - 2020-07-09 07:55:31 --> Config Class Initialized
INFO - 2020-07-09 07:55:31 --> Loader Class Initialized
INFO - 2020-07-09 07:55:31 --> Helper loaded: url_helper
INFO - 2020-07-09 07:55:31 --> Helper loaded: main_helper
INFO - 2020-07-09 07:55:31 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:55:31 --> Controller Class Initialized
DEBUG - 2020-07-09 07:55:31 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:56:33 --> Config Class Initialized
INFO - 2020-07-09 07:56:33 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:56:33 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:56:33 --> Utf8 Class Initialized
INFO - 2020-07-09 07:56:33 --> URI Class Initialized
DEBUG - 2020-07-09 07:56:33 --> No URI present. Default controller set.
INFO - 2020-07-09 07:56:33 --> Router Class Initialized
INFO - 2020-07-09 07:56:33 --> Output Class Initialized
INFO - 2020-07-09 07:56:33 --> Security Class Initialized
DEBUG - 2020-07-09 07:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:56:33 --> Input Class Initialized
INFO - 2020-07-09 07:56:33 --> Language Class Initialized
INFO - 2020-07-09 07:56:33 --> Language Class Initialized
INFO - 2020-07-09 07:56:33 --> Config Class Initialized
INFO - 2020-07-09 07:56:33 --> Loader Class Initialized
INFO - 2020-07-09 07:56:33 --> Helper loaded: url_helper
INFO - 2020-07-09 07:56:33 --> Helper loaded: main_helper
INFO - 2020-07-09 07:56:33 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:56:33 --> Controller Class Initialized
DEBUG - 2020-07-09 07:56:33 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:56:33 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:56:33 --> Final output sent to browser
DEBUG - 2020-07-09 07:56:33 --> Total execution time: 0.0046
INFO - 2020-07-09 07:56:34 --> Config Class Initialized
INFO - 2020-07-09 07:56:34 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:56:34 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:56:34 --> Utf8 Class Initialized
INFO - 2020-07-09 07:56:34 --> URI Class Initialized
INFO - 2020-07-09 07:56:34 --> Router Class Initialized
INFO - 2020-07-09 07:56:34 --> Output Class Initialized
INFO - 2020-07-09 07:56:34 --> Security Class Initialized
DEBUG - 2020-07-09 07:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:56:34 --> Input Class Initialized
INFO - 2020-07-09 07:56:34 --> Language Class Initialized
INFO - 2020-07-09 07:56:34 --> Language Class Initialized
INFO - 2020-07-09 07:56:34 --> Config Class Initialized
INFO - 2020-07-09 07:56:34 --> Loader Class Initialized
INFO - 2020-07-09 07:56:34 --> Helper loaded: url_helper
INFO - 2020-07-09 07:56:34 --> Helper loaded: main_helper
INFO - 2020-07-09 07:56:34 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:56:35 --> Controller Class Initialized
DEBUG - 2020-07-09 07:56:35 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:56:35 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:56:35 --> Final output sent to browser
DEBUG - 2020-07-09 07:56:35 --> Total execution time: 0.0040
INFO - 2020-07-09 07:56:48 --> Config Class Initialized
INFO - 2020-07-09 07:56:48 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:56:48 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:56:48 --> Utf8 Class Initialized
INFO - 2020-07-09 07:56:48 --> URI Class Initialized
INFO - 2020-07-09 07:56:48 --> Router Class Initialized
INFO - 2020-07-09 07:56:48 --> Output Class Initialized
INFO - 2020-07-09 07:56:48 --> Security Class Initialized
DEBUG - 2020-07-09 07:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:56:48 --> Input Class Initialized
INFO - 2020-07-09 07:56:48 --> Language Class Initialized
INFO - 2020-07-09 07:56:48 --> Language Class Initialized
INFO - 2020-07-09 07:56:48 --> Config Class Initialized
INFO - 2020-07-09 07:56:48 --> Loader Class Initialized
INFO - 2020-07-09 07:56:48 --> Helper loaded: url_helper
INFO - 2020-07-09 07:56:48 --> Helper loaded: main_helper
INFO - 2020-07-09 07:56:48 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:56:48 --> Controller Class Initialized
DEBUG - 2020-07-09 07:56:48 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:56:48 --> Config Class Initialized
INFO - 2020-07-09 07:56:48 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:56:48 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:56:48 --> Utf8 Class Initialized
INFO - 2020-07-09 07:56:48 --> URI Class Initialized
DEBUG - 2020-07-09 07:56:48 --> No URI present. Default controller set.
INFO - 2020-07-09 07:56:48 --> Router Class Initialized
INFO - 2020-07-09 07:56:48 --> Output Class Initialized
INFO - 2020-07-09 07:56:48 --> Security Class Initialized
DEBUG - 2020-07-09 07:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:56:48 --> Input Class Initialized
INFO - 2020-07-09 07:56:48 --> Language Class Initialized
INFO - 2020-07-09 07:56:48 --> Language Class Initialized
INFO - 2020-07-09 07:56:48 --> Config Class Initialized
INFO - 2020-07-09 07:56:48 --> Loader Class Initialized
INFO - 2020-07-09 07:56:48 --> Helper loaded: url_helper
INFO - 2020-07-09 07:56:48 --> Helper loaded: main_helper
INFO - 2020-07-09 07:56:48 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:56:48 --> Controller Class Initialized
DEBUG - 2020-07-09 07:56:48 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:56:48 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:56:48 --> Final output sent to browser
DEBUG - 2020-07-09 07:56:48 --> Total execution time: 0.0047
INFO - 2020-07-09 07:56:52 --> Config Class Initialized
INFO - 2020-07-09 07:56:52 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:56:52 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:56:52 --> Utf8 Class Initialized
INFO - 2020-07-09 07:56:52 --> URI Class Initialized
INFO - 2020-07-09 07:56:52 --> Router Class Initialized
INFO - 2020-07-09 07:56:52 --> Output Class Initialized
INFO - 2020-07-09 07:56:52 --> Security Class Initialized
DEBUG - 2020-07-09 07:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:56:52 --> Input Class Initialized
INFO - 2020-07-09 07:56:52 --> Language Class Initialized
INFO - 2020-07-09 07:56:52 --> Language Class Initialized
INFO - 2020-07-09 07:56:52 --> Config Class Initialized
INFO - 2020-07-09 07:56:52 --> Loader Class Initialized
INFO - 2020-07-09 07:56:52 --> Helper loaded: url_helper
INFO - 2020-07-09 07:56:52 --> Helper loaded: main_helper
INFO - 2020-07-09 07:56:52 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:56:52 --> Controller Class Initialized
DEBUG - 2020-07-09 07:56:52 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:56:52 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:56:52 --> Final output sent to browser
DEBUG - 2020-07-09 07:56:52 --> Total execution time: 0.0031
INFO - 2020-07-09 07:56:59 --> Config Class Initialized
INFO - 2020-07-09 07:56:59 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:56:59 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:56:59 --> Utf8 Class Initialized
INFO - 2020-07-09 07:56:59 --> URI Class Initialized
DEBUG - 2020-07-09 07:56:59 --> No URI present. Default controller set.
INFO - 2020-07-09 07:56:59 --> Router Class Initialized
INFO - 2020-07-09 07:56:59 --> Output Class Initialized
INFO - 2020-07-09 07:56:59 --> Security Class Initialized
DEBUG - 2020-07-09 07:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:56:59 --> Input Class Initialized
INFO - 2020-07-09 07:56:59 --> Language Class Initialized
INFO - 2020-07-09 07:56:59 --> Language Class Initialized
INFO - 2020-07-09 07:56:59 --> Config Class Initialized
INFO - 2020-07-09 07:56:59 --> Loader Class Initialized
INFO - 2020-07-09 07:56:59 --> Helper loaded: url_helper
INFO - 2020-07-09 07:56:59 --> Helper loaded: main_helper
INFO - 2020-07-09 07:56:59 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:56:59 --> Controller Class Initialized
DEBUG - 2020-07-09 07:56:59 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:56:59 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:56:59 --> Final output sent to browser
DEBUG - 2020-07-09 07:56:59 --> Total execution time: 0.0035
INFO - 2020-07-09 07:57:32 --> Config Class Initialized
INFO - 2020-07-09 07:57:32 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:57:32 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:57:32 --> Utf8 Class Initialized
INFO - 2020-07-09 07:57:32 --> URI Class Initialized
INFO - 2020-07-09 07:57:32 --> Router Class Initialized
INFO - 2020-07-09 07:57:32 --> Output Class Initialized
INFO - 2020-07-09 07:57:32 --> Security Class Initialized
DEBUG - 2020-07-09 07:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:57:32 --> Input Class Initialized
INFO - 2020-07-09 07:57:32 --> Language Class Initialized
INFO - 2020-07-09 07:57:32 --> Language Class Initialized
INFO - 2020-07-09 07:57:32 --> Config Class Initialized
INFO - 2020-07-09 07:57:32 --> Loader Class Initialized
INFO - 2020-07-09 07:57:32 --> Helper loaded: url_helper
INFO - 2020-07-09 07:57:32 --> Helper loaded: main_helper
INFO - 2020-07-09 07:57:32 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:57:32 --> Controller Class Initialized
DEBUG - 2020-07-09 07:57:32 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:57:32 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:57:32 --> Final output sent to browser
DEBUG - 2020-07-09 07:57:32 --> Total execution time: 0.0053
INFO - 2020-07-09 07:57:49 --> Config Class Initialized
INFO - 2020-07-09 07:57:49 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:57:49 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:57:49 --> Utf8 Class Initialized
INFO - 2020-07-09 07:57:49 --> URI Class Initialized
INFO - 2020-07-09 07:57:49 --> Router Class Initialized
INFO - 2020-07-09 07:57:49 --> Output Class Initialized
INFO - 2020-07-09 07:57:49 --> Security Class Initialized
DEBUG - 2020-07-09 07:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:57:49 --> Input Class Initialized
INFO - 2020-07-09 07:57:49 --> Language Class Initialized
INFO - 2020-07-09 07:57:49 --> Language Class Initialized
INFO - 2020-07-09 07:57:49 --> Config Class Initialized
INFO - 2020-07-09 07:57:49 --> Loader Class Initialized
INFO - 2020-07-09 07:57:49 --> Helper loaded: url_helper
INFO - 2020-07-09 07:57:49 --> Helper loaded: main_helper
INFO - 2020-07-09 07:57:49 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:57:49 --> Controller Class Initialized
DEBUG - 2020-07-09 07:57:49 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:57:49 --> Config Class Initialized
INFO - 2020-07-09 07:57:49 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:57:49 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:57:49 --> Utf8 Class Initialized
INFO - 2020-07-09 07:57:49 --> URI Class Initialized
DEBUG - 2020-07-09 07:57:49 --> No URI present. Default controller set.
INFO - 2020-07-09 07:57:49 --> Router Class Initialized
INFO - 2020-07-09 07:57:49 --> Output Class Initialized
INFO - 2020-07-09 07:57:49 --> Security Class Initialized
DEBUG - 2020-07-09 07:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:57:49 --> Input Class Initialized
INFO - 2020-07-09 07:57:49 --> Language Class Initialized
INFO - 2020-07-09 07:57:49 --> Language Class Initialized
INFO - 2020-07-09 07:57:49 --> Config Class Initialized
INFO - 2020-07-09 07:57:49 --> Loader Class Initialized
INFO - 2020-07-09 07:57:49 --> Helper loaded: url_helper
INFO - 2020-07-09 07:57:49 --> Helper loaded: main_helper
INFO - 2020-07-09 07:57:49 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:57:49 --> Controller Class Initialized
DEBUG - 2020-07-09 07:57:49 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 07:57:49 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 07:57:49 --> Final output sent to browser
DEBUG - 2020-07-09 07:57:49 --> Total execution time: 0.0044
INFO - 2020-07-09 07:58:19 --> Config Class Initialized
INFO - 2020-07-09 07:58:19 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:58:19 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:58:19 --> Utf8 Class Initialized
INFO - 2020-07-09 07:58:19 --> URI Class Initialized
INFO - 2020-07-09 07:58:19 --> Router Class Initialized
INFO - 2020-07-09 07:58:19 --> Output Class Initialized
INFO - 2020-07-09 07:58:19 --> Security Class Initialized
DEBUG - 2020-07-09 07:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:58:19 --> Input Class Initialized
INFO - 2020-07-09 07:58:19 --> Language Class Initialized
INFO - 2020-07-09 07:58:19 --> Language Class Initialized
INFO - 2020-07-09 07:58:19 --> Config Class Initialized
INFO - 2020-07-09 07:58:19 --> Loader Class Initialized
INFO - 2020-07-09 07:58:19 --> Helper loaded: url_helper
INFO - 2020-07-09 07:58:19 --> Helper loaded: main_helper
INFO - 2020-07-09 07:58:19 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:58:19 --> Controller Class Initialized
DEBUG - 2020-07-09 07:58:19 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:58:19 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:58:19 --> Final output sent to browser
DEBUG - 2020-07-09 07:58:19 --> Total execution time: 0.0035
INFO - 2020-07-09 07:58:24 --> Config Class Initialized
INFO - 2020-07-09 07:58:24 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:58:24 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:58:24 --> Utf8 Class Initialized
INFO - 2020-07-09 07:58:24 --> URI Class Initialized
INFO - 2020-07-09 07:58:24 --> Router Class Initialized
INFO - 2020-07-09 07:58:24 --> Output Class Initialized
INFO - 2020-07-09 07:58:24 --> Security Class Initialized
DEBUG - 2020-07-09 07:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:58:24 --> Input Class Initialized
INFO - 2020-07-09 07:58:24 --> Language Class Initialized
INFO - 2020-07-09 07:58:24 --> Language Class Initialized
INFO - 2020-07-09 07:58:24 --> Config Class Initialized
INFO - 2020-07-09 07:58:24 --> Loader Class Initialized
INFO - 2020-07-09 07:58:24 --> Helper loaded: url_helper
INFO - 2020-07-09 07:58:24 --> Helper loaded: main_helper
INFO - 2020-07-09 07:58:24 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:58:24 --> Controller Class Initialized
DEBUG - 2020-07-09 07:58:24 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:58:24 --> Config Class Initialized
INFO - 2020-07-09 07:58:24 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:58:24 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:58:24 --> Utf8 Class Initialized
INFO - 2020-07-09 07:58:24 --> URI Class Initialized
INFO - 2020-07-09 07:58:24 --> Router Class Initialized
INFO - 2020-07-09 07:58:24 --> Output Class Initialized
INFO - 2020-07-09 07:58:24 --> Security Class Initialized
DEBUG - 2020-07-09 07:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:58:24 --> Input Class Initialized
INFO - 2020-07-09 07:58:24 --> Language Class Initialized
INFO - 2020-07-09 07:58:24 --> Language Class Initialized
INFO - 2020-07-09 07:58:24 --> Config Class Initialized
INFO - 2020-07-09 07:58:24 --> Loader Class Initialized
INFO - 2020-07-09 07:58:24 --> Helper loaded: url_helper
INFO - 2020-07-09 07:58:24 --> Helper loaded: main_helper
INFO - 2020-07-09 07:58:24 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:58:24 --> Controller Class Initialized
DEBUG - 2020-07-09 07:58:24 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:58:24 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:58:24 --> Final output sent to browser
DEBUG - 2020-07-09 07:58:24 --> Total execution time: 0.0033
INFO - 2020-07-09 07:58:44 --> Config Class Initialized
INFO - 2020-07-09 07:58:44 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:58:44 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:58:44 --> Utf8 Class Initialized
INFO - 2020-07-09 07:58:44 --> URI Class Initialized
INFO - 2020-07-09 07:58:44 --> Router Class Initialized
INFO - 2020-07-09 07:58:44 --> Output Class Initialized
INFO - 2020-07-09 07:58:44 --> Security Class Initialized
DEBUG - 2020-07-09 07:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:58:44 --> Input Class Initialized
INFO - 2020-07-09 07:58:44 --> Language Class Initialized
INFO - 2020-07-09 07:58:44 --> Language Class Initialized
INFO - 2020-07-09 07:58:44 --> Config Class Initialized
INFO - 2020-07-09 07:58:44 --> Loader Class Initialized
INFO - 2020-07-09 07:58:44 --> Helper loaded: url_helper
INFO - 2020-07-09 07:58:44 --> Helper loaded: main_helper
INFO - 2020-07-09 07:58:44 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:58:44 --> Controller Class Initialized
DEBUG - 2020-07-09 07:58:44 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:58:44 --> Config Class Initialized
INFO - 2020-07-09 07:58:44 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:58:44 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:58:44 --> Utf8 Class Initialized
INFO - 2020-07-09 07:58:44 --> URI Class Initialized
INFO - 2020-07-09 07:58:44 --> Router Class Initialized
INFO - 2020-07-09 07:58:44 --> Output Class Initialized
INFO - 2020-07-09 07:58:44 --> Security Class Initialized
DEBUG - 2020-07-09 07:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:58:44 --> Input Class Initialized
INFO - 2020-07-09 07:58:44 --> Language Class Initialized
INFO - 2020-07-09 07:58:44 --> Language Class Initialized
INFO - 2020-07-09 07:58:44 --> Config Class Initialized
INFO - 2020-07-09 07:58:44 --> Loader Class Initialized
INFO - 2020-07-09 07:58:44 --> Helper loaded: url_helper
INFO - 2020-07-09 07:58:44 --> Helper loaded: main_helper
INFO - 2020-07-09 07:58:44 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:58:44 --> Controller Class Initialized
DEBUG - 2020-07-09 07:58:44 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:58:44 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:58:44 --> Final output sent to browser
DEBUG - 2020-07-09 07:58:44 --> Total execution time: 0.0033
INFO - 2020-07-09 07:59:14 --> Config Class Initialized
INFO - 2020-07-09 07:59:14 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:59:14 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:59:14 --> Utf8 Class Initialized
INFO - 2020-07-09 07:59:14 --> URI Class Initialized
INFO - 2020-07-09 07:59:14 --> Router Class Initialized
INFO - 2020-07-09 07:59:14 --> Output Class Initialized
INFO - 2020-07-09 07:59:14 --> Security Class Initialized
DEBUG - 2020-07-09 07:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:59:14 --> Input Class Initialized
INFO - 2020-07-09 07:59:14 --> Language Class Initialized
INFO - 2020-07-09 07:59:14 --> Language Class Initialized
INFO - 2020-07-09 07:59:14 --> Config Class Initialized
INFO - 2020-07-09 07:59:14 --> Loader Class Initialized
INFO - 2020-07-09 07:59:14 --> Helper loaded: url_helper
INFO - 2020-07-09 07:59:14 --> Helper loaded: main_helper
INFO - 2020-07-09 07:59:14 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:59:14 --> Controller Class Initialized
DEBUG - 2020-07-09 07:59:14 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:59:14 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:59:14 --> Final output sent to browser
DEBUG - 2020-07-09 07:59:14 --> Total execution time: 0.0038
INFO - 2020-07-09 07:59:18 --> Config Class Initialized
INFO - 2020-07-09 07:59:18 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:59:18 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:59:18 --> Utf8 Class Initialized
INFO - 2020-07-09 07:59:18 --> URI Class Initialized
INFO - 2020-07-09 07:59:18 --> Router Class Initialized
INFO - 2020-07-09 07:59:18 --> Output Class Initialized
INFO - 2020-07-09 07:59:18 --> Security Class Initialized
DEBUG - 2020-07-09 07:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:59:18 --> Input Class Initialized
INFO - 2020-07-09 07:59:18 --> Language Class Initialized
INFO - 2020-07-09 07:59:18 --> Language Class Initialized
INFO - 2020-07-09 07:59:18 --> Config Class Initialized
INFO - 2020-07-09 07:59:18 --> Loader Class Initialized
INFO - 2020-07-09 07:59:18 --> Helper loaded: url_helper
INFO - 2020-07-09 07:59:18 --> Helper loaded: main_helper
INFO - 2020-07-09 07:59:18 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:59:18 --> Controller Class Initialized
DEBUG - 2020-07-09 07:59:18 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:59:18 --> Config Class Initialized
INFO - 2020-07-09 07:59:18 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:59:18 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:59:18 --> Utf8 Class Initialized
INFO - 2020-07-09 07:59:18 --> URI Class Initialized
INFO - 2020-07-09 07:59:18 --> Router Class Initialized
INFO - 2020-07-09 07:59:18 --> Output Class Initialized
INFO - 2020-07-09 07:59:18 --> Security Class Initialized
DEBUG - 2020-07-09 07:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:59:18 --> Input Class Initialized
INFO - 2020-07-09 07:59:18 --> Language Class Initialized
INFO - 2020-07-09 07:59:18 --> Language Class Initialized
INFO - 2020-07-09 07:59:18 --> Config Class Initialized
INFO - 2020-07-09 07:59:18 --> Loader Class Initialized
INFO - 2020-07-09 07:59:18 --> Helper loaded: url_helper
INFO - 2020-07-09 07:59:18 --> Helper loaded: main_helper
INFO - 2020-07-09 07:59:18 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:59:18 --> Controller Class Initialized
DEBUG - 2020-07-09 07:59:18 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:59:18 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:59:18 --> Final output sent to browser
DEBUG - 2020-07-09 07:59:18 --> Total execution time: 0.0035
INFO - 2020-07-09 07:59:53 --> Config Class Initialized
INFO - 2020-07-09 07:59:53 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:59:53 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:59:53 --> Utf8 Class Initialized
INFO - 2020-07-09 07:59:53 --> URI Class Initialized
INFO - 2020-07-09 07:59:53 --> Router Class Initialized
INFO - 2020-07-09 07:59:53 --> Output Class Initialized
INFO - 2020-07-09 07:59:53 --> Security Class Initialized
DEBUG - 2020-07-09 07:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:59:53 --> Input Class Initialized
INFO - 2020-07-09 07:59:53 --> Language Class Initialized
INFO - 2020-07-09 07:59:53 --> Language Class Initialized
INFO - 2020-07-09 07:59:53 --> Config Class Initialized
INFO - 2020-07-09 07:59:53 --> Loader Class Initialized
INFO - 2020-07-09 07:59:53 --> Helper loaded: url_helper
INFO - 2020-07-09 07:59:53 --> Helper loaded: main_helper
INFO - 2020-07-09 07:59:53 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:59:53 --> Controller Class Initialized
DEBUG - 2020-07-09 07:59:53 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 07:59:53 --> Config Class Initialized
INFO - 2020-07-09 07:59:53 --> Hooks Class Initialized
DEBUG - 2020-07-09 07:59:53 --> UTF-8 Support Enabled
INFO - 2020-07-09 07:59:53 --> Utf8 Class Initialized
INFO - 2020-07-09 07:59:53 --> URI Class Initialized
INFO - 2020-07-09 07:59:53 --> Router Class Initialized
INFO - 2020-07-09 07:59:53 --> Output Class Initialized
INFO - 2020-07-09 07:59:53 --> Security Class Initialized
DEBUG - 2020-07-09 07:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 07:59:53 --> Input Class Initialized
INFO - 2020-07-09 07:59:53 --> Language Class Initialized
INFO - 2020-07-09 07:59:53 --> Language Class Initialized
INFO - 2020-07-09 07:59:53 --> Config Class Initialized
INFO - 2020-07-09 07:59:53 --> Loader Class Initialized
INFO - 2020-07-09 07:59:53 --> Helper loaded: url_helper
INFO - 2020-07-09 07:59:53 --> Helper loaded: main_helper
INFO - 2020-07-09 07:59:53 --> Database Driver Class Initialized
DEBUG - 2020-07-09 07:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 07:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 07:59:53 --> Controller Class Initialized
DEBUG - 2020-07-09 07:59:53 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 07:59:53 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 07:59:53 --> Final output sent to browser
DEBUG - 2020-07-09 07:59:53 --> Total execution time: 0.0052
INFO - 2020-07-09 08:00:46 --> Config Class Initialized
INFO - 2020-07-09 08:00:46 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:00:46 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:00:46 --> Utf8 Class Initialized
INFO - 2020-07-09 08:00:46 --> URI Class Initialized
INFO - 2020-07-09 08:00:46 --> Router Class Initialized
INFO - 2020-07-09 08:00:46 --> Output Class Initialized
INFO - 2020-07-09 08:00:46 --> Security Class Initialized
DEBUG - 2020-07-09 08:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:00:46 --> Input Class Initialized
INFO - 2020-07-09 08:00:46 --> Language Class Initialized
INFO - 2020-07-09 08:00:46 --> Language Class Initialized
INFO - 2020-07-09 08:00:46 --> Config Class Initialized
INFO - 2020-07-09 08:00:46 --> Loader Class Initialized
INFO - 2020-07-09 08:00:46 --> Helper loaded: url_helper
INFO - 2020-07-09 08:00:46 --> Helper loaded: main_helper
INFO - 2020-07-09 08:00:46 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:00:46 --> Controller Class Initialized
DEBUG - 2020-07-09 08:00:46 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 08:00:46 --> Config Class Initialized
INFO - 2020-07-09 08:00:46 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:00:46 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:00:46 --> Utf8 Class Initialized
INFO - 2020-07-09 08:00:46 --> URI Class Initialized
INFO - 2020-07-09 08:00:46 --> Router Class Initialized
INFO - 2020-07-09 08:00:46 --> Output Class Initialized
INFO - 2020-07-09 08:00:46 --> Security Class Initialized
DEBUG - 2020-07-09 08:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:00:46 --> Input Class Initialized
INFO - 2020-07-09 08:00:46 --> Language Class Initialized
INFO - 2020-07-09 08:00:46 --> Language Class Initialized
INFO - 2020-07-09 08:00:46 --> Config Class Initialized
INFO - 2020-07-09 08:00:46 --> Loader Class Initialized
INFO - 2020-07-09 08:00:46 --> Helper loaded: url_helper
INFO - 2020-07-09 08:00:46 --> Helper loaded: main_helper
INFO - 2020-07-09 08:00:46 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:00:46 --> Controller Class Initialized
DEBUG - 2020-07-09 08:00:46 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 08:00:46 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 08:00:46 --> Final output sent to browser
DEBUG - 2020-07-09 08:00:46 --> Total execution time: 0.0032
INFO - 2020-07-09 08:00:54 --> Config Class Initialized
INFO - 2020-07-09 08:00:54 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:00:54 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:00:54 --> Utf8 Class Initialized
INFO - 2020-07-09 08:00:54 --> URI Class Initialized
INFO - 2020-07-09 08:00:54 --> Router Class Initialized
INFO - 2020-07-09 08:00:54 --> Output Class Initialized
INFO - 2020-07-09 08:00:54 --> Security Class Initialized
DEBUG - 2020-07-09 08:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:00:54 --> Input Class Initialized
INFO - 2020-07-09 08:00:54 --> Language Class Initialized
INFO - 2020-07-09 08:00:54 --> Language Class Initialized
INFO - 2020-07-09 08:00:54 --> Config Class Initialized
INFO - 2020-07-09 08:00:54 --> Loader Class Initialized
INFO - 2020-07-09 08:00:54 --> Helper loaded: url_helper
INFO - 2020-07-09 08:00:54 --> Helper loaded: main_helper
INFO - 2020-07-09 08:00:54 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:00:54 --> Controller Class Initialized
DEBUG - 2020-07-09 08:00:54 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 08:00:55 --> Config Class Initialized
INFO - 2020-07-09 08:00:55 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:00:55 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:00:55 --> Utf8 Class Initialized
INFO - 2020-07-09 08:00:55 --> URI Class Initialized
DEBUG - 2020-07-09 08:00:55 --> No URI present. Default controller set.
INFO - 2020-07-09 08:00:55 --> Router Class Initialized
INFO - 2020-07-09 08:00:55 --> Output Class Initialized
INFO - 2020-07-09 08:00:55 --> Security Class Initialized
DEBUG - 2020-07-09 08:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:00:55 --> Input Class Initialized
INFO - 2020-07-09 08:00:55 --> Language Class Initialized
INFO - 2020-07-09 08:00:55 --> Language Class Initialized
INFO - 2020-07-09 08:00:55 --> Config Class Initialized
INFO - 2020-07-09 08:00:55 --> Loader Class Initialized
INFO - 2020-07-09 08:00:55 --> Helper loaded: url_helper
INFO - 2020-07-09 08:00:55 --> Helper loaded: main_helper
INFO - 2020-07-09 08:00:55 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:00:55 --> Controller Class Initialized
DEBUG - 2020-07-09 08:00:55 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 08:00:55 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:00:55 --> Final output sent to browser
DEBUG - 2020-07-09 08:00:55 --> Total execution time: 0.0052
INFO - 2020-07-09 08:01:22 --> Config Class Initialized
INFO - 2020-07-09 08:01:22 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:01:22 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:01:22 --> Utf8 Class Initialized
INFO - 2020-07-09 08:01:22 --> URI Class Initialized
INFO - 2020-07-09 08:01:22 --> Router Class Initialized
INFO - 2020-07-09 08:01:22 --> Output Class Initialized
INFO - 2020-07-09 08:01:22 --> Security Class Initialized
DEBUG - 2020-07-09 08:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:01:22 --> Input Class Initialized
INFO - 2020-07-09 08:01:22 --> Language Class Initialized
INFO - 2020-07-09 08:01:22 --> Language Class Initialized
INFO - 2020-07-09 08:01:22 --> Config Class Initialized
INFO - 2020-07-09 08:01:22 --> Loader Class Initialized
INFO - 2020-07-09 08:01:22 --> Helper loaded: url_helper
INFO - 2020-07-09 08:01:22 --> Helper loaded: main_helper
INFO - 2020-07-09 08:01:22 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:01:22 --> Controller Class Initialized
INFO - 2020-07-09 08:01:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:01:22 --> Pagination Class Initialized
ERROR - 2020-07-09 08:01:22 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:01:22 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:01:22 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:01:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:01:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:01:22 --> Encryption Class Initialized
INFO - 2020-07-09 08:01:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:01:23 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:01:23 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:01:23 --> Final output sent to browser
DEBUG - 2020-07-09 08:01:23 --> Total execution time: 1.3553
INFO - 2020-07-09 08:03:34 --> Config Class Initialized
INFO - 2020-07-09 08:03:34 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:03:34 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:03:34 --> Utf8 Class Initialized
INFO - 2020-07-09 08:03:34 --> URI Class Initialized
INFO - 2020-07-09 08:03:34 --> Router Class Initialized
INFO - 2020-07-09 08:03:34 --> Output Class Initialized
INFO - 2020-07-09 08:03:34 --> Security Class Initialized
DEBUG - 2020-07-09 08:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:03:34 --> Input Class Initialized
INFO - 2020-07-09 08:03:34 --> Language Class Initialized
INFO - 2020-07-09 08:03:34 --> Language Class Initialized
INFO - 2020-07-09 08:03:34 --> Config Class Initialized
INFO - 2020-07-09 08:03:34 --> Loader Class Initialized
INFO - 2020-07-09 08:03:34 --> Helper loaded: url_helper
INFO - 2020-07-09 08:03:34 --> Helper loaded: main_helper
INFO - 2020-07-09 08:03:34 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:03:34 --> Controller Class Initialized
INFO - 2020-07-09 08:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:03:34 --> Pagination Class Initialized
ERROR - 2020-07-09 08:03:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:03:34 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:03:34 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:03:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:03:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:03:34 --> Encryption Class Initialized
INFO - 2020-07-09 08:03:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:03:34 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:03:34 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:03:34 --> Final output sent to browser
DEBUG - 2020-07-09 08:03:34 --> Total execution time: 0.0052
INFO - 2020-07-09 08:04:26 --> Config Class Initialized
INFO - 2020-07-09 08:04:26 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:04:26 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:04:26 --> Utf8 Class Initialized
INFO - 2020-07-09 08:04:26 --> URI Class Initialized
INFO - 2020-07-09 08:04:26 --> Router Class Initialized
INFO - 2020-07-09 08:04:26 --> Output Class Initialized
INFO - 2020-07-09 08:04:26 --> Security Class Initialized
DEBUG - 2020-07-09 08:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:04:26 --> Input Class Initialized
INFO - 2020-07-09 08:04:26 --> Language Class Initialized
INFO - 2020-07-09 08:04:26 --> Language Class Initialized
INFO - 2020-07-09 08:04:26 --> Config Class Initialized
INFO - 2020-07-09 08:04:26 --> Loader Class Initialized
INFO - 2020-07-09 08:04:26 --> Helper loaded: url_helper
INFO - 2020-07-09 08:04:26 --> Helper loaded: main_helper
INFO - 2020-07-09 08:04:26 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:04:26 --> Controller Class Initialized
INFO - 2020-07-09 08:04:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:04:26 --> Pagination Class Initialized
ERROR - 2020-07-09 08:04:26 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:04:26 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:04:26 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:04:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:04:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:04:26 --> Encryption Class Initialized
INFO - 2020-07-09 08:04:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:04:27 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-09 08:04:27 --> Final output sent to browser
DEBUG - 2020-07-09 08:04:27 --> Total execution time: 1.3228
INFO - 2020-07-09 08:06:11 --> Config Class Initialized
INFO - 2020-07-09 08:06:11 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:06:11 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:06:11 --> Utf8 Class Initialized
INFO - 2020-07-09 08:06:11 --> URI Class Initialized
INFO - 2020-07-09 08:06:11 --> Router Class Initialized
INFO - 2020-07-09 08:06:11 --> Output Class Initialized
INFO - 2020-07-09 08:06:11 --> Security Class Initialized
DEBUG - 2020-07-09 08:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:06:11 --> Input Class Initialized
INFO - 2020-07-09 08:06:11 --> Language Class Initialized
INFO - 2020-07-09 08:06:11 --> Language Class Initialized
INFO - 2020-07-09 08:06:11 --> Config Class Initialized
INFO - 2020-07-09 08:06:11 --> Loader Class Initialized
INFO - 2020-07-09 08:06:11 --> Helper loaded: url_helper
INFO - 2020-07-09 08:06:11 --> Helper loaded: main_helper
INFO - 2020-07-09 08:06:11 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:06:11 --> Controller Class Initialized
INFO - 2020-07-09 08:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:06:11 --> Pagination Class Initialized
ERROR - 2020-07-09 08:06:11 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:06:11 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:06:11 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:06:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:06:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:06:11 --> Encryption Class Initialized
INFO - 2020-07-09 08:06:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:06:11 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:06:11 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:06:11 --> Final output sent to browser
DEBUG - 2020-07-09 08:06:11 --> Total execution time: 0.0073
INFO - 2020-07-09 08:06:19 --> Config Class Initialized
INFO - 2020-07-09 08:06:19 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:06:19 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:06:19 --> Utf8 Class Initialized
INFO - 2020-07-09 08:06:19 --> URI Class Initialized
INFO - 2020-07-09 08:06:19 --> Router Class Initialized
INFO - 2020-07-09 08:06:19 --> Output Class Initialized
INFO - 2020-07-09 08:06:19 --> Security Class Initialized
DEBUG - 2020-07-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:06:19 --> Input Class Initialized
INFO - 2020-07-09 08:06:19 --> Language Class Initialized
INFO - 2020-07-09 08:06:19 --> Language Class Initialized
INFO - 2020-07-09 08:06:19 --> Config Class Initialized
INFO - 2020-07-09 08:06:19 --> Loader Class Initialized
INFO - 2020-07-09 08:06:19 --> Helper loaded: url_helper
INFO - 2020-07-09 08:06:19 --> Helper loaded: main_helper
INFO - 2020-07-09 08:06:19 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:06:19 --> Controller Class Initialized
DEBUG - 2020-07-09 08:06:19 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 08:06:19 --> Config Class Initialized
INFO - 2020-07-09 08:06:19 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:06:19 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:06:19 --> Utf8 Class Initialized
INFO - 2020-07-09 08:06:19 --> URI Class Initialized
DEBUG - 2020-07-09 08:06:19 --> No URI present. Default controller set.
INFO - 2020-07-09 08:06:19 --> Router Class Initialized
INFO - 2020-07-09 08:06:19 --> Output Class Initialized
INFO - 2020-07-09 08:06:19 --> Security Class Initialized
DEBUG - 2020-07-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:06:19 --> Input Class Initialized
INFO - 2020-07-09 08:06:19 --> Language Class Initialized
INFO - 2020-07-09 08:06:19 --> Language Class Initialized
INFO - 2020-07-09 08:06:19 --> Config Class Initialized
INFO - 2020-07-09 08:06:19 --> Loader Class Initialized
INFO - 2020-07-09 08:06:19 --> Helper loaded: url_helper
INFO - 2020-07-09 08:06:19 --> Helper loaded: main_helper
INFO - 2020-07-09 08:06:19 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:06:19 --> Controller Class Initialized
DEBUG - 2020-07-09 08:06:19 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 08:06:19 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:06:19 --> Final output sent to browser
DEBUG - 2020-07-09 08:06:19 --> Total execution time: 0.0034
INFO - 2020-07-09 08:06:25 --> Config Class Initialized
INFO - 2020-07-09 08:06:25 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:06:25 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:06:25 --> Utf8 Class Initialized
INFO - 2020-07-09 08:06:25 --> URI Class Initialized
INFO - 2020-07-09 08:06:25 --> Router Class Initialized
INFO - 2020-07-09 08:06:25 --> Output Class Initialized
INFO - 2020-07-09 08:06:25 --> Security Class Initialized
DEBUG - 2020-07-09 08:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:06:25 --> Input Class Initialized
INFO - 2020-07-09 08:06:25 --> Language Class Initialized
INFO - 2020-07-09 08:06:25 --> Language Class Initialized
INFO - 2020-07-09 08:06:25 --> Config Class Initialized
INFO - 2020-07-09 08:06:25 --> Loader Class Initialized
INFO - 2020-07-09 08:06:25 --> Helper loaded: url_helper
INFO - 2020-07-09 08:06:25 --> Helper loaded: main_helper
INFO - 2020-07-09 08:06:25 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:06:25 --> Controller Class Initialized
INFO - 2020-07-09 08:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:06:25 --> Pagination Class Initialized
ERROR - 2020-07-09 08:06:25 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:06:25 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:06:25 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:06:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:06:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:06:25 --> Encryption Class Initialized
INFO - 2020-07-09 08:06:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:06:27 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:06:27 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:06:27 --> Final output sent to browser
DEBUG - 2020-07-09 08:06:27 --> Total execution time: 1.6755
INFO - 2020-07-09 08:08:46 --> Config Class Initialized
INFO - 2020-07-09 08:08:46 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:08:46 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:08:46 --> Utf8 Class Initialized
INFO - 2020-07-09 08:08:46 --> URI Class Initialized
INFO - 2020-07-09 08:08:46 --> Router Class Initialized
INFO - 2020-07-09 08:08:46 --> Output Class Initialized
INFO - 2020-07-09 08:08:46 --> Security Class Initialized
DEBUG - 2020-07-09 08:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:08:46 --> Input Class Initialized
INFO - 2020-07-09 08:08:46 --> Language Class Initialized
INFO - 2020-07-09 08:08:46 --> Language Class Initialized
INFO - 2020-07-09 08:08:46 --> Config Class Initialized
INFO - 2020-07-09 08:08:46 --> Loader Class Initialized
INFO - 2020-07-09 08:08:46 --> Helper loaded: url_helper
INFO - 2020-07-09 08:08:46 --> Helper loaded: main_helper
INFO - 2020-07-09 08:08:46 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:08:46 --> Controller Class Initialized
DEBUG - 2020-07-09 08:08:46 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-09 08:08:46 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-09 08:08:46 --> Final output sent to browser
DEBUG - 2020-07-09 08:08:46 --> Total execution time: 0.0047
INFO - 2020-07-09 08:08:54 --> Config Class Initialized
INFO - 2020-07-09 08:08:54 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:08:54 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:08:54 --> Utf8 Class Initialized
INFO - 2020-07-09 08:08:54 --> URI Class Initialized
INFO - 2020-07-09 08:08:54 --> Router Class Initialized
INFO - 2020-07-09 08:08:54 --> Output Class Initialized
INFO - 2020-07-09 08:08:54 --> Security Class Initialized
DEBUG - 2020-07-09 08:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:08:54 --> Input Class Initialized
INFO - 2020-07-09 08:08:54 --> Language Class Initialized
INFO - 2020-07-09 08:08:54 --> Language Class Initialized
INFO - 2020-07-09 08:08:54 --> Config Class Initialized
INFO - 2020-07-09 08:08:54 --> Loader Class Initialized
INFO - 2020-07-09 08:08:54 --> Helper loaded: url_helper
INFO - 2020-07-09 08:08:54 --> Helper loaded: main_helper
INFO - 2020-07-09 08:08:54 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:08:54 --> Controller Class Initialized
DEBUG - 2020-07-09 08:08:54 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 08:08:55 --> Config Class Initialized
INFO - 2020-07-09 08:08:55 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:08:55 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:08:55 --> Utf8 Class Initialized
INFO - 2020-07-09 08:08:55 --> URI Class Initialized
DEBUG - 2020-07-09 08:08:55 --> No URI present. Default controller set.
INFO - 2020-07-09 08:08:55 --> Router Class Initialized
INFO - 2020-07-09 08:08:55 --> Output Class Initialized
INFO - 2020-07-09 08:08:55 --> Security Class Initialized
DEBUG - 2020-07-09 08:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:08:55 --> Input Class Initialized
INFO - 2020-07-09 08:08:55 --> Language Class Initialized
INFO - 2020-07-09 08:08:55 --> Language Class Initialized
INFO - 2020-07-09 08:08:55 --> Config Class Initialized
INFO - 2020-07-09 08:08:55 --> Loader Class Initialized
INFO - 2020-07-09 08:08:55 --> Helper loaded: url_helper
INFO - 2020-07-09 08:08:55 --> Helper loaded: main_helper
INFO - 2020-07-09 08:08:55 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:08:55 --> Controller Class Initialized
DEBUG - 2020-07-09 08:08:55 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 08:08:55 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:08:55 --> Final output sent to browser
DEBUG - 2020-07-09 08:08:55 --> Total execution time: 0.0035
INFO - 2020-07-09 08:09:04 --> Config Class Initialized
INFO - 2020-07-09 08:09:04 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:09:04 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:09:04 --> Utf8 Class Initialized
INFO - 2020-07-09 08:09:04 --> URI Class Initialized
INFO - 2020-07-09 08:09:04 --> Router Class Initialized
INFO - 2020-07-09 08:09:04 --> Output Class Initialized
INFO - 2020-07-09 08:09:04 --> Security Class Initialized
DEBUG - 2020-07-09 08:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:09:04 --> Input Class Initialized
INFO - 2020-07-09 08:09:04 --> Language Class Initialized
INFO - 2020-07-09 08:09:04 --> Language Class Initialized
INFO - 2020-07-09 08:09:04 --> Config Class Initialized
INFO - 2020-07-09 08:09:04 --> Loader Class Initialized
INFO - 2020-07-09 08:09:04 --> Helper loaded: url_helper
INFO - 2020-07-09 08:09:04 --> Helper loaded: main_helper
INFO - 2020-07-09 08:09:04 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:09:04 --> Controller Class Initialized
INFO - 2020-07-09 08:09:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:09:04 --> Pagination Class Initialized
ERROR - 2020-07-09 08:09:04 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:09:04 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:09:04 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:09:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:09:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:09:04 --> Encryption Class Initialized
INFO - 2020-07-09 08:09:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:09:04 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:09:04 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:09:04 --> Final output sent to browser
DEBUG - 2020-07-09 08:09:04 --> Total execution time: 0.0046
INFO - 2020-07-09 08:12:53 --> Config Class Initialized
INFO - 2020-07-09 08:12:53 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:12:53 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:12:53 --> Utf8 Class Initialized
INFO - 2020-07-09 08:12:53 --> URI Class Initialized
INFO - 2020-07-09 08:12:53 --> Router Class Initialized
INFO - 2020-07-09 08:12:53 --> Output Class Initialized
INFO - 2020-07-09 08:12:53 --> Security Class Initialized
DEBUG - 2020-07-09 08:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:12:53 --> Input Class Initialized
INFO - 2020-07-09 08:12:53 --> Language Class Initialized
INFO - 2020-07-09 08:12:53 --> Language Class Initialized
INFO - 2020-07-09 08:12:53 --> Config Class Initialized
INFO - 2020-07-09 08:12:53 --> Loader Class Initialized
INFO - 2020-07-09 08:12:53 --> Helper loaded: url_helper
INFO - 2020-07-09 08:12:53 --> Helper loaded: main_helper
INFO - 2020-07-09 08:12:53 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:12:53 --> Controller Class Initialized
INFO - 2020-07-09 08:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:12:53 --> Pagination Class Initialized
ERROR - 2020-07-09 08:12:53 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:12:53 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:12:53 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:12:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:12:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:12:53 --> Encryption Class Initialized
INFO - 2020-07-09 08:12:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:12:54 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:12:54 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:12:54 --> Final output sent to browser
DEBUG - 2020-07-09 08:12:54 --> Total execution time: 1.3941
INFO - 2020-07-09 08:13:38 --> Config Class Initialized
INFO - 2020-07-09 08:13:38 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:13:38 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:13:38 --> Utf8 Class Initialized
INFO - 2020-07-09 08:13:38 --> URI Class Initialized
INFO - 2020-07-09 08:13:38 --> Router Class Initialized
INFO - 2020-07-09 08:13:38 --> Output Class Initialized
INFO - 2020-07-09 08:13:38 --> Security Class Initialized
DEBUG - 2020-07-09 08:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:13:38 --> Input Class Initialized
INFO - 2020-07-09 08:13:38 --> Language Class Initialized
INFO - 2020-07-09 08:13:38 --> Language Class Initialized
INFO - 2020-07-09 08:13:38 --> Config Class Initialized
INFO - 2020-07-09 08:13:38 --> Loader Class Initialized
INFO - 2020-07-09 08:13:38 --> Helper loaded: url_helper
INFO - 2020-07-09 08:13:38 --> Helper loaded: main_helper
INFO - 2020-07-09 08:13:38 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:13:38 --> Controller Class Initialized
INFO - 2020-07-09 08:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:13:38 --> Pagination Class Initialized
ERROR - 2020-07-09 08:13:38 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:13:38 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:13:38 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:13:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:13:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:13:38 --> Encryption Class Initialized
INFO - 2020-07-09 08:13:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:13:38 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:13:38 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:13:38 --> Final output sent to browser
DEBUG - 2020-07-09 08:13:38 --> Total execution time: 0.0050
INFO - 2020-07-09 08:14:02 --> Config Class Initialized
INFO - 2020-07-09 08:14:02 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:14:02 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:14:02 --> Utf8 Class Initialized
INFO - 2020-07-09 08:14:02 --> URI Class Initialized
INFO - 2020-07-09 08:14:02 --> Router Class Initialized
INFO - 2020-07-09 08:14:02 --> Output Class Initialized
INFO - 2020-07-09 08:14:02 --> Security Class Initialized
DEBUG - 2020-07-09 08:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:14:02 --> Input Class Initialized
INFO - 2020-07-09 08:14:02 --> Language Class Initialized
INFO - 2020-07-09 08:14:02 --> Language Class Initialized
INFO - 2020-07-09 08:14:02 --> Config Class Initialized
INFO - 2020-07-09 08:14:02 --> Loader Class Initialized
INFO - 2020-07-09 08:14:02 --> Helper loaded: url_helper
INFO - 2020-07-09 08:14:02 --> Helper loaded: main_helper
INFO - 2020-07-09 08:14:02 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:14:02 --> Controller Class Initialized
INFO - 2020-07-09 08:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:14:02 --> Pagination Class Initialized
ERROR - 2020-07-09 08:14:02 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:14:02 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:14:02 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:14:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:14:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:14:02 --> Encryption Class Initialized
INFO - 2020-07-09 08:14:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:14:02 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:14:02 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:14:02 --> Final output sent to browser
DEBUG - 2020-07-09 08:14:02 --> Total execution time: 0.0045
INFO - 2020-07-09 08:14:17 --> Config Class Initialized
INFO - 2020-07-09 08:14:17 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:14:17 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:14:17 --> Utf8 Class Initialized
INFO - 2020-07-09 08:14:17 --> URI Class Initialized
INFO - 2020-07-09 08:14:17 --> Router Class Initialized
INFO - 2020-07-09 08:14:17 --> Output Class Initialized
INFO - 2020-07-09 08:14:17 --> Security Class Initialized
DEBUG - 2020-07-09 08:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:14:17 --> Input Class Initialized
INFO - 2020-07-09 08:14:17 --> Language Class Initialized
INFO - 2020-07-09 08:14:17 --> Language Class Initialized
INFO - 2020-07-09 08:14:17 --> Config Class Initialized
INFO - 2020-07-09 08:14:17 --> Loader Class Initialized
INFO - 2020-07-09 08:14:17 --> Helper loaded: url_helper
INFO - 2020-07-09 08:14:17 --> Helper loaded: main_helper
INFO - 2020-07-09 08:14:17 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:14:17 --> Controller Class Initialized
INFO - 2020-07-09 08:14:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:14:17 --> Pagination Class Initialized
ERROR - 2020-07-09 08:14:17 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:14:17 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:14:17 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:14:17 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:14:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:14:17 --> Encryption Class Initialized
INFO - 2020-07-09 08:14:17 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:14:17 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:14:17 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:14:17 --> Final output sent to browser
DEBUG - 2020-07-09 08:14:17 --> Total execution time: 0.0049
INFO - 2020-07-09 08:15:39 --> Config Class Initialized
INFO - 2020-07-09 08:15:39 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:15:39 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:15:39 --> Utf8 Class Initialized
INFO - 2020-07-09 08:15:39 --> URI Class Initialized
INFO - 2020-07-09 08:15:39 --> Router Class Initialized
INFO - 2020-07-09 08:15:39 --> Output Class Initialized
INFO - 2020-07-09 08:15:39 --> Security Class Initialized
DEBUG - 2020-07-09 08:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:15:39 --> Input Class Initialized
INFO - 2020-07-09 08:15:39 --> Language Class Initialized
INFO - 2020-07-09 08:15:39 --> Language Class Initialized
INFO - 2020-07-09 08:15:39 --> Config Class Initialized
INFO - 2020-07-09 08:15:39 --> Loader Class Initialized
INFO - 2020-07-09 08:15:39 --> Helper loaded: url_helper
INFO - 2020-07-09 08:15:39 --> Helper loaded: main_helper
INFO - 2020-07-09 08:15:39 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:15:39 --> Controller Class Initialized
INFO - 2020-07-09 08:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:15:39 --> Pagination Class Initialized
ERROR - 2020-07-09 08:15:39 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:15:39 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:15:39 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:15:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:15:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:15:39 --> Encryption Class Initialized
INFO - 2020-07-09 08:15:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:15:39 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:15:39 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:15:39 --> Final output sent to browser
DEBUG - 2020-07-09 08:15:39 --> Total execution time: 0.0049
INFO - 2020-07-09 08:18:07 --> Config Class Initialized
INFO - 2020-07-09 08:18:07 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:18:07 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:18:07 --> Utf8 Class Initialized
INFO - 2020-07-09 08:18:07 --> URI Class Initialized
INFO - 2020-07-09 08:18:07 --> Router Class Initialized
INFO - 2020-07-09 08:18:07 --> Output Class Initialized
INFO - 2020-07-09 08:18:07 --> Security Class Initialized
DEBUG - 2020-07-09 08:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:18:07 --> Input Class Initialized
INFO - 2020-07-09 08:18:07 --> Language Class Initialized
INFO - 2020-07-09 08:18:07 --> Language Class Initialized
INFO - 2020-07-09 08:18:07 --> Config Class Initialized
INFO - 2020-07-09 08:18:07 --> Loader Class Initialized
INFO - 2020-07-09 08:18:07 --> Helper loaded: url_helper
INFO - 2020-07-09 08:18:07 --> Helper loaded: main_helper
INFO - 2020-07-09 08:18:07 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:18:07 --> Controller Class Initialized
INFO - 2020-07-09 08:18:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:18:07 --> Pagination Class Initialized
ERROR - 2020-07-09 08:18:07 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:18:07 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:18:07 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:18:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:18:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:18:07 --> Encryption Class Initialized
INFO - 2020-07-09 08:18:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:18:08 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:18:08 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:18:08 --> Final output sent to browser
DEBUG - 2020-07-09 08:18:08 --> Total execution time: 1.3821
INFO - 2020-07-09 08:18:34 --> Config Class Initialized
INFO - 2020-07-09 08:18:34 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:18:34 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:18:34 --> Utf8 Class Initialized
INFO - 2020-07-09 08:18:34 --> URI Class Initialized
INFO - 2020-07-09 08:18:34 --> Router Class Initialized
INFO - 2020-07-09 08:18:34 --> Output Class Initialized
INFO - 2020-07-09 08:18:34 --> Security Class Initialized
DEBUG - 2020-07-09 08:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:18:34 --> Input Class Initialized
INFO - 2020-07-09 08:18:34 --> Language Class Initialized
INFO - 2020-07-09 08:18:34 --> Language Class Initialized
INFO - 2020-07-09 08:18:34 --> Config Class Initialized
INFO - 2020-07-09 08:18:34 --> Loader Class Initialized
INFO - 2020-07-09 08:18:34 --> Helper loaded: url_helper
INFO - 2020-07-09 08:18:34 --> Helper loaded: main_helper
INFO - 2020-07-09 08:18:34 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:18:34 --> Controller Class Initialized
INFO - 2020-07-09 08:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:18:34 --> Pagination Class Initialized
ERROR - 2020-07-09 08:18:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:18:34 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:18:34 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:18:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:18:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:18:34 --> Encryption Class Initialized
INFO - 2020-07-09 08:18:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:18:34 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:18:34 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:18:34 --> Final output sent to browser
DEBUG - 2020-07-09 08:18:34 --> Total execution time: 0.0084
INFO - 2020-07-09 08:18:59 --> Config Class Initialized
INFO - 2020-07-09 08:18:59 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:18:59 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:18:59 --> Utf8 Class Initialized
INFO - 2020-07-09 08:18:59 --> URI Class Initialized
INFO - 2020-07-09 08:18:59 --> Router Class Initialized
INFO - 2020-07-09 08:18:59 --> Output Class Initialized
INFO - 2020-07-09 08:18:59 --> Security Class Initialized
DEBUG - 2020-07-09 08:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:18:59 --> Input Class Initialized
INFO - 2020-07-09 08:18:59 --> Language Class Initialized
INFO - 2020-07-09 08:18:59 --> Language Class Initialized
INFO - 2020-07-09 08:18:59 --> Config Class Initialized
INFO - 2020-07-09 08:18:59 --> Loader Class Initialized
INFO - 2020-07-09 08:18:59 --> Helper loaded: url_helper
INFO - 2020-07-09 08:18:59 --> Helper loaded: main_helper
INFO - 2020-07-09 08:18:59 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:18:59 --> Controller Class Initialized
INFO - 2020-07-09 08:18:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:18:59 --> Pagination Class Initialized
ERROR - 2020-07-09 08:18:59 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:18:59 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:18:59 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:18:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:18:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:18:59 --> Encryption Class Initialized
INFO - 2020-07-09 08:18:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:18:59 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:18:59 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:18:59 --> Final output sent to browser
DEBUG - 2020-07-09 08:18:59 --> Total execution time: 0.0055
INFO - 2020-07-09 08:19:58 --> Config Class Initialized
INFO - 2020-07-09 08:19:58 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:19:58 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:19:58 --> Utf8 Class Initialized
INFO - 2020-07-09 08:19:58 --> URI Class Initialized
INFO - 2020-07-09 08:19:58 --> Router Class Initialized
INFO - 2020-07-09 08:19:58 --> Output Class Initialized
INFO - 2020-07-09 08:19:58 --> Security Class Initialized
DEBUG - 2020-07-09 08:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:19:58 --> Input Class Initialized
INFO - 2020-07-09 08:19:58 --> Language Class Initialized
INFO - 2020-07-09 08:19:58 --> Language Class Initialized
INFO - 2020-07-09 08:19:58 --> Config Class Initialized
INFO - 2020-07-09 08:19:58 --> Loader Class Initialized
INFO - 2020-07-09 08:19:58 --> Helper loaded: url_helper
INFO - 2020-07-09 08:19:58 --> Helper loaded: main_helper
INFO - 2020-07-09 08:19:58 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:19:58 --> Controller Class Initialized
INFO - 2020-07-09 08:19:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:19:58 --> Pagination Class Initialized
ERROR - 2020-07-09 08:19:58 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:19:58 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:19:58 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:19:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:19:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:19:58 --> Encryption Class Initialized
INFO - 2020-07-09 08:19:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:19:58 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:19:58 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:19:58 --> Final output sent to browser
DEBUG - 2020-07-09 08:19:58 --> Total execution time: 0.0051
INFO - 2020-07-09 08:20:20 --> Config Class Initialized
INFO - 2020-07-09 08:20:20 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:20:20 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:20:20 --> Utf8 Class Initialized
INFO - 2020-07-09 08:20:20 --> URI Class Initialized
INFO - 2020-07-09 08:20:20 --> Router Class Initialized
INFO - 2020-07-09 08:20:20 --> Output Class Initialized
INFO - 2020-07-09 08:20:20 --> Security Class Initialized
DEBUG - 2020-07-09 08:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:20:20 --> Input Class Initialized
INFO - 2020-07-09 08:20:20 --> Language Class Initialized
INFO - 2020-07-09 08:20:20 --> Language Class Initialized
INFO - 2020-07-09 08:20:20 --> Config Class Initialized
INFO - 2020-07-09 08:20:20 --> Loader Class Initialized
INFO - 2020-07-09 08:20:20 --> Helper loaded: url_helper
INFO - 2020-07-09 08:20:20 --> Helper loaded: main_helper
INFO - 2020-07-09 08:20:20 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:20:20 --> Controller Class Initialized
INFO - 2020-07-09 08:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:20:20 --> Pagination Class Initialized
ERROR - 2020-07-09 08:20:20 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:20:20 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:20:20 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:20:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:20:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:20:20 --> Encryption Class Initialized
INFO - 2020-07-09 08:20:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:20:20 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:20:20 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:20:20 --> Final output sent to browser
DEBUG - 2020-07-09 08:20:20 --> Total execution time: 0.0045
INFO - 2020-07-09 08:21:32 --> Config Class Initialized
INFO - 2020-07-09 08:21:32 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:21:32 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:21:32 --> Utf8 Class Initialized
INFO - 2020-07-09 08:21:32 --> URI Class Initialized
INFO - 2020-07-09 08:21:32 --> Router Class Initialized
INFO - 2020-07-09 08:21:32 --> Output Class Initialized
INFO - 2020-07-09 08:21:32 --> Security Class Initialized
DEBUG - 2020-07-09 08:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:21:32 --> Input Class Initialized
INFO - 2020-07-09 08:21:32 --> Language Class Initialized
INFO - 2020-07-09 08:21:32 --> Language Class Initialized
INFO - 2020-07-09 08:21:32 --> Config Class Initialized
INFO - 2020-07-09 08:21:32 --> Loader Class Initialized
INFO - 2020-07-09 08:21:32 --> Helper loaded: url_helper
INFO - 2020-07-09 08:21:32 --> Helper loaded: main_helper
INFO - 2020-07-09 08:21:32 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:21:32 --> Controller Class Initialized
INFO - 2020-07-09 08:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:21:32 --> Pagination Class Initialized
ERROR - 2020-07-09 08:21:32 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:21:32 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:21:32 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:21:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:21:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:21:32 --> Encryption Class Initialized
INFO - 2020-07-09 08:21:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:21:32 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:21:32 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:21:32 --> Final output sent to browser
DEBUG - 2020-07-09 08:21:32 --> Total execution time: 0.0048
INFO - 2020-07-09 08:22:10 --> Config Class Initialized
INFO - 2020-07-09 08:22:10 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:22:10 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:22:10 --> Utf8 Class Initialized
INFO - 2020-07-09 08:22:10 --> URI Class Initialized
INFO - 2020-07-09 08:22:10 --> Router Class Initialized
INFO - 2020-07-09 08:22:10 --> Output Class Initialized
INFO - 2020-07-09 08:22:10 --> Security Class Initialized
DEBUG - 2020-07-09 08:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:22:10 --> Input Class Initialized
INFO - 2020-07-09 08:22:10 --> Language Class Initialized
INFO - 2020-07-09 08:22:10 --> Language Class Initialized
INFO - 2020-07-09 08:22:10 --> Config Class Initialized
INFO - 2020-07-09 08:22:10 --> Loader Class Initialized
INFO - 2020-07-09 08:22:10 --> Helper loaded: url_helper
INFO - 2020-07-09 08:22:10 --> Helper loaded: main_helper
INFO - 2020-07-09 08:22:10 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:22:10 --> Controller Class Initialized
INFO - 2020-07-09 08:22:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:22:10 --> Pagination Class Initialized
ERROR - 2020-07-09 08:22:10 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:22:10 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:22:10 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:22:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:22:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:22:10 --> Encryption Class Initialized
INFO - 2020-07-09 08:22:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:22:10 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:22:10 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:22:10 --> Final output sent to browser
DEBUG - 2020-07-09 08:22:10 --> Total execution time: 0.0048
INFO - 2020-07-09 08:23:26 --> Config Class Initialized
INFO - 2020-07-09 08:23:26 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:23:26 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:23:26 --> Utf8 Class Initialized
INFO - 2020-07-09 08:23:26 --> URI Class Initialized
INFO - 2020-07-09 08:23:26 --> Router Class Initialized
INFO - 2020-07-09 08:23:26 --> Output Class Initialized
INFO - 2020-07-09 08:23:26 --> Security Class Initialized
DEBUG - 2020-07-09 08:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:23:26 --> Input Class Initialized
INFO - 2020-07-09 08:23:26 --> Language Class Initialized
INFO - 2020-07-09 08:23:26 --> Language Class Initialized
INFO - 2020-07-09 08:23:26 --> Config Class Initialized
INFO - 2020-07-09 08:23:26 --> Loader Class Initialized
INFO - 2020-07-09 08:23:26 --> Helper loaded: url_helper
INFO - 2020-07-09 08:23:26 --> Helper loaded: main_helper
INFO - 2020-07-09 08:23:26 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:23:26 --> Controller Class Initialized
INFO - 2020-07-09 08:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:23:26 --> Pagination Class Initialized
ERROR - 2020-07-09 08:23:26 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:23:26 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:23:26 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:23:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:23:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:23:26 --> Encryption Class Initialized
INFO - 2020-07-09 08:23:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:23:28 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:23:28 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:23:28 --> Final output sent to browser
DEBUG - 2020-07-09 08:23:28 --> Total execution time: 1.4119
INFO - 2020-07-09 08:23:31 --> Config Class Initialized
INFO - 2020-07-09 08:23:31 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:23:31 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:23:31 --> Utf8 Class Initialized
INFO - 2020-07-09 08:23:31 --> URI Class Initialized
INFO - 2020-07-09 08:23:31 --> Router Class Initialized
INFO - 2020-07-09 08:23:31 --> Output Class Initialized
INFO - 2020-07-09 08:23:31 --> Security Class Initialized
DEBUG - 2020-07-09 08:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:23:31 --> Input Class Initialized
INFO - 2020-07-09 08:23:31 --> Language Class Initialized
INFO - 2020-07-09 08:23:31 --> Language Class Initialized
INFO - 2020-07-09 08:23:31 --> Config Class Initialized
INFO - 2020-07-09 08:23:31 --> Loader Class Initialized
INFO - 2020-07-09 08:23:31 --> Helper loaded: url_helper
INFO - 2020-07-09 08:23:31 --> Helper loaded: main_helper
INFO - 2020-07-09 08:23:31 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:23:31 --> Controller Class Initialized
DEBUG - 2020-07-09 08:23:31 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:23:31 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:23:31 --> Final output sent to browser
DEBUG - 2020-07-09 08:23:31 --> Total execution time: 0.0080
INFO - 2020-07-09 08:23:32 --> Config Class Initialized
INFO - 2020-07-09 08:23:32 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:23:32 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:23:32 --> Utf8 Class Initialized
INFO - 2020-07-09 08:23:32 --> URI Class Initialized
INFO - 2020-07-09 08:23:32 --> Router Class Initialized
INFO - 2020-07-09 08:23:32 --> Output Class Initialized
INFO - 2020-07-09 08:23:32 --> Security Class Initialized
DEBUG - 2020-07-09 08:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:23:32 --> Input Class Initialized
INFO - 2020-07-09 08:23:32 --> Language Class Initialized
INFO - 2020-07-09 08:23:32 --> Language Class Initialized
INFO - 2020-07-09 08:23:32 --> Config Class Initialized
INFO - 2020-07-09 08:23:32 --> Loader Class Initialized
INFO - 2020-07-09 08:23:32 --> Helper loaded: url_helper
INFO - 2020-07-09 08:23:32 --> Helper loaded: main_helper
INFO - 2020-07-09 08:23:32 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:23:32 --> Controller Class Initialized
INFO - 2020-07-09 08:23:32 --> Final output sent to browser
DEBUG - 2020-07-09 08:23:32 --> Total execution time: 0.0070
INFO - 2020-07-09 08:27:33 --> Config Class Initialized
INFO - 2020-07-09 08:27:33 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:27:33 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:27:33 --> Utf8 Class Initialized
INFO - 2020-07-09 08:27:33 --> URI Class Initialized
INFO - 2020-07-09 08:27:33 --> Router Class Initialized
INFO - 2020-07-09 08:27:33 --> Output Class Initialized
INFO - 2020-07-09 08:27:33 --> Security Class Initialized
DEBUG - 2020-07-09 08:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:27:33 --> Input Class Initialized
INFO - 2020-07-09 08:27:33 --> Language Class Initialized
INFO - 2020-07-09 08:27:33 --> Language Class Initialized
INFO - 2020-07-09 08:27:33 --> Config Class Initialized
INFO - 2020-07-09 08:27:33 --> Loader Class Initialized
INFO - 2020-07-09 08:27:33 --> Helper loaded: url_helper
INFO - 2020-07-09 08:27:33 --> Helper loaded: main_helper
INFO - 2020-07-09 08:27:33 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:27:33 --> Controller Class Initialized
DEBUG - 2020-07-09 08:27:33 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:27:33 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:27:33 --> Final output sent to browser
DEBUG - 2020-07-09 08:27:33 --> Total execution time: 0.0039
INFO - 2020-07-09 08:27:34 --> Config Class Initialized
INFO - 2020-07-09 08:27:34 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:27:34 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:27:34 --> Utf8 Class Initialized
INFO - 2020-07-09 08:27:34 --> URI Class Initialized
INFO - 2020-07-09 08:27:34 --> Router Class Initialized
INFO - 2020-07-09 08:27:34 --> Output Class Initialized
INFO - 2020-07-09 08:27:34 --> Security Class Initialized
DEBUG - 2020-07-09 08:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:27:34 --> Input Class Initialized
INFO - 2020-07-09 08:27:34 --> Language Class Initialized
INFO - 2020-07-09 08:27:34 --> Language Class Initialized
INFO - 2020-07-09 08:27:34 --> Config Class Initialized
INFO - 2020-07-09 08:27:34 --> Loader Class Initialized
INFO - 2020-07-09 08:27:34 --> Helper loaded: url_helper
INFO - 2020-07-09 08:27:34 --> Helper loaded: main_helper
INFO - 2020-07-09 08:27:34 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:27:34 --> Controller Class Initialized
INFO - 2020-07-09 08:27:34 --> Final output sent to browser
DEBUG - 2020-07-09 08:27:34 --> Total execution time: 0.0048
INFO - 2020-07-09 08:28:34 --> Config Class Initialized
INFO - 2020-07-09 08:28:34 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:28:34 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:28:34 --> Utf8 Class Initialized
INFO - 2020-07-09 08:28:34 --> URI Class Initialized
INFO - 2020-07-09 08:28:34 --> Router Class Initialized
INFO - 2020-07-09 08:28:34 --> Output Class Initialized
INFO - 2020-07-09 08:28:34 --> Security Class Initialized
DEBUG - 2020-07-09 08:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:28:34 --> Input Class Initialized
INFO - 2020-07-09 08:28:34 --> Language Class Initialized
INFO - 2020-07-09 08:28:34 --> Language Class Initialized
INFO - 2020-07-09 08:28:34 --> Config Class Initialized
INFO - 2020-07-09 08:28:34 --> Loader Class Initialized
INFO - 2020-07-09 08:28:34 --> Helper loaded: url_helper
INFO - 2020-07-09 08:28:34 --> Helper loaded: main_helper
INFO - 2020-07-09 08:28:34 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:28:34 --> Controller Class Initialized
DEBUG - 2020-07-09 08:28:34 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:28:34 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:28:34 --> Final output sent to browser
DEBUG - 2020-07-09 08:28:34 --> Total execution time: 0.0036
INFO - 2020-07-09 08:28:35 --> Config Class Initialized
INFO - 2020-07-09 08:28:35 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:28:35 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:28:35 --> Utf8 Class Initialized
INFO - 2020-07-09 08:28:35 --> URI Class Initialized
INFO - 2020-07-09 08:28:35 --> Router Class Initialized
INFO - 2020-07-09 08:28:35 --> Output Class Initialized
INFO - 2020-07-09 08:28:35 --> Security Class Initialized
DEBUG - 2020-07-09 08:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:28:35 --> Input Class Initialized
INFO - 2020-07-09 08:28:35 --> Language Class Initialized
INFO - 2020-07-09 08:28:35 --> Language Class Initialized
INFO - 2020-07-09 08:28:35 --> Config Class Initialized
INFO - 2020-07-09 08:28:35 --> Loader Class Initialized
INFO - 2020-07-09 08:28:35 --> Helper loaded: url_helper
INFO - 2020-07-09 08:28:35 --> Helper loaded: main_helper
INFO - 2020-07-09 08:28:35 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:28:35 --> Controller Class Initialized
INFO - 2020-07-09 08:28:35 --> Final output sent to browser
DEBUG - 2020-07-09 08:28:35 --> Total execution time: 0.0048
INFO - 2020-07-09 08:29:36 --> Config Class Initialized
INFO - 2020-07-09 08:29:36 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:29:36 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:29:36 --> Utf8 Class Initialized
INFO - 2020-07-09 08:29:36 --> URI Class Initialized
INFO - 2020-07-09 08:29:36 --> Router Class Initialized
INFO - 2020-07-09 08:29:36 --> Output Class Initialized
INFO - 2020-07-09 08:29:36 --> Security Class Initialized
DEBUG - 2020-07-09 08:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:29:36 --> Input Class Initialized
INFO - 2020-07-09 08:29:36 --> Language Class Initialized
INFO - 2020-07-09 08:29:36 --> Language Class Initialized
INFO - 2020-07-09 08:29:36 --> Config Class Initialized
INFO - 2020-07-09 08:29:36 --> Loader Class Initialized
INFO - 2020-07-09 08:29:36 --> Helper loaded: url_helper
INFO - 2020-07-09 08:29:36 --> Helper loaded: main_helper
INFO - 2020-07-09 08:29:36 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:29:36 --> Controller Class Initialized
DEBUG - 2020-07-09 08:29:36 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:29:36 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:29:36 --> Final output sent to browser
DEBUG - 2020-07-09 08:29:36 --> Total execution time: 0.0034
INFO - 2020-07-09 08:29:36 --> Config Class Initialized
INFO - 2020-07-09 08:29:36 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:29:36 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:29:36 --> Utf8 Class Initialized
INFO - 2020-07-09 08:29:36 --> URI Class Initialized
INFO - 2020-07-09 08:29:36 --> Router Class Initialized
INFO - 2020-07-09 08:29:36 --> Output Class Initialized
INFO - 2020-07-09 08:29:36 --> Security Class Initialized
DEBUG - 2020-07-09 08:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:29:36 --> Input Class Initialized
INFO - 2020-07-09 08:29:36 --> Language Class Initialized
INFO - 2020-07-09 08:29:36 --> Language Class Initialized
INFO - 2020-07-09 08:29:36 --> Config Class Initialized
INFO - 2020-07-09 08:29:36 --> Loader Class Initialized
INFO - 2020-07-09 08:29:36 --> Helper loaded: url_helper
INFO - 2020-07-09 08:29:36 --> Helper loaded: main_helper
INFO - 2020-07-09 08:29:36 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:29:36 --> Controller Class Initialized
INFO - 2020-07-09 08:29:36 --> Final output sent to browser
DEBUG - 2020-07-09 08:29:36 --> Total execution time: 0.0046
INFO - 2020-07-09 08:30:21 --> Config Class Initialized
INFO - 2020-07-09 08:30:21 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:30:21 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:30:21 --> Utf8 Class Initialized
INFO - 2020-07-09 08:30:21 --> URI Class Initialized
INFO - 2020-07-09 08:30:21 --> Router Class Initialized
INFO - 2020-07-09 08:30:21 --> Output Class Initialized
INFO - 2020-07-09 08:30:21 --> Security Class Initialized
DEBUG - 2020-07-09 08:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:30:21 --> Input Class Initialized
INFO - 2020-07-09 08:30:21 --> Language Class Initialized
INFO - 2020-07-09 08:30:21 --> Language Class Initialized
INFO - 2020-07-09 08:30:21 --> Config Class Initialized
INFO - 2020-07-09 08:30:21 --> Loader Class Initialized
INFO - 2020-07-09 08:30:21 --> Helper loaded: url_helper
INFO - 2020-07-09 08:30:21 --> Helper loaded: main_helper
INFO - 2020-07-09 08:30:21 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:30:21 --> Controller Class Initialized
DEBUG - 2020-07-09 08:30:21 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:30:21 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:30:21 --> Final output sent to browser
DEBUG - 2020-07-09 08:30:21 --> Total execution time: 0.0060
INFO - 2020-07-09 08:30:21 --> Config Class Initialized
INFO - 2020-07-09 08:30:21 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:30:21 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:30:21 --> Utf8 Class Initialized
INFO - 2020-07-09 08:30:21 --> URI Class Initialized
INFO - 2020-07-09 08:30:21 --> Router Class Initialized
INFO - 2020-07-09 08:30:21 --> Output Class Initialized
INFO - 2020-07-09 08:30:21 --> Security Class Initialized
DEBUG - 2020-07-09 08:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:30:21 --> Input Class Initialized
INFO - 2020-07-09 08:30:21 --> Language Class Initialized
INFO - 2020-07-09 08:30:21 --> Language Class Initialized
INFO - 2020-07-09 08:30:21 --> Config Class Initialized
INFO - 2020-07-09 08:30:21 --> Loader Class Initialized
INFO - 2020-07-09 08:30:21 --> Helper loaded: url_helper
INFO - 2020-07-09 08:30:21 --> Helper loaded: main_helper
INFO - 2020-07-09 08:30:21 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:30:21 --> Controller Class Initialized
INFO - 2020-07-09 08:30:21 --> Final output sent to browser
DEBUG - 2020-07-09 08:30:21 --> Total execution time: 0.0039
INFO - 2020-07-09 08:30:46 --> Config Class Initialized
INFO - 2020-07-09 08:30:46 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:30:46 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:30:46 --> Utf8 Class Initialized
INFO - 2020-07-09 08:30:46 --> URI Class Initialized
INFO - 2020-07-09 08:30:46 --> Router Class Initialized
INFO - 2020-07-09 08:30:46 --> Output Class Initialized
INFO - 2020-07-09 08:30:46 --> Security Class Initialized
DEBUG - 2020-07-09 08:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:30:46 --> Input Class Initialized
INFO - 2020-07-09 08:30:46 --> Language Class Initialized
INFO - 2020-07-09 08:30:46 --> Language Class Initialized
INFO - 2020-07-09 08:30:46 --> Config Class Initialized
INFO - 2020-07-09 08:30:46 --> Loader Class Initialized
INFO - 2020-07-09 08:30:46 --> Helper loaded: url_helper
INFO - 2020-07-09 08:30:46 --> Helper loaded: main_helper
INFO - 2020-07-09 08:30:46 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:30:46 --> Controller Class Initialized
DEBUG - 2020-07-09 08:30:46 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:30:46 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:30:46 --> Final output sent to browser
DEBUG - 2020-07-09 08:30:46 --> Total execution time: 0.0033
INFO - 2020-07-09 08:30:46 --> Config Class Initialized
INFO - 2020-07-09 08:30:46 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:30:46 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:30:46 --> Utf8 Class Initialized
INFO - 2020-07-09 08:30:46 --> URI Class Initialized
INFO - 2020-07-09 08:30:46 --> Router Class Initialized
INFO - 2020-07-09 08:30:46 --> Output Class Initialized
INFO - 2020-07-09 08:30:46 --> Security Class Initialized
DEBUG - 2020-07-09 08:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:30:46 --> Input Class Initialized
INFO - 2020-07-09 08:30:46 --> Language Class Initialized
INFO - 2020-07-09 08:30:46 --> Language Class Initialized
INFO - 2020-07-09 08:30:46 --> Config Class Initialized
INFO - 2020-07-09 08:30:46 --> Loader Class Initialized
INFO - 2020-07-09 08:30:46 --> Helper loaded: url_helper
INFO - 2020-07-09 08:30:46 --> Helper loaded: main_helper
INFO - 2020-07-09 08:30:46 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:30:46 --> Controller Class Initialized
INFO - 2020-07-09 08:30:46 --> Final output sent to browser
DEBUG - 2020-07-09 08:30:46 --> Total execution time: 0.0052
INFO - 2020-07-09 08:31:19 --> Config Class Initialized
INFO - 2020-07-09 08:31:19 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:31:19 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:31:19 --> Utf8 Class Initialized
INFO - 2020-07-09 08:31:19 --> URI Class Initialized
INFO - 2020-07-09 08:31:19 --> Router Class Initialized
INFO - 2020-07-09 08:31:19 --> Output Class Initialized
INFO - 2020-07-09 08:31:19 --> Security Class Initialized
DEBUG - 2020-07-09 08:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:31:19 --> Input Class Initialized
INFO - 2020-07-09 08:31:19 --> Language Class Initialized
INFO - 2020-07-09 08:31:19 --> Language Class Initialized
INFO - 2020-07-09 08:31:19 --> Config Class Initialized
INFO - 2020-07-09 08:31:19 --> Loader Class Initialized
INFO - 2020-07-09 08:31:19 --> Helper loaded: url_helper
INFO - 2020-07-09 08:31:19 --> Helper loaded: main_helper
INFO - 2020-07-09 08:31:19 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:31:19 --> Controller Class Initialized
DEBUG - 2020-07-09 08:31:19 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:31:19 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:31:19 --> Final output sent to browser
DEBUG - 2020-07-09 08:31:19 --> Total execution time: 0.0036
INFO - 2020-07-09 08:31:20 --> Config Class Initialized
INFO - 2020-07-09 08:31:20 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:31:20 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:31:20 --> Utf8 Class Initialized
INFO - 2020-07-09 08:31:20 --> URI Class Initialized
INFO - 2020-07-09 08:31:20 --> Router Class Initialized
INFO - 2020-07-09 08:31:20 --> Output Class Initialized
INFO - 2020-07-09 08:31:20 --> Security Class Initialized
DEBUG - 2020-07-09 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:31:20 --> Input Class Initialized
INFO - 2020-07-09 08:31:20 --> Language Class Initialized
INFO - 2020-07-09 08:31:20 --> Language Class Initialized
INFO - 2020-07-09 08:31:20 --> Config Class Initialized
INFO - 2020-07-09 08:31:20 --> Loader Class Initialized
INFO - 2020-07-09 08:31:20 --> Helper loaded: url_helper
INFO - 2020-07-09 08:31:20 --> Helper loaded: main_helper
INFO - 2020-07-09 08:31:20 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:31:20 --> Controller Class Initialized
INFO - 2020-07-09 08:31:20 --> Final output sent to browser
DEBUG - 2020-07-09 08:31:20 --> Total execution time: 0.0068
INFO - 2020-07-09 08:32:29 --> Config Class Initialized
INFO - 2020-07-09 08:32:29 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:32:29 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:32:29 --> Utf8 Class Initialized
INFO - 2020-07-09 08:32:29 --> URI Class Initialized
INFO - 2020-07-09 08:32:29 --> Router Class Initialized
INFO - 2020-07-09 08:32:29 --> Output Class Initialized
INFO - 2020-07-09 08:32:29 --> Security Class Initialized
DEBUG - 2020-07-09 08:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:32:29 --> Input Class Initialized
INFO - 2020-07-09 08:32:29 --> Language Class Initialized
INFO - 2020-07-09 08:32:29 --> Language Class Initialized
INFO - 2020-07-09 08:32:29 --> Config Class Initialized
INFO - 2020-07-09 08:32:29 --> Loader Class Initialized
INFO - 2020-07-09 08:32:29 --> Helper loaded: url_helper
INFO - 2020-07-09 08:32:29 --> Helper loaded: main_helper
INFO - 2020-07-09 08:32:29 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:32:29 --> Controller Class Initialized
DEBUG - 2020-07-09 08:32:29 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:32:29 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:32:29 --> Final output sent to browser
DEBUG - 2020-07-09 08:32:29 --> Total execution time: 0.0038
INFO - 2020-07-09 08:32:30 --> Config Class Initialized
INFO - 2020-07-09 08:32:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:32:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:32:30 --> Utf8 Class Initialized
INFO - 2020-07-09 08:32:30 --> URI Class Initialized
INFO - 2020-07-09 08:32:30 --> Router Class Initialized
INFO - 2020-07-09 08:32:30 --> Output Class Initialized
INFO - 2020-07-09 08:32:30 --> Security Class Initialized
DEBUG - 2020-07-09 08:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:32:30 --> Input Class Initialized
INFO - 2020-07-09 08:32:30 --> Language Class Initialized
INFO - 2020-07-09 08:32:30 --> Language Class Initialized
INFO - 2020-07-09 08:32:30 --> Config Class Initialized
INFO - 2020-07-09 08:32:30 --> Loader Class Initialized
INFO - 2020-07-09 08:32:30 --> Helper loaded: url_helper
INFO - 2020-07-09 08:32:30 --> Helper loaded: main_helper
INFO - 2020-07-09 08:32:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:32:30 --> Controller Class Initialized
INFO - 2020-07-09 08:32:30 --> Final output sent to browser
DEBUG - 2020-07-09 08:32:30 --> Total execution time: 0.0040
INFO - 2020-07-09 08:33:04 --> Config Class Initialized
INFO - 2020-07-09 08:33:04 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:33:04 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:33:04 --> Utf8 Class Initialized
INFO - 2020-07-09 08:33:04 --> URI Class Initialized
INFO - 2020-07-09 08:33:04 --> Router Class Initialized
INFO - 2020-07-09 08:33:04 --> Output Class Initialized
INFO - 2020-07-09 08:33:04 --> Security Class Initialized
DEBUG - 2020-07-09 08:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:33:04 --> Input Class Initialized
INFO - 2020-07-09 08:33:04 --> Language Class Initialized
INFO - 2020-07-09 08:33:04 --> Language Class Initialized
INFO - 2020-07-09 08:33:04 --> Config Class Initialized
INFO - 2020-07-09 08:33:04 --> Loader Class Initialized
INFO - 2020-07-09 08:33:04 --> Helper loaded: url_helper
INFO - 2020-07-09 08:33:04 --> Helper loaded: main_helper
INFO - 2020-07-09 08:33:04 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:33:04 --> Controller Class Initialized
DEBUG - 2020-07-09 08:33:04 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:33:04 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:33:04 --> Final output sent to browser
DEBUG - 2020-07-09 08:33:04 --> Total execution time: 0.0034
INFO - 2020-07-09 08:33:05 --> Config Class Initialized
INFO - 2020-07-09 08:33:05 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:33:05 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:33:05 --> Utf8 Class Initialized
INFO - 2020-07-09 08:33:05 --> URI Class Initialized
INFO - 2020-07-09 08:33:05 --> Router Class Initialized
INFO - 2020-07-09 08:33:05 --> Output Class Initialized
INFO - 2020-07-09 08:33:05 --> Security Class Initialized
DEBUG - 2020-07-09 08:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:33:05 --> Input Class Initialized
INFO - 2020-07-09 08:33:05 --> Language Class Initialized
INFO - 2020-07-09 08:33:05 --> Language Class Initialized
INFO - 2020-07-09 08:33:05 --> Config Class Initialized
INFO - 2020-07-09 08:33:05 --> Loader Class Initialized
INFO - 2020-07-09 08:33:05 --> Helper loaded: url_helper
INFO - 2020-07-09 08:33:05 --> Helper loaded: main_helper
INFO - 2020-07-09 08:33:05 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:33:05 --> Controller Class Initialized
INFO - 2020-07-09 08:33:05 --> Final output sent to browser
DEBUG - 2020-07-09 08:33:05 --> Total execution time: 0.0057
INFO - 2020-07-09 08:33:14 --> Config Class Initialized
INFO - 2020-07-09 08:33:14 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:33:14 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:33:14 --> Utf8 Class Initialized
INFO - 2020-07-09 08:33:14 --> URI Class Initialized
INFO - 2020-07-09 08:33:14 --> Router Class Initialized
INFO - 2020-07-09 08:33:14 --> Output Class Initialized
INFO - 2020-07-09 08:33:14 --> Security Class Initialized
DEBUG - 2020-07-09 08:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:33:14 --> Input Class Initialized
INFO - 2020-07-09 08:33:14 --> Language Class Initialized
INFO - 2020-07-09 08:33:14 --> Language Class Initialized
INFO - 2020-07-09 08:33:14 --> Config Class Initialized
INFO - 2020-07-09 08:33:14 --> Loader Class Initialized
INFO - 2020-07-09 08:33:14 --> Helper loaded: url_helper
INFO - 2020-07-09 08:33:14 --> Helper loaded: main_helper
INFO - 2020-07-09 08:33:14 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:33:14 --> Controller Class Initialized
DEBUG - 2020-07-09 08:33:14 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:33:14 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:33:14 --> Final output sent to browser
DEBUG - 2020-07-09 08:33:14 --> Total execution time: 0.0037
INFO - 2020-07-09 08:33:15 --> Config Class Initialized
INFO - 2020-07-09 08:33:15 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:33:15 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:33:15 --> Utf8 Class Initialized
INFO - 2020-07-09 08:33:15 --> URI Class Initialized
INFO - 2020-07-09 08:33:15 --> Router Class Initialized
INFO - 2020-07-09 08:33:15 --> Output Class Initialized
INFO - 2020-07-09 08:33:15 --> Security Class Initialized
DEBUG - 2020-07-09 08:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:33:15 --> Input Class Initialized
INFO - 2020-07-09 08:33:15 --> Language Class Initialized
INFO - 2020-07-09 08:33:15 --> Language Class Initialized
INFO - 2020-07-09 08:33:15 --> Config Class Initialized
INFO - 2020-07-09 08:33:15 --> Loader Class Initialized
INFO - 2020-07-09 08:33:15 --> Helper loaded: url_helper
INFO - 2020-07-09 08:33:15 --> Helper loaded: main_helper
INFO - 2020-07-09 08:33:15 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:33:15 --> Controller Class Initialized
INFO - 2020-07-09 08:33:15 --> Final output sent to browser
DEBUG - 2020-07-09 08:33:15 --> Total execution time: 0.0063
INFO - 2020-07-09 08:33:52 --> Config Class Initialized
INFO - 2020-07-09 08:33:52 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:33:52 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:33:52 --> Utf8 Class Initialized
INFO - 2020-07-09 08:33:52 --> URI Class Initialized
INFO - 2020-07-09 08:33:52 --> Router Class Initialized
INFO - 2020-07-09 08:33:52 --> Output Class Initialized
INFO - 2020-07-09 08:33:52 --> Security Class Initialized
DEBUG - 2020-07-09 08:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:33:52 --> Input Class Initialized
INFO - 2020-07-09 08:33:52 --> Language Class Initialized
INFO - 2020-07-09 08:33:52 --> Language Class Initialized
INFO - 2020-07-09 08:33:52 --> Config Class Initialized
INFO - 2020-07-09 08:33:52 --> Loader Class Initialized
INFO - 2020-07-09 08:33:52 --> Helper loaded: url_helper
INFO - 2020-07-09 08:33:52 --> Helper loaded: main_helper
INFO - 2020-07-09 08:33:52 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:33:52 --> Controller Class Initialized
DEBUG - 2020-07-09 08:33:52 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:33:52 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:33:52 --> Final output sent to browser
DEBUG - 2020-07-09 08:33:52 --> Total execution time: 0.0041
INFO - 2020-07-09 08:33:53 --> Config Class Initialized
INFO - 2020-07-09 08:33:53 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:33:53 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:33:53 --> Utf8 Class Initialized
INFO - 2020-07-09 08:33:53 --> URI Class Initialized
INFO - 2020-07-09 08:33:53 --> Router Class Initialized
INFO - 2020-07-09 08:33:53 --> Output Class Initialized
INFO - 2020-07-09 08:33:53 --> Security Class Initialized
DEBUG - 2020-07-09 08:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:33:53 --> Input Class Initialized
INFO - 2020-07-09 08:33:53 --> Language Class Initialized
INFO - 2020-07-09 08:33:53 --> Language Class Initialized
INFO - 2020-07-09 08:33:53 --> Config Class Initialized
INFO - 2020-07-09 08:33:53 --> Loader Class Initialized
INFO - 2020-07-09 08:33:53 --> Helper loaded: url_helper
INFO - 2020-07-09 08:33:53 --> Helper loaded: main_helper
INFO - 2020-07-09 08:33:53 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:33:53 --> Controller Class Initialized
INFO - 2020-07-09 08:33:53 --> Final output sent to browser
DEBUG - 2020-07-09 08:33:53 --> Total execution time: 0.0058
INFO - 2020-07-09 08:33:59 --> Config Class Initialized
INFO - 2020-07-09 08:33:59 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:33:59 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:33:59 --> Utf8 Class Initialized
INFO - 2020-07-09 08:33:59 --> URI Class Initialized
INFO - 2020-07-09 08:33:59 --> Router Class Initialized
INFO - 2020-07-09 08:33:59 --> Output Class Initialized
INFO - 2020-07-09 08:33:59 --> Security Class Initialized
DEBUG - 2020-07-09 08:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:33:59 --> Input Class Initialized
INFO - 2020-07-09 08:33:59 --> Language Class Initialized
INFO - 2020-07-09 08:33:59 --> Language Class Initialized
INFO - 2020-07-09 08:33:59 --> Config Class Initialized
INFO - 2020-07-09 08:33:59 --> Loader Class Initialized
INFO - 2020-07-09 08:33:59 --> Helper loaded: url_helper
INFO - 2020-07-09 08:33:59 --> Helper loaded: main_helper
INFO - 2020-07-09 08:33:59 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:33:59 --> Controller Class Initialized
DEBUG - 2020-07-09 08:33:59 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:33:59 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:33:59 --> Final output sent to browser
DEBUG - 2020-07-09 08:33:59 --> Total execution time: 0.0037
INFO - 2020-07-09 08:34:00 --> Config Class Initialized
INFO - 2020-07-09 08:34:00 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:34:00 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:34:00 --> Utf8 Class Initialized
INFO - 2020-07-09 08:34:00 --> URI Class Initialized
INFO - 2020-07-09 08:34:00 --> Router Class Initialized
INFO - 2020-07-09 08:34:00 --> Output Class Initialized
INFO - 2020-07-09 08:34:00 --> Security Class Initialized
DEBUG - 2020-07-09 08:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:34:00 --> Input Class Initialized
INFO - 2020-07-09 08:34:00 --> Language Class Initialized
INFO - 2020-07-09 08:34:00 --> Language Class Initialized
INFO - 2020-07-09 08:34:00 --> Config Class Initialized
INFO - 2020-07-09 08:34:00 --> Loader Class Initialized
INFO - 2020-07-09 08:34:00 --> Helper loaded: url_helper
INFO - 2020-07-09 08:34:00 --> Helper loaded: main_helper
INFO - 2020-07-09 08:34:00 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:34:00 --> Controller Class Initialized
INFO - 2020-07-09 08:34:00 --> Final output sent to browser
DEBUG - 2020-07-09 08:34:00 --> Total execution time: 0.0055
INFO - 2020-07-09 08:34:28 --> Config Class Initialized
INFO - 2020-07-09 08:34:28 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:34:28 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:34:28 --> Utf8 Class Initialized
INFO - 2020-07-09 08:34:28 --> URI Class Initialized
DEBUG - 2020-07-09 08:34:28 --> No URI present. Default controller set.
INFO - 2020-07-09 08:34:28 --> Router Class Initialized
INFO - 2020-07-09 08:34:28 --> Output Class Initialized
INFO - 2020-07-09 08:34:28 --> Security Class Initialized
DEBUG - 2020-07-09 08:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:34:28 --> Input Class Initialized
INFO - 2020-07-09 08:34:28 --> Language Class Initialized
INFO - 2020-07-09 08:34:28 --> Language Class Initialized
INFO - 2020-07-09 08:34:28 --> Config Class Initialized
INFO - 2020-07-09 08:34:28 --> Loader Class Initialized
INFO - 2020-07-09 08:34:28 --> Helper loaded: url_helper
INFO - 2020-07-09 08:34:28 --> Helper loaded: main_helper
INFO - 2020-07-09 08:34:28 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:34:28 --> Controller Class Initialized
DEBUG - 2020-07-09 08:34:28 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 08:34:28 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:34:28 --> Final output sent to browser
DEBUG - 2020-07-09 08:34:28 --> Total execution time: 0.0035
INFO - 2020-07-09 08:34:39 --> Config Class Initialized
INFO - 2020-07-09 08:34:39 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:34:39 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:34:39 --> Utf8 Class Initialized
INFO - 2020-07-09 08:34:39 --> URI Class Initialized
INFO - 2020-07-09 08:34:39 --> Router Class Initialized
INFO - 2020-07-09 08:34:39 --> Output Class Initialized
INFO - 2020-07-09 08:34:39 --> Security Class Initialized
DEBUG - 2020-07-09 08:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:34:39 --> Input Class Initialized
INFO - 2020-07-09 08:34:39 --> Language Class Initialized
INFO - 2020-07-09 08:34:39 --> Language Class Initialized
INFO - 2020-07-09 08:34:39 --> Config Class Initialized
INFO - 2020-07-09 08:34:39 --> Loader Class Initialized
INFO - 2020-07-09 08:34:39 --> Helper loaded: url_helper
INFO - 2020-07-09 08:34:39 --> Helper loaded: main_helper
INFO - 2020-07-09 08:34:39 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:34:39 --> Controller Class Initialized
INFO - 2020-07-09 08:34:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:34:39 --> Pagination Class Initialized
ERROR - 2020-07-09 08:34:39 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:34:39 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:34:39 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:34:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:34:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:34:39 --> Encryption Class Initialized
INFO - 2020-07-09 08:34:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:34:40 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:34:40 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:34:40 --> Final output sent to browser
DEBUG - 2020-07-09 08:34:40 --> Total execution time: 1.4614
INFO - 2020-07-09 08:34:56 --> Config Class Initialized
INFO - 2020-07-09 08:34:56 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:34:56 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:34:56 --> Utf8 Class Initialized
INFO - 2020-07-09 08:34:56 --> URI Class Initialized
INFO - 2020-07-09 08:34:56 --> Router Class Initialized
INFO - 2020-07-09 08:34:56 --> Output Class Initialized
INFO - 2020-07-09 08:34:56 --> Security Class Initialized
DEBUG - 2020-07-09 08:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:34:56 --> Input Class Initialized
INFO - 2020-07-09 08:34:56 --> Language Class Initialized
INFO - 2020-07-09 08:34:56 --> Language Class Initialized
INFO - 2020-07-09 08:34:56 --> Config Class Initialized
INFO - 2020-07-09 08:34:56 --> Loader Class Initialized
INFO - 2020-07-09 08:34:56 --> Helper loaded: url_helper
INFO - 2020-07-09 08:34:56 --> Helper loaded: main_helper
INFO - 2020-07-09 08:34:56 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:34:56 --> Controller Class Initialized
INFO - 2020-07-09 08:34:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:34:56 --> Pagination Class Initialized
ERROR - 2020-07-09 08:34:56 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:34:56 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:34:56 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:34:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:34:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:34:56 --> Encryption Class Initialized
INFO - 2020-07-09 08:34:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:34:57 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-09 08:34:57 --> Final output sent to browser
DEBUG - 2020-07-09 08:34:57 --> Total execution time: 1.2383
INFO - 2020-07-09 08:35:04 --> Config Class Initialized
INFO - 2020-07-09 08:35:04 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:35:04 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:35:04 --> Utf8 Class Initialized
INFO - 2020-07-09 08:35:04 --> URI Class Initialized
INFO - 2020-07-09 08:35:04 --> Router Class Initialized
INFO - 2020-07-09 08:35:04 --> Output Class Initialized
INFO - 2020-07-09 08:35:04 --> Security Class Initialized
DEBUG - 2020-07-09 08:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:35:04 --> Input Class Initialized
INFO - 2020-07-09 08:35:04 --> Language Class Initialized
INFO - 2020-07-09 08:35:04 --> Language Class Initialized
INFO - 2020-07-09 08:35:04 --> Config Class Initialized
INFO - 2020-07-09 08:35:04 --> Loader Class Initialized
INFO - 2020-07-09 08:35:04 --> Helper loaded: url_helper
INFO - 2020-07-09 08:35:04 --> Helper loaded: main_helper
INFO - 2020-07-09 08:35:04 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:35:04 --> Controller Class Initialized
INFO - 2020-07-09 08:35:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:35:04 --> Pagination Class Initialized
ERROR - 2020-07-09 08:35:04 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:35:04 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:35:04 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:35:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:35:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:35:04 --> Encryption Class Initialized
INFO - 2020-07-09 08:35:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:35:05 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-09 08:35:05 --> Final output sent to browser
DEBUG - 2020-07-09 08:35:05 --> Total execution time: 1.3225
INFO - 2020-07-09 08:36:05 --> Config Class Initialized
INFO - 2020-07-09 08:36:05 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:36:05 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:36:05 --> Utf8 Class Initialized
INFO - 2020-07-09 08:36:05 --> URI Class Initialized
INFO - 2020-07-09 08:36:05 --> Router Class Initialized
INFO - 2020-07-09 08:36:05 --> Output Class Initialized
INFO - 2020-07-09 08:36:05 --> Security Class Initialized
DEBUG - 2020-07-09 08:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:36:05 --> Input Class Initialized
INFO - 2020-07-09 08:36:05 --> Language Class Initialized
INFO - 2020-07-09 08:36:05 --> Language Class Initialized
INFO - 2020-07-09 08:36:05 --> Config Class Initialized
INFO - 2020-07-09 08:36:05 --> Loader Class Initialized
INFO - 2020-07-09 08:36:05 --> Helper loaded: url_helper
INFO - 2020-07-09 08:36:05 --> Helper loaded: main_helper
INFO - 2020-07-09 08:36:05 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:36:05 --> Controller Class Initialized
INFO - 2020-07-09 08:36:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:36:05 --> Pagination Class Initialized
ERROR - 2020-07-09 08:36:05 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:36:05 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:36:05 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:36:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:36:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:36:05 --> Encryption Class Initialized
INFO - 2020-07-09 08:36:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:36:05 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:36:05 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:36:05 --> Final output sent to browser
DEBUG - 2020-07-09 08:36:05 --> Total execution time: 0.0046
INFO - 2020-07-09 08:39:30 --> Config Class Initialized
INFO - 2020-07-09 08:39:30 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:39:30 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:39:30 --> Utf8 Class Initialized
INFO - 2020-07-09 08:39:30 --> URI Class Initialized
INFO - 2020-07-09 08:39:30 --> Router Class Initialized
INFO - 2020-07-09 08:39:30 --> Output Class Initialized
INFO - 2020-07-09 08:39:30 --> Security Class Initialized
DEBUG - 2020-07-09 08:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:39:30 --> Input Class Initialized
INFO - 2020-07-09 08:39:30 --> Language Class Initialized
INFO - 2020-07-09 08:39:30 --> Language Class Initialized
INFO - 2020-07-09 08:39:30 --> Config Class Initialized
INFO - 2020-07-09 08:39:30 --> Loader Class Initialized
INFO - 2020-07-09 08:39:30 --> Helper loaded: url_helper
INFO - 2020-07-09 08:39:30 --> Helper loaded: main_helper
INFO - 2020-07-09 08:39:30 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:39:30 --> Controller Class Initialized
INFO - 2020-07-09 08:39:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:39:30 --> Pagination Class Initialized
ERROR - 2020-07-09 08:39:30 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:39:30 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:39:30 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:39:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:39:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:39:30 --> Encryption Class Initialized
INFO - 2020-07-09 08:39:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:39:30 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:39:30 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:39:30 --> Final output sent to browser
DEBUG - 2020-07-09 08:39:30 --> Total execution time: 0.0059
INFO - 2020-07-09 08:39:44 --> Config Class Initialized
INFO - 2020-07-09 08:39:44 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:39:44 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:39:44 --> Utf8 Class Initialized
INFO - 2020-07-09 08:39:44 --> URI Class Initialized
INFO - 2020-07-09 08:39:44 --> Router Class Initialized
INFO - 2020-07-09 08:39:44 --> Output Class Initialized
INFO - 2020-07-09 08:39:44 --> Security Class Initialized
DEBUG - 2020-07-09 08:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:39:44 --> Input Class Initialized
INFO - 2020-07-09 08:39:44 --> Language Class Initialized
INFO - 2020-07-09 08:39:44 --> Language Class Initialized
INFO - 2020-07-09 08:39:44 --> Config Class Initialized
INFO - 2020-07-09 08:39:44 --> Loader Class Initialized
INFO - 2020-07-09 08:39:44 --> Helper loaded: url_helper
INFO - 2020-07-09 08:39:44 --> Helper loaded: main_helper
INFO - 2020-07-09 08:39:44 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:39:44 --> Controller Class Initialized
INFO - 2020-07-09 08:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:39:44 --> Pagination Class Initialized
ERROR - 2020-07-09 08:39:44 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:39:44 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:39:44 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:39:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:39:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:39:44 --> Encryption Class Initialized
INFO - 2020-07-09 08:39:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:39:45 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:39:45 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:39:45 --> Final output sent to browser
DEBUG - 2020-07-09 08:39:45 --> Total execution time: 1.3456
INFO - 2020-07-09 08:40:05 --> Config Class Initialized
INFO - 2020-07-09 08:40:05 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:40:05 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:40:05 --> Utf8 Class Initialized
INFO - 2020-07-09 08:40:05 --> URI Class Initialized
INFO - 2020-07-09 08:40:05 --> Router Class Initialized
INFO - 2020-07-09 08:40:05 --> Output Class Initialized
INFO - 2020-07-09 08:40:05 --> Security Class Initialized
DEBUG - 2020-07-09 08:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:40:05 --> Input Class Initialized
INFO - 2020-07-09 08:40:05 --> Language Class Initialized
INFO - 2020-07-09 08:40:05 --> Language Class Initialized
INFO - 2020-07-09 08:40:05 --> Config Class Initialized
INFO - 2020-07-09 08:40:05 --> Loader Class Initialized
INFO - 2020-07-09 08:40:05 --> Helper loaded: url_helper
INFO - 2020-07-09 08:40:05 --> Helper loaded: main_helper
INFO - 2020-07-09 08:40:05 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:40:05 --> Controller Class Initialized
INFO - 2020-07-09 08:40:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:40:05 --> Pagination Class Initialized
ERROR - 2020-07-09 08:40:05 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:40:05 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:40:05 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:40:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:40:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:40:05 --> Encryption Class Initialized
INFO - 2020-07-09 08:40:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:40:05 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:40:05 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:40:05 --> Final output sent to browser
DEBUG - 2020-07-09 08:40:05 --> Total execution time: 0.0047
INFO - 2020-07-09 08:41:05 --> Config Class Initialized
INFO - 2020-07-09 08:41:05 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:41:05 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:41:05 --> Utf8 Class Initialized
INFO - 2020-07-09 08:41:05 --> URI Class Initialized
INFO - 2020-07-09 08:41:05 --> Router Class Initialized
INFO - 2020-07-09 08:41:05 --> Output Class Initialized
INFO - 2020-07-09 08:41:05 --> Security Class Initialized
DEBUG - 2020-07-09 08:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:41:05 --> Input Class Initialized
INFO - 2020-07-09 08:41:05 --> Language Class Initialized
INFO - 2020-07-09 08:41:05 --> Language Class Initialized
INFO - 2020-07-09 08:41:05 --> Config Class Initialized
INFO - 2020-07-09 08:41:05 --> Loader Class Initialized
INFO - 2020-07-09 08:41:05 --> Helper loaded: url_helper
INFO - 2020-07-09 08:41:05 --> Helper loaded: main_helper
INFO - 2020-07-09 08:41:05 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:41:05 --> Controller Class Initialized
DEBUG - 2020-07-09 08:41:05 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:41:05 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:41:05 --> Final output sent to browser
DEBUG - 2020-07-09 08:41:05 --> Total execution time: 0.0041
INFO - 2020-07-09 08:41:05 --> Config Class Initialized
INFO - 2020-07-09 08:41:05 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:41:05 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:41:05 --> Utf8 Class Initialized
INFO - 2020-07-09 08:41:05 --> URI Class Initialized
INFO - 2020-07-09 08:41:05 --> Router Class Initialized
INFO - 2020-07-09 08:41:05 --> Output Class Initialized
INFO - 2020-07-09 08:41:05 --> Security Class Initialized
DEBUG - 2020-07-09 08:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:41:05 --> Input Class Initialized
INFO - 2020-07-09 08:41:05 --> Language Class Initialized
INFO - 2020-07-09 08:41:05 --> Language Class Initialized
INFO - 2020-07-09 08:41:05 --> Config Class Initialized
INFO - 2020-07-09 08:41:05 --> Loader Class Initialized
INFO - 2020-07-09 08:41:05 --> Helper loaded: url_helper
INFO - 2020-07-09 08:41:05 --> Helper loaded: main_helper
INFO - 2020-07-09 08:41:05 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:41:05 --> Controller Class Initialized
INFO - 2020-07-09 08:41:05 --> Final output sent to browser
DEBUG - 2020-07-09 08:41:05 --> Total execution time: 0.0047
INFO - 2020-07-09 08:41:28 --> Config Class Initialized
INFO - 2020-07-09 08:41:28 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:41:28 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:41:28 --> Utf8 Class Initialized
INFO - 2020-07-09 08:41:28 --> URI Class Initialized
INFO - 2020-07-09 08:41:28 --> Router Class Initialized
INFO - 2020-07-09 08:41:28 --> Output Class Initialized
INFO - 2020-07-09 08:41:28 --> Security Class Initialized
DEBUG - 2020-07-09 08:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:41:28 --> Input Class Initialized
INFO - 2020-07-09 08:41:28 --> Language Class Initialized
INFO - 2020-07-09 08:41:28 --> Language Class Initialized
INFO - 2020-07-09 08:41:28 --> Config Class Initialized
INFO - 2020-07-09 08:41:28 --> Loader Class Initialized
INFO - 2020-07-09 08:41:28 --> Helper loaded: url_helper
INFO - 2020-07-09 08:41:28 --> Helper loaded: main_helper
INFO - 2020-07-09 08:41:28 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:41:28 --> Controller Class Initialized
DEBUG - 2020-07-09 08:41:28 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:41:28 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:41:28 --> Final output sent to browser
DEBUG - 2020-07-09 08:41:28 --> Total execution time: 0.0052
INFO - 2020-07-09 08:41:29 --> Config Class Initialized
INFO - 2020-07-09 08:41:29 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:41:29 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:41:29 --> Utf8 Class Initialized
INFO - 2020-07-09 08:41:29 --> URI Class Initialized
INFO - 2020-07-09 08:41:29 --> Router Class Initialized
INFO - 2020-07-09 08:41:29 --> Output Class Initialized
INFO - 2020-07-09 08:41:29 --> Security Class Initialized
DEBUG - 2020-07-09 08:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:41:29 --> Input Class Initialized
INFO - 2020-07-09 08:41:29 --> Language Class Initialized
INFO - 2020-07-09 08:41:29 --> Language Class Initialized
INFO - 2020-07-09 08:41:29 --> Config Class Initialized
INFO - 2020-07-09 08:41:29 --> Loader Class Initialized
INFO - 2020-07-09 08:41:29 --> Helper loaded: url_helper
INFO - 2020-07-09 08:41:29 --> Helper loaded: main_helper
INFO - 2020-07-09 08:41:29 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:41:29 --> Controller Class Initialized
INFO - 2020-07-09 08:41:29 --> Final output sent to browser
DEBUG - 2020-07-09 08:41:29 --> Total execution time: 0.0053
INFO - 2020-07-09 08:41:37 --> Config Class Initialized
INFO - 2020-07-09 08:41:37 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:41:37 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:41:37 --> Utf8 Class Initialized
INFO - 2020-07-09 08:41:37 --> URI Class Initialized
INFO - 2020-07-09 08:41:37 --> Router Class Initialized
INFO - 2020-07-09 08:41:37 --> Output Class Initialized
INFO - 2020-07-09 08:41:37 --> Security Class Initialized
DEBUG - 2020-07-09 08:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:41:37 --> Input Class Initialized
INFO - 2020-07-09 08:41:37 --> Language Class Initialized
INFO - 2020-07-09 08:41:37 --> Language Class Initialized
INFO - 2020-07-09 08:41:37 --> Config Class Initialized
INFO - 2020-07-09 08:41:37 --> Loader Class Initialized
INFO - 2020-07-09 08:41:37 --> Helper loaded: url_helper
INFO - 2020-07-09 08:41:37 --> Helper loaded: main_helper
INFO - 2020-07-09 08:41:37 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:41:37 --> Controller Class Initialized
DEBUG - 2020-07-09 08:41:37 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-09 08:41:37 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:41:37 --> Final output sent to browser
DEBUG - 2020-07-09 08:41:37 --> Total execution time: 0.0036
INFO - 2020-07-09 08:41:38 --> Config Class Initialized
INFO - 2020-07-09 08:41:38 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:41:38 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:41:38 --> Utf8 Class Initialized
INFO - 2020-07-09 08:41:38 --> URI Class Initialized
INFO - 2020-07-09 08:41:38 --> Router Class Initialized
INFO - 2020-07-09 08:41:38 --> Output Class Initialized
INFO - 2020-07-09 08:41:38 --> Security Class Initialized
DEBUG - 2020-07-09 08:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:41:38 --> Input Class Initialized
INFO - 2020-07-09 08:41:38 --> Language Class Initialized
INFO - 2020-07-09 08:41:38 --> Language Class Initialized
INFO - 2020-07-09 08:41:38 --> Config Class Initialized
INFO - 2020-07-09 08:41:38 --> Loader Class Initialized
INFO - 2020-07-09 08:41:38 --> Helper loaded: url_helper
INFO - 2020-07-09 08:41:38 --> Helper loaded: main_helper
INFO - 2020-07-09 08:41:38 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:41:38 --> Controller Class Initialized
INFO - 2020-07-09 08:41:38 --> Final output sent to browser
DEBUG - 2020-07-09 08:41:38 --> Total execution time: 0.0047
INFO - 2020-07-09 08:42:21 --> Config Class Initialized
INFO - 2020-07-09 08:42:21 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:42:21 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:42:21 --> Utf8 Class Initialized
INFO - 2020-07-09 08:42:21 --> URI Class Initialized
INFO - 2020-07-09 08:42:21 --> Router Class Initialized
INFO - 2020-07-09 08:42:21 --> Output Class Initialized
INFO - 2020-07-09 08:42:21 --> Security Class Initialized
DEBUG - 2020-07-09 08:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:42:21 --> Input Class Initialized
INFO - 2020-07-09 08:42:21 --> Language Class Initialized
INFO - 2020-07-09 08:42:21 --> Language Class Initialized
INFO - 2020-07-09 08:42:21 --> Config Class Initialized
INFO - 2020-07-09 08:42:21 --> Loader Class Initialized
INFO - 2020-07-09 08:42:21 --> Helper loaded: url_helper
INFO - 2020-07-09 08:42:21 --> Helper loaded: main_helper
INFO - 2020-07-09 08:42:21 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:42:21 --> Controller Class Initialized
INFO - 2020-07-09 08:42:21 --> Final output sent to browser
DEBUG - 2020-07-09 08:42:21 --> Total execution time: 0.0058
INFO - 2020-07-09 08:42:34 --> Config Class Initialized
INFO - 2020-07-09 08:42:34 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:42:34 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:42:34 --> Utf8 Class Initialized
INFO - 2020-07-09 08:42:34 --> URI Class Initialized
DEBUG - 2020-07-09 08:42:34 --> No URI present. Default controller set.
INFO - 2020-07-09 08:42:34 --> Router Class Initialized
INFO - 2020-07-09 08:42:34 --> Output Class Initialized
INFO - 2020-07-09 08:42:34 --> Security Class Initialized
DEBUG - 2020-07-09 08:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:42:34 --> Input Class Initialized
INFO - 2020-07-09 08:42:34 --> Language Class Initialized
INFO - 2020-07-09 08:42:34 --> Language Class Initialized
INFO - 2020-07-09 08:42:34 --> Config Class Initialized
INFO - 2020-07-09 08:42:34 --> Loader Class Initialized
INFO - 2020-07-09 08:42:34 --> Helper loaded: url_helper
INFO - 2020-07-09 08:42:34 --> Helper loaded: main_helper
INFO - 2020-07-09 08:42:34 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:42:34 --> Controller Class Initialized
DEBUG - 2020-07-09 08:42:34 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 08:42:34 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:42:34 --> Final output sent to browser
DEBUG - 2020-07-09 08:42:34 --> Total execution time: 0.0040
INFO - 2020-07-09 08:42:40 --> Config Class Initialized
INFO - 2020-07-09 08:42:40 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:42:40 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:42:40 --> Utf8 Class Initialized
INFO - 2020-07-09 08:42:40 --> URI Class Initialized
INFO - 2020-07-09 08:42:40 --> Router Class Initialized
INFO - 2020-07-09 08:42:40 --> Output Class Initialized
INFO - 2020-07-09 08:42:40 --> Security Class Initialized
DEBUG - 2020-07-09 08:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:42:40 --> Input Class Initialized
INFO - 2020-07-09 08:42:40 --> Language Class Initialized
INFO - 2020-07-09 08:42:40 --> Language Class Initialized
INFO - 2020-07-09 08:42:40 --> Config Class Initialized
INFO - 2020-07-09 08:42:40 --> Loader Class Initialized
INFO - 2020-07-09 08:42:40 --> Helper loaded: url_helper
INFO - 2020-07-09 08:42:40 --> Helper loaded: main_helper
INFO - 2020-07-09 08:42:40 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:42:40 --> Controller Class Initialized
INFO - 2020-07-09 08:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 08:42:40 --> Pagination Class Initialized
ERROR - 2020-07-09 08:42:40 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 08:42:40 --> Helper loaded: file_helper
DEBUG - 2020-07-09 08:42:40 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 08:42:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 08:42:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 08:42:40 --> Encryption Class Initialized
INFO - 2020-07-09 08:42:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 08:42:40 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 08:42:40 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:42:40 --> Final output sent to browser
DEBUG - 2020-07-09 08:42:40 --> Total execution time: 0.0051
INFO - 2020-07-09 08:45:58 --> Config Class Initialized
INFO - 2020-07-09 08:45:58 --> Hooks Class Initialized
DEBUG - 2020-07-09 08:45:58 --> UTF-8 Support Enabled
INFO - 2020-07-09 08:45:58 --> Utf8 Class Initialized
INFO - 2020-07-09 08:45:58 --> URI Class Initialized
DEBUG - 2020-07-09 08:45:58 --> No URI present. Default controller set.
INFO - 2020-07-09 08:45:58 --> Router Class Initialized
INFO - 2020-07-09 08:45:58 --> Output Class Initialized
INFO - 2020-07-09 08:45:58 --> Security Class Initialized
DEBUG - 2020-07-09 08:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 08:45:58 --> Input Class Initialized
INFO - 2020-07-09 08:45:58 --> Language Class Initialized
INFO - 2020-07-09 08:45:58 --> Language Class Initialized
INFO - 2020-07-09 08:45:58 --> Config Class Initialized
INFO - 2020-07-09 08:45:58 --> Loader Class Initialized
INFO - 2020-07-09 08:45:58 --> Helper loaded: url_helper
INFO - 2020-07-09 08:45:58 --> Helper loaded: main_helper
INFO - 2020-07-09 08:45:58 --> Database Driver Class Initialized
DEBUG - 2020-07-09 08:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 08:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 08:45:58 --> Controller Class Initialized
DEBUG - 2020-07-09 08:45:58 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 08:45:58 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 08:45:58 --> Final output sent to browser
DEBUG - 2020-07-09 08:45:58 --> Total execution time: 0.0040
INFO - 2020-07-09 17:16:07 --> Config Class Initialized
INFO - 2020-07-09 17:16:07 --> Hooks Class Initialized
DEBUG - 2020-07-09 17:16:07 --> UTF-8 Support Enabled
INFO - 2020-07-09 17:16:07 --> Utf8 Class Initialized
INFO - 2020-07-09 17:16:07 --> URI Class Initialized
DEBUG - 2020-07-09 17:16:07 --> No URI present. Default controller set.
INFO - 2020-07-09 17:16:07 --> Router Class Initialized
INFO - 2020-07-09 17:16:07 --> Output Class Initialized
INFO - 2020-07-09 17:16:07 --> Security Class Initialized
DEBUG - 2020-07-09 17:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 17:16:07 --> Input Class Initialized
INFO - 2020-07-09 17:16:07 --> Language Class Initialized
INFO - 2020-07-09 17:16:07 --> Language Class Initialized
INFO - 2020-07-09 17:16:07 --> Config Class Initialized
INFO - 2020-07-09 17:16:07 --> Loader Class Initialized
INFO - 2020-07-09 17:16:07 --> Helper loaded: url_helper
INFO - 2020-07-09 17:16:07 --> Helper loaded: main_helper
INFO - 2020-07-09 17:16:07 --> Database Driver Class Initialized
DEBUG - 2020-07-09 17:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 17:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 17:16:07 --> Controller Class Initialized
DEBUG - 2020-07-09 17:16:07 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 17:16:07 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 17:16:07 --> Final output sent to browser
DEBUG - 2020-07-09 17:16:07 --> Total execution time: 0.0043
INFO - 2020-07-09 17:16:11 --> Config Class Initialized
INFO - 2020-07-09 17:16:11 --> Hooks Class Initialized
DEBUG - 2020-07-09 17:16:11 --> UTF-8 Support Enabled
INFO - 2020-07-09 17:16:11 --> Utf8 Class Initialized
INFO - 2020-07-09 17:16:11 --> URI Class Initialized
DEBUG - 2020-07-09 17:16:11 --> No URI present. Default controller set.
INFO - 2020-07-09 17:16:11 --> Router Class Initialized
INFO - 2020-07-09 17:16:11 --> Output Class Initialized
INFO - 2020-07-09 17:16:11 --> Security Class Initialized
DEBUG - 2020-07-09 17:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 17:16:11 --> Input Class Initialized
INFO - 2020-07-09 17:16:11 --> Language Class Initialized
INFO - 2020-07-09 17:16:11 --> Language Class Initialized
INFO - 2020-07-09 17:16:11 --> Config Class Initialized
INFO - 2020-07-09 17:16:11 --> Loader Class Initialized
INFO - 2020-07-09 17:16:11 --> Helper loaded: url_helper
INFO - 2020-07-09 17:16:11 --> Helper loaded: main_helper
INFO - 2020-07-09 17:16:11 --> Database Driver Class Initialized
DEBUG - 2020-07-09 17:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 17:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 17:16:11 --> Controller Class Initialized
DEBUG - 2020-07-09 17:16:11 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 17:16:11 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 17:16:11 --> Final output sent to browser
DEBUG - 2020-07-09 17:16:11 --> Total execution time: 0.0032
INFO - 2020-07-09 17:16:14 --> Config Class Initialized
INFO - 2020-07-09 17:16:14 --> Hooks Class Initialized
DEBUG - 2020-07-09 17:16:14 --> UTF-8 Support Enabled
INFO - 2020-07-09 17:16:14 --> Utf8 Class Initialized
INFO - 2020-07-09 17:16:14 --> URI Class Initialized
INFO - 2020-07-09 17:16:14 --> Router Class Initialized
INFO - 2020-07-09 17:16:14 --> Output Class Initialized
INFO - 2020-07-09 17:16:14 --> Security Class Initialized
DEBUG - 2020-07-09 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 17:16:14 --> Input Class Initialized
INFO - 2020-07-09 17:16:14 --> Language Class Initialized
INFO - 2020-07-09 17:16:14 --> Language Class Initialized
INFO - 2020-07-09 17:16:14 --> Config Class Initialized
INFO - 2020-07-09 17:16:14 --> Loader Class Initialized
INFO - 2020-07-09 17:16:14 --> Helper loaded: url_helper
INFO - 2020-07-09 17:16:14 --> Helper loaded: main_helper
INFO - 2020-07-09 17:16:14 --> Database Driver Class Initialized
DEBUG - 2020-07-09 17:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 17:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 17:16:14 --> Controller Class Initialized
DEBUG - 2020-07-09 17:16:14 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
INFO - 2020-07-09 17:16:14 --> Config Class Initialized
INFO - 2020-07-09 17:16:14 --> Hooks Class Initialized
DEBUG - 2020-07-09 17:16:14 --> UTF-8 Support Enabled
INFO - 2020-07-09 17:16:14 --> Utf8 Class Initialized
INFO - 2020-07-09 17:16:14 --> URI Class Initialized
DEBUG - 2020-07-09 17:16:14 --> No URI present. Default controller set.
INFO - 2020-07-09 17:16:14 --> Router Class Initialized
INFO - 2020-07-09 17:16:14 --> Output Class Initialized
INFO - 2020-07-09 17:16:14 --> Security Class Initialized
DEBUG - 2020-07-09 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 17:16:14 --> Input Class Initialized
INFO - 2020-07-09 17:16:14 --> Language Class Initialized
INFO - 2020-07-09 17:16:14 --> Language Class Initialized
INFO - 2020-07-09 17:16:14 --> Config Class Initialized
INFO - 2020-07-09 17:16:14 --> Loader Class Initialized
INFO - 2020-07-09 17:16:14 --> Helper loaded: url_helper
INFO - 2020-07-09 17:16:14 --> Helper loaded: main_helper
INFO - 2020-07-09 17:16:14 --> Database Driver Class Initialized
DEBUG - 2020-07-09 17:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 17:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 17:16:14 --> Controller Class Initialized
DEBUG - 2020-07-09 17:16:14 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 17:16:14 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 17:16:14 --> Final output sent to browser
DEBUG - 2020-07-09 17:16:14 --> Total execution time: 0.0049
INFO - 2020-07-09 17:36:49 --> Config Class Initialized
INFO - 2020-07-09 17:36:49 --> Hooks Class Initialized
DEBUG - 2020-07-09 17:36:49 --> UTF-8 Support Enabled
INFO - 2020-07-09 17:36:49 --> Utf8 Class Initialized
INFO - 2020-07-09 17:36:49 --> URI Class Initialized
DEBUG - 2020-07-09 17:36:49 --> No URI present. Default controller set.
INFO - 2020-07-09 17:36:49 --> Router Class Initialized
INFO - 2020-07-09 17:36:49 --> Output Class Initialized
INFO - 2020-07-09 17:36:49 --> Security Class Initialized
DEBUG - 2020-07-09 17:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 17:36:49 --> Input Class Initialized
INFO - 2020-07-09 17:36:49 --> Language Class Initialized
INFO - 2020-07-09 17:36:49 --> Language Class Initialized
INFO - 2020-07-09 17:36:49 --> Config Class Initialized
INFO - 2020-07-09 17:36:49 --> Loader Class Initialized
INFO - 2020-07-09 17:36:49 --> Helper loaded: url_helper
INFO - 2020-07-09 17:36:49 --> Helper loaded: main_helper
INFO - 2020-07-09 17:36:49 --> Database Driver Class Initialized
DEBUG - 2020-07-09 17:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 17:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 17:36:49 --> Controller Class Initialized
DEBUG - 2020-07-09 17:36:49 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-09 17:36:49 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 17:36:49 --> Final output sent to browser
DEBUG - 2020-07-09 17:36:49 --> Total execution time: 0.0062
INFO - 2020-07-09 17:42:49 --> Config Class Initialized
INFO - 2020-07-09 17:42:49 --> Hooks Class Initialized
DEBUG - 2020-07-09 17:42:49 --> UTF-8 Support Enabled
INFO - 2020-07-09 17:42:49 --> Utf8 Class Initialized
INFO - 2020-07-09 17:42:49 --> URI Class Initialized
INFO - 2020-07-09 17:42:49 --> Router Class Initialized
INFO - 2020-07-09 17:42:49 --> Output Class Initialized
INFO - 2020-07-09 17:42:49 --> Security Class Initialized
DEBUG - 2020-07-09 17:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 17:42:49 --> Input Class Initialized
INFO - 2020-07-09 17:42:49 --> Language Class Initialized
INFO - 2020-07-09 17:42:49 --> Language Class Initialized
INFO - 2020-07-09 17:42:49 --> Config Class Initialized
INFO - 2020-07-09 17:42:49 --> Loader Class Initialized
INFO - 2020-07-09 17:42:49 --> Helper loaded: url_helper
INFO - 2020-07-09 17:42:49 --> Helper loaded: main_helper
INFO - 2020-07-09 17:42:49 --> Database Driver Class Initialized
DEBUG - 2020-07-09 17:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 17:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 17:42:49 --> Controller Class Initialized
INFO - 2020-07-09 17:42:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 17:42:49 --> Pagination Class Initialized
ERROR - 2020-07-09 17:42:49 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 17:42:49 --> Helper loaded: file_helper
DEBUG - 2020-07-09 17:42:49 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 17:42:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 17:42:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 17:42:49 --> Encryption Class Initialized
INFO - 2020-07-09 17:42:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 17:42:50 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-09 17:42:50 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-09 17:42:50 --> Final output sent to browser
DEBUG - 2020-07-09 17:42:50 --> Total execution time: 1.4552
INFO - 2020-07-09 17:43:35 --> Config Class Initialized
INFO - 2020-07-09 17:43:35 --> Hooks Class Initialized
DEBUG - 2020-07-09 17:43:35 --> UTF-8 Support Enabled
INFO - 2020-07-09 17:43:35 --> Utf8 Class Initialized
INFO - 2020-07-09 17:43:35 --> URI Class Initialized
INFO - 2020-07-09 17:43:35 --> Router Class Initialized
INFO - 2020-07-09 17:43:35 --> Output Class Initialized
INFO - 2020-07-09 17:43:35 --> Security Class Initialized
DEBUG - 2020-07-09 17:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 17:43:35 --> Input Class Initialized
INFO - 2020-07-09 17:43:35 --> Language Class Initialized
INFO - 2020-07-09 17:43:35 --> Language Class Initialized
INFO - 2020-07-09 17:43:35 --> Config Class Initialized
INFO - 2020-07-09 17:43:35 --> Loader Class Initialized
INFO - 2020-07-09 17:43:35 --> Helper loaded: url_helper
INFO - 2020-07-09 17:43:35 --> Helper loaded: main_helper
INFO - 2020-07-09 17:43:35 --> Database Driver Class Initialized
DEBUG - 2020-07-09 17:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 17:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 17:43:35 --> Controller Class Initialized
INFO - 2020-07-09 17:43:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 17:43:35 --> Pagination Class Initialized
ERROR - 2020-07-09 17:43:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 17:43:35 --> Helper loaded: file_helper
DEBUG - 2020-07-09 17:43:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 17:43:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 17:43:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 17:43:35 --> Encryption Class Initialized
INFO - 2020-07-09 17:43:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 17:43:36 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-09 17:43:36 --> Final output sent to browser
DEBUG - 2020-07-09 17:43:36 --> Total execution time: 1.3157
INFO - 2020-07-09 17:43:44 --> Config Class Initialized
INFO - 2020-07-09 17:43:44 --> Hooks Class Initialized
DEBUG - 2020-07-09 17:43:44 --> UTF-8 Support Enabled
INFO - 2020-07-09 17:43:44 --> Utf8 Class Initialized
INFO - 2020-07-09 17:43:44 --> URI Class Initialized
INFO - 2020-07-09 17:43:44 --> Router Class Initialized
INFO - 2020-07-09 17:43:44 --> Output Class Initialized
INFO - 2020-07-09 17:43:44 --> Security Class Initialized
DEBUG - 2020-07-09 17:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-09 17:43:44 --> Input Class Initialized
INFO - 2020-07-09 17:43:44 --> Language Class Initialized
INFO - 2020-07-09 17:43:44 --> Language Class Initialized
INFO - 2020-07-09 17:43:44 --> Config Class Initialized
INFO - 2020-07-09 17:43:44 --> Loader Class Initialized
INFO - 2020-07-09 17:43:44 --> Helper loaded: url_helper
INFO - 2020-07-09 17:43:44 --> Helper loaded: main_helper
INFO - 2020-07-09 17:43:44 --> Database Driver Class Initialized
DEBUG - 2020-07-09 17:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-09 17:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-09 17:43:44 --> Controller Class Initialized
INFO - 2020-07-09 17:43:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-09 17:43:44 --> Pagination Class Initialized
ERROR - 2020-07-09 17:43:44 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-09 17:43:44 --> Helper loaded: file_helper
DEBUG - 2020-07-09 17:43:44 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-09 17:43:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-09 17:43:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-09 17:43:44 --> Encryption Class Initialized
INFO - 2020-07-09 17:43:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-09 17:43:45 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-09 17:43:45 --> Final output sent to browser
DEBUG - 2020-07-09 17:43:45 --> Total execution time: 1.2448
