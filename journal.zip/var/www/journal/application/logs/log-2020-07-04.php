<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-07-04 10:55:07 --> Config Class Initialized
INFO - 2020-07-04 10:55:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 10:55:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 10:55:07 --> Utf8 Class Initialized
INFO - 2020-07-04 10:55:07 --> URI Class Initialized
INFO - 2020-07-04 10:55:07 --> Router Class Initialized
INFO - 2020-07-04 10:55:07 --> Output Class Initialized
INFO - 2020-07-04 10:55:07 --> Security Class Initialized
DEBUG - 2020-07-04 10:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 10:55:07 --> Input Class Initialized
INFO - 2020-07-04 10:55:07 --> Language Class Initialized
INFO - 2020-07-04 10:55:07 --> Language Class Initialized
INFO - 2020-07-04 10:55:07 --> Config Class Initialized
INFO - 2020-07-04 10:55:07 --> Loader Class Initialized
INFO - 2020-07-04 10:55:07 --> Helper loaded: url_helper
INFO - 2020-07-04 10:55:07 --> Helper loaded: main_helper
INFO - 2020-07-04 10:55:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 10:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 10:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 10:55:07 --> Controller Class Initialized
INFO - 2020-07-04 10:55:07 --> Config Class Initialized
INFO - 2020-07-04 10:55:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 10:55:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 10:55:07 --> Utf8 Class Initialized
INFO - 2020-07-04 10:55:07 --> URI Class Initialized
INFO - 2020-07-04 10:55:07 --> Router Class Initialized
INFO - 2020-07-04 10:55:07 --> Output Class Initialized
INFO - 2020-07-04 10:55:07 --> Security Class Initialized
DEBUG - 2020-07-04 10:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 10:55:07 --> Input Class Initialized
INFO - 2020-07-04 10:55:07 --> Language Class Initialized
INFO - 2020-07-04 10:55:07 --> Language Class Initialized
INFO - 2020-07-04 10:55:07 --> Config Class Initialized
INFO - 2020-07-04 10:55:07 --> Loader Class Initialized
INFO - 2020-07-04 10:55:07 --> Helper loaded: url_helper
INFO - 2020-07-04 10:55:07 --> Helper loaded: main_helper
INFO - 2020-07-04 10:55:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 10:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 10:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 10:55:07 --> Controller Class Initialized
DEBUG - 2020-07-04 10:55:07 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 10:55:07 --> File loaded: /var/www/journal/application/modules/template/views/flash_msg.php
DEBUG - 2020-07-04 10:55:07 --> File loaded: /var/www/journal/application/modules/template/views/flash_msg.php
DEBUG - 2020-07-04 10:55:07 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 10:55:07 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 10:55:07 --> Final output sent to browser
DEBUG - 2020-07-04 10:55:07 --> Total execution time: 0.0038
INFO - 2020-07-04 10:56:22 --> Config Class Initialized
INFO - 2020-07-04 10:56:22 --> Hooks Class Initialized
DEBUG - 2020-07-04 10:56:22 --> UTF-8 Support Enabled
INFO - 2020-07-04 10:56:22 --> Utf8 Class Initialized
INFO - 2020-07-04 10:56:22 --> URI Class Initialized
INFO - 2020-07-04 10:56:22 --> Router Class Initialized
INFO - 2020-07-04 10:56:22 --> Output Class Initialized
INFO - 2020-07-04 10:56:22 --> Security Class Initialized
DEBUG - 2020-07-04 10:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 10:56:22 --> Input Class Initialized
INFO - 2020-07-04 10:56:22 --> Language Class Initialized
INFO - 2020-07-04 10:56:22 --> Language Class Initialized
INFO - 2020-07-04 10:56:22 --> Config Class Initialized
INFO - 2020-07-04 10:56:22 --> Loader Class Initialized
INFO - 2020-07-04 10:56:22 --> Helper loaded: url_helper
INFO - 2020-07-04 10:56:22 --> Helper loaded: main_helper
INFO - 2020-07-04 10:56:22 --> Database Driver Class Initialized
DEBUG - 2020-07-04 10:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 10:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 10:56:22 --> Controller Class Initialized
INFO - 2020-07-04 10:56:22 --> Config Class Initialized
INFO - 2020-07-04 10:56:22 --> Hooks Class Initialized
DEBUG - 2020-07-04 10:56:22 --> UTF-8 Support Enabled
INFO - 2020-07-04 10:56:22 --> Utf8 Class Initialized
INFO - 2020-07-04 10:56:22 --> URI Class Initialized
INFO - 2020-07-04 10:56:22 --> Router Class Initialized
INFO - 2020-07-04 10:56:22 --> Output Class Initialized
INFO - 2020-07-04 10:56:22 --> Security Class Initialized
DEBUG - 2020-07-04 10:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 10:56:22 --> Input Class Initialized
INFO - 2020-07-04 10:56:22 --> Language Class Initialized
INFO - 2020-07-04 10:56:22 --> Language Class Initialized
INFO - 2020-07-04 10:56:22 --> Config Class Initialized
INFO - 2020-07-04 10:56:22 --> Loader Class Initialized
INFO - 2020-07-04 10:56:22 --> Helper loaded: url_helper
INFO - 2020-07-04 10:56:22 --> Helper loaded: main_helper
INFO - 2020-07-04 10:56:22 --> Database Driver Class Initialized
DEBUG - 2020-07-04 10:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 10:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 10:56:22 --> Controller Class Initialized
DEBUG - 2020-07-04 10:56:22 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 10:56:22 --> File loaded: /var/www/journal/application/modules/template/views/flash_msg.php
DEBUG - 2020-07-04 10:56:22 --> File loaded: /var/www/journal/application/modules/template/views/flash_msg.php
DEBUG - 2020-07-04 10:56:22 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 10:56:22 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 10:56:22 --> Final output sent to browser
DEBUG - 2020-07-04 10:56:22 --> Total execution time: 0.0037
INFO - 2020-07-04 10:57:18 --> Config Class Initialized
INFO - 2020-07-04 10:57:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 10:57:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 10:57:18 --> Utf8 Class Initialized
INFO - 2020-07-04 10:57:18 --> URI Class Initialized
INFO - 2020-07-04 10:57:18 --> Router Class Initialized
INFO - 2020-07-04 10:57:18 --> Output Class Initialized
INFO - 2020-07-04 10:57:18 --> Security Class Initialized
DEBUG - 2020-07-04 10:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 10:57:18 --> Input Class Initialized
INFO - 2020-07-04 10:57:18 --> Language Class Initialized
INFO - 2020-07-04 10:57:18 --> Language Class Initialized
INFO - 2020-07-04 10:57:18 --> Config Class Initialized
INFO - 2020-07-04 10:57:18 --> Loader Class Initialized
INFO - 2020-07-04 10:57:18 --> Helper loaded: url_helper
INFO - 2020-07-04 10:57:18 --> Helper loaded: main_helper
INFO - 2020-07-04 10:57:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 10:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 10:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 10:57:18 --> Controller Class Initialized
INFO - 2020-07-04 10:57:18 --> Config Class Initialized
INFO - 2020-07-04 10:57:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 10:57:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 10:57:18 --> Utf8 Class Initialized
INFO - 2020-07-04 10:57:18 --> URI Class Initialized
INFO - 2020-07-04 10:57:18 --> Router Class Initialized
INFO - 2020-07-04 10:57:18 --> Output Class Initialized
INFO - 2020-07-04 10:57:18 --> Security Class Initialized
DEBUG - 2020-07-04 10:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 10:57:18 --> Input Class Initialized
INFO - 2020-07-04 10:57:18 --> Language Class Initialized
INFO - 2020-07-04 10:57:18 --> Language Class Initialized
INFO - 2020-07-04 10:57:18 --> Config Class Initialized
INFO - 2020-07-04 10:57:18 --> Loader Class Initialized
INFO - 2020-07-04 10:57:18 --> Helper loaded: url_helper
INFO - 2020-07-04 10:57:18 --> Helper loaded: main_helper
INFO - 2020-07-04 10:57:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 10:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 10:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 10:57:18 --> Controller Class Initialized
DEBUG - 2020-07-04 10:57:18 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 10:57:18 --> File loaded: /var/www/journal/application/modules/template/views/flash_msg.php
DEBUG - 2020-07-04 10:57:18 --> File loaded: /var/www/journal/application/modules/template/views/flash_msg.php
DEBUG - 2020-07-04 10:57:18 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 10:57:18 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 10:57:18 --> Final output sent to browser
DEBUG - 2020-07-04 10:57:18 --> Total execution time: 0.0035
INFO - 2020-07-04 11:04:47 --> Config Class Initialized
INFO - 2020-07-04 11:04:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 11:04:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 11:04:47 --> Utf8 Class Initialized
INFO - 2020-07-04 11:04:47 --> URI Class Initialized
INFO - 2020-07-04 11:04:47 --> Router Class Initialized
INFO - 2020-07-04 11:04:47 --> Output Class Initialized
INFO - 2020-07-04 11:04:47 --> Security Class Initialized
DEBUG - 2020-07-04 11:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 11:04:47 --> Input Class Initialized
INFO - 2020-07-04 11:04:47 --> Language Class Initialized
INFO - 2020-07-04 11:04:47 --> Language Class Initialized
INFO - 2020-07-04 11:04:47 --> Config Class Initialized
INFO - 2020-07-04 11:04:47 --> Loader Class Initialized
INFO - 2020-07-04 11:04:47 --> Helper loaded: url_helper
INFO - 2020-07-04 11:04:47 --> Helper loaded: main_helper
INFO - 2020-07-04 11:04:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 11:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 11:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 11:04:47 --> Controller Class Initialized
INFO - 2020-07-04 11:04:47 --> Config Class Initialized
INFO - 2020-07-04 11:04:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 11:04:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 11:04:47 --> Utf8 Class Initialized
INFO - 2020-07-04 11:04:47 --> URI Class Initialized
INFO - 2020-07-04 11:04:47 --> Router Class Initialized
INFO - 2020-07-04 11:04:47 --> Output Class Initialized
INFO - 2020-07-04 11:04:47 --> Security Class Initialized
DEBUG - 2020-07-04 11:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 11:04:47 --> Input Class Initialized
INFO - 2020-07-04 11:04:47 --> Language Class Initialized
INFO - 2020-07-04 11:04:47 --> Language Class Initialized
INFO - 2020-07-04 11:04:47 --> Config Class Initialized
INFO - 2020-07-04 11:04:47 --> Loader Class Initialized
INFO - 2020-07-04 11:04:47 --> Helper loaded: url_helper
INFO - 2020-07-04 11:04:47 --> Helper loaded: main_helper
INFO - 2020-07-04 11:04:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 11:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 11:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 11:04:47 --> Controller Class Initialized
DEBUG - 2020-07-04 11:04:47 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 11:04:47 --> File loaded: /var/www/journal/application/modules/template/views/flash_msg.php
DEBUG - 2020-07-04 11:04:47 --> File loaded: /var/www/journal/application/modules/template/views/flash_msg.php
DEBUG - 2020-07-04 11:04:47 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 11:04:47 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 11:04:47 --> Final output sent to browser
DEBUG - 2020-07-04 11:04:47 --> Total execution time: 0.0039
INFO - 2020-07-04 11:05:01 --> Config Class Initialized
INFO - 2020-07-04 11:05:01 --> Hooks Class Initialized
DEBUG - 2020-07-04 11:05:01 --> UTF-8 Support Enabled
INFO - 2020-07-04 11:05:01 --> Utf8 Class Initialized
INFO - 2020-07-04 11:05:01 --> URI Class Initialized
INFO - 2020-07-04 11:05:01 --> Router Class Initialized
INFO - 2020-07-04 11:05:01 --> Output Class Initialized
INFO - 2020-07-04 11:05:01 --> Security Class Initialized
DEBUG - 2020-07-04 11:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 11:05:01 --> Input Class Initialized
INFO - 2020-07-04 11:05:01 --> Language Class Initialized
INFO - 2020-07-04 11:05:01 --> Language Class Initialized
INFO - 2020-07-04 11:05:01 --> Config Class Initialized
INFO - 2020-07-04 11:05:01 --> Loader Class Initialized
INFO - 2020-07-04 11:05:01 --> Helper loaded: url_helper
INFO - 2020-07-04 11:05:01 --> Helper loaded: main_helper
INFO - 2020-07-04 11:05:01 --> Database Driver Class Initialized
DEBUG - 2020-07-04 11:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 11:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 11:05:01 --> Controller Class Initialized
DEBUG - 2020-07-04 11:05:01 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 11:05:01 --> File loaded: /var/www/journal/application/modules/template/views/flash_msg.php
DEBUG - 2020-07-04 11:05:01 --> File loaded: /var/www/journal/application/modules/template/views/flash_msg.php
DEBUG - 2020-07-04 11:05:01 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 11:05:01 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 11:05:01 --> Final output sent to browser
DEBUG - 2020-07-04 11:05:01 --> Total execution time: 0.0061
INFO - 2020-07-04 11:05:06 --> Config Class Initialized
INFO - 2020-07-04 11:05:06 --> Hooks Class Initialized
DEBUG - 2020-07-04 11:05:06 --> UTF-8 Support Enabled
INFO - 2020-07-04 11:05:06 --> Utf8 Class Initialized
INFO - 2020-07-04 11:05:06 --> URI Class Initialized
INFO - 2020-07-04 11:05:06 --> Router Class Initialized
INFO - 2020-07-04 11:05:06 --> Output Class Initialized
INFO - 2020-07-04 11:05:06 --> Security Class Initialized
DEBUG - 2020-07-04 11:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 11:05:06 --> Input Class Initialized
INFO - 2020-07-04 11:05:06 --> Language Class Initialized
INFO - 2020-07-04 11:05:06 --> Language Class Initialized
INFO - 2020-07-04 11:05:06 --> Config Class Initialized
INFO - 2020-07-04 11:05:06 --> Loader Class Initialized
INFO - 2020-07-04 11:05:06 --> Helper loaded: url_helper
INFO - 2020-07-04 11:05:06 --> Helper loaded: main_helper
INFO - 2020-07-04 11:05:06 --> Database Driver Class Initialized
DEBUG - 2020-07-04 11:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 11:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 11:05:06 --> Controller Class Initialized
INFO - 2020-07-04 11:05:07 --> Config Class Initialized
INFO - 2020-07-04 11:05:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 11:05:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 11:05:07 --> Utf8 Class Initialized
INFO - 2020-07-04 11:05:07 --> URI Class Initialized
INFO - 2020-07-04 11:05:07 --> Router Class Initialized
INFO - 2020-07-04 11:05:07 --> Output Class Initialized
INFO - 2020-07-04 11:05:07 --> Security Class Initialized
DEBUG - 2020-07-04 11:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 11:05:07 --> Input Class Initialized
INFO - 2020-07-04 11:05:07 --> Language Class Initialized
INFO - 2020-07-04 11:05:07 --> Language Class Initialized
INFO - 2020-07-04 11:05:07 --> Config Class Initialized
INFO - 2020-07-04 11:05:07 --> Loader Class Initialized
INFO - 2020-07-04 11:05:07 --> Helper loaded: url_helper
INFO - 2020-07-04 11:05:07 --> Helper loaded: main_helper
INFO - 2020-07-04 11:05:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 11:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 11:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 11:05:07 --> Controller Class Initialized
DEBUG - 2020-07-04 11:05:07 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 11:05:07 --> File loaded: /var/www/journal/application/modules/template/views/flash_msg.php
DEBUG - 2020-07-04 11:05:07 --> File loaded: /var/www/journal/application/modules/template/views/flash_msg.php
DEBUG - 2020-07-04 11:05:07 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 11:05:07 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 11:05:07 --> Final output sent to browser
DEBUG - 2020-07-04 11:05:07 --> Total execution time: 0.0038
INFO - 2020-07-04 11:06:38 --> Config Class Initialized
INFO - 2020-07-04 11:06:38 --> Hooks Class Initialized
DEBUG - 2020-07-04 11:06:38 --> UTF-8 Support Enabled
INFO - 2020-07-04 11:06:38 --> Utf8 Class Initialized
INFO - 2020-07-04 11:06:38 --> URI Class Initialized
INFO - 2020-07-04 11:06:38 --> Router Class Initialized
INFO - 2020-07-04 11:06:38 --> Output Class Initialized
INFO - 2020-07-04 11:06:38 --> Security Class Initialized
DEBUG - 2020-07-04 11:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 11:06:38 --> Input Class Initialized
INFO - 2020-07-04 11:06:38 --> Language Class Initialized
INFO - 2020-07-04 11:06:38 --> Language Class Initialized
INFO - 2020-07-04 11:06:38 --> Config Class Initialized
INFO - 2020-07-04 11:06:38 --> Loader Class Initialized
INFO - 2020-07-04 11:06:38 --> Helper loaded: url_helper
INFO - 2020-07-04 11:06:38 --> Helper loaded: main_helper
INFO - 2020-07-04 11:06:38 --> Database Driver Class Initialized
DEBUG - 2020-07-04 11:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 11:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 11:06:38 --> Controller Class Initialized
DEBUG - 2020-07-04 11:06:38 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 11:06:38 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 11:06:38 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 11:06:38 --> Final output sent to browser
DEBUG - 2020-07-04 11:06:38 --> Total execution time: 0.0050
INFO - 2020-07-04 11:07:03 --> Config Class Initialized
INFO - 2020-07-04 11:07:03 --> Hooks Class Initialized
DEBUG - 2020-07-04 11:07:03 --> UTF-8 Support Enabled
INFO - 2020-07-04 11:07:03 --> Utf8 Class Initialized
INFO - 2020-07-04 11:07:03 --> URI Class Initialized
INFO - 2020-07-04 11:07:03 --> Router Class Initialized
INFO - 2020-07-04 11:07:03 --> Output Class Initialized
INFO - 2020-07-04 11:07:03 --> Security Class Initialized
DEBUG - 2020-07-04 11:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 11:07:03 --> Input Class Initialized
INFO - 2020-07-04 11:07:03 --> Language Class Initialized
INFO - 2020-07-04 11:07:03 --> Language Class Initialized
INFO - 2020-07-04 11:07:03 --> Config Class Initialized
INFO - 2020-07-04 11:07:03 --> Loader Class Initialized
INFO - 2020-07-04 11:07:03 --> Helper loaded: url_helper
INFO - 2020-07-04 11:07:03 --> Helper loaded: main_helper
INFO - 2020-07-04 11:07:03 --> Database Driver Class Initialized
DEBUG - 2020-07-04 11:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 11:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 11:07:03 --> Controller Class Initialized
INFO - 2020-07-04 11:07:03 --> Config Class Initialized
INFO - 2020-07-04 11:07:03 --> Hooks Class Initialized
DEBUG - 2020-07-04 11:07:03 --> UTF-8 Support Enabled
INFO - 2020-07-04 11:07:03 --> Utf8 Class Initialized
INFO - 2020-07-04 11:07:03 --> URI Class Initialized
INFO - 2020-07-04 11:07:03 --> Router Class Initialized
INFO - 2020-07-04 11:07:03 --> Output Class Initialized
INFO - 2020-07-04 11:07:03 --> Security Class Initialized
DEBUG - 2020-07-04 11:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 11:07:03 --> Input Class Initialized
INFO - 2020-07-04 11:07:03 --> Language Class Initialized
INFO - 2020-07-04 11:07:03 --> Language Class Initialized
INFO - 2020-07-04 11:07:03 --> Config Class Initialized
INFO - 2020-07-04 11:07:03 --> Loader Class Initialized
INFO - 2020-07-04 11:07:03 --> Helper loaded: url_helper
INFO - 2020-07-04 11:07:03 --> Helper loaded: main_helper
INFO - 2020-07-04 11:07:03 --> Database Driver Class Initialized
DEBUG - 2020-07-04 11:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 11:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 11:07:03 --> Controller Class Initialized
DEBUG - 2020-07-04 11:07:03 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 11:07:03 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 11:07:03 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 11:07:03 --> Final output sent to browser
DEBUG - 2020-07-04 11:07:03 --> Total execution time: 0.0037
INFO - 2020-07-04 13:06:49 --> Config Class Initialized
INFO - 2020-07-04 13:06:49 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:06:49 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:06:49 --> Utf8 Class Initialized
INFO - 2020-07-04 13:06:49 --> URI Class Initialized
INFO - 2020-07-04 13:06:49 --> Router Class Initialized
INFO - 2020-07-04 13:06:49 --> Output Class Initialized
INFO - 2020-07-04 13:06:49 --> Security Class Initialized
DEBUG - 2020-07-04 13:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:06:49 --> Input Class Initialized
INFO - 2020-07-04 13:06:49 --> Language Class Initialized
ERROR - 2020-07-04 13:06:49 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' /var/www/journal/application/modules/mail/controllers/Mail.php 45
INFO - 2020-07-04 13:07:00 --> Config Class Initialized
INFO - 2020-07-04 13:07:00 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:07:00 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:07:00 --> Utf8 Class Initialized
INFO - 2020-07-04 13:07:00 --> URI Class Initialized
INFO - 2020-07-04 13:07:00 --> Router Class Initialized
INFO - 2020-07-04 13:07:00 --> Output Class Initialized
INFO - 2020-07-04 13:07:00 --> Security Class Initialized
DEBUG - 2020-07-04 13:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:07:00 --> Input Class Initialized
INFO - 2020-07-04 13:07:00 --> Language Class Initialized
INFO - 2020-07-04 13:07:00 --> Language Class Initialized
INFO - 2020-07-04 13:07:00 --> Config Class Initialized
INFO - 2020-07-04 13:07:00 --> Loader Class Initialized
INFO - 2020-07-04 13:07:00 --> Helper loaded: url_helper
INFO - 2020-07-04 13:07:00 --> Helper loaded: main_helper
INFO - 2020-07-04 13:07:00 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:07:00 --> Controller Class Initialized
DEBUG - 2020-07-04 13:07:00 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:07:00 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:07:00 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:07:00 --> Final output sent to browser
DEBUG - 2020-07-04 13:07:00 --> Total execution time: 0.0089
INFO - 2020-07-04 13:07:01 --> Config Class Initialized
INFO - 2020-07-04 13:07:01 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:07:01 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:07:01 --> Utf8 Class Initialized
INFO - 2020-07-04 13:07:01 --> URI Class Initialized
INFO - 2020-07-04 13:07:01 --> Router Class Initialized
INFO - 2020-07-04 13:07:01 --> Output Class Initialized
INFO - 2020-07-04 13:07:01 --> Security Class Initialized
DEBUG - 2020-07-04 13:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:07:01 --> Input Class Initialized
INFO - 2020-07-04 13:07:01 --> Language Class Initialized
INFO - 2020-07-04 13:07:01 --> Language Class Initialized
INFO - 2020-07-04 13:07:01 --> Config Class Initialized
INFO - 2020-07-04 13:07:01 --> Loader Class Initialized
INFO - 2020-07-04 13:07:01 --> Helper loaded: url_helper
INFO - 2020-07-04 13:07:01 --> Helper loaded: main_helper
INFO - 2020-07-04 13:07:01 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:07:01 --> Controller Class Initialized
INFO - 2020-07-04 13:07:01 --> Final output sent to browser
DEBUG - 2020-07-04 13:07:01 --> Total execution time: 0.0155
INFO - 2020-07-04 13:08:05 --> Config Class Initialized
INFO - 2020-07-04 13:08:05 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:08:05 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:08:05 --> Utf8 Class Initialized
INFO - 2020-07-04 13:08:05 --> URI Class Initialized
INFO - 2020-07-04 13:08:05 --> Router Class Initialized
INFO - 2020-07-04 13:08:05 --> Output Class Initialized
INFO - 2020-07-04 13:08:05 --> Security Class Initialized
DEBUG - 2020-07-04 13:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:08:05 --> Input Class Initialized
INFO - 2020-07-04 13:08:05 --> Language Class Initialized
INFO - 2020-07-04 13:08:05 --> Language Class Initialized
INFO - 2020-07-04 13:08:05 --> Config Class Initialized
INFO - 2020-07-04 13:08:05 --> Loader Class Initialized
INFO - 2020-07-04 13:08:05 --> Helper loaded: url_helper
INFO - 2020-07-04 13:08:05 --> Helper loaded: main_helper
INFO - 2020-07-04 13:08:05 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:08:05 --> Controller Class Initialized
DEBUG - 2020-07-04 13:08:05 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:08:05 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:08:05 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:08:05 --> Final output sent to browser
DEBUG - 2020-07-04 13:08:05 --> Total execution time: 0.0051
INFO - 2020-07-04 13:08:06 --> Config Class Initialized
INFO - 2020-07-04 13:08:06 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:08:06 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:08:06 --> Utf8 Class Initialized
INFO - 2020-07-04 13:08:06 --> URI Class Initialized
INFO - 2020-07-04 13:08:06 --> Router Class Initialized
INFO - 2020-07-04 13:08:06 --> Output Class Initialized
INFO - 2020-07-04 13:08:06 --> Security Class Initialized
DEBUG - 2020-07-04 13:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:08:06 --> Input Class Initialized
INFO - 2020-07-04 13:08:06 --> Language Class Initialized
INFO - 2020-07-04 13:08:06 --> Language Class Initialized
INFO - 2020-07-04 13:08:06 --> Config Class Initialized
INFO - 2020-07-04 13:08:06 --> Loader Class Initialized
INFO - 2020-07-04 13:08:06 --> Helper loaded: url_helper
INFO - 2020-07-04 13:08:06 --> Helper loaded: main_helper
INFO - 2020-07-04 13:08:06 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:08:06 --> Controller Class Initialized
INFO - 2020-07-04 13:08:06 --> Final output sent to browser
DEBUG - 2020-07-04 13:08:06 --> Total execution time: 0.0074
INFO - 2020-07-04 13:08:12 --> Config Class Initialized
INFO - 2020-07-04 13:08:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:08:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:08:12 --> Utf8 Class Initialized
INFO - 2020-07-04 13:08:12 --> URI Class Initialized
INFO - 2020-07-04 13:08:12 --> Router Class Initialized
INFO - 2020-07-04 13:08:12 --> Output Class Initialized
INFO - 2020-07-04 13:08:12 --> Security Class Initialized
DEBUG - 2020-07-04 13:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:08:12 --> Input Class Initialized
INFO - 2020-07-04 13:08:12 --> Language Class Initialized
INFO - 2020-07-04 13:08:12 --> Language Class Initialized
INFO - 2020-07-04 13:08:12 --> Config Class Initialized
INFO - 2020-07-04 13:08:12 --> Loader Class Initialized
INFO - 2020-07-04 13:08:12 --> Helper loaded: url_helper
INFO - 2020-07-04 13:08:12 --> Helper loaded: main_helper
INFO - 2020-07-04 13:08:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:08:12 --> Controller Class Initialized
DEBUG - 2020-07-04 13:08:12 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:08:12 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:08:12 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:08:12 --> Final output sent to browser
DEBUG - 2020-07-04 13:08:12 --> Total execution time: 0.0035
INFO - 2020-07-04 13:08:13 --> Config Class Initialized
INFO - 2020-07-04 13:08:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:08:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:08:13 --> Utf8 Class Initialized
INFO - 2020-07-04 13:08:13 --> URI Class Initialized
INFO - 2020-07-04 13:08:13 --> Router Class Initialized
INFO - 2020-07-04 13:08:13 --> Output Class Initialized
INFO - 2020-07-04 13:08:13 --> Security Class Initialized
DEBUG - 2020-07-04 13:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:08:13 --> Input Class Initialized
INFO - 2020-07-04 13:08:13 --> Language Class Initialized
INFO - 2020-07-04 13:08:13 --> Language Class Initialized
INFO - 2020-07-04 13:08:13 --> Config Class Initialized
INFO - 2020-07-04 13:08:13 --> Loader Class Initialized
INFO - 2020-07-04 13:08:13 --> Helper loaded: url_helper
INFO - 2020-07-04 13:08:13 --> Helper loaded: main_helper
INFO - 2020-07-04 13:08:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:08:13 --> Controller Class Initialized
INFO - 2020-07-04 13:08:13 --> Final output sent to browser
DEBUG - 2020-07-04 13:08:13 --> Total execution time: 0.0045
INFO - 2020-07-04 13:08:30 --> Config Class Initialized
INFO - 2020-07-04 13:08:30 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:08:30 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:08:30 --> Utf8 Class Initialized
INFO - 2020-07-04 13:08:30 --> URI Class Initialized
INFO - 2020-07-04 13:08:30 --> Router Class Initialized
INFO - 2020-07-04 13:08:30 --> Output Class Initialized
INFO - 2020-07-04 13:08:30 --> Security Class Initialized
DEBUG - 2020-07-04 13:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:08:30 --> Input Class Initialized
INFO - 2020-07-04 13:08:30 --> Language Class Initialized
INFO - 2020-07-04 13:08:30 --> Language Class Initialized
INFO - 2020-07-04 13:08:30 --> Config Class Initialized
INFO - 2020-07-04 13:08:30 --> Loader Class Initialized
INFO - 2020-07-04 13:08:30 --> Helper loaded: url_helper
INFO - 2020-07-04 13:08:30 --> Helper loaded: main_helper
INFO - 2020-07-04 13:08:30 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:08:30 --> Controller Class Initialized
DEBUG - 2020-07-04 13:08:30 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:08:30 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:08:30 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:08:30 --> Final output sent to browser
DEBUG - 2020-07-04 13:08:30 --> Total execution time: 0.0035
INFO - 2020-07-04 13:08:31 --> Config Class Initialized
INFO - 2020-07-04 13:08:31 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:08:31 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:08:31 --> Utf8 Class Initialized
INFO - 2020-07-04 13:08:31 --> URI Class Initialized
INFO - 2020-07-04 13:08:31 --> Router Class Initialized
INFO - 2020-07-04 13:08:31 --> Output Class Initialized
INFO - 2020-07-04 13:08:31 --> Security Class Initialized
DEBUG - 2020-07-04 13:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:08:31 --> Input Class Initialized
INFO - 2020-07-04 13:08:31 --> Language Class Initialized
INFO - 2020-07-04 13:08:31 --> Language Class Initialized
INFO - 2020-07-04 13:08:31 --> Config Class Initialized
INFO - 2020-07-04 13:08:31 --> Loader Class Initialized
INFO - 2020-07-04 13:08:31 --> Helper loaded: url_helper
INFO - 2020-07-04 13:08:31 --> Helper loaded: main_helper
INFO - 2020-07-04 13:08:31 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:08:31 --> Controller Class Initialized
INFO - 2020-07-04 13:08:31 --> Final output sent to browser
DEBUG - 2020-07-04 13:08:31 --> Total execution time: 0.0079
INFO - 2020-07-04 13:08:48 --> Config Class Initialized
INFO - 2020-07-04 13:08:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:08:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:08:48 --> Utf8 Class Initialized
INFO - 2020-07-04 13:08:48 --> URI Class Initialized
INFO - 2020-07-04 13:08:48 --> Router Class Initialized
INFO - 2020-07-04 13:08:48 --> Output Class Initialized
INFO - 2020-07-04 13:08:48 --> Security Class Initialized
DEBUG - 2020-07-04 13:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:08:48 --> Input Class Initialized
INFO - 2020-07-04 13:08:48 --> Language Class Initialized
INFO - 2020-07-04 13:08:48 --> Language Class Initialized
INFO - 2020-07-04 13:08:48 --> Config Class Initialized
INFO - 2020-07-04 13:08:48 --> Loader Class Initialized
INFO - 2020-07-04 13:08:48 --> Helper loaded: url_helper
INFO - 2020-07-04 13:08:48 --> Helper loaded: main_helper
INFO - 2020-07-04 13:08:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:08:48 --> Controller Class Initialized
DEBUG - 2020-07-04 13:08:48 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:08:48 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:08:48 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:08:48 --> Final output sent to browser
DEBUG - 2020-07-04 13:08:48 --> Total execution time: 0.0035
INFO - 2020-07-04 13:08:49 --> Config Class Initialized
INFO - 2020-07-04 13:08:49 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:08:49 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:08:49 --> Utf8 Class Initialized
INFO - 2020-07-04 13:08:49 --> URI Class Initialized
INFO - 2020-07-04 13:08:49 --> Router Class Initialized
INFO - 2020-07-04 13:08:49 --> Output Class Initialized
INFO - 2020-07-04 13:08:49 --> Security Class Initialized
DEBUG - 2020-07-04 13:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:08:49 --> Input Class Initialized
INFO - 2020-07-04 13:08:49 --> Language Class Initialized
INFO - 2020-07-04 13:08:49 --> Language Class Initialized
INFO - 2020-07-04 13:08:49 --> Config Class Initialized
INFO - 2020-07-04 13:08:49 --> Loader Class Initialized
INFO - 2020-07-04 13:08:49 --> Helper loaded: url_helper
INFO - 2020-07-04 13:08:49 --> Helper loaded: main_helper
INFO - 2020-07-04 13:08:49 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:08:49 --> Controller Class Initialized
INFO - 2020-07-04 13:08:49 --> Final output sent to browser
DEBUG - 2020-07-04 13:08:49 --> Total execution time: 0.0062
INFO - 2020-07-04 13:09:08 --> Config Class Initialized
INFO - 2020-07-04 13:09:08 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:09:08 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:09:08 --> Utf8 Class Initialized
INFO - 2020-07-04 13:09:08 --> URI Class Initialized
INFO - 2020-07-04 13:09:08 --> Router Class Initialized
INFO - 2020-07-04 13:09:08 --> Output Class Initialized
INFO - 2020-07-04 13:09:08 --> Security Class Initialized
DEBUG - 2020-07-04 13:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:09:08 --> Input Class Initialized
INFO - 2020-07-04 13:09:08 --> Language Class Initialized
INFO - 2020-07-04 13:09:08 --> Language Class Initialized
INFO - 2020-07-04 13:09:08 --> Config Class Initialized
INFO - 2020-07-04 13:09:08 --> Loader Class Initialized
INFO - 2020-07-04 13:09:08 --> Helper loaded: url_helper
INFO - 2020-07-04 13:09:08 --> Helper loaded: main_helper
INFO - 2020-07-04 13:09:08 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:09:08 --> Controller Class Initialized
DEBUG - 2020-07-04 13:09:08 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:09:08 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:09:08 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:09:08 --> Final output sent to browser
DEBUG - 2020-07-04 13:09:08 --> Total execution time: 0.0035
INFO - 2020-07-04 13:09:09 --> Config Class Initialized
INFO - 2020-07-04 13:09:09 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:09:09 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:09:09 --> Utf8 Class Initialized
INFO - 2020-07-04 13:09:09 --> URI Class Initialized
INFO - 2020-07-04 13:09:09 --> Router Class Initialized
INFO - 2020-07-04 13:09:09 --> Output Class Initialized
INFO - 2020-07-04 13:09:09 --> Security Class Initialized
DEBUG - 2020-07-04 13:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:09:09 --> Input Class Initialized
INFO - 2020-07-04 13:09:09 --> Language Class Initialized
INFO - 2020-07-04 13:09:09 --> Language Class Initialized
INFO - 2020-07-04 13:09:09 --> Config Class Initialized
INFO - 2020-07-04 13:09:09 --> Loader Class Initialized
INFO - 2020-07-04 13:09:09 --> Helper loaded: url_helper
INFO - 2020-07-04 13:09:09 --> Helper loaded: main_helper
INFO - 2020-07-04 13:09:09 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:09:09 --> Controller Class Initialized
INFO - 2020-07-04 13:09:09 --> Final output sent to browser
DEBUG - 2020-07-04 13:09:09 --> Total execution time: 0.0043
INFO - 2020-07-04 13:09:18 --> Config Class Initialized
INFO - 2020-07-04 13:09:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:09:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:09:18 --> Utf8 Class Initialized
INFO - 2020-07-04 13:09:18 --> URI Class Initialized
INFO - 2020-07-04 13:09:18 --> Router Class Initialized
INFO - 2020-07-04 13:09:18 --> Output Class Initialized
INFO - 2020-07-04 13:09:18 --> Security Class Initialized
DEBUG - 2020-07-04 13:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:09:18 --> Input Class Initialized
INFO - 2020-07-04 13:09:18 --> Language Class Initialized
INFO - 2020-07-04 13:09:18 --> Language Class Initialized
INFO - 2020-07-04 13:09:18 --> Config Class Initialized
INFO - 2020-07-04 13:09:18 --> Loader Class Initialized
INFO - 2020-07-04 13:09:18 --> Helper loaded: url_helper
INFO - 2020-07-04 13:09:18 --> Helper loaded: main_helper
INFO - 2020-07-04 13:09:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:09:18 --> Controller Class Initialized
DEBUG - 2020-07-04 13:09:18 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:09:18 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:09:18 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:09:18 --> Final output sent to browser
DEBUG - 2020-07-04 13:09:18 --> Total execution time: 0.0032
INFO - 2020-07-04 13:09:18 --> Config Class Initialized
INFO - 2020-07-04 13:09:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:09:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:09:18 --> Utf8 Class Initialized
INFO - 2020-07-04 13:09:18 --> URI Class Initialized
INFO - 2020-07-04 13:09:18 --> Router Class Initialized
INFO - 2020-07-04 13:09:18 --> Output Class Initialized
INFO - 2020-07-04 13:09:18 --> Security Class Initialized
DEBUG - 2020-07-04 13:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:09:18 --> Input Class Initialized
INFO - 2020-07-04 13:09:18 --> Language Class Initialized
INFO - 2020-07-04 13:09:18 --> Language Class Initialized
INFO - 2020-07-04 13:09:18 --> Config Class Initialized
INFO - 2020-07-04 13:09:18 --> Loader Class Initialized
INFO - 2020-07-04 13:09:18 --> Helper loaded: url_helper
INFO - 2020-07-04 13:09:18 --> Helper loaded: main_helper
INFO - 2020-07-04 13:09:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:09:18 --> Controller Class Initialized
INFO - 2020-07-04 13:09:18 --> Final output sent to browser
DEBUG - 2020-07-04 13:09:18 --> Total execution time: 0.0050
INFO - 2020-07-04 13:09:56 --> Config Class Initialized
INFO - 2020-07-04 13:09:56 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:09:56 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:09:56 --> Utf8 Class Initialized
INFO - 2020-07-04 13:09:56 --> URI Class Initialized
INFO - 2020-07-04 13:09:56 --> Router Class Initialized
INFO - 2020-07-04 13:09:56 --> Output Class Initialized
INFO - 2020-07-04 13:09:56 --> Security Class Initialized
DEBUG - 2020-07-04 13:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:09:56 --> Input Class Initialized
INFO - 2020-07-04 13:09:56 --> Language Class Initialized
INFO - 2020-07-04 13:09:56 --> Language Class Initialized
INFO - 2020-07-04 13:09:56 --> Config Class Initialized
INFO - 2020-07-04 13:09:56 --> Loader Class Initialized
INFO - 2020-07-04 13:09:56 --> Helper loaded: url_helper
INFO - 2020-07-04 13:09:56 --> Helper loaded: main_helper
INFO - 2020-07-04 13:09:56 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:09:56 --> Controller Class Initialized
DEBUG - 2020-07-04 13:09:56 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:09:56 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:09:56 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:09:56 --> Final output sent to browser
DEBUG - 2020-07-04 13:09:56 --> Total execution time: 0.0043
INFO - 2020-07-04 13:09:57 --> Config Class Initialized
INFO - 2020-07-04 13:09:57 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:09:57 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:09:57 --> Utf8 Class Initialized
INFO - 2020-07-04 13:09:57 --> URI Class Initialized
INFO - 2020-07-04 13:09:57 --> Router Class Initialized
INFO - 2020-07-04 13:09:57 --> Output Class Initialized
INFO - 2020-07-04 13:09:57 --> Security Class Initialized
DEBUG - 2020-07-04 13:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:09:57 --> Input Class Initialized
INFO - 2020-07-04 13:09:57 --> Language Class Initialized
INFO - 2020-07-04 13:09:57 --> Language Class Initialized
INFO - 2020-07-04 13:09:57 --> Config Class Initialized
INFO - 2020-07-04 13:09:57 --> Loader Class Initialized
INFO - 2020-07-04 13:09:57 --> Helper loaded: url_helper
INFO - 2020-07-04 13:09:57 --> Helper loaded: main_helper
INFO - 2020-07-04 13:09:57 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:09:57 --> Controller Class Initialized
INFO - 2020-07-04 13:09:57 --> Final output sent to browser
DEBUG - 2020-07-04 13:09:57 --> Total execution time: 0.0053
INFO - 2020-07-04 13:10:49 --> Config Class Initialized
INFO - 2020-07-04 13:10:49 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:10:49 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:10:49 --> Utf8 Class Initialized
INFO - 2020-07-04 13:10:49 --> URI Class Initialized
INFO - 2020-07-04 13:10:49 --> Router Class Initialized
INFO - 2020-07-04 13:10:49 --> Output Class Initialized
INFO - 2020-07-04 13:10:49 --> Security Class Initialized
DEBUG - 2020-07-04 13:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:10:49 --> Input Class Initialized
INFO - 2020-07-04 13:10:49 --> Language Class Initialized
INFO - 2020-07-04 13:10:49 --> Language Class Initialized
INFO - 2020-07-04 13:10:49 --> Config Class Initialized
INFO - 2020-07-04 13:10:49 --> Loader Class Initialized
INFO - 2020-07-04 13:10:49 --> Helper loaded: url_helper
INFO - 2020-07-04 13:10:49 --> Helper loaded: main_helper
INFO - 2020-07-04 13:10:49 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:10:49 --> Controller Class Initialized
DEBUG - 2020-07-04 13:10:49 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:10:49 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:10:49 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:10:49 --> Final output sent to browser
DEBUG - 2020-07-04 13:10:49 --> Total execution time: 0.0040
INFO - 2020-07-04 13:10:50 --> Config Class Initialized
INFO - 2020-07-04 13:10:50 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:10:50 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:10:50 --> Utf8 Class Initialized
INFO - 2020-07-04 13:10:50 --> URI Class Initialized
INFO - 2020-07-04 13:10:50 --> Router Class Initialized
INFO - 2020-07-04 13:10:50 --> Output Class Initialized
INFO - 2020-07-04 13:10:50 --> Security Class Initialized
DEBUG - 2020-07-04 13:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:10:50 --> Input Class Initialized
INFO - 2020-07-04 13:10:50 --> Language Class Initialized
INFO - 2020-07-04 13:10:50 --> Language Class Initialized
INFO - 2020-07-04 13:10:50 --> Config Class Initialized
INFO - 2020-07-04 13:10:50 --> Loader Class Initialized
INFO - 2020-07-04 13:10:50 --> Helper loaded: url_helper
INFO - 2020-07-04 13:10:50 --> Helper loaded: main_helper
INFO - 2020-07-04 13:10:50 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:10:50 --> Controller Class Initialized
INFO - 2020-07-04 13:10:50 --> Final output sent to browser
DEBUG - 2020-07-04 13:10:50 --> Total execution time: 0.0034
INFO - 2020-07-04 13:10:57 --> Config Class Initialized
INFO - 2020-07-04 13:10:57 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:10:57 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:10:57 --> Utf8 Class Initialized
INFO - 2020-07-04 13:10:57 --> URI Class Initialized
INFO - 2020-07-04 13:10:57 --> Router Class Initialized
INFO - 2020-07-04 13:10:57 --> Output Class Initialized
INFO - 2020-07-04 13:10:57 --> Security Class Initialized
DEBUG - 2020-07-04 13:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:10:57 --> Input Class Initialized
INFO - 2020-07-04 13:10:57 --> Language Class Initialized
INFO - 2020-07-04 13:10:57 --> Language Class Initialized
INFO - 2020-07-04 13:10:57 --> Config Class Initialized
INFO - 2020-07-04 13:10:57 --> Loader Class Initialized
INFO - 2020-07-04 13:10:57 --> Helper loaded: url_helper
INFO - 2020-07-04 13:10:57 --> Helper loaded: main_helper
INFO - 2020-07-04 13:10:57 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:10:57 --> Controller Class Initialized
DEBUG - 2020-07-04 13:10:57 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:10:57 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:10:57 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:10:57 --> Final output sent to browser
DEBUG - 2020-07-04 13:10:57 --> Total execution time: 0.0035
INFO - 2020-07-04 13:10:58 --> Config Class Initialized
INFO - 2020-07-04 13:10:58 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:10:58 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:10:58 --> Utf8 Class Initialized
INFO - 2020-07-04 13:10:58 --> URI Class Initialized
INFO - 2020-07-04 13:10:58 --> Router Class Initialized
INFO - 2020-07-04 13:10:58 --> Output Class Initialized
INFO - 2020-07-04 13:10:58 --> Security Class Initialized
DEBUG - 2020-07-04 13:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:10:58 --> Input Class Initialized
INFO - 2020-07-04 13:10:58 --> Language Class Initialized
INFO - 2020-07-04 13:10:58 --> Language Class Initialized
INFO - 2020-07-04 13:10:58 --> Config Class Initialized
INFO - 2020-07-04 13:10:58 --> Loader Class Initialized
INFO - 2020-07-04 13:10:58 --> Helper loaded: url_helper
INFO - 2020-07-04 13:10:58 --> Helper loaded: main_helper
INFO - 2020-07-04 13:10:58 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:10:58 --> Controller Class Initialized
INFO - 2020-07-04 13:10:58 --> Final output sent to browser
DEBUG - 2020-07-04 13:10:58 --> Total execution time: 0.0041
INFO - 2020-07-04 13:11:11 --> Config Class Initialized
INFO - 2020-07-04 13:11:11 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:11:11 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:11:11 --> Utf8 Class Initialized
INFO - 2020-07-04 13:11:11 --> URI Class Initialized
INFO - 2020-07-04 13:11:11 --> Router Class Initialized
INFO - 2020-07-04 13:11:11 --> Output Class Initialized
INFO - 2020-07-04 13:11:11 --> Security Class Initialized
DEBUG - 2020-07-04 13:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:11:11 --> Input Class Initialized
INFO - 2020-07-04 13:11:11 --> Language Class Initialized
INFO - 2020-07-04 13:11:11 --> Language Class Initialized
INFO - 2020-07-04 13:11:11 --> Config Class Initialized
INFO - 2020-07-04 13:11:11 --> Loader Class Initialized
INFO - 2020-07-04 13:11:11 --> Helper loaded: url_helper
INFO - 2020-07-04 13:11:11 --> Helper loaded: main_helper
INFO - 2020-07-04 13:11:11 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:11:11 --> Controller Class Initialized
DEBUG - 2020-07-04 13:11:11 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:11:11 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:11:11 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:11:11 --> Final output sent to browser
DEBUG - 2020-07-04 13:11:11 --> Total execution time: 0.0053
INFO - 2020-07-04 13:11:12 --> Config Class Initialized
INFO - 2020-07-04 13:11:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:11:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:11:12 --> Utf8 Class Initialized
INFO - 2020-07-04 13:11:12 --> URI Class Initialized
INFO - 2020-07-04 13:11:12 --> Router Class Initialized
INFO - 2020-07-04 13:11:12 --> Output Class Initialized
INFO - 2020-07-04 13:11:12 --> Security Class Initialized
DEBUG - 2020-07-04 13:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:11:12 --> Input Class Initialized
INFO - 2020-07-04 13:11:12 --> Language Class Initialized
INFO - 2020-07-04 13:11:12 --> Language Class Initialized
INFO - 2020-07-04 13:11:12 --> Config Class Initialized
INFO - 2020-07-04 13:11:12 --> Loader Class Initialized
INFO - 2020-07-04 13:11:12 --> Helper loaded: url_helper
INFO - 2020-07-04 13:11:12 --> Helper loaded: main_helper
INFO - 2020-07-04 13:11:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:11:12 --> Controller Class Initialized
INFO - 2020-07-04 13:11:12 --> Final output sent to browser
DEBUG - 2020-07-04 13:11:12 --> Total execution time: 0.0065
INFO - 2020-07-04 13:11:53 --> Config Class Initialized
INFO - 2020-07-04 13:11:53 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:11:53 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:11:53 --> Utf8 Class Initialized
INFO - 2020-07-04 13:11:53 --> URI Class Initialized
INFO - 2020-07-04 13:11:53 --> Router Class Initialized
INFO - 2020-07-04 13:11:53 --> Output Class Initialized
INFO - 2020-07-04 13:11:53 --> Security Class Initialized
DEBUG - 2020-07-04 13:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:11:53 --> Input Class Initialized
INFO - 2020-07-04 13:11:53 --> Language Class Initialized
INFO - 2020-07-04 13:11:53 --> Language Class Initialized
INFO - 2020-07-04 13:11:53 --> Config Class Initialized
INFO - 2020-07-04 13:11:53 --> Loader Class Initialized
INFO - 2020-07-04 13:11:53 --> Helper loaded: url_helper
INFO - 2020-07-04 13:11:53 --> Helper loaded: main_helper
INFO - 2020-07-04 13:11:53 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:11:53 --> Controller Class Initialized
DEBUG - 2020-07-04 13:11:53 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:11:53 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:11:53 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:11:53 --> Final output sent to browser
DEBUG - 2020-07-04 13:11:53 --> Total execution time: 0.0035
INFO - 2020-07-04 13:11:54 --> Config Class Initialized
INFO - 2020-07-04 13:11:54 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:11:54 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:11:54 --> Utf8 Class Initialized
INFO - 2020-07-04 13:11:54 --> URI Class Initialized
INFO - 2020-07-04 13:11:54 --> Router Class Initialized
INFO - 2020-07-04 13:11:54 --> Output Class Initialized
INFO - 2020-07-04 13:11:54 --> Security Class Initialized
DEBUG - 2020-07-04 13:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:11:54 --> Input Class Initialized
INFO - 2020-07-04 13:11:54 --> Language Class Initialized
INFO - 2020-07-04 13:11:54 --> Language Class Initialized
INFO - 2020-07-04 13:11:54 --> Config Class Initialized
INFO - 2020-07-04 13:11:54 --> Loader Class Initialized
INFO - 2020-07-04 13:11:54 --> Helper loaded: url_helper
INFO - 2020-07-04 13:11:54 --> Helper loaded: main_helper
INFO - 2020-07-04 13:11:54 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:11:54 --> Controller Class Initialized
INFO - 2020-07-04 13:11:54 --> Final output sent to browser
DEBUG - 2020-07-04 13:11:54 --> Total execution time: 0.0038
INFO - 2020-07-04 13:12:39 --> Config Class Initialized
INFO - 2020-07-04 13:12:39 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:12:39 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:12:39 --> Utf8 Class Initialized
INFO - 2020-07-04 13:12:39 --> URI Class Initialized
INFO - 2020-07-04 13:12:39 --> Router Class Initialized
INFO - 2020-07-04 13:12:39 --> Output Class Initialized
INFO - 2020-07-04 13:12:39 --> Security Class Initialized
DEBUG - 2020-07-04 13:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:12:39 --> Input Class Initialized
INFO - 2020-07-04 13:12:39 --> Language Class Initialized
INFO - 2020-07-04 13:12:39 --> Language Class Initialized
INFO - 2020-07-04 13:12:39 --> Config Class Initialized
INFO - 2020-07-04 13:12:39 --> Loader Class Initialized
INFO - 2020-07-04 13:12:39 --> Helper loaded: url_helper
INFO - 2020-07-04 13:12:39 --> Helper loaded: main_helper
INFO - 2020-07-04 13:12:39 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:12:39 --> Controller Class Initialized
DEBUG - 2020-07-04 13:12:39 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:12:39 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:12:39 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:12:39 --> Final output sent to browser
DEBUG - 2020-07-04 13:12:39 --> Total execution time: 0.0037
INFO - 2020-07-04 13:12:39 --> Config Class Initialized
INFO - 2020-07-04 13:12:39 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:12:39 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:12:39 --> Utf8 Class Initialized
INFO - 2020-07-04 13:12:39 --> URI Class Initialized
INFO - 2020-07-04 13:12:39 --> Router Class Initialized
INFO - 2020-07-04 13:12:39 --> Output Class Initialized
INFO - 2020-07-04 13:12:39 --> Security Class Initialized
DEBUG - 2020-07-04 13:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:12:39 --> Input Class Initialized
INFO - 2020-07-04 13:12:39 --> Language Class Initialized
INFO - 2020-07-04 13:12:39 --> Language Class Initialized
INFO - 2020-07-04 13:12:39 --> Config Class Initialized
INFO - 2020-07-04 13:12:39 --> Loader Class Initialized
INFO - 2020-07-04 13:12:39 --> Helper loaded: url_helper
INFO - 2020-07-04 13:12:39 --> Helper loaded: main_helper
INFO - 2020-07-04 13:12:39 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:12:39 --> Controller Class Initialized
INFO - 2020-07-04 13:12:39 --> Final output sent to browser
DEBUG - 2020-07-04 13:12:39 --> Total execution time: 0.0053
INFO - 2020-07-04 13:13:21 --> Config Class Initialized
INFO - 2020-07-04 13:13:21 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:13:21 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:13:21 --> Utf8 Class Initialized
INFO - 2020-07-04 13:13:21 --> URI Class Initialized
INFO - 2020-07-04 13:13:21 --> Router Class Initialized
INFO - 2020-07-04 13:13:21 --> Output Class Initialized
INFO - 2020-07-04 13:13:21 --> Security Class Initialized
DEBUG - 2020-07-04 13:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:13:21 --> Input Class Initialized
INFO - 2020-07-04 13:13:21 --> Language Class Initialized
INFO - 2020-07-04 13:13:21 --> Language Class Initialized
INFO - 2020-07-04 13:13:21 --> Config Class Initialized
INFO - 2020-07-04 13:13:21 --> Loader Class Initialized
INFO - 2020-07-04 13:13:21 --> Helper loaded: url_helper
INFO - 2020-07-04 13:13:21 --> Helper loaded: main_helper
INFO - 2020-07-04 13:13:21 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:13:21 --> Controller Class Initialized
DEBUG - 2020-07-04 13:13:21 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:13:21 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:13:21 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:13:21 --> Final output sent to browser
DEBUG - 2020-07-04 13:13:21 --> Total execution time: 0.0036
INFO - 2020-07-04 13:13:22 --> Config Class Initialized
INFO - 2020-07-04 13:13:22 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:13:22 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:13:22 --> Utf8 Class Initialized
INFO - 2020-07-04 13:13:22 --> URI Class Initialized
INFO - 2020-07-04 13:13:22 --> Router Class Initialized
INFO - 2020-07-04 13:13:22 --> Output Class Initialized
INFO - 2020-07-04 13:13:22 --> Security Class Initialized
DEBUG - 2020-07-04 13:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:13:22 --> Input Class Initialized
INFO - 2020-07-04 13:13:22 --> Language Class Initialized
INFO - 2020-07-04 13:13:22 --> Language Class Initialized
INFO - 2020-07-04 13:13:22 --> Config Class Initialized
INFO - 2020-07-04 13:13:22 --> Loader Class Initialized
INFO - 2020-07-04 13:13:22 --> Helper loaded: url_helper
INFO - 2020-07-04 13:13:22 --> Helper loaded: main_helper
INFO - 2020-07-04 13:13:22 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:13:22 --> Controller Class Initialized
INFO - 2020-07-04 13:13:22 --> Final output sent to browser
DEBUG - 2020-07-04 13:13:22 --> Total execution time: 0.0069
INFO - 2020-07-04 13:17:14 --> Config Class Initialized
INFO - 2020-07-04 13:17:14 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:17:14 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:17:14 --> Utf8 Class Initialized
INFO - 2020-07-04 13:17:14 --> URI Class Initialized
INFO - 2020-07-04 13:17:14 --> Router Class Initialized
INFO - 2020-07-04 13:17:14 --> Output Class Initialized
INFO - 2020-07-04 13:17:14 --> Security Class Initialized
DEBUG - 2020-07-04 13:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:17:14 --> Input Class Initialized
INFO - 2020-07-04 13:17:14 --> Language Class Initialized
INFO - 2020-07-04 13:17:14 --> Language Class Initialized
INFO - 2020-07-04 13:17:14 --> Config Class Initialized
INFO - 2020-07-04 13:17:14 --> Loader Class Initialized
INFO - 2020-07-04 13:17:14 --> Helper loaded: url_helper
INFO - 2020-07-04 13:17:14 --> Helper loaded: main_helper
INFO - 2020-07-04 13:17:14 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:17:14 --> Controller Class Initialized
DEBUG - 2020-07-04 13:17:14 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:17:14 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:17:14 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:17:14 --> Final output sent to browser
DEBUG - 2020-07-04 13:17:14 --> Total execution time: 0.0045
INFO - 2020-07-04 13:17:15 --> Config Class Initialized
INFO - 2020-07-04 13:17:15 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:17:15 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:17:15 --> Utf8 Class Initialized
INFO - 2020-07-04 13:17:15 --> URI Class Initialized
INFO - 2020-07-04 13:17:15 --> Router Class Initialized
INFO - 2020-07-04 13:17:15 --> Output Class Initialized
INFO - 2020-07-04 13:17:15 --> Security Class Initialized
DEBUG - 2020-07-04 13:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:17:15 --> Input Class Initialized
INFO - 2020-07-04 13:17:15 --> Language Class Initialized
INFO - 2020-07-04 13:17:15 --> Language Class Initialized
INFO - 2020-07-04 13:17:15 --> Config Class Initialized
INFO - 2020-07-04 13:17:15 --> Loader Class Initialized
INFO - 2020-07-04 13:17:15 --> Helper loaded: url_helper
INFO - 2020-07-04 13:17:15 --> Helper loaded: main_helper
INFO - 2020-07-04 13:17:15 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:17:15 --> Controller Class Initialized
INFO - 2020-07-04 13:17:15 --> Final output sent to browser
DEBUG - 2020-07-04 13:17:15 --> Total execution time: 0.0035
INFO - 2020-07-04 13:17:41 --> Config Class Initialized
INFO - 2020-07-04 13:17:41 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:17:41 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:17:41 --> Utf8 Class Initialized
INFO - 2020-07-04 13:17:41 --> URI Class Initialized
INFO - 2020-07-04 13:17:41 --> Router Class Initialized
INFO - 2020-07-04 13:17:41 --> Output Class Initialized
INFO - 2020-07-04 13:17:41 --> Security Class Initialized
DEBUG - 2020-07-04 13:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:17:41 --> Input Class Initialized
INFO - 2020-07-04 13:17:41 --> Language Class Initialized
INFO - 2020-07-04 13:17:41 --> Language Class Initialized
INFO - 2020-07-04 13:17:41 --> Config Class Initialized
INFO - 2020-07-04 13:17:41 --> Loader Class Initialized
INFO - 2020-07-04 13:17:41 --> Helper loaded: url_helper
INFO - 2020-07-04 13:17:41 --> Helper loaded: main_helper
INFO - 2020-07-04 13:17:41 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:17:41 --> Controller Class Initialized
DEBUG - 2020-07-04 13:17:41 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:17:41 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:17:41 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:17:41 --> Final output sent to browser
DEBUG - 2020-07-04 13:17:41 --> Total execution time: 0.0045
INFO - 2020-07-04 13:17:42 --> Config Class Initialized
INFO - 2020-07-04 13:17:42 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:17:42 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:17:42 --> Utf8 Class Initialized
INFO - 2020-07-04 13:17:42 --> URI Class Initialized
INFO - 2020-07-04 13:17:42 --> Router Class Initialized
INFO - 2020-07-04 13:17:42 --> Output Class Initialized
INFO - 2020-07-04 13:17:42 --> Security Class Initialized
DEBUG - 2020-07-04 13:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:17:42 --> Input Class Initialized
INFO - 2020-07-04 13:17:42 --> Language Class Initialized
INFO - 2020-07-04 13:17:42 --> Language Class Initialized
INFO - 2020-07-04 13:17:42 --> Config Class Initialized
INFO - 2020-07-04 13:17:42 --> Loader Class Initialized
INFO - 2020-07-04 13:17:42 --> Helper loaded: url_helper
INFO - 2020-07-04 13:17:42 --> Helper loaded: main_helper
INFO - 2020-07-04 13:17:42 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:17:42 --> Controller Class Initialized
INFO - 2020-07-04 13:17:42 --> Final output sent to browser
DEBUG - 2020-07-04 13:17:42 --> Total execution time: 0.0043
INFO - 2020-07-04 13:21:08 --> Config Class Initialized
INFO - 2020-07-04 13:21:08 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:21:08 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:21:08 --> Utf8 Class Initialized
INFO - 2020-07-04 13:21:08 --> URI Class Initialized
INFO - 2020-07-04 13:21:08 --> Router Class Initialized
INFO - 2020-07-04 13:21:08 --> Output Class Initialized
INFO - 2020-07-04 13:21:08 --> Security Class Initialized
DEBUG - 2020-07-04 13:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:21:08 --> Input Class Initialized
INFO - 2020-07-04 13:21:08 --> Language Class Initialized
INFO - 2020-07-04 13:21:08 --> Language Class Initialized
INFO - 2020-07-04 13:21:08 --> Config Class Initialized
INFO - 2020-07-04 13:21:08 --> Loader Class Initialized
INFO - 2020-07-04 13:21:08 --> Helper loaded: url_helper
INFO - 2020-07-04 13:21:08 --> Helper loaded: main_helper
INFO - 2020-07-04 13:21:08 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:21:08 --> Controller Class Initialized
DEBUG - 2020-07-04 13:21:08 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:21:08 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:21:08 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:21:08 --> Final output sent to browser
DEBUG - 2020-07-04 13:21:08 --> Total execution time: 0.0036
INFO - 2020-07-04 13:21:09 --> Config Class Initialized
INFO - 2020-07-04 13:21:09 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:21:09 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:21:09 --> Utf8 Class Initialized
INFO - 2020-07-04 13:21:09 --> URI Class Initialized
INFO - 2020-07-04 13:21:09 --> Router Class Initialized
INFO - 2020-07-04 13:21:09 --> Output Class Initialized
INFO - 2020-07-04 13:21:09 --> Security Class Initialized
DEBUG - 2020-07-04 13:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:21:09 --> Input Class Initialized
INFO - 2020-07-04 13:21:09 --> Language Class Initialized
INFO - 2020-07-04 13:21:09 --> Language Class Initialized
INFO - 2020-07-04 13:21:09 --> Config Class Initialized
INFO - 2020-07-04 13:21:09 --> Loader Class Initialized
INFO - 2020-07-04 13:21:09 --> Helper loaded: url_helper
INFO - 2020-07-04 13:21:09 --> Helper loaded: main_helper
INFO - 2020-07-04 13:21:09 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:21:09 --> Controller Class Initialized
INFO - 2020-07-04 13:21:09 --> Final output sent to browser
DEBUG - 2020-07-04 13:21:09 --> Total execution time: 0.0046
INFO - 2020-07-04 13:21:36 --> Config Class Initialized
INFO - 2020-07-04 13:21:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:21:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:21:36 --> Utf8 Class Initialized
INFO - 2020-07-04 13:21:36 --> URI Class Initialized
INFO - 2020-07-04 13:21:36 --> Router Class Initialized
INFO - 2020-07-04 13:21:36 --> Output Class Initialized
INFO - 2020-07-04 13:21:36 --> Security Class Initialized
DEBUG - 2020-07-04 13:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:21:36 --> Input Class Initialized
INFO - 2020-07-04 13:21:36 --> Language Class Initialized
INFO - 2020-07-04 13:21:36 --> Language Class Initialized
INFO - 2020-07-04 13:21:36 --> Config Class Initialized
INFO - 2020-07-04 13:21:36 --> Loader Class Initialized
INFO - 2020-07-04 13:21:36 --> Helper loaded: url_helper
INFO - 2020-07-04 13:21:36 --> Helper loaded: main_helper
INFO - 2020-07-04 13:21:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:21:36 --> Controller Class Initialized
DEBUG - 2020-07-04 13:21:36 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:21:36 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:21:36 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:21:36 --> Final output sent to browser
DEBUG - 2020-07-04 13:21:36 --> Total execution time: 0.0038
INFO - 2020-07-04 13:21:36 --> Config Class Initialized
INFO - 2020-07-04 13:21:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:21:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:21:36 --> Utf8 Class Initialized
INFO - 2020-07-04 13:21:36 --> URI Class Initialized
INFO - 2020-07-04 13:21:36 --> Router Class Initialized
INFO - 2020-07-04 13:21:36 --> Output Class Initialized
INFO - 2020-07-04 13:21:36 --> Security Class Initialized
DEBUG - 2020-07-04 13:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:21:36 --> Input Class Initialized
INFO - 2020-07-04 13:21:36 --> Language Class Initialized
INFO - 2020-07-04 13:21:36 --> Language Class Initialized
INFO - 2020-07-04 13:21:36 --> Config Class Initialized
INFO - 2020-07-04 13:21:36 --> Loader Class Initialized
INFO - 2020-07-04 13:21:36 --> Helper loaded: url_helper
INFO - 2020-07-04 13:21:36 --> Helper loaded: main_helper
INFO - 2020-07-04 13:21:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:21:36 --> Controller Class Initialized
INFO - 2020-07-04 13:21:36 --> Final output sent to browser
DEBUG - 2020-07-04 13:21:36 --> Total execution time: 0.0063
INFO - 2020-07-04 13:22:24 --> Config Class Initialized
INFO - 2020-07-04 13:22:24 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:22:24 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:22:24 --> Utf8 Class Initialized
INFO - 2020-07-04 13:22:24 --> URI Class Initialized
INFO - 2020-07-04 13:22:24 --> Router Class Initialized
INFO - 2020-07-04 13:22:24 --> Output Class Initialized
INFO - 2020-07-04 13:22:24 --> Security Class Initialized
DEBUG - 2020-07-04 13:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:22:24 --> Input Class Initialized
INFO - 2020-07-04 13:22:24 --> Language Class Initialized
INFO - 2020-07-04 13:22:24 --> Language Class Initialized
INFO - 2020-07-04 13:22:24 --> Config Class Initialized
INFO - 2020-07-04 13:22:24 --> Loader Class Initialized
INFO - 2020-07-04 13:22:24 --> Helper loaded: url_helper
INFO - 2020-07-04 13:22:24 --> Helper loaded: main_helper
INFO - 2020-07-04 13:22:24 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:22:24 --> Controller Class Initialized
DEBUG - 2020-07-04 13:22:24 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:22:24 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:22:24 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:22:24 --> Final output sent to browser
DEBUG - 2020-07-04 13:22:24 --> Total execution time: 0.0037
INFO - 2020-07-04 13:22:24 --> Config Class Initialized
INFO - 2020-07-04 13:22:24 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:22:24 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:22:24 --> Utf8 Class Initialized
INFO - 2020-07-04 13:22:24 --> URI Class Initialized
INFO - 2020-07-04 13:22:24 --> Router Class Initialized
INFO - 2020-07-04 13:22:24 --> Output Class Initialized
INFO - 2020-07-04 13:22:24 --> Security Class Initialized
DEBUG - 2020-07-04 13:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:22:24 --> Input Class Initialized
INFO - 2020-07-04 13:22:24 --> Language Class Initialized
INFO - 2020-07-04 13:22:24 --> Language Class Initialized
INFO - 2020-07-04 13:22:24 --> Config Class Initialized
INFO - 2020-07-04 13:22:24 --> Loader Class Initialized
INFO - 2020-07-04 13:22:24 --> Helper loaded: url_helper
INFO - 2020-07-04 13:22:24 --> Helper loaded: main_helper
INFO - 2020-07-04 13:22:24 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:22:24 --> Controller Class Initialized
INFO - 2020-07-04 13:22:24 --> Final output sent to browser
DEBUG - 2020-07-04 13:22:24 --> Total execution time: 0.0039
INFO - 2020-07-04 13:22:49 --> Config Class Initialized
INFO - 2020-07-04 13:22:49 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:22:49 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:22:49 --> Utf8 Class Initialized
INFO - 2020-07-04 13:22:49 --> URI Class Initialized
INFO - 2020-07-04 13:22:49 --> Router Class Initialized
INFO - 2020-07-04 13:22:49 --> Output Class Initialized
INFO - 2020-07-04 13:22:49 --> Security Class Initialized
DEBUG - 2020-07-04 13:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:22:49 --> Input Class Initialized
INFO - 2020-07-04 13:22:49 --> Language Class Initialized
INFO - 2020-07-04 13:22:49 --> Language Class Initialized
INFO - 2020-07-04 13:22:49 --> Config Class Initialized
INFO - 2020-07-04 13:22:49 --> Loader Class Initialized
INFO - 2020-07-04 13:22:49 --> Helper loaded: url_helper
INFO - 2020-07-04 13:22:49 --> Helper loaded: main_helper
INFO - 2020-07-04 13:22:49 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:22:49 --> Controller Class Initialized
DEBUG - 2020-07-04 13:22:49 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:22:49 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:22:49 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:22:49 --> Final output sent to browser
DEBUG - 2020-07-04 13:22:49 --> Total execution time: 0.0035
INFO - 2020-07-04 13:22:50 --> Config Class Initialized
INFO - 2020-07-04 13:22:50 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:22:50 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:22:50 --> Utf8 Class Initialized
INFO - 2020-07-04 13:22:50 --> URI Class Initialized
INFO - 2020-07-04 13:22:50 --> Router Class Initialized
INFO - 2020-07-04 13:22:50 --> Output Class Initialized
INFO - 2020-07-04 13:22:50 --> Security Class Initialized
DEBUG - 2020-07-04 13:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:22:50 --> Input Class Initialized
INFO - 2020-07-04 13:22:50 --> Language Class Initialized
INFO - 2020-07-04 13:22:50 --> Language Class Initialized
INFO - 2020-07-04 13:22:50 --> Config Class Initialized
INFO - 2020-07-04 13:22:50 --> Loader Class Initialized
INFO - 2020-07-04 13:22:50 --> Helper loaded: url_helper
INFO - 2020-07-04 13:22:50 --> Helper loaded: main_helper
INFO - 2020-07-04 13:22:50 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:22:50 --> Controller Class Initialized
INFO - 2020-07-04 13:22:50 --> Final output sent to browser
DEBUG - 2020-07-04 13:22:50 --> Total execution time: 0.0037
INFO - 2020-07-04 13:23:02 --> Config Class Initialized
INFO - 2020-07-04 13:23:02 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:23:02 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:23:02 --> Utf8 Class Initialized
INFO - 2020-07-04 13:23:02 --> URI Class Initialized
INFO - 2020-07-04 13:23:02 --> Router Class Initialized
INFO - 2020-07-04 13:23:02 --> Output Class Initialized
INFO - 2020-07-04 13:23:02 --> Security Class Initialized
DEBUG - 2020-07-04 13:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:23:02 --> Input Class Initialized
INFO - 2020-07-04 13:23:02 --> Language Class Initialized
INFO - 2020-07-04 13:23:02 --> Language Class Initialized
INFO - 2020-07-04 13:23:02 --> Config Class Initialized
INFO - 2020-07-04 13:23:02 --> Loader Class Initialized
INFO - 2020-07-04 13:23:02 --> Helper loaded: url_helper
INFO - 2020-07-04 13:23:02 --> Helper loaded: main_helper
INFO - 2020-07-04 13:23:02 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:23:03 --> Controller Class Initialized
DEBUG - 2020-07-04 13:23:03 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:23:03 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:23:03 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:23:03 --> Final output sent to browser
DEBUG - 2020-07-04 13:23:03 --> Total execution time: 0.0057
INFO - 2020-07-04 13:23:04 --> Config Class Initialized
INFO - 2020-07-04 13:23:04 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:23:04 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:23:04 --> Utf8 Class Initialized
INFO - 2020-07-04 13:23:04 --> URI Class Initialized
INFO - 2020-07-04 13:23:04 --> Router Class Initialized
INFO - 2020-07-04 13:23:04 --> Output Class Initialized
INFO - 2020-07-04 13:23:04 --> Security Class Initialized
DEBUG - 2020-07-04 13:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:23:04 --> Input Class Initialized
INFO - 2020-07-04 13:23:04 --> Language Class Initialized
INFO - 2020-07-04 13:23:04 --> Language Class Initialized
INFO - 2020-07-04 13:23:04 --> Config Class Initialized
INFO - 2020-07-04 13:23:04 --> Loader Class Initialized
INFO - 2020-07-04 13:23:04 --> Helper loaded: url_helper
INFO - 2020-07-04 13:23:04 --> Helper loaded: main_helper
INFO - 2020-07-04 13:23:04 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:23:04 --> Controller Class Initialized
INFO - 2020-07-04 13:23:04 --> Final output sent to browser
DEBUG - 2020-07-04 13:23:04 --> Total execution time: 0.0103
INFO - 2020-07-04 13:23:16 --> Config Class Initialized
INFO - 2020-07-04 13:23:16 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:23:16 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:23:16 --> Utf8 Class Initialized
INFO - 2020-07-04 13:23:16 --> URI Class Initialized
INFO - 2020-07-04 13:23:16 --> Router Class Initialized
INFO - 2020-07-04 13:23:16 --> Output Class Initialized
INFO - 2020-07-04 13:23:16 --> Security Class Initialized
DEBUG - 2020-07-04 13:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:23:16 --> Input Class Initialized
INFO - 2020-07-04 13:23:16 --> Language Class Initialized
INFO - 2020-07-04 13:23:16 --> Language Class Initialized
INFO - 2020-07-04 13:23:16 --> Config Class Initialized
INFO - 2020-07-04 13:23:16 --> Loader Class Initialized
INFO - 2020-07-04 13:23:16 --> Helper loaded: url_helper
INFO - 2020-07-04 13:23:16 --> Helper loaded: main_helper
INFO - 2020-07-04 13:23:16 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:23:16 --> Controller Class Initialized
DEBUG - 2020-07-04 13:23:16 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:23:16 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:23:16 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:23:16 --> Final output sent to browser
DEBUG - 2020-07-04 13:23:16 --> Total execution time: 0.0034
INFO - 2020-07-04 13:23:16 --> Config Class Initialized
INFO - 2020-07-04 13:23:16 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:23:16 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:23:16 --> Utf8 Class Initialized
INFO - 2020-07-04 13:23:16 --> URI Class Initialized
INFO - 2020-07-04 13:23:16 --> Router Class Initialized
INFO - 2020-07-04 13:23:16 --> Output Class Initialized
INFO - 2020-07-04 13:23:16 --> Security Class Initialized
DEBUG - 2020-07-04 13:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:23:16 --> Input Class Initialized
INFO - 2020-07-04 13:23:16 --> Language Class Initialized
INFO - 2020-07-04 13:23:16 --> Language Class Initialized
INFO - 2020-07-04 13:23:16 --> Config Class Initialized
INFO - 2020-07-04 13:23:16 --> Loader Class Initialized
INFO - 2020-07-04 13:23:16 --> Helper loaded: url_helper
INFO - 2020-07-04 13:23:16 --> Helper loaded: main_helper
INFO - 2020-07-04 13:23:16 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:23:16 --> Controller Class Initialized
INFO - 2020-07-04 13:23:16 --> Final output sent to browser
DEBUG - 2020-07-04 13:23:16 --> Total execution time: 0.0072
INFO - 2020-07-04 13:24:21 --> Config Class Initialized
INFO - 2020-07-04 13:24:21 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:24:21 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:24:21 --> Utf8 Class Initialized
INFO - 2020-07-04 13:24:21 --> URI Class Initialized
INFO - 2020-07-04 13:24:21 --> Router Class Initialized
INFO - 2020-07-04 13:24:21 --> Output Class Initialized
INFO - 2020-07-04 13:24:21 --> Security Class Initialized
DEBUG - 2020-07-04 13:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:24:21 --> Input Class Initialized
INFO - 2020-07-04 13:24:21 --> Language Class Initialized
INFO - 2020-07-04 13:24:21 --> Language Class Initialized
INFO - 2020-07-04 13:24:21 --> Config Class Initialized
INFO - 2020-07-04 13:24:21 --> Loader Class Initialized
INFO - 2020-07-04 13:24:21 --> Helper loaded: url_helper
INFO - 2020-07-04 13:24:21 --> Helper loaded: main_helper
INFO - 2020-07-04 13:24:21 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:24:21 --> Controller Class Initialized
DEBUG - 2020-07-04 13:24:21 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:24:21 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:24:21 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:24:21 --> Final output sent to browser
DEBUG - 2020-07-04 13:24:21 --> Total execution time: 0.0034
INFO - 2020-07-04 13:24:22 --> Config Class Initialized
INFO - 2020-07-04 13:24:22 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:24:22 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:24:22 --> Utf8 Class Initialized
INFO - 2020-07-04 13:24:22 --> URI Class Initialized
INFO - 2020-07-04 13:24:22 --> Router Class Initialized
INFO - 2020-07-04 13:24:22 --> Output Class Initialized
INFO - 2020-07-04 13:24:22 --> Security Class Initialized
DEBUG - 2020-07-04 13:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:24:22 --> Input Class Initialized
INFO - 2020-07-04 13:24:22 --> Language Class Initialized
INFO - 2020-07-04 13:24:22 --> Language Class Initialized
INFO - 2020-07-04 13:24:22 --> Config Class Initialized
INFO - 2020-07-04 13:24:22 --> Loader Class Initialized
INFO - 2020-07-04 13:24:22 --> Helper loaded: url_helper
INFO - 2020-07-04 13:24:22 --> Helper loaded: main_helper
INFO - 2020-07-04 13:24:22 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:24:22 --> Controller Class Initialized
INFO - 2020-07-04 13:24:22 --> Final output sent to browser
DEBUG - 2020-07-04 13:24:22 --> Total execution time: 0.0067
INFO - 2020-07-04 13:26:08 --> Config Class Initialized
INFO - 2020-07-04 13:26:08 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:26:08 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:26:08 --> Utf8 Class Initialized
INFO - 2020-07-04 13:26:08 --> URI Class Initialized
INFO - 2020-07-04 13:26:08 --> Router Class Initialized
INFO - 2020-07-04 13:26:08 --> Output Class Initialized
INFO - 2020-07-04 13:26:08 --> Security Class Initialized
DEBUG - 2020-07-04 13:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:26:08 --> Input Class Initialized
INFO - 2020-07-04 13:26:08 --> Language Class Initialized
INFO - 2020-07-04 13:26:08 --> Language Class Initialized
INFO - 2020-07-04 13:26:08 --> Config Class Initialized
INFO - 2020-07-04 13:26:08 --> Loader Class Initialized
INFO - 2020-07-04 13:26:08 --> Helper loaded: url_helper
INFO - 2020-07-04 13:26:08 --> Helper loaded: main_helper
INFO - 2020-07-04 13:26:08 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:26:08 --> Controller Class Initialized
DEBUG - 2020-07-04 13:26:08 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:26:08 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:26:08 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:26:08 --> Final output sent to browser
DEBUG - 2020-07-04 13:26:08 --> Total execution time: 0.0048
INFO - 2020-07-04 13:26:08 --> Config Class Initialized
INFO - 2020-07-04 13:26:08 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:26:08 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:26:08 --> Utf8 Class Initialized
INFO - 2020-07-04 13:26:08 --> URI Class Initialized
INFO - 2020-07-04 13:26:08 --> Router Class Initialized
INFO - 2020-07-04 13:26:08 --> Output Class Initialized
INFO - 2020-07-04 13:26:08 --> Security Class Initialized
DEBUG - 2020-07-04 13:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:26:08 --> Input Class Initialized
INFO - 2020-07-04 13:26:08 --> Language Class Initialized
INFO - 2020-07-04 13:26:08 --> Language Class Initialized
INFO - 2020-07-04 13:26:08 --> Config Class Initialized
INFO - 2020-07-04 13:26:08 --> Loader Class Initialized
INFO - 2020-07-04 13:26:08 --> Helper loaded: url_helper
INFO - 2020-07-04 13:26:08 --> Helper loaded: main_helper
INFO - 2020-07-04 13:26:08 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:26:08 --> Controller Class Initialized
INFO - 2020-07-04 13:26:08 --> Final output sent to browser
DEBUG - 2020-07-04 13:26:08 --> Total execution time: 0.0044
INFO - 2020-07-04 13:26:15 --> Config Class Initialized
INFO - 2020-07-04 13:26:15 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:26:15 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:26:15 --> Utf8 Class Initialized
INFO - 2020-07-04 13:26:15 --> URI Class Initialized
INFO - 2020-07-04 13:26:15 --> Router Class Initialized
INFO - 2020-07-04 13:26:15 --> Output Class Initialized
INFO - 2020-07-04 13:26:15 --> Security Class Initialized
DEBUG - 2020-07-04 13:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:26:15 --> Input Class Initialized
INFO - 2020-07-04 13:26:15 --> Language Class Initialized
INFO - 2020-07-04 13:26:15 --> Language Class Initialized
INFO - 2020-07-04 13:26:15 --> Config Class Initialized
INFO - 2020-07-04 13:26:15 --> Loader Class Initialized
INFO - 2020-07-04 13:26:15 --> Helper loaded: url_helper
INFO - 2020-07-04 13:26:15 --> Helper loaded: main_helper
INFO - 2020-07-04 13:26:15 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:26:15 --> Controller Class Initialized
DEBUG - 2020-07-04 13:26:15 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:26:15 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:26:15 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:26:15 --> Final output sent to browser
DEBUG - 2020-07-04 13:26:15 --> Total execution time: 0.0039
INFO - 2020-07-04 13:26:16 --> Config Class Initialized
INFO - 2020-07-04 13:26:16 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:26:16 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:26:16 --> Utf8 Class Initialized
INFO - 2020-07-04 13:26:16 --> URI Class Initialized
INFO - 2020-07-04 13:26:16 --> Router Class Initialized
INFO - 2020-07-04 13:26:16 --> Output Class Initialized
INFO - 2020-07-04 13:26:16 --> Security Class Initialized
DEBUG - 2020-07-04 13:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:26:16 --> Input Class Initialized
INFO - 2020-07-04 13:26:16 --> Language Class Initialized
INFO - 2020-07-04 13:26:16 --> Language Class Initialized
INFO - 2020-07-04 13:26:16 --> Config Class Initialized
INFO - 2020-07-04 13:26:16 --> Loader Class Initialized
INFO - 2020-07-04 13:26:16 --> Helper loaded: url_helper
INFO - 2020-07-04 13:26:16 --> Helper loaded: main_helper
INFO - 2020-07-04 13:26:16 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:26:16 --> Controller Class Initialized
INFO - 2020-07-04 13:26:16 --> Final output sent to browser
DEBUG - 2020-07-04 13:26:16 --> Total execution time: 0.0052
INFO - 2020-07-04 13:26:39 --> Config Class Initialized
INFO - 2020-07-04 13:26:39 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:26:39 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:26:39 --> Utf8 Class Initialized
INFO - 2020-07-04 13:26:39 --> URI Class Initialized
INFO - 2020-07-04 13:26:39 --> Router Class Initialized
INFO - 2020-07-04 13:26:39 --> Output Class Initialized
INFO - 2020-07-04 13:26:39 --> Security Class Initialized
DEBUG - 2020-07-04 13:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:26:39 --> Input Class Initialized
INFO - 2020-07-04 13:26:39 --> Language Class Initialized
INFO - 2020-07-04 13:26:39 --> Language Class Initialized
INFO - 2020-07-04 13:26:39 --> Config Class Initialized
INFO - 2020-07-04 13:26:39 --> Loader Class Initialized
INFO - 2020-07-04 13:26:39 --> Helper loaded: url_helper
INFO - 2020-07-04 13:26:39 --> Helper loaded: main_helper
INFO - 2020-07-04 13:26:39 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:26:39 --> Controller Class Initialized
DEBUG - 2020-07-04 13:26:39 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:26:39 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:26:39 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:26:39 --> Final output sent to browser
DEBUG - 2020-07-04 13:26:39 --> Total execution time: 0.0034
INFO - 2020-07-04 13:26:40 --> Config Class Initialized
INFO - 2020-07-04 13:26:40 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:26:40 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:26:40 --> Utf8 Class Initialized
INFO - 2020-07-04 13:26:40 --> URI Class Initialized
INFO - 2020-07-04 13:26:40 --> Router Class Initialized
INFO - 2020-07-04 13:26:40 --> Output Class Initialized
INFO - 2020-07-04 13:26:40 --> Security Class Initialized
DEBUG - 2020-07-04 13:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:26:40 --> Input Class Initialized
INFO - 2020-07-04 13:26:40 --> Language Class Initialized
INFO - 2020-07-04 13:26:40 --> Language Class Initialized
INFO - 2020-07-04 13:26:40 --> Config Class Initialized
INFO - 2020-07-04 13:26:40 --> Loader Class Initialized
INFO - 2020-07-04 13:26:40 --> Helper loaded: url_helper
INFO - 2020-07-04 13:26:40 --> Helper loaded: main_helper
INFO - 2020-07-04 13:26:40 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:26:40 --> Controller Class Initialized
INFO - 2020-07-04 13:26:40 --> Final output sent to browser
DEBUG - 2020-07-04 13:26:40 --> Total execution time: 0.0060
INFO - 2020-07-04 13:26:53 --> Config Class Initialized
INFO - 2020-07-04 13:26:53 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:26:53 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:26:53 --> Utf8 Class Initialized
INFO - 2020-07-04 13:26:53 --> URI Class Initialized
INFO - 2020-07-04 13:26:53 --> Router Class Initialized
INFO - 2020-07-04 13:26:53 --> Output Class Initialized
INFO - 2020-07-04 13:26:53 --> Security Class Initialized
DEBUG - 2020-07-04 13:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:26:53 --> Input Class Initialized
INFO - 2020-07-04 13:26:53 --> Language Class Initialized
INFO - 2020-07-04 13:26:53 --> Language Class Initialized
INFO - 2020-07-04 13:26:53 --> Config Class Initialized
INFO - 2020-07-04 13:26:53 --> Loader Class Initialized
INFO - 2020-07-04 13:26:53 --> Helper loaded: url_helper
INFO - 2020-07-04 13:26:53 --> Helper loaded: main_helper
INFO - 2020-07-04 13:26:53 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:26:53 --> Controller Class Initialized
DEBUG - 2020-07-04 13:26:53 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:26:53 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:26:53 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:26:53 --> Final output sent to browser
DEBUG - 2020-07-04 13:26:53 --> Total execution time: 0.0058
INFO - 2020-07-04 13:26:53 --> Config Class Initialized
INFO - 2020-07-04 13:26:53 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:26:53 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:26:53 --> Utf8 Class Initialized
INFO - 2020-07-04 13:26:53 --> URI Class Initialized
INFO - 2020-07-04 13:26:53 --> Router Class Initialized
INFO - 2020-07-04 13:26:53 --> Output Class Initialized
INFO - 2020-07-04 13:26:53 --> Security Class Initialized
DEBUG - 2020-07-04 13:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:26:53 --> Input Class Initialized
INFO - 2020-07-04 13:26:53 --> Language Class Initialized
INFO - 2020-07-04 13:26:53 --> Language Class Initialized
INFO - 2020-07-04 13:26:53 --> Config Class Initialized
INFO - 2020-07-04 13:26:53 --> Loader Class Initialized
INFO - 2020-07-04 13:26:53 --> Helper loaded: url_helper
INFO - 2020-07-04 13:26:53 --> Helper loaded: main_helper
INFO - 2020-07-04 13:26:53 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:26:53 --> Controller Class Initialized
INFO - 2020-07-04 13:26:53 --> Final output sent to browser
DEBUG - 2020-07-04 13:26:53 --> Total execution time: 0.0042
INFO - 2020-07-04 13:26:59 --> Config Class Initialized
INFO - 2020-07-04 13:26:59 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:26:59 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:26:59 --> Utf8 Class Initialized
INFO - 2020-07-04 13:26:59 --> URI Class Initialized
INFO - 2020-07-04 13:26:59 --> Router Class Initialized
INFO - 2020-07-04 13:26:59 --> Output Class Initialized
INFO - 2020-07-04 13:26:59 --> Security Class Initialized
DEBUG - 2020-07-04 13:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:26:59 --> Input Class Initialized
INFO - 2020-07-04 13:26:59 --> Language Class Initialized
INFO - 2020-07-04 13:26:59 --> Language Class Initialized
INFO - 2020-07-04 13:26:59 --> Config Class Initialized
INFO - 2020-07-04 13:26:59 --> Loader Class Initialized
INFO - 2020-07-04 13:26:59 --> Helper loaded: url_helper
INFO - 2020-07-04 13:26:59 --> Helper loaded: main_helper
INFO - 2020-07-04 13:26:59 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:26:59 --> Controller Class Initialized
DEBUG - 2020-07-04 13:26:59 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:26:59 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:26:59 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:26:59 --> Final output sent to browser
DEBUG - 2020-07-04 13:26:59 --> Total execution time: 0.0039
INFO - 2020-07-04 13:27:00 --> Config Class Initialized
INFO - 2020-07-04 13:27:00 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:27:00 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:27:00 --> Utf8 Class Initialized
INFO - 2020-07-04 13:27:00 --> URI Class Initialized
INFO - 2020-07-04 13:27:00 --> Router Class Initialized
INFO - 2020-07-04 13:27:00 --> Output Class Initialized
INFO - 2020-07-04 13:27:00 --> Security Class Initialized
DEBUG - 2020-07-04 13:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:27:00 --> Input Class Initialized
INFO - 2020-07-04 13:27:00 --> Language Class Initialized
INFO - 2020-07-04 13:27:00 --> Language Class Initialized
INFO - 2020-07-04 13:27:00 --> Config Class Initialized
INFO - 2020-07-04 13:27:00 --> Loader Class Initialized
INFO - 2020-07-04 13:27:00 --> Helper loaded: url_helper
INFO - 2020-07-04 13:27:00 --> Helper loaded: main_helper
INFO - 2020-07-04 13:27:00 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:27:00 --> Controller Class Initialized
INFO - 2020-07-04 13:27:00 --> Final output sent to browser
DEBUG - 2020-07-04 13:27:00 --> Total execution time: 0.0045
INFO - 2020-07-04 13:27:06 --> Config Class Initialized
INFO - 2020-07-04 13:27:06 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:27:06 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:27:06 --> Utf8 Class Initialized
INFO - 2020-07-04 13:27:06 --> URI Class Initialized
INFO - 2020-07-04 13:27:06 --> Router Class Initialized
INFO - 2020-07-04 13:27:06 --> Output Class Initialized
INFO - 2020-07-04 13:27:06 --> Security Class Initialized
DEBUG - 2020-07-04 13:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:27:06 --> Input Class Initialized
INFO - 2020-07-04 13:27:06 --> Language Class Initialized
INFO - 2020-07-04 13:27:06 --> Language Class Initialized
INFO - 2020-07-04 13:27:06 --> Config Class Initialized
INFO - 2020-07-04 13:27:06 --> Loader Class Initialized
INFO - 2020-07-04 13:27:06 --> Helper loaded: url_helper
INFO - 2020-07-04 13:27:06 --> Helper loaded: main_helper
INFO - 2020-07-04 13:27:06 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:27:06 --> Controller Class Initialized
DEBUG - 2020-07-04 13:27:06 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:27:06 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:27:06 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:27:06 --> Final output sent to browser
DEBUG - 2020-07-04 13:27:06 --> Total execution time: 0.0043
INFO - 2020-07-04 13:27:07 --> Config Class Initialized
INFO - 2020-07-04 13:27:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:27:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:27:07 --> Utf8 Class Initialized
INFO - 2020-07-04 13:27:07 --> URI Class Initialized
INFO - 2020-07-04 13:27:07 --> Router Class Initialized
INFO - 2020-07-04 13:27:07 --> Output Class Initialized
INFO - 2020-07-04 13:27:07 --> Security Class Initialized
DEBUG - 2020-07-04 13:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:27:07 --> Input Class Initialized
INFO - 2020-07-04 13:27:07 --> Language Class Initialized
INFO - 2020-07-04 13:27:07 --> Language Class Initialized
INFO - 2020-07-04 13:27:07 --> Config Class Initialized
INFO - 2020-07-04 13:27:07 --> Loader Class Initialized
INFO - 2020-07-04 13:27:07 --> Helper loaded: url_helper
INFO - 2020-07-04 13:27:07 --> Helper loaded: main_helper
INFO - 2020-07-04 13:27:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:27:07 --> Controller Class Initialized
INFO - 2020-07-04 13:27:07 --> Final output sent to browser
DEBUG - 2020-07-04 13:27:07 --> Total execution time: 0.0036
INFO - 2020-07-04 13:27:46 --> Config Class Initialized
INFO - 2020-07-04 13:27:46 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:27:46 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:27:46 --> Utf8 Class Initialized
INFO - 2020-07-04 13:27:46 --> URI Class Initialized
INFO - 2020-07-04 13:27:46 --> Router Class Initialized
INFO - 2020-07-04 13:27:46 --> Output Class Initialized
INFO - 2020-07-04 13:27:46 --> Security Class Initialized
DEBUG - 2020-07-04 13:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:27:46 --> Input Class Initialized
INFO - 2020-07-04 13:27:46 --> Language Class Initialized
INFO - 2020-07-04 13:27:46 --> Language Class Initialized
INFO - 2020-07-04 13:27:46 --> Config Class Initialized
INFO - 2020-07-04 13:27:46 --> Loader Class Initialized
INFO - 2020-07-04 13:27:46 --> Helper loaded: url_helper
INFO - 2020-07-04 13:27:46 --> Helper loaded: main_helper
INFO - 2020-07-04 13:27:46 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:27:46 --> Controller Class Initialized
DEBUG - 2020-07-04 13:27:46 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:27:46 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:27:46 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:27:46 --> Final output sent to browser
DEBUG - 2020-07-04 13:27:46 --> Total execution time: 0.0039
INFO - 2020-07-04 13:27:47 --> Config Class Initialized
INFO - 2020-07-04 13:27:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:27:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:27:47 --> Utf8 Class Initialized
INFO - 2020-07-04 13:27:47 --> URI Class Initialized
INFO - 2020-07-04 13:27:47 --> Router Class Initialized
INFO - 2020-07-04 13:27:47 --> Output Class Initialized
INFO - 2020-07-04 13:27:47 --> Security Class Initialized
DEBUG - 2020-07-04 13:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:27:47 --> Input Class Initialized
INFO - 2020-07-04 13:27:47 --> Language Class Initialized
INFO - 2020-07-04 13:27:47 --> Language Class Initialized
INFO - 2020-07-04 13:27:47 --> Config Class Initialized
INFO - 2020-07-04 13:27:47 --> Loader Class Initialized
INFO - 2020-07-04 13:27:47 --> Helper loaded: url_helper
INFO - 2020-07-04 13:27:47 --> Helper loaded: main_helper
INFO - 2020-07-04 13:27:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:27:47 --> Controller Class Initialized
INFO - 2020-07-04 13:27:47 --> Final output sent to browser
DEBUG - 2020-07-04 13:27:47 --> Total execution time: 0.0059
INFO - 2020-07-04 13:28:04 --> Config Class Initialized
INFO - 2020-07-04 13:28:04 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:28:04 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:28:04 --> Utf8 Class Initialized
INFO - 2020-07-04 13:28:04 --> URI Class Initialized
INFO - 2020-07-04 13:28:04 --> Router Class Initialized
INFO - 2020-07-04 13:28:04 --> Output Class Initialized
INFO - 2020-07-04 13:28:04 --> Security Class Initialized
DEBUG - 2020-07-04 13:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:28:04 --> Input Class Initialized
INFO - 2020-07-04 13:28:04 --> Language Class Initialized
INFO - 2020-07-04 13:28:04 --> Language Class Initialized
INFO - 2020-07-04 13:28:04 --> Config Class Initialized
INFO - 2020-07-04 13:28:04 --> Loader Class Initialized
INFO - 2020-07-04 13:28:04 --> Helper loaded: url_helper
INFO - 2020-07-04 13:28:04 --> Helper loaded: main_helper
INFO - 2020-07-04 13:28:04 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:28:04 --> Controller Class Initialized
DEBUG - 2020-07-04 13:28:04 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:28:04 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:28:04 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:28:04 --> Final output sent to browser
DEBUG - 2020-07-04 13:28:04 --> Total execution time: 0.0046
INFO - 2020-07-04 13:28:05 --> Config Class Initialized
INFO - 2020-07-04 13:28:05 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:28:05 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:28:05 --> Utf8 Class Initialized
INFO - 2020-07-04 13:28:05 --> URI Class Initialized
INFO - 2020-07-04 13:28:05 --> Router Class Initialized
INFO - 2020-07-04 13:28:05 --> Output Class Initialized
INFO - 2020-07-04 13:28:05 --> Security Class Initialized
DEBUG - 2020-07-04 13:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:28:05 --> Input Class Initialized
INFO - 2020-07-04 13:28:05 --> Language Class Initialized
INFO - 2020-07-04 13:28:05 --> Language Class Initialized
INFO - 2020-07-04 13:28:05 --> Config Class Initialized
INFO - 2020-07-04 13:28:05 --> Loader Class Initialized
INFO - 2020-07-04 13:28:05 --> Helper loaded: url_helper
INFO - 2020-07-04 13:28:05 --> Helper loaded: main_helper
INFO - 2020-07-04 13:28:05 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:28:05 --> Controller Class Initialized
INFO - 2020-07-04 13:28:05 --> Final output sent to browser
DEBUG - 2020-07-04 13:28:05 --> Total execution time: 0.0050
INFO - 2020-07-04 13:50:48 --> Config Class Initialized
INFO - 2020-07-04 13:50:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:50:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:50:48 --> Utf8 Class Initialized
INFO - 2020-07-04 13:50:48 --> URI Class Initialized
INFO - 2020-07-04 13:50:48 --> Router Class Initialized
INFO - 2020-07-04 13:50:48 --> Output Class Initialized
INFO - 2020-07-04 13:50:48 --> Security Class Initialized
DEBUG - 2020-07-04 13:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:50:48 --> Input Class Initialized
INFO - 2020-07-04 13:50:48 --> Language Class Initialized
INFO - 2020-07-04 13:50:48 --> Language Class Initialized
INFO - 2020-07-04 13:50:48 --> Config Class Initialized
INFO - 2020-07-04 13:50:48 --> Loader Class Initialized
INFO - 2020-07-04 13:50:48 --> Helper loaded: url_helper
INFO - 2020-07-04 13:50:48 --> Helper loaded: main_helper
INFO - 2020-07-04 13:50:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:50:48 --> Controller Class Initialized
DEBUG - 2020-07-04 13:50:48 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:50:48 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:50:48 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:50:48 --> Final output sent to browser
DEBUG - 2020-07-04 13:50:48 --> Total execution time: 0.0080
INFO - 2020-07-04 13:50:48 --> Config Class Initialized
INFO - 2020-07-04 13:50:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:50:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:50:48 --> Utf8 Class Initialized
INFO - 2020-07-04 13:50:48 --> URI Class Initialized
INFO - 2020-07-04 13:50:48 --> Router Class Initialized
INFO - 2020-07-04 13:50:48 --> Output Class Initialized
INFO - 2020-07-04 13:50:48 --> Security Class Initialized
DEBUG - 2020-07-04 13:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:50:48 --> Input Class Initialized
INFO - 2020-07-04 13:50:48 --> Language Class Initialized
INFO - 2020-07-04 13:50:48 --> Language Class Initialized
INFO - 2020-07-04 13:50:48 --> Config Class Initialized
INFO - 2020-07-04 13:50:48 --> Loader Class Initialized
INFO - 2020-07-04 13:50:48 --> Helper loaded: url_helper
INFO - 2020-07-04 13:50:48 --> Helper loaded: main_helper
INFO - 2020-07-04 13:50:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:50:48 --> Controller Class Initialized
INFO - 2020-07-04 13:50:48 --> Final output sent to browser
DEBUG - 2020-07-04 13:50:48 --> Total execution time: 0.0037
INFO - 2020-07-04 13:51:24 --> Config Class Initialized
INFO - 2020-07-04 13:51:24 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:51:24 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:51:24 --> Utf8 Class Initialized
INFO - 2020-07-04 13:51:24 --> URI Class Initialized
INFO - 2020-07-04 13:51:24 --> Router Class Initialized
INFO - 2020-07-04 13:51:24 --> Output Class Initialized
INFO - 2020-07-04 13:51:24 --> Security Class Initialized
DEBUG - 2020-07-04 13:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:51:24 --> Input Class Initialized
INFO - 2020-07-04 13:51:24 --> Language Class Initialized
INFO - 2020-07-04 13:51:24 --> Language Class Initialized
INFO - 2020-07-04 13:51:24 --> Config Class Initialized
INFO - 2020-07-04 13:51:24 --> Loader Class Initialized
INFO - 2020-07-04 13:51:24 --> Helper loaded: url_helper
INFO - 2020-07-04 13:51:24 --> Helper loaded: main_helper
INFO - 2020-07-04 13:51:24 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:51:24 --> Controller Class Initialized
DEBUG - 2020-07-04 13:51:24 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:51:24 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:51:24 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:51:24 --> Final output sent to browser
DEBUG - 2020-07-04 13:51:24 --> Total execution time: 0.0035
INFO - 2020-07-04 13:51:26 --> Config Class Initialized
INFO - 2020-07-04 13:51:26 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:51:26 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:51:26 --> Utf8 Class Initialized
INFO - 2020-07-04 13:51:26 --> URI Class Initialized
INFO - 2020-07-04 13:51:26 --> Router Class Initialized
INFO - 2020-07-04 13:51:26 --> Output Class Initialized
INFO - 2020-07-04 13:51:26 --> Security Class Initialized
DEBUG - 2020-07-04 13:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:51:26 --> Input Class Initialized
INFO - 2020-07-04 13:51:26 --> Language Class Initialized
INFO - 2020-07-04 13:51:26 --> Language Class Initialized
INFO - 2020-07-04 13:51:26 --> Config Class Initialized
INFO - 2020-07-04 13:51:26 --> Loader Class Initialized
INFO - 2020-07-04 13:51:26 --> Helper loaded: url_helper
INFO - 2020-07-04 13:51:26 --> Helper loaded: main_helper
INFO - 2020-07-04 13:51:26 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:51:26 --> Controller Class Initialized
DEBUG - 2020-07-04 13:51:26 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:51:26 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:51:26 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:51:26 --> Final output sent to browser
DEBUG - 2020-07-04 13:51:26 --> Total execution time: 0.0037
INFO - 2020-07-04 13:51:39 --> Config Class Initialized
INFO - 2020-07-04 13:51:39 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:51:39 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:51:39 --> Utf8 Class Initialized
INFO - 2020-07-04 13:51:39 --> URI Class Initialized
INFO - 2020-07-04 13:51:39 --> Router Class Initialized
INFO - 2020-07-04 13:51:39 --> Output Class Initialized
INFO - 2020-07-04 13:51:39 --> Security Class Initialized
DEBUG - 2020-07-04 13:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:51:39 --> Input Class Initialized
INFO - 2020-07-04 13:51:39 --> Language Class Initialized
INFO - 2020-07-04 13:51:39 --> Language Class Initialized
INFO - 2020-07-04 13:51:39 --> Config Class Initialized
INFO - 2020-07-04 13:51:39 --> Loader Class Initialized
INFO - 2020-07-04 13:51:39 --> Helper loaded: url_helper
INFO - 2020-07-04 13:51:39 --> Helper loaded: main_helper
INFO - 2020-07-04 13:51:39 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:51:39 --> Controller Class Initialized
DEBUG - 2020-07-04 13:51:39 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:51:39 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:51:39 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:51:39 --> Final output sent to browser
DEBUG - 2020-07-04 13:51:39 --> Total execution time: 0.0038
INFO - 2020-07-04 13:51:47 --> Config Class Initialized
INFO - 2020-07-04 13:51:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:51:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:51:47 --> Utf8 Class Initialized
INFO - 2020-07-04 13:51:47 --> URI Class Initialized
INFO - 2020-07-04 13:51:47 --> Router Class Initialized
INFO - 2020-07-04 13:51:47 --> Output Class Initialized
INFO - 2020-07-04 13:51:47 --> Security Class Initialized
DEBUG - 2020-07-04 13:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:51:47 --> Input Class Initialized
INFO - 2020-07-04 13:51:47 --> Language Class Initialized
INFO - 2020-07-04 13:51:47 --> Language Class Initialized
INFO - 2020-07-04 13:51:47 --> Config Class Initialized
INFO - 2020-07-04 13:51:47 --> Loader Class Initialized
INFO - 2020-07-04 13:51:47 --> Helper loaded: url_helper
INFO - 2020-07-04 13:51:47 --> Helper loaded: main_helper
INFO - 2020-07-04 13:51:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:51:47 --> Controller Class Initialized
DEBUG - 2020-07-04 13:51:47 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:51:47 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:51:47 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:51:47 --> Final output sent to browser
DEBUG - 2020-07-04 13:51:47 --> Total execution time: 0.0035
INFO - 2020-07-04 13:51:48 --> Config Class Initialized
INFO - 2020-07-04 13:51:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:51:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:51:48 --> Utf8 Class Initialized
INFO - 2020-07-04 13:51:48 --> URI Class Initialized
INFO - 2020-07-04 13:51:48 --> Router Class Initialized
INFO - 2020-07-04 13:51:48 --> Output Class Initialized
INFO - 2020-07-04 13:51:48 --> Security Class Initialized
DEBUG - 2020-07-04 13:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:51:48 --> Input Class Initialized
INFO - 2020-07-04 13:51:48 --> Language Class Initialized
INFO - 2020-07-04 13:51:48 --> Language Class Initialized
INFO - 2020-07-04 13:51:48 --> Config Class Initialized
INFO - 2020-07-04 13:51:48 --> Loader Class Initialized
INFO - 2020-07-04 13:51:48 --> Helper loaded: url_helper
INFO - 2020-07-04 13:51:48 --> Helper loaded: main_helper
INFO - 2020-07-04 13:51:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:51:48 --> Controller Class Initialized
INFO - 2020-07-04 13:51:48 --> Final output sent to browser
DEBUG - 2020-07-04 13:51:48 --> Total execution time: 0.0072
INFO - 2020-07-04 13:52:28 --> Config Class Initialized
INFO - 2020-07-04 13:52:28 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:52:28 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:52:28 --> Utf8 Class Initialized
INFO - 2020-07-04 13:52:28 --> URI Class Initialized
INFO - 2020-07-04 13:52:28 --> Router Class Initialized
INFO - 2020-07-04 13:52:28 --> Output Class Initialized
INFO - 2020-07-04 13:52:28 --> Security Class Initialized
DEBUG - 2020-07-04 13:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:52:28 --> Input Class Initialized
INFO - 2020-07-04 13:52:28 --> Language Class Initialized
INFO - 2020-07-04 13:52:28 --> Language Class Initialized
INFO - 2020-07-04 13:52:28 --> Config Class Initialized
INFO - 2020-07-04 13:52:28 --> Loader Class Initialized
INFO - 2020-07-04 13:52:28 --> Helper loaded: url_helper
INFO - 2020-07-04 13:52:28 --> Helper loaded: main_helper
INFO - 2020-07-04 13:52:28 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:52:28 --> Controller Class Initialized
DEBUG - 2020-07-04 13:52:28 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:52:28 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:52:28 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:52:28 --> Final output sent to browser
DEBUG - 2020-07-04 13:52:28 --> Total execution time: 0.0048
INFO - 2020-07-04 13:52:29 --> Config Class Initialized
INFO - 2020-07-04 13:52:29 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:52:29 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:52:29 --> Utf8 Class Initialized
INFO - 2020-07-04 13:52:29 --> URI Class Initialized
INFO - 2020-07-04 13:52:29 --> Router Class Initialized
INFO - 2020-07-04 13:52:29 --> Output Class Initialized
INFO - 2020-07-04 13:52:29 --> Security Class Initialized
DEBUG - 2020-07-04 13:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:52:29 --> Input Class Initialized
INFO - 2020-07-04 13:52:29 --> Language Class Initialized
INFO - 2020-07-04 13:52:29 --> Language Class Initialized
INFO - 2020-07-04 13:52:29 --> Config Class Initialized
INFO - 2020-07-04 13:52:29 --> Loader Class Initialized
INFO - 2020-07-04 13:52:29 --> Helper loaded: url_helper
INFO - 2020-07-04 13:52:29 --> Helper loaded: main_helper
INFO - 2020-07-04 13:52:29 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:52:29 --> Controller Class Initialized
INFO - 2020-07-04 13:52:29 --> Final output sent to browser
DEBUG - 2020-07-04 13:52:29 --> Total execution time: 0.0042
INFO - 2020-07-04 13:52:38 --> Config Class Initialized
INFO - 2020-07-04 13:52:38 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:52:38 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:52:38 --> Utf8 Class Initialized
INFO - 2020-07-04 13:52:38 --> URI Class Initialized
INFO - 2020-07-04 13:52:38 --> Router Class Initialized
INFO - 2020-07-04 13:52:38 --> Output Class Initialized
INFO - 2020-07-04 13:52:38 --> Security Class Initialized
DEBUG - 2020-07-04 13:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:52:38 --> Input Class Initialized
INFO - 2020-07-04 13:52:38 --> Language Class Initialized
INFO - 2020-07-04 13:52:38 --> Language Class Initialized
INFO - 2020-07-04 13:52:38 --> Config Class Initialized
INFO - 2020-07-04 13:52:38 --> Loader Class Initialized
INFO - 2020-07-04 13:52:38 --> Helper loaded: url_helper
INFO - 2020-07-04 13:52:38 --> Helper loaded: main_helper
INFO - 2020-07-04 13:52:38 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:52:38 --> Controller Class Initialized
DEBUG - 2020-07-04 13:52:38 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:52:38 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:52:38 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:52:38 --> Final output sent to browser
DEBUG - 2020-07-04 13:52:38 --> Total execution time: 0.0040
INFO - 2020-07-04 13:53:58 --> Config Class Initialized
INFO - 2020-07-04 13:53:58 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:53:58 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:53:58 --> Utf8 Class Initialized
INFO - 2020-07-04 13:53:58 --> URI Class Initialized
INFO - 2020-07-04 13:53:58 --> Router Class Initialized
INFO - 2020-07-04 13:53:58 --> Output Class Initialized
INFO - 2020-07-04 13:53:58 --> Security Class Initialized
DEBUG - 2020-07-04 13:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:53:58 --> Input Class Initialized
INFO - 2020-07-04 13:53:58 --> Language Class Initialized
INFO - 2020-07-04 13:53:58 --> Language Class Initialized
INFO - 2020-07-04 13:53:58 --> Config Class Initialized
INFO - 2020-07-04 13:53:58 --> Loader Class Initialized
INFO - 2020-07-04 13:53:58 --> Helper loaded: url_helper
INFO - 2020-07-04 13:53:58 --> Helper loaded: main_helper
INFO - 2020-07-04 13:53:58 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:53:58 --> Controller Class Initialized
DEBUG - 2020-07-04 13:53:58 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:53:58 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:53:58 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:53:58 --> Final output sent to browser
DEBUG - 2020-07-04 13:53:58 --> Total execution time: 0.0051
INFO - 2020-07-04 13:55:31 --> Config Class Initialized
INFO - 2020-07-04 13:55:31 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:55:31 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:55:31 --> Utf8 Class Initialized
INFO - 2020-07-04 13:55:31 --> URI Class Initialized
INFO - 2020-07-04 13:55:31 --> Router Class Initialized
INFO - 2020-07-04 13:55:31 --> Output Class Initialized
INFO - 2020-07-04 13:55:31 --> Security Class Initialized
DEBUG - 2020-07-04 13:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:55:31 --> Input Class Initialized
INFO - 2020-07-04 13:55:31 --> Language Class Initialized
INFO - 2020-07-04 13:55:31 --> Language Class Initialized
INFO - 2020-07-04 13:55:31 --> Config Class Initialized
INFO - 2020-07-04 13:55:31 --> Loader Class Initialized
INFO - 2020-07-04 13:55:31 --> Helper loaded: url_helper
INFO - 2020-07-04 13:55:31 --> Helper loaded: main_helper
INFO - 2020-07-04 13:55:31 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:55:31 --> Controller Class Initialized
DEBUG - 2020-07-04 13:55:31 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:55:31 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:55:31 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:55:31 --> Final output sent to browser
DEBUG - 2020-07-04 13:55:31 --> Total execution time: 0.0033
INFO - 2020-07-04 13:58:23 --> Config Class Initialized
INFO - 2020-07-04 13:58:23 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:58:23 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:58:23 --> Utf8 Class Initialized
INFO - 2020-07-04 13:58:23 --> URI Class Initialized
INFO - 2020-07-04 13:58:23 --> Router Class Initialized
INFO - 2020-07-04 13:58:23 --> Output Class Initialized
INFO - 2020-07-04 13:58:23 --> Security Class Initialized
DEBUG - 2020-07-04 13:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:58:23 --> Input Class Initialized
INFO - 2020-07-04 13:58:23 --> Language Class Initialized
INFO - 2020-07-04 13:58:23 --> Language Class Initialized
INFO - 2020-07-04 13:58:23 --> Config Class Initialized
INFO - 2020-07-04 13:58:23 --> Loader Class Initialized
INFO - 2020-07-04 13:58:23 --> Helper loaded: url_helper
INFO - 2020-07-04 13:58:23 --> Helper loaded: main_helper
INFO - 2020-07-04 13:58:23 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:58:23 --> Controller Class Initialized
DEBUG - 2020-07-04 13:58:23 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 13:58:23 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 13:58:23 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:58:23 --> Final output sent to browser
DEBUG - 2020-07-04 13:58:23 --> Total execution time: 0.0035
INFO - 2020-07-04 13:58:24 --> Config Class Initialized
INFO - 2020-07-04 13:58:24 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:58:24 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:58:24 --> Utf8 Class Initialized
INFO - 2020-07-04 13:58:24 --> URI Class Initialized
INFO - 2020-07-04 13:58:24 --> Router Class Initialized
INFO - 2020-07-04 13:58:24 --> Output Class Initialized
INFO - 2020-07-04 13:58:24 --> Security Class Initialized
DEBUG - 2020-07-04 13:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:58:24 --> Input Class Initialized
INFO - 2020-07-04 13:58:24 --> Language Class Initialized
INFO - 2020-07-04 13:58:24 --> Language Class Initialized
INFO - 2020-07-04 13:58:24 --> Config Class Initialized
INFO - 2020-07-04 13:58:24 --> Loader Class Initialized
INFO - 2020-07-04 13:58:24 --> Helper loaded: url_helper
INFO - 2020-07-04 13:58:24 --> Helper loaded: main_helper
INFO - 2020-07-04 13:58:24 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:58:24 --> Controller Class Initialized
INFO - 2020-07-04 13:58:24 --> Final output sent to browser
DEBUG - 2020-07-04 13:58:24 --> Total execution time: 0.0053
INFO - 2020-07-04 13:58:55 --> Config Class Initialized
INFO - 2020-07-04 13:58:55 --> Hooks Class Initialized
DEBUG - 2020-07-04 13:58:55 --> UTF-8 Support Enabled
INFO - 2020-07-04 13:58:55 --> Utf8 Class Initialized
INFO - 2020-07-04 13:58:55 --> URI Class Initialized
DEBUG - 2020-07-04 13:58:55 --> No URI present. Default controller set.
INFO - 2020-07-04 13:58:55 --> Router Class Initialized
INFO - 2020-07-04 13:58:55 --> Output Class Initialized
INFO - 2020-07-04 13:58:55 --> Security Class Initialized
DEBUG - 2020-07-04 13:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 13:58:55 --> Input Class Initialized
INFO - 2020-07-04 13:58:55 --> Language Class Initialized
INFO - 2020-07-04 13:58:55 --> Language Class Initialized
INFO - 2020-07-04 13:58:55 --> Config Class Initialized
INFO - 2020-07-04 13:58:55 --> Loader Class Initialized
INFO - 2020-07-04 13:58:55 --> Helper loaded: url_helper
INFO - 2020-07-04 13:58:55 --> Helper loaded: main_helper
INFO - 2020-07-04 13:58:55 --> Database Driver Class Initialized
DEBUG - 2020-07-04 13:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 13:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 13:58:55 --> Controller Class Initialized
DEBUG - 2020-07-04 13:58:55 --> File loaded: /var/www/journal/application/modules/template/views/landing_nav.php
DEBUG - 2020-07-04 13:58:55 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 13:58:55 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 13:58:55 --> Final output sent to browser
DEBUG - 2020-07-04 13:58:55 --> Total execution time: 0.0051
INFO - 2020-07-04 14:05:22 --> Config Class Initialized
INFO - 2020-07-04 14:05:22 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:05:22 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:05:22 --> Utf8 Class Initialized
INFO - 2020-07-04 14:05:22 --> URI Class Initialized
DEBUG - 2020-07-04 14:05:22 --> No URI present. Default controller set.
INFO - 2020-07-04 14:05:22 --> Router Class Initialized
INFO - 2020-07-04 14:05:22 --> Output Class Initialized
INFO - 2020-07-04 14:05:22 --> Security Class Initialized
DEBUG - 2020-07-04 14:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:05:22 --> Input Class Initialized
INFO - 2020-07-04 14:05:22 --> Language Class Initialized
INFO - 2020-07-04 14:05:22 --> Language Class Initialized
INFO - 2020-07-04 14:05:22 --> Config Class Initialized
INFO - 2020-07-04 14:05:22 --> Loader Class Initialized
INFO - 2020-07-04 14:05:22 --> Helper loaded: url_helper
INFO - 2020-07-04 14:05:22 --> Helper loaded: main_helper
INFO - 2020-07-04 14:05:22 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:05:22 --> Controller Class Initialized
DEBUG - 2020-07-04 14:05:22 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:05:22 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 14:05:22 --> Final output sent to browser
DEBUG - 2020-07-04 14:05:22 --> Total execution time: 0.0051
INFO - 2020-07-04 14:05:37 --> Config Class Initialized
INFO - 2020-07-04 14:05:37 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:05:37 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:05:37 --> Utf8 Class Initialized
INFO - 2020-07-04 14:05:37 --> URI Class Initialized
DEBUG - 2020-07-04 14:05:37 --> No URI present. Default controller set.
INFO - 2020-07-04 14:05:37 --> Router Class Initialized
INFO - 2020-07-04 14:05:37 --> Output Class Initialized
INFO - 2020-07-04 14:05:37 --> Security Class Initialized
DEBUG - 2020-07-04 14:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:05:37 --> Input Class Initialized
INFO - 2020-07-04 14:05:37 --> Language Class Initialized
INFO - 2020-07-04 14:05:37 --> Language Class Initialized
INFO - 2020-07-04 14:05:37 --> Config Class Initialized
INFO - 2020-07-04 14:05:37 --> Loader Class Initialized
INFO - 2020-07-04 14:05:37 --> Helper loaded: url_helper
INFO - 2020-07-04 14:05:37 --> Helper loaded: main_helper
INFO - 2020-07-04 14:05:37 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:05:37 --> Controller Class Initialized
DEBUG - 2020-07-04 14:05:37 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:05:37 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 14:05:37 --> Final output sent to browser
DEBUG - 2020-07-04 14:05:37 --> Total execution time: 0.0044
INFO - 2020-07-04 14:05:56 --> Config Class Initialized
INFO - 2020-07-04 14:05:56 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:05:56 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:05:56 --> Utf8 Class Initialized
INFO - 2020-07-04 14:05:56 --> URI Class Initialized
DEBUG - 2020-07-04 14:05:56 --> No URI present. Default controller set.
INFO - 2020-07-04 14:05:56 --> Router Class Initialized
INFO - 2020-07-04 14:05:56 --> Output Class Initialized
INFO - 2020-07-04 14:05:56 --> Security Class Initialized
DEBUG - 2020-07-04 14:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:05:56 --> Input Class Initialized
INFO - 2020-07-04 14:05:56 --> Language Class Initialized
INFO - 2020-07-04 14:05:56 --> Language Class Initialized
INFO - 2020-07-04 14:05:56 --> Config Class Initialized
INFO - 2020-07-04 14:05:56 --> Loader Class Initialized
INFO - 2020-07-04 14:05:56 --> Helper loaded: url_helper
INFO - 2020-07-04 14:05:56 --> Helper loaded: main_helper
INFO - 2020-07-04 14:05:56 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:05:56 --> Controller Class Initialized
DEBUG - 2020-07-04 14:05:56 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:05:56 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 14:05:56 --> Final output sent to browser
DEBUG - 2020-07-04 14:05:56 --> Total execution time: 0.0041
INFO - 2020-07-04 14:06:34 --> Config Class Initialized
INFO - 2020-07-04 14:06:34 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:06:34 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:06:34 --> Utf8 Class Initialized
INFO - 2020-07-04 14:06:34 --> URI Class Initialized
INFO - 2020-07-04 14:06:34 --> Router Class Initialized
INFO - 2020-07-04 14:06:34 --> Output Class Initialized
INFO - 2020-07-04 14:06:34 --> Security Class Initialized
DEBUG - 2020-07-04 14:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:06:34 --> Input Class Initialized
INFO - 2020-07-04 14:06:34 --> Language Class Initialized
INFO - 2020-07-04 14:06:34 --> Language Class Initialized
INFO - 2020-07-04 14:06:34 --> Config Class Initialized
INFO - 2020-07-04 14:06:34 --> Loader Class Initialized
INFO - 2020-07-04 14:06:34 --> Helper loaded: url_helper
INFO - 2020-07-04 14:06:34 --> Helper loaded: main_helper
INFO - 2020-07-04 14:06:34 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:06:34 --> Controller Class Initialized
DEBUG - 2020-07-04 14:06:34 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:06:34 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 14:06:34 --> Final output sent to browser
DEBUG - 2020-07-04 14:06:34 --> Total execution time: 0.0061
INFO - 2020-07-04 14:06:45 --> Config Class Initialized
INFO - 2020-07-04 14:06:45 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:06:45 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:06:45 --> Utf8 Class Initialized
INFO - 2020-07-04 14:06:45 --> URI Class Initialized
DEBUG - 2020-07-04 14:06:45 --> No URI present. Default controller set.
INFO - 2020-07-04 14:06:45 --> Router Class Initialized
INFO - 2020-07-04 14:06:45 --> Output Class Initialized
INFO - 2020-07-04 14:06:45 --> Security Class Initialized
DEBUG - 2020-07-04 14:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:06:45 --> Input Class Initialized
INFO - 2020-07-04 14:06:45 --> Language Class Initialized
INFO - 2020-07-04 14:06:45 --> Language Class Initialized
INFO - 2020-07-04 14:06:45 --> Config Class Initialized
INFO - 2020-07-04 14:06:45 --> Loader Class Initialized
INFO - 2020-07-04 14:06:45 --> Helper loaded: url_helper
INFO - 2020-07-04 14:06:45 --> Helper loaded: main_helper
INFO - 2020-07-04 14:06:45 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:06:45 --> Controller Class Initialized
DEBUG - 2020-07-04 14:06:45 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:06:45 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 14:06:45 --> Final output sent to browser
DEBUG - 2020-07-04 14:06:45 --> Total execution time: 0.0034
INFO - 2020-07-04 14:06:54 --> Config Class Initialized
INFO - 2020-07-04 14:06:54 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:06:54 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:06:54 --> Utf8 Class Initialized
INFO - 2020-07-04 14:06:54 --> URI Class Initialized
DEBUG - 2020-07-04 14:06:54 --> No URI present. Default controller set.
INFO - 2020-07-04 14:06:54 --> Router Class Initialized
INFO - 2020-07-04 14:06:54 --> Output Class Initialized
INFO - 2020-07-04 14:06:54 --> Security Class Initialized
DEBUG - 2020-07-04 14:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:06:54 --> Input Class Initialized
INFO - 2020-07-04 14:06:54 --> Language Class Initialized
INFO - 2020-07-04 14:06:54 --> Language Class Initialized
INFO - 2020-07-04 14:06:54 --> Config Class Initialized
INFO - 2020-07-04 14:06:54 --> Loader Class Initialized
INFO - 2020-07-04 14:06:54 --> Helper loaded: url_helper
INFO - 2020-07-04 14:06:54 --> Helper loaded: main_helper
INFO - 2020-07-04 14:06:54 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:06:54 --> Controller Class Initialized
DEBUG - 2020-07-04 14:06:54 --> File loaded: /var/www/journal/application/modules/template/views/landing_nav.php
DEBUG - 2020-07-04 14:06:54 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:06:54 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 14:06:54 --> Final output sent to browser
DEBUG - 2020-07-04 14:06:54 --> Total execution time: 0.0038
INFO - 2020-07-04 14:07:33 --> Config Class Initialized
INFO - 2020-07-04 14:07:33 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:07:33 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:07:33 --> Utf8 Class Initialized
INFO - 2020-07-04 14:07:33 --> URI Class Initialized
INFO - 2020-07-04 14:07:33 --> Router Class Initialized
INFO - 2020-07-04 14:07:33 --> Output Class Initialized
INFO - 2020-07-04 14:07:33 --> Security Class Initialized
DEBUG - 2020-07-04 14:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:07:33 --> Input Class Initialized
INFO - 2020-07-04 14:07:33 --> Language Class Initialized
INFO - 2020-07-04 14:07:33 --> Language Class Initialized
INFO - 2020-07-04 14:07:33 --> Config Class Initialized
INFO - 2020-07-04 14:07:33 --> Loader Class Initialized
INFO - 2020-07-04 14:07:33 --> Helper loaded: url_helper
INFO - 2020-07-04 14:07:33 --> Helper loaded: main_helper
INFO - 2020-07-04 14:07:33 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:07:33 --> Controller Class Initialized
DEBUG - 2020-07-04 14:07:33 --> File loaded: /var/www/journal/application/modules/template/views/nonlanding_nav.php
DEBUG - 2020-07-04 14:07:33 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:07:33 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 14:07:33 --> Final output sent to browser
DEBUG - 2020-07-04 14:07:33 --> Total execution time: 0.0058
INFO - 2020-07-04 14:07:33 --> Config Class Initialized
INFO - 2020-07-04 14:07:33 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:07:33 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:07:33 --> Utf8 Class Initialized
INFO - 2020-07-04 14:07:33 --> URI Class Initialized
INFO - 2020-07-04 14:07:33 --> Router Class Initialized
INFO - 2020-07-04 14:07:33 --> Output Class Initialized
INFO - 2020-07-04 14:07:33 --> Security Class Initialized
DEBUG - 2020-07-04 14:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:07:33 --> Input Class Initialized
INFO - 2020-07-04 14:07:33 --> Language Class Initialized
INFO - 2020-07-04 14:07:33 --> Language Class Initialized
INFO - 2020-07-04 14:07:33 --> Config Class Initialized
INFO - 2020-07-04 14:07:33 --> Loader Class Initialized
INFO - 2020-07-04 14:07:33 --> Helper loaded: url_helper
INFO - 2020-07-04 14:07:33 --> Helper loaded: main_helper
INFO - 2020-07-04 14:07:33 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:07:33 --> Controller Class Initialized
INFO - 2020-07-04 14:07:33 --> Final output sent to browser
DEBUG - 2020-07-04 14:07:33 --> Total execution time: 0.0044
INFO - 2020-07-04 14:11:34 --> Config Class Initialized
INFO - 2020-07-04 14:11:34 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:11:34 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:11:34 --> Utf8 Class Initialized
INFO - 2020-07-04 14:11:34 --> URI Class Initialized
DEBUG - 2020-07-04 14:11:34 --> No URI present. Default controller set.
INFO - 2020-07-04 14:11:34 --> Router Class Initialized
INFO - 2020-07-04 14:11:34 --> Output Class Initialized
INFO - 2020-07-04 14:11:34 --> Security Class Initialized
DEBUG - 2020-07-04 14:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:11:34 --> Input Class Initialized
INFO - 2020-07-04 14:11:34 --> Language Class Initialized
INFO - 2020-07-04 14:11:34 --> Language Class Initialized
INFO - 2020-07-04 14:11:34 --> Config Class Initialized
INFO - 2020-07-04 14:11:34 --> Loader Class Initialized
INFO - 2020-07-04 14:11:34 --> Helper loaded: url_helper
INFO - 2020-07-04 14:11:34 --> Helper loaded: main_helper
INFO - 2020-07-04 14:11:34 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:11:34 --> Controller Class Initialized
DEBUG - 2020-07-04 14:11:34 --> File loaded: /var/www/journal/application/modules/template/views/landing_nav.php
DEBUG - 2020-07-04 14:11:34 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:11:34 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 14:11:34 --> Final output sent to browser
DEBUG - 2020-07-04 14:11:34 --> Total execution time: 0.0061
INFO - 2020-07-04 14:15:13 --> Config Class Initialized
INFO - 2020-07-04 14:15:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:15:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:15:13 --> Utf8 Class Initialized
INFO - 2020-07-04 14:15:13 --> URI Class Initialized
DEBUG - 2020-07-04 14:15:13 --> No URI present. Default controller set.
INFO - 2020-07-04 14:15:13 --> Router Class Initialized
INFO - 2020-07-04 14:15:13 --> Output Class Initialized
INFO - 2020-07-04 14:15:13 --> Security Class Initialized
DEBUG - 2020-07-04 14:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:15:13 --> Input Class Initialized
INFO - 2020-07-04 14:15:13 --> Language Class Initialized
INFO - 2020-07-04 14:15:13 --> Language Class Initialized
INFO - 2020-07-04 14:15:13 --> Config Class Initialized
INFO - 2020-07-04 14:15:13 --> Loader Class Initialized
INFO - 2020-07-04 14:15:13 --> Helper loaded: url_helper
INFO - 2020-07-04 14:15:13 --> Helper loaded: main_helper
INFO - 2020-07-04 14:15:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:15:13 --> Controller Class Initialized
DEBUG - 2020-07-04 14:15:13 --> File loaded: /var/www/journal/application/modules/template/views/landing_nav.php
DEBUG - 2020-07-04 14:15:13 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:15:13 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 14:15:13 --> Final output sent to browser
DEBUG - 2020-07-04 14:15:13 --> Total execution time: 0.0063
INFO - 2020-07-04 14:15:17 --> Config Class Initialized
INFO - 2020-07-04 14:15:17 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:15:17 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:15:17 --> Utf8 Class Initialized
INFO - 2020-07-04 14:15:17 --> URI Class Initialized
INFO - 2020-07-04 14:15:17 --> Router Class Initialized
INFO - 2020-07-04 14:15:17 --> Output Class Initialized
INFO - 2020-07-04 14:15:17 --> Security Class Initialized
DEBUG - 2020-07-04 14:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:15:17 --> Input Class Initialized
INFO - 2020-07-04 14:15:17 --> Language Class Initialized
INFO - 2020-07-04 14:15:17 --> Language Class Initialized
INFO - 2020-07-04 14:15:17 --> Config Class Initialized
INFO - 2020-07-04 14:15:17 --> Loader Class Initialized
INFO - 2020-07-04 14:15:17 --> Helper loaded: url_helper
INFO - 2020-07-04 14:15:17 --> Helper loaded: main_helper
INFO - 2020-07-04 14:15:17 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:15:17 --> Controller Class Initialized
DEBUG - 2020-07-04 14:15:17 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:15:17 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:15:17 --> Final output sent to browser
DEBUG - 2020-07-04 14:15:17 --> Total execution time: 0.0058
INFO - 2020-07-04 14:15:55 --> Config Class Initialized
INFO - 2020-07-04 14:15:55 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:15:55 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:15:55 --> Utf8 Class Initialized
INFO - 2020-07-04 14:15:55 --> URI Class Initialized
INFO - 2020-07-04 14:15:55 --> Router Class Initialized
INFO - 2020-07-04 14:15:55 --> Output Class Initialized
INFO - 2020-07-04 14:15:55 --> Security Class Initialized
DEBUG - 2020-07-04 14:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:15:55 --> Input Class Initialized
INFO - 2020-07-04 14:15:55 --> Language Class Initialized
INFO - 2020-07-04 14:15:55 --> Language Class Initialized
INFO - 2020-07-04 14:15:55 --> Config Class Initialized
INFO - 2020-07-04 14:15:55 --> Loader Class Initialized
INFO - 2020-07-04 14:15:55 --> Helper loaded: url_helper
INFO - 2020-07-04 14:15:55 --> Helper loaded: main_helper
INFO - 2020-07-04 14:15:55 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:15:55 --> Controller Class Initialized
DEBUG - 2020-07-04 14:15:55 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:15:55 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:15:55 --> Final output sent to browser
DEBUG - 2020-07-04 14:15:55 --> Total execution time: 0.0032
INFO - 2020-07-04 14:18:41 --> Config Class Initialized
INFO - 2020-07-04 14:18:41 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:18:41 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:18:41 --> Utf8 Class Initialized
INFO - 2020-07-04 14:18:41 --> URI Class Initialized
INFO - 2020-07-04 14:18:41 --> Router Class Initialized
INFO - 2020-07-04 14:18:41 --> Output Class Initialized
INFO - 2020-07-04 14:18:41 --> Security Class Initialized
DEBUG - 2020-07-04 14:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:18:41 --> Input Class Initialized
INFO - 2020-07-04 14:18:41 --> Language Class Initialized
INFO - 2020-07-04 14:18:41 --> Language Class Initialized
INFO - 2020-07-04 14:18:41 --> Config Class Initialized
INFO - 2020-07-04 14:18:41 --> Loader Class Initialized
INFO - 2020-07-04 14:18:41 --> Helper loaded: url_helper
INFO - 2020-07-04 14:18:41 --> Helper loaded: main_helper
INFO - 2020-07-04 14:18:41 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:18:41 --> Controller Class Initialized
DEBUG - 2020-07-04 14:18:41 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:18:41 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:18:41 --> Final output sent to browser
DEBUG - 2020-07-04 14:18:41 --> Total execution time: 0.0045
INFO - 2020-07-04 14:21:09 --> Config Class Initialized
INFO - 2020-07-04 14:21:09 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:21:09 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:21:09 --> Utf8 Class Initialized
INFO - 2020-07-04 14:21:09 --> URI Class Initialized
INFO - 2020-07-04 14:21:09 --> Router Class Initialized
INFO - 2020-07-04 14:21:09 --> Output Class Initialized
INFO - 2020-07-04 14:21:09 --> Security Class Initialized
DEBUG - 2020-07-04 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:21:09 --> Input Class Initialized
INFO - 2020-07-04 14:21:09 --> Language Class Initialized
INFO - 2020-07-04 14:21:09 --> Language Class Initialized
INFO - 2020-07-04 14:21:09 --> Config Class Initialized
INFO - 2020-07-04 14:21:09 --> Loader Class Initialized
INFO - 2020-07-04 14:21:09 --> Helper loaded: url_helper
INFO - 2020-07-04 14:21:09 --> Helper loaded: main_helper
INFO - 2020-07-04 14:21:09 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:21:09 --> Controller Class Initialized
DEBUG - 2020-07-04 14:21:09 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:21:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:21:09 --> Final output sent to browser
DEBUG - 2020-07-04 14:21:09 --> Total execution time: 0.0048
INFO - 2020-07-04 14:21:24 --> Config Class Initialized
INFO - 2020-07-04 14:21:24 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:21:24 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:21:24 --> Utf8 Class Initialized
INFO - 2020-07-04 14:21:24 --> URI Class Initialized
INFO - 2020-07-04 14:21:24 --> Router Class Initialized
INFO - 2020-07-04 14:21:24 --> Output Class Initialized
INFO - 2020-07-04 14:21:24 --> Security Class Initialized
DEBUG - 2020-07-04 14:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:21:24 --> Input Class Initialized
INFO - 2020-07-04 14:21:24 --> Language Class Initialized
INFO - 2020-07-04 14:21:24 --> Language Class Initialized
INFO - 2020-07-04 14:21:24 --> Config Class Initialized
INFO - 2020-07-04 14:21:24 --> Loader Class Initialized
INFO - 2020-07-04 14:21:24 --> Helper loaded: url_helper
INFO - 2020-07-04 14:21:24 --> Helper loaded: main_helper
INFO - 2020-07-04 14:21:24 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:21:24 --> Controller Class Initialized
DEBUG - 2020-07-04 14:21:24 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:21:24 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:21:24 --> Final output sent to browser
DEBUG - 2020-07-04 14:21:24 --> Total execution time: 0.0032
INFO - 2020-07-04 14:23:47 --> Config Class Initialized
INFO - 2020-07-04 14:23:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:23:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:23:47 --> Utf8 Class Initialized
INFO - 2020-07-04 14:23:47 --> URI Class Initialized
INFO - 2020-07-04 14:23:47 --> Router Class Initialized
INFO - 2020-07-04 14:23:47 --> Output Class Initialized
INFO - 2020-07-04 14:23:47 --> Security Class Initialized
DEBUG - 2020-07-04 14:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:23:47 --> Input Class Initialized
INFO - 2020-07-04 14:23:47 --> Language Class Initialized
INFO - 2020-07-04 14:23:47 --> Language Class Initialized
INFO - 2020-07-04 14:23:47 --> Config Class Initialized
INFO - 2020-07-04 14:23:47 --> Loader Class Initialized
INFO - 2020-07-04 14:23:47 --> Helper loaded: url_helper
INFO - 2020-07-04 14:23:47 --> Helper loaded: main_helper
INFO - 2020-07-04 14:23:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:23:47 --> Controller Class Initialized
DEBUG - 2020-07-04 14:23:47 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:23:47 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:23:47 --> Final output sent to browser
DEBUG - 2020-07-04 14:23:47 --> Total execution time: 0.0042
INFO - 2020-07-04 14:24:03 --> Config Class Initialized
INFO - 2020-07-04 14:24:03 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:24:03 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:24:03 --> Utf8 Class Initialized
INFO - 2020-07-04 14:24:03 --> URI Class Initialized
INFO - 2020-07-04 14:24:03 --> Router Class Initialized
INFO - 2020-07-04 14:24:03 --> Output Class Initialized
INFO - 2020-07-04 14:24:03 --> Security Class Initialized
DEBUG - 2020-07-04 14:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:24:03 --> Input Class Initialized
INFO - 2020-07-04 14:24:03 --> Language Class Initialized
INFO - 2020-07-04 14:24:03 --> Language Class Initialized
INFO - 2020-07-04 14:24:03 --> Config Class Initialized
INFO - 2020-07-04 14:24:03 --> Loader Class Initialized
INFO - 2020-07-04 14:24:03 --> Helper loaded: url_helper
INFO - 2020-07-04 14:24:03 --> Helper loaded: main_helper
INFO - 2020-07-04 14:24:03 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:24:03 --> Controller Class Initialized
DEBUG - 2020-07-04 14:24:03 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:24:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:24:03 --> Final output sent to browser
DEBUG - 2020-07-04 14:24:03 --> Total execution time: 0.0033
INFO - 2020-07-04 14:25:25 --> Config Class Initialized
INFO - 2020-07-04 14:25:25 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:25:25 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:25:25 --> Utf8 Class Initialized
INFO - 2020-07-04 14:25:25 --> URI Class Initialized
INFO - 2020-07-04 14:25:25 --> Router Class Initialized
INFO - 2020-07-04 14:25:25 --> Output Class Initialized
INFO - 2020-07-04 14:25:25 --> Security Class Initialized
DEBUG - 2020-07-04 14:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:25:25 --> Input Class Initialized
INFO - 2020-07-04 14:25:25 --> Language Class Initialized
INFO - 2020-07-04 14:25:25 --> Language Class Initialized
INFO - 2020-07-04 14:25:25 --> Config Class Initialized
INFO - 2020-07-04 14:25:25 --> Loader Class Initialized
INFO - 2020-07-04 14:25:25 --> Helper loaded: url_helper
INFO - 2020-07-04 14:25:25 --> Helper loaded: main_helper
INFO - 2020-07-04 14:25:25 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:25:25 --> Controller Class Initialized
DEBUG - 2020-07-04 14:25:25 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:25:25 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:25:25 --> Final output sent to browser
DEBUG - 2020-07-04 14:25:25 --> Total execution time: 0.0060
INFO - 2020-07-04 14:25:49 --> Config Class Initialized
INFO - 2020-07-04 14:25:49 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:25:49 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:25:49 --> Utf8 Class Initialized
INFO - 2020-07-04 14:25:49 --> URI Class Initialized
INFO - 2020-07-04 14:25:49 --> Router Class Initialized
INFO - 2020-07-04 14:25:49 --> Output Class Initialized
INFO - 2020-07-04 14:25:49 --> Security Class Initialized
DEBUG - 2020-07-04 14:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:25:49 --> Input Class Initialized
INFO - 2020-07-04 14:25:49 --> Language Class Initialized
INFO - 2020-07-04 14:25:49 --> Language Class Initialized
INFO - 2020-07-04 14:25:49 --> Config Class Initialized
INFO - 2020-07-04 14:25:49 --> Loader Class Initialized
INFO - 2020-07-04 14:25:49 --> Helper loaded: url_helper
INFO - 2020-07-04 14:25:49 --> Helper loaded: main_helper
INFO - 2020-07-04 14:25:49 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:25:49 --> Controller Class Initialized
DEBUG - 2020-07-04 14:25:49 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:25:49 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:25:49 --> Final output sent to browser
DEBUG - 2020-07-04 14:25:49 --> Total execution time: 0.0037
INFO - 2020-07-04 14:26:56 --> Config Class Initialized
INFO - 2020-07-04 14:26:56 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:26:56 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:26:56 --> Utf8 Class Initialized
INFO - 2020-07-04 14:26:56 --> URI Class Initialized
INFO - 2020-07-04 14:26:56 --> Router Class Initialized
INFO - 2020-07-04 14:26:56 --> Output Class Initialized
INFO - 2020-07-04 14:26:56 --> Security Class Initialized
DEBUG - 2020-07-04 14:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:26:56 --> Input Class Initialized
INFO - 2020-07-04 14:26:56 --> Language Class Initialized
INFO - 2020-07-04 14:26:56 --> Language Class Initialized
INFO - 2020-07-04 14:26:56 --> Config Class Initialized
INFO - 2020-07-04 14:26:56 --> Loader Class Initialized
INFO - 2020-07-04 14:26:56 --> Helper loaded: url_helper
INFO - 2020-07-04 14:26:56 --> Helper loaded: main_helper
INFO - 2020-07-04 14:26:56 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:26:56 --> Controller Class Initialized
DEBUG - 2020-07-04 14:26:56 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:26:56 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:26:56 --> Final output sent to browser
DEBUG - 2020-07-04 14:26:56 --> Total execution time: 0.0035
INFO - 2020-07-04 14:28:47 --> Config Class Initialized
INFO - 2020-07-04 14:28:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:28:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:28:47 --> Utf8 Class Initialized
INFO - 2020-07-04 14:28:47 --> URI Class Initialized
INFO - 2020-07-04 14:28:47 --> Router Class Initialized
INFO - 2020-07-04 14:28:47 --> Output Class Initialized
INFO - 2020-07-04 14:28:47 --> Security Class Initialized
DEBUG - 2020-07-04 14:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:28:47 --> Input Class Initialized
INFO - 2020-07-04 14:28:47 --> Language Class Initialized
INFO - 2020-07-04 14:28:47 --> Language Class Initialized
INFO - 2020-07-04 14:28:47 --> Config Class Initialized
INFO - 2020-07-04 14:28:47 --> Loader Class Initialized
INFO - 2020-07-04 14:28:47 --> Helper loaded: url_helper
INFO - 2020-07-04 14:28:47 --> Helper loaded: main_helper
INFO - 2020-07-04 14:28:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:28:47 --> Controller Class Initialized
DEBUG - 2020-07-04 14:28:47 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:28:47 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:28:47 --> Final output sent to browser
DEBUG - 2020-07-04 14:28:47 --> Total execution time: 0.0038
INFO - 2020-07-04 14:28:48 --> Config Class Initialized
INFO - 2020-07-04 14:28:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:28:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:28:48 --> Utf8 Class Initialized
INFO - 2020-07-04 14:28:48 --> URI Class Initialized
INFO - 2020-07-04 14:28:48 --> Router Class Initialized
INFO - 2020-07-04 14:28:48 --> Output Class Initialized
INFO - 2020-07-04 14:28:48 --> Security Class Initialized
DEBUG - 2020-07-04 14:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:28:48 --> Input Class Initialized
INFO - 2020-07-04 14:28:48 --> Language Class Initialized
INFO - 2020-07-04 14:28:48 --> Language Class Initialized
INFO - 2020-07-04 14:28:48 --> Config Class Initialized
INFO - 2020-07-04 14:28:48 --> Loader Class Initialized
INFO - 2020-07-04 14:28:48 --> Helper loaded: url_helper
INFO - 2020-07-04 14:28:48 --> Helper loaded: main_helper
INFO - 2020-07-04 14:28:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:28:48 --> Controller Class Initialized
INFO - 2020-07-04 14:28:48 --> Final output sent to browser
DEBUG - 2020-07-04 14:28:48 --> Total execution time: 0.0062
INFO - 2020-07-04 14:30:13 --> Config Class Initialized
INFO - 2020-07-04 14:30:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:30:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:30:13 --> Utf8 Class Initialized
INFO - 2020-07-04 14:30:13 --> URI Class Initialized
INFO - 2020-07-04 14:30:13 --> Router Class Initialized
INFO - 2020-07-04 14:30:13 --> Output Class Initialized
INFO - 2020-07-04 14:30:13 --> Security Class Initialized
DEBUG - 2020-07-04 14:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:30:13 --> Input Class Initialized
INFO - 2020-07-04 14:30:13 --> Language Class Initialized
INFO - 2020-07-04 14:30:13 --> Language Class Initialized
INFO - 2020-07-04 14:30:13 --> Config Class Initialized
INFO - 2020-07-04 14:30:13 --> Loader Class Initialized
INFO - 2020-07-04 14:30:13 --> Helper loaded: url_helper
INFO - 2020-07-04 14:30:13 --> Helper loaded: main_helper
INFO - 2020-07-04 14:30:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:30:13 --> Controller Class Initialized
DEBUG - 2020-07-04 14:30:13 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:30:13 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:30:13 --> Final output sent to browser
DEBUG - 2020-07-04 14:30:13 --> Total execution time: 0.0060
INFO - 2020-07-04 14:30:14 --> Config Class Initialized
INFO - 2020-07-04 14:30:14 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:30:14 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:30:14 --> Utf8 Class Initialized
INFO - 2020-07-04 14:30:14 --> URI Class Initialized
INFO - 2020-07-04 14:30:14 --> Router Class Initialized
INFO - 2020-07-04 14:30:14 --> Output Class Initialized
INFO - 2020-07-04 14:30:14 --> Security Class Initialized
DEBUG - 2020-07-04 14:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:30:14 --> Input Class Initialized
INFO - 2020-07-04 14:30:14 --> Language Class Initialized
INFO - 2020-07-04 14:30:14 --> Language Class Initialized
INFO - 2020-07-04 14:30:14 --> Config Class Initialized
INFO - 2020-07-04 14:30:14 --> Loader Class Initialized
INFO - 2020-07-04 14:30:14 --> Helper loaded: url_helper
INFO - 2020-07-04 14:30:14 --> Helper loaded: main_helper
INFO - 2020-07-04 14:30:14 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:30:14 --> Controller Class Initialized
INFO - 2020-07-04 14:30:14 --> Final output sent to browser
DEBUG - 2020-07-04 14:30:14 --> Total execution time: 0.0062
INFO - 2020-07-04 14:31:12 --> Config Class Initialized
INFO - 2020-07-04 14:31:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:31:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:31:12 --> Utf8 Class Initialized
INFO - 2020-07-04 14:31:12 --> URI Class Initialized
INFO - 2020-07-04 14:31:12 --> Router Class Initialized
INFO - 2020-07-04 14:31:12 --> Output Class Initialized
INFO - 2020-07-04 14:31:12 --> Security Class Initialized
DEBUG - 2020-07-04 14:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:31:12 --> Input Class Initialized
INFO - 2020-07-04 14:31:12 --> Language Class Initialized
INFO - 2020-07-04 14:31:12 --> Language Class Initialized
INFO - 2020-07-04 14:31:12 --> Config Class Initialized
INFO - 2020-07-04 14:31:12 --> Loader Class Initialized
INFO - 2020-07-04 14:31:12 --> Helper loaded: url_helper
INFO - 2020-07-04 14:31:12 --> Helper loaded: main_helper
INFO - 2020-07-04 14:31:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:31:12 --> Controller Class Initialized
DEBUG - 2020-07-04 14:31:12 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:31:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:31:12 --> Final output sent to browser
DEBUG - 2020-07-04 14:31:12 --> Total execution time: 0.0054
INFO - 2020-07-04 14:31:13 --> Config Class Initialized
INFO - 2020-07-04 14:31:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:31:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:31:13 --> Utf8 Class Initialized
INFO - 2020-07-04 14:31:13 --> URI Class Initialized
INFO - 2020-07-04 14:31:13 --> Router Class Initialized
INFO - 2020-07-04 14:31:13 --> Output Class Initialized
INFO - 2020-07-04 14:31:13 --> Security Class Initialized
DEBUG - 2020-07-04 14:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:31:13 --> Input Class Initialized
INFO - 2020-07-04 14:31:13 --> Language Class Initialized
INFO - 2020-07-04 14:31:13 --> Language Class Initialized
INFO - 2020-07-04 14:31:13 --> Config Class Initialized
INFO - 2020-07-04 14:31:13 --> Loader Class Initialized
INFO - 2020-07-04 14:31:13 --> Helper loaded: url_helper
INFO - 2020-07-04 14:31:13 --> Helper loaded: main_helper
INFO - 2020-07-04 14:31:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:31:13 --> Controller Class Initialized
INFO - 2020-07-04 14:31:13 --> Final output sent to browser
DEBUG - 2020-07-04 14:31:13 --> Total execution time: 0.0052
INFO - 2020-07-04 14:32:03 --> Config Class Initialized
INFO - 2020-07-04 14:32:03 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:32:03 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:32:03 --> Utf8 Class Initialized
INFO - 2020-07-04 14:32:03 --> URI Class Initialized
INFO - 2020-07-04 14:32:03 --> Router Class Initialized
INFO - 2020-07-04 14:32:03 --> Output Class Initialized
INFO - 2020-07-04 14:32:03 --> Security Class Initialized
DEBUG - 2020-07-04 14:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:32:03 --> Input Class Initialized
INFO - 2020-07-04 14:32:03 --> Language Class Initialized
INFO - 2020-07-04 14:32:03 --> Language Class Initialized
INFO - 2020-07-04 14:32:03 --> Config Class Initialized
INFO - 2020-07-04 14:32:03 --> Loader Class Initialized
INFO - 2020-07-04 14:32:03 --> Helper loaded: url_helper
INFO - 2020-07-04 14:32:03 --> Helper loaded: main_helper
INFO - 2020-07-04 14:32:03 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:32:03 --> Controller Class Initialized
DEBUG - 2020-07-04 14:32:03 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:32:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:32:03 --> Final output sent to browser
DEBUG - 2020-07-04 14:32:03 --> Total execution time: 0.0039
INFO - 2020-07-04 14:32:16 --> Config Class Initialized
INFO - 2020-07-04 14:32:16 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:32:16 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:32:16 --> Utf8 Class Initialized
INFO - 2020-07-04 14:32:16 --> URI Class Initialized
INFO - 2020-07-04 14:32:16 --> Router Class Initialized
INFO - 2020-07-04 14:32:16 --> Output Class Initialized
INFO - 2020-07-04 14:32:16 --> Security Class Initialized
DEBUG - 2020-07-04 14:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:32:16 --> Input Class Initialized
INFO - 2020-07-04 14:32:16 --> Language Class Initialized
INFO - 2020-07-04 14:32:16 --> Language Class Initialized
INFO - 2020-07-04 14:32:16 --> Config Class Initialized
INFO - 2020-07-04 14:32:16 --> Loader Class Initialized
INFO - 2020-07-04 14:32:16 --> Helper loaded: url_helper
INFO - 2020-07-04 14:32:16 --> Helper loaded: main_helper
INFO - 2020-07-04 14:32:16 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:32:16 --> Controller Class Initialized
DEBUG - 2020-07-04 14:32:16 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:32:16 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:32:16 --> Final output sent to browser
DEBUG - 2020-07-04 14:32:16 --> Total execution time: 0.0046
INFO - 2020-07-04 14:32:17 --> Config Class Initialized
INFO - 2020-07-04 14:32:17 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:32:17 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:32:17 --> Utf8 Class Initialized
INFO - 2020-07-04 14:32:17 --> URI Class Initialized
INFO - 2020-07-04 14:32:17 --> Router Class Initialized
INFO - 2020-07-04 14:32:17 --> Output Class Initialized
INFO - 2020-07-04 14:32:17 --> Security Class Initialized
DEBUG - 2020-07-04 14:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:32:17 --> Input Class Initialized
INFO - 2020-07-04 14:32:17 --> Language Class Initialized
INFO - 2020-07-04 14:32:17 --> Language Class Initialized
INFO - 2020-07-04 14:32:17 --> Config Class Initialized
INFO - 2020-07-04 14:32:17 --> Loader Class Initialized
INFO - 2020-07-04 14:32:17 --> Helper loaded: url_helper
INFO - 2020-07-04 14:32:17 --> Helper loaded: main_helper
INFO - 2020-07-04 14:32:17 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:32:17 --> Controller Class Initialized
INFO - 2020-07-04 14:32:17 --> Final output sent to browser
DEBUG - 2020-07-04 14:32:17 --> Total execution time: 0.0070
INFO - 2020-07-04 14:32:51 --> Config Class Initialized
INFO - 2020-07-04 14:32:51 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:32:51 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:32:51 --> Utf8 Class Initialized
INFO - 2020-07-04 14:32:51 --> URI Class Initialized
INFO - 2020-07-04 14:32:51 --> Router Class Initialized
INFO - 2020-07-04 14:32:51 --> Output Class Initialized
INFO - 2020-07-04 14:32:51 --> Security Class Initialized
DEBUG - 2020-07-04 14:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:32:51 --> Input Class Initialized
INFO - 2020-07-04 14:32:51 --> Language Class Initialized
INFO - 2020-07-04 14:32:51 --> Language Class Initialized
INFO - 2020-07-04 14:32:51 --> Config Class Initialized
INFO - 2020-07-04 14:32:51 --> Loader Class Initialized
INFO - 2020-07-04 14:32:51 --> Helper loaded: url_helper
INFO - 2020-07-04 14:32:51 --> Helper loaded: main_helper
INFO - 2020-07-04 14:32:51 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:32:51 --> Controller Class Initialized
DEBUG - 2020-07-04 14:32:51 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:32:51 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:32:51 --> Final output sent to browser
DEBUG - 2020-07-04 14:32:51 --> Total execution time: 0.0034
INFO - 2020-07-04 14:32:52 --> Config Class Initialized
INFO - 2020-07-04 14:32:52 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:32:52 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:32:52 --> Utf8 Class Initialized
INFO - 2020-07-04 14:32:52 --> URI Class Initialized
INFO - 2020-07-04 14:32:52 --> Router Class Initialized
INFO - 2020-07-04 14:32:52 --> Output Class Initialized
INFO - 2020-07-04 14:32:52 --> Security Class Initialized
DEBUG - 2020-07-04 14:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:32:52 --> Input Class Initialized
INFO - 2020-07-04 14:32:52 --> Language Class Initialized
INFO - 2020-07-04 14:32:52 --> Language Class Initialized
INFO - 2020-07-04 14:32:52 --> Config Class Initialized
INFO - 2020-07-04 14:32:52 --> Loader Class Initialized
INFO - 2020-07-04 14:32:52 --> Helper loaded: url_helper
INFO - 2020-07-04 14:32:52 --> Helper loaded: main_helper
INFO - 2020-07-04 14:32:52 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:32:52 --> Controller Class Initialized
INFO - 2020-07-04 14:32:52 --> Final output sent to browser
DEBUG - 2020-07-04 14:32:52 --> Total execution time: 0.0065
INFO - 2020-07-04 14:33:03 --> Config Class Initialized
INFO - 2020-07-04 14:33:03 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:33:03 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:33:03 --> Utf8 Class Initialized
INFO - 2020-07-04 14:33:03 --> URI Class Initialized
INFO - 2020-07-04 14:33:03 --> Router Class Initialized
INFO - 2020-07-04 14:33:03 --> Output Class Initialized
INFO - 2020-07-04 14:33:03 --> Security Class Initialized
DEBUG - 2020-07-04 14:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:33:03 --> Input Class Initialized
INFO - 2020-07-04 14:33:03 --> Language Class Initialized
INFO - 2020-07-04 14:33:03 --> Language Class Initialized
INFO - 2020-07-04 14:33:03 --> Config Class Initialized
INFO - 2020-07-04 14:33:03 --> Loader Class Initialized
INFO - 2020-07-04 14:33:03 --> Helper loaded: url_helper
INFO - 2020-07-04 14:33:03 --> Helper loaded: main_helper
INFO - 2020-07-04 14:33:03 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:33:03 --> Controller Class Initialized
DEBUG - 2020-07-04 14:33:03 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:33:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:33:03 --> Final output sent to browser
DEBUG - 2020-07-04 14:33:03 --> Total execution time: 0.0036
INFO - 2020-07-04 14:33:04 --> Config Class Initialized
INFO - 2020-07-04 14:33:04 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:33:04 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:33:04 --> Utf8 Class Initialized
INFO - 2020-07-04 14:33:04 --> URI Class Initialized
INFO - 2020-07-04 14:33:04 --> Router Class Initialized
INFO - 2020-07-04 14:33:04 --> Output Class Initialized
INFO - 2020-07-04 14:33:04 --> Security Class Initialized
DEBUG - 2020-07-04 14:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:33:04 --> Input Class Initialized
INFO - 2020-07-04 14:33:04 --> Language Class Initialized
INFO - 2020-07-04 14:33:04 --> Language Class Initialized
INFO - 2020-07-04 14:33:04 --> Config Class Initialized
INFO - 2020-07-04 14:33:04 --> Loader Class Initialized
INFO - 2020-07-04 14:33:04 --> Helper loaded: url_helper
INFO - 2020-07-04 14:33:04 --> Helper loaded: main_helper
INFO - 2020-07-04 14:33:04 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:33:04 --> Controller Class Initialized
INFO - 2020-07-04 14:33:04 --> Final output sent to browser
DEBUG - 2020-07-04 14:33:04 --> Total execution time: 0.0056
INFO - 2020-07-04 14:33:16 --> Config Class Initialized
INFO - 2020-07-04 14:33:16 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:33:16 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:33:16 --> Utf8 Class Initialized
INFO - 2020-07-04 14:33:16 --> URI Class Initialized
INFO - 2020-07-04 14:33:16 --> Router Class Initialized
INFO - 2020-07-04 14:33:16 --> Output Class Initialized
INFO - 2020-07-04 14:33:16 --> Security Class Initialized
DEBUG - 2020-07-04 14:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:33:16 --> Input Class Initialized
INFO - 2020-07-04 14:33:16 --> Language Class Initialized
INFO - 2020-07-04 14:33:16 --> Language Class Initialized
INFO - 2020-07-04 14:33:16 --> Config Class Initialized
INFO - 2020-07-04 14:33:16 --> Loader Class Initialized
INFO - 2020-07-04 14:33:16 --> Helper loaded: url_helper
INFO - 2020-07-04 14:33:16 --> Helper loaded: main_helper
INFO - 2020-07-04 14:33:16 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:33:16 --> Controller Class Initialized
DEBUG - 2020-07-04 14:33:16 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:33:16 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:33:16 --> Final output sent to browser
DEBUG - 2020-07-04 14:33:16 --> Total execution time: 0.0039
INFO - 2020-07-04 14:33:16 --> Config Class Initialized
INFO - 2020-07-04 14:33:16 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:33:16 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:33:16 --> Utf8 Class Initialized
INFO - 2020-07-04 14:33:16 --> URI Class Initialized
INFO - 2020-07-04 14:33:16 --> Router Class Initialized
INFO - 2020-07-04 14:33:16 --> Output Class Initialized
INFO - 2020-07-04 14:33:16 --> Security Class Initialized
DEBUG - 2020-07-04 14:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:33:16 --> Input Class Initialized
INFO - 2020-07-04 14:33:16 --> Language Class Initialized
INFO - 2020-07-04 14:33:16 --> Language Class Initialized
INFO - 2020-07-04 14:33:16 --> Config Class Initialized
INFO - 2020-07-04 14:33:16 --> Loader Class Initialized
INFO - 2020-07-04 14:33:16 --> Helper loaded: url_helper
INFO - 2020-07-04 14:33:16 --> Helper loaded: main_helper
INFO - 2020-07-04 14:33:16 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:33:16 --> Controller Class Initialized
INFO - 2020-07-04 14:33:16 --> Final output sent to browser
DEBUG - 2020-07-04 14:33:16 --> Total execution time: 0.0086
INFO - 2020-07-04 14:34:01 --> Config Class Initialized
INFO - 2020-07-04 14:34:01 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:34:01 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:34:01 --> Utf8 Class Initialized
INFO - 2020-07-04 14:34:01 --> URI Class Initialized
INFO - 2020-07-04 14:34:01 --> Router Class Initialized
INFO - 2020-07-04 14:34:01 --> Output Class Initialized
INFO - 2020-07-04 14:34:01 --> Security Class Initialized
DEBUG - 2020-07-04 14:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:34:01 --> Input Class Initialized
INFO - 2020-07-04 14:34:01 --> Language Class Initialized
INFO - 2020-07-04 14:34:01 --> Language Class Initialized
INFO - 2020-07-04 14:34:01 --> Config Class Initialized
INFO - 2020-07-04 14:34:01 --> Loader Class Initialized
INFO - 2020-07-04 14:34:01 --> Helper loaded: url_helper
INFO - 2020-07-04 14:34:01 --> Helper loaded: main_helper
INFO - 2020-07-04 14:34:01 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:34:01 --> Controller Class Initialized
DEBUG - 2020-07-04 14:34:01 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:34:01 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:34:01 --> Final output sent to browser
DEBUG - 2020-07-04 14:34:01 --> Total execution time: 0.0061
INFO - 2020-07-04 14:34:02 --> Config Class Initialized
INFO - 2020-07-04 14:34:02 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:34:02 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:34:02 --> Utf8 Class Initialized
INFO - 2020-07-04 14:34:02 --> URI Class Initialized
INFO - 2020-07-04 14:34:02 --> Router Class Initialized
INFO - 2020-07-04 14:34:02 --> Output Class Initialized
INFO - 2020-07-04 14:34:02 --> Security Class Initialized
DEBUG - 2020-07-04 14:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:34:02 --> Input Class Initialized
INFO - 2020-07-04 14:34:02 --> Language Class Initialized
INFO - 2020-07-04 14:34:02 --> Language Class Initialized
INFO - 2020-07-04 14:34:02 --> Config Class Initialized
INFO - 2020-07-04 14:34:02 --> Loader Class Initialized
INFO - 2020-07-04 14:34:02 --> Helper loaded: url_helper
INFO - 2020-07-04 14:34:02 --> Helper loaded: main_helper
INFO - 2020-07-04 14:34:02 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:34:02 --> Controller Class Initialized
INFO - 2020-07-04 14:34:02 --> Final output sent to browser
DEBUG - 2020-07-04 14:34:02 --> Total execution time: 0.0040
INFO - 2020-07-04 14:34:20 --> Config Class Initialized
INFO - 2020-07-04 14:34:20 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:34:20 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:34:20 --> Utf8 Class Initialized
INFO - 2020-07-04 14:34:20 --> URI Class Initialized
INFO - 2020-07-04 14:34:20 --> Router Class Initialized
INFO - 2020-07-04 14:34:20 --> Output Class Initialized
INFO - 2020-07-04 14:34:20 --> Security Class Initialized
DEBUG - 2020-07-04 14:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:34:20 --> Input Class Initialized
INFO - 2020-07-04 14:34:20 --> Language Class Initialized
INFO - 2020-07-04 14:34:20 --> Language Class Initialized
INFO - 2020-07-04 14:34:20 --> Config Class Initialized
INFO - 2020-07-04 14:34:20 --> Loader Class Initialized
INFO - 2020-07-04 14:34:20 --> Helper loaded: url_helper
INFO - 2020-07-04 14:34:20 --> Helper loaded: main_helper
INFO - 2020-07-04 14:34:20 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:34:20 --> Controller Class Initialized
DEBUG - 2020-07-04 14:34:20 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:34:20 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:34:20 --> Final output sent to browser
DEBUG - 2020-07-04 14:34:20 --> Total execution time: 0.0037
INFO - 2020-07-04 14:34:21 --> Config Class Initialized
INFO - 2020-07-04 14:34:21 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:34:21 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:34:21 --> Utf8 Class Initialized
INFO - 2020-07-04 14:34:21 --> URI Class Initialized
INFO - 2020-07-04 14:34:21 --> Router Class Initialized
INFO - 2020-07-04 14:34:21 --> Output Class Initialized
INFO - 2020-07-04 14:34:21 --> Security Class Initialized
DEBUG - 2020-07-04 14:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:34:21 --> Input Class Initialized
INFO - 2020-07-04 14:34:21 --> Language Class Initialized
INFO - 2020-07-04 14:34:21 --> Language Class Initialized
INFO - 2020-07-04 14:34:21 --> Config Class Initialized
INFO - 2020-07-04 14:34:21 --> Loader Class Initialized
INFO - 2020-07-04 14:34:21 --> Helper loaded: url_helper
INFO - 2020-07-04 14:34:21 --> Helper loaded: main_helper
INFO - 2020-07-04 14:34:21 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:34:21 --> Controller Class Initialized
INFO - 2020-07-04 14:34:21 --> Final output sent to browser
DEBUG - 2020-07-04 14:34:21 --> Total execution time: 0.0045
INFO - 2020-07-04 14:34:32 --> Config Class Initialized
INFO - 2020-07-04 14:34:32 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:34:32 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:34:32 --> Utf8 Class Initialized
INFO - 2020-07-04 14:34:32 --> URI Class Initialized
INFO - 2020-07-04 14:34:32 --> Router Class Initialized
INFO - 2020-07-04 14:34:32 --> Output Class Initialized
INFO - 2020-07-04 14:34:32 --> Security Class Initialized
DEBUG - 2020-07-04 14:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:34:32 --> Input Class Initialized
INFO - 2020-07-04 14:34:32 --> Language Class Initialized
INFO - 2020-07-04 14:34:32 --> Language Class Initialized
INFO - 2020-07-04 14:34:32 --> Config Class Initialized
INFO - 2020-07-04 14:34:32 --> Loader Class Initialized
INFO - 2020-07-04 14:34:32 --> Helper loaded: url_helper
INFO - 2020-07-04 14:34:32 --> Helper loaded: main_helper
INFO - 2020-07-04 14:34:32 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:34:32 --> Controller Class Initialized
DEBUG - 2020-07-04 14:34:32 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 14:34:32 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:34:32 --> Final output sent to browser
DEBUG - 2020-07-04 14:34:32 --> Total execution time: 0.0036
INFO - 2020-07-04 14:34:33 --> Config Class Initialized
INFO - 2020-07-04 14:34:33 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:34:33 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:34:33 --> Utf8 Class Initialized
INFO - 2020-07-04 14:34:33 --> URI Class Initialized
INFO - 2020-07-04 14:34:33 --> Router Class Initialized
INFO - 2020-07-04 14:34:33 --> Output Class Initialized
INFO - 2020-07-04 14:34:33 --> Security Class Initialized
DEBUG - 2020-07-04 14:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:34:33 --> Input Class Initialized
INFO - 2020-07-04 14:34:33 --> Language Class Initialized
INFO - 2020-07-04 14:34:33 --> Language Class Initialized
INFO - 2020-07-04 14:34:33 --> Config Class Initialized
INFO - 2020-07-04 14:34:33 --> Loader Class Initialized
INFO - 2020-07-04 14:34:33 --> Helper loaded: url_helper
INFO - 2020-07-04 14:34:33 --> Helper loaded: main_helper
INFO - 2020-07-04 14:34:33 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:34:33 --> Controller Class Initialized
INFO - 2020-07-04 14:34:33 --> Final output sent to browser
DEBUG - 2020-07-04 14:34:33 --> Total execution time: 0.0048
INFO - 2020-07-04 14:34:59 --> Config Class Initialized
INFO - 2020-07-04 14:34:59 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:34:59 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:34:59 --> Utf8 Class Initialized
INFO - 2020-07-04 14:34:59 --> URI Class Initialized
DEBUG - 2020-07-04 14:34:59 --> No URI present. Default controller set.
INFO - 2020-07-04 14:34:59 --> Router Class Initialized
INFO - 2020-07-04 14:34:59 --> Output Class Initialized
INFO - 2020-07-04 14:34:59 --> Security Class Initialized
DEBUG - 2020-07-04 14:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:34:59 --> Input Class Initialized
INFO - 2020-07-04 14:34:59 --> Language Class Initialized
INFO - 2020-07-04 14:34:59 --> Language Class Initialized
INFO - 2020-07-04 14:34:59 --> Config Class Initialized
INFO - 2020-07-04 14:34:59 --> Loader Class Initialized
INFO - 2020-07-04 14:34:59 --> Helper loaded: url_helper
INFO - 2020-07-04 14:34:59 --> Helper loaded: main_helper
INFO - 2020-07-04 14:34:59 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:34:59 --> Controller Class Initialized
DEBUG - 2020-07-04 14:34:59 --> File loaded: /var/www/journal/application/modules/template/views/landing_nav.php
DEBUG - 2020-07-04 14:34:59 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:34:59 --> File loaded: /var/www/journal/application/modules/template/views/master.php
INFO - 2020-07-04 14:34:59 --> Final output sent to browser
DEBUG - 2020-07-04 14:34:59 --> Total execution time: 0.0049
INFO - 2020-07-04 14:36:01 --> Config Class Initialized
INFO - 2020-07-04 14:36:01 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:36:01 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:36:01 --> Utf8 Class Initialized
INFO - 2020-07-04 14:36:01 --> URI Class Initialized
DEBUG - 2020-07-04 14:36:01 --> No URI present. Default controller set.
INFO - 2020-07-04 14:36:01 --> Router Class Initialized
INFO - 2020-07-04 14:36:01 --> Output Class Initialized
INFO - 2020-07-04 14:36:01 --> Security Class Initialized
DEBUG - 2020-07-04 14:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:36:01 --> Input Class Initialized
INFO - 2020-07-04 14:36:01 --> Language Class Initialized
INFO - 2020-07-04 14:36:01 --> Language Class Initialized
INFO - 2020-07-04 14:36:01 --> Config Class Initialized
INFO - 2020-07-04 14:36:01 --> Loader Class Initialized
INFO - 2020-07-04 14:36:01 --> Helper loaded: url_helper
INFO - 2020-07-04 14:36:01 --> Helper loaded: main_helper
INFO - 2020-07-04 14:36:01 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:36:01 --> Controller Class Initialized
DEBUG - 2020-07-04 14:36:01 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:36:01 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:36:01 --> Final output sent to browser
DEBUG - 2020-07-04 14:36:01 --> Total execution time: 0.0037
INFO - 2020-07-04 14:38:27 --> Config Class Initialized
INFO - 2020-07-04 14:38:27 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:38:27 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:38:27 --> Utf8 Class Initialized
INFO - 2020-07-04 14:38:27 --> URI Class Initialized
DEBUG - 2020-07-04 14:38:27 --> No URI present. Default controller set.
INFO - 2020-07-04 14:38:27 --> Router Class Initialized
INFO - 2020-07-04 14:38:27 --> Output Class Initialized
INFO - 2020-07-04 14:38:27 --> Security Class Initialized
DEBUG - 2020-07-04 14:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:38:27 --> Input Class Initialized
INFO - 2020-07-04 14:38:27 --> Language Class Initialized
INFO - 2020-07-04 14:38:27 --> Language Class Initialized
INFO - 2020-07-04 14:38:27 --> Config Class Initialized
INFO - 2020-07-04 14:38:27 --> Loader Class Initialized
INFO - 2020-07-04 14:38:27 --> Helper loaded: url_helper
INFO - 2020-07-04 14:38:27 --> Helper loaded: main_helper
INFO - 2020-07-04 14:38:27 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:38:27 --> Controller Class Initialized
DEBUG - 2020-07-04 14:38:27 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:38:27 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:38:27 --> Final output sent to browser
DEBUG - 2020-07-04 14:38:27 --> Total execution time: 0.0038
INFO - 2020-07-04 14:39:34 --> Config Class Initialized
INFO - 2020-07-04 14:39:34 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:39:34 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:39:34 --> Utf8 Class Initialized
INFO - 2020-07-04 14:39:34 --> URI Class Initialized
DEBUG - 2020-07-04 14:39:34 --> No URI present. Default controller set.
INFO - 2020-07-04 14:39:34 --> Router Class Initialized
INFO - 2020-07-04 14:39:34 --> Output Class Initialized
INFO - 2020-07-04 14:39:34 --> Security Class Initialized
DEBUG - 2020-07-04 14:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:39:34 --> Input Class Initialized
INFO - 2020-07-04 14:39:34 --> Language Class Initialized
INFO - 2020-07-04 14:39:34 --> Language Class Initialized
INFO - 2020-07-04 14:39:34 --> Config Class Initialized
INFO - 2020-07-04 14:39:34 --> Loader Class Initialized
INFO - 2020-07-04 14:39:34 --> Helper loaded: url_helper
INFO - 2020-07-04 14:39:34 --> Helper loaded: main_helper
INFO - 2020-07-04 14:39:34 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:39:34 --> Controller Class Initialized
DEBUG - 2020-07-04 14:39:34 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:39:34 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:39:34 --> Final output sent to browser
DEBUG - 2020-07-04 14:39:34 --> Total execution time: 0.0038
INFO - 2020-07-04 14:40:14 --> Config Class Initialized
INFO - 2020-07-04 14:40:14 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:40:14 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:40:14 --> Utf8 Class Initialized
INFO - 2020-07-04 14:40:14 --> URI Class Initialized
DEBUG - 2020-07-04 14:40:14 --> No URI present. Default controller set.
INFO - 2020-07-04 14:40:14 --> Router Class Initialized
INFO - 2020-07-04 14:40:14 --> Output Class Initialized
INFO - 2020-07-04 14:40:14 --> Security Class Initialized
DEBUG - 2020-07-04 14:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:40:14 --> Input Class Initialized
INFO - 2020-07-04 14:40:14 --> Language Class Initialized
INFO - 2020-07-04 14:40:14 --> Language Class Initialized
INFO - 2020-07-04 14:40:14 --> Config Class Initialized
INFO - 2020-07-04 14:40:14 --> Loader Class Initialized
INFO - 2020-07-04 14:40:14 --> Helper loaded: url_helper
INFO - 2020-07-04 14:40:14 --> Helper loaded: main_helper
INFO - 2020-07-04 14:40:14 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:40:14 --> Controller Class Initialized
DEBUG - 2020-07-04 14:40:14 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:40:14 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:40:14 --> Final output sent to browser
DEBUG - 2020-07-04 14:40:14 --> Total execution time: 0.0059
INFO - 2020-07-04 14:42:04 --> Config Class Initialized
INFO - 2020-07-04 14:42:04 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:42:04 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:42:04 --> Utf8 Class Initialized
INFO - 2020-07-04 14:42:04 --> URI Class Initialized
DEBUG - 2020-07-04 14:42:04 --> No URI present. Default controller set.
INFO - 2020-07-04 14:42:04 --> Router Class Initialized
INFO - 2020-07-04 14:42:04 --> Output Class Initialized
INFO - 2020-07-04 14:42:04 --> Security Class Initialized
DEBUG - 2020-07-04 14:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:42:04 --> Input Class Initialized
INFO - 2020-07-04 14:42:04 --> Language Class Initialized
INFO - 2020-07-04 14:42:04 --> Language Class Initialized
INFO - 2020-07-04 14:42:04 --> Config Class Initialized
INFO - 2020-07-04 14:42:04 --> Loader Class Initialized
INFO - 2020-07-04 14:42:04 --> Helper loaded: url_helper
INFO - 2020-07-04 14:42:04 --> Helper loaded: main_helper
INFO - 2020-07-04 14:42:04 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:42:04 --> Controller Class Initialized
DEBUG - 2020-07-04 14:42:04 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:42:04 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:42:04 --> Final output sent to browser
DEBUG - 2020-07-04 14:42:04 --> Total execution time: 0.0064
INFO - 2020-07-04 14:42:50 --> Config Class Initialized
INFO - 2020-07-04 14:42:50 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:42:50 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:42:50 --> Utf8 Class Initialized
INFO - 2020-07-04 14:42:50 --> URI Class Initialized
DEBUG - 2020-07-04 14:42:50 --> No URI present. Default controller set.
INFO - 2020-07-04 14:42:50 --> Router Class Initialized
INFO - 2020-07-04 14:42:50 --> Output Class Initialized
INFO - 2020-07-04 14:42:50 --> Security Class Initialized
DEBUG - 2020-07-04 14:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:42:50 --> Input Class Initialized
INFO - 2020-07-04 14:42:50 --> Language Class Initialized
INFO - 2020-07-04 14:42:50 --> Language Class Initialized
INFO - 2020-07-04 14:42:50 --> Config Class Initialized
INFO - 2020-07-04 14:42:50 --> Loader Class Initialized
INFO - 2020-07-04 14:42:50 --> Helper loaded: url_helper
INFO - 2020-07-04 14:42:50 --> Helper loaded: main_helper
INFO - 2020-07-04 14:42:50 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:42:50 --> Controller Class Initialized
DEBUG - 2020-07-04 14:42:50 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:42:50 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:42:50 --> Final output sent to browser
DEBUG - 2020-07-04 14:42:50 --> Total execution time: 0.0055
INFO - 2020-07-04 14:44:48 --> Config Class Initialized
INFO - 2020-07-04 14:44:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:44:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:44:48 --> Utf8 Class Initialized
INFO - 2020-07-04 14:44:48 --> URI Class Initialized
DEBUG - 2020-07-04 14:44:48 --> No URI present. Default controller set.
INFO - 2020-07-04 14:44:48 --> Router Class Initialized
INFO - 2020-07-04 14:44:48 --> Output Class Initialized
INFO - 2020-07-04 14:44:48 --> Security Class Initialized
DEBUG - 2020-07-04 14:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:44:48 --> Input Class Initialized
INFO - 2020-07-04 14:44:48 --> Language Class Initialized
INFO - 2020-07-04 14:44:48 --> Language Class Initialized
INFO - 2020-07-04 14:44:48 --> Config Class Initialized
INFO - 2020-07-04 14:44:48 --> Loader Class Initialized
INFO - 2020-07-04 14:44:48 --> Helper loaded: url_helper
INFO - 2020-07-04 14:44:48 --> Helper loaded: main_helper
INFO - 2020-07-04 14:44:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:44:48 --> Controller Class Initialized
DEBUG - 2020-07-04 14:44:48 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:44:48 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:44:48 --> Final output sent to browser
DEBUG - 2020-07-04 14:44:48 --> Total execution time: 0.0038
INFO - 2020-07-04 14:44:55 --> Config Class Initialized
INFO - 2020-07-04 14:44:55 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:44:55 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:44:55 --> Utf8 Class Initialized
INFO - 2020-07-04 14:44:55 --> URI Class Initialized
DEBUG - 2020-07-04 14:44:55 --> No URI present. Default controller set.
INFO - 2020-07-04 14:44:55 --> Router Class Initialized
INFO - 2020-07-04 14:44:55 --> Output Class Initialized
INFO - 2020-07-04 14:44:55 --> Security Class Initialized
DEBUG - 2020-07-04 14:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:44:55 --> Input Class Initialized
INFO - 2020-07-04 14:44:55 --> Language Class Initialized
INFO - 2020-07-04 14:44:55 --> Language Class Initialized
INFO - 2020-07-04 14:44:55 --> Config Class Initialized
INFO - 2020-07-04 14:44:55 --> Loader Class Initialized
INFO - 2020-07-04 14:44:55 --> Helper loaded: url_helper
INFO - 2020-07-04 14:44:55 --> Helper loaded: main_helper
INFO - 2020-07-04 14:44:55 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:44:55 --> Controller Class Initialized
DEBUG - 2020-07-04 14:44:55 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:44:55 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:44:55 --> Final output sent to browser
DEBUG - 2020-07-04 14:44:55 --> Total execution time: 0.0045
INFO - 2020-07-04 14:45:22 --> Config Class Initialized
INFO - 2020-07-04 14:45:22 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:45:22 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:45:22 --> Utf8 Class Initialized
INFO - 2020-07-04 14:45:22 --> URI Class Initialized
DEBUG - 2020-07-04 14:45:22 --> No URI present. Default controller set.
INFO - 2020-07-04 14:45:22 --> Router Class Initialized
INFO - 2020-07-04 14:45:22 --> Output Class Initialized
INFO - 2020-07-04 14:45:22 --> Security Class Initialized
DEBUG - 2020-07-04 14:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:45:22 --> Input Class Initialized
INFO - 2020-07-04 14:45:22 --> Language Class Initialized
INFO - 2020-07-04 14:45:22 --> Language Class Initialized
INFO - 2020-07-04 14:45:22 --> Config Class Initialized
INFO - 2020-07-04 14:45:22 --> Loader Class Initialized
INFO - 2020-07-04 14:45:22 --> Helper loaded: url_helper
INFO - 2020-07-04 14:45:22 --> Helper loaded: main_helper
INFO - 2020-07-04 14:45:22 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:45:22 --> Controller Class Initialized
DEBUG - 2020-07-04 14:45:22 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:45:22 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:45:22 --> Final output sent to browser
DEBUG - 2020-07-04 14:45:22 --> Total execution time: 0.0036
INFO - 2020-07-04 14:45:29 --> Config Class Initialized
INFO - 2020-07-04 14:45:29 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:45:29 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:45:29 --> Utf8 Class Initialized
INFO - 2020-07-04 14:45:29 --> URI Class Initialized
DEBUG - 2020-07-04 14:45:29 --> No URI present. Default controller set.
INFO - 2020-07-04 14:45:29 --> Router Class Initialized
INFO - 2020-07-04 14:45:29 --> Output Class Initialized
INFO - 2020-07-04 14:45:29 --> Security Class Initialized
DEBUG - 2020-07-04 14:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:45:29 --> Input Class Initialized
INFO - 2020-07-04 14:45:29 --> Language Class Initialized
INFO - 2020-07-04 14:45:29 --> Language Class Initialized
INFO - 2020-07-04 14:45:29 --> Config Class Initialized
INFO - 2020-07-04 14:45:29 --> Loader Class Initialized
INFO - 2020-07-04 14:45:29 --> Helper loaded: url_helper
INFO - 2020-07-04 14:45:29 --> Helper loaded: main_helper
INFO - 2020-07-04 14:45:29 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:45:29 --> Controller Class Initialized
DEBUG - 2020-07-04 14:45:29 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:45:29 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:45:29 --> Final output sent to browser
DEBUG - 2020-07-04 14:45:29 --> Total execution time: 0.0038
INFO - 2020-07-04 14:45:55 --> Config Class Initialized
INFO - 2020-07-04 14:45:55 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:45:55 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:45:55 --> Utf8 Class Initialized
INFO - 2020-07-04 14:45:55 --> URI Class Initialized
DEBUG - 2020-07-04 14:45:55 --> No URI present. Default controller set.
INFO - 2020-07-04 14:45:55 --> Router Class Initialized
INFO - 2020-07-04 14:45:55 --> Output Class Initialized
INFO - 2020-07-04 14:45:55 --> Security Class Initialized
DEBUG - 2020-07-04 14:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:45:55 --> Input Class Initialized
INFO - 2020-07-04 14:45:55 --> Language Class Initialized
INFO - 2020-07-04 14:45:55 --> Language Class Initialized
INFO - 2020-07-04 14:45:55 --> Config Class Initialized
INFO - 2020-07-04 14:45:55 --> Loader Class Initialized
INFO - 2020-07-04 14:45:55 --> Helper loaded: url_helper
INFO - 2020-07-04 14:45:55 --> Helper loaded: main_helper
INFO - 2020-07-04 14:45:55 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:45:55 --> Controller Class Initialized
DEBUG - 2020-07-04 14:45:55 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:45:55 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:45:55 --> Final output sent to browser
DEBUG - 2020-07-04 14:45:55 --> Total execution time: 0.0047
INFO - 2020-07-04 14:46:48 --> Config Class Initialized
INFO - 2020-07-04 14:46:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:46:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:46:48 --> Utf8 Class Initialized
INFO - 2020-07-04 14:46:48 --> URI Class Initialized
DEBUG - 2020-07-04 14:46:48 --> No URI present. Default controller set.
INFO - 2020-07-04 14:46:48 --> Router Class Initialized
INFO - 2020-07-04 14:46:48 --> Output Class Initialized
INFO - 2020-07-04 14:46:48 --> Security Class Initialized
DEBUG - 2020-07-04 14:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:46:48 --> Input Class Initialized
INFO - 2020-07-04 14:46:48 --> Language Class Initialized
INFO - 2020-07-04 14:46:48 --> Language Class Initialized
INFO - 2020-07-04 14:46:48 --> Config Class Initialized
INFO - 2020-07-04 14:46:48 --> Loader Class Initialized
INFO - 2020-07-04 14:46:48 --> Helper loaded: url_helper
INFO - 2020-07-04 14:46:48 --> Helper loaded: main_helper
INFO - 2020-07-04 14:46:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:46:48 --> Controller Class Initialized
DEBUG - 2020-07-04 14:46:48 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:46:48 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:46:48 --> Final output sent to browser
DEBUG - 2020-07-04 14:46:48 --> Total execution time: 0.0053
INFO - 2020-07-04 14:47:05 --> Config Class Initialized
INFO - 2020-07-04 14:47:05 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:47:05 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:47:05 --> Utf8 Class Initialized
INFO - 2020-07-04 14:47:05 --> URI Class Initialized
DEBUG - 2020-07-04 14:47:05 --> No URI present. Default controller set.
INFO - 2020-07-04 14:47:05 --> Router Class Initialized
INFO - 2020-07-04 14:47:05 --> Output Class Initialized
INFO - 2020-07-04 14:47:05 --> Security Class Initialized
DEBUG - 2020-07-04 14:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:47:05 --> Input Class Initialized
INFO - 2020-07-04 14:47:05 --> Language Class Initialized
INFO - 2020-07-04 14:47:05 --> Language Class Initialized
INFO - 2020-07-04 14:47:05 --> Config Class Initialized
INFO - 2020-07-04 14:47:05 --> Loader Class Initialized
INFO - 2020-07-04 14:47:05 --> Helper loaded: url_helper
INFO - 2020-07-04 14:47:05 --> Helper loaded: main_helper
INFO - 2020-07-04 14:47:05 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:47:06 --> Controller Class Initialized
DEBUG - 2020-07-04 14:47:06 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:47:06 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:47:06 --> Final output sent to browser
DEBUG - 2020-07-04 14:47:06 --> Total execution time: 0.0056
INFO - 2020-07-04 14:47:07 --> Config Class Initialized
INFO - 2020-07-04 14:47:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:47:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:47:07 --> Utf8 Class Initialized
INFO - 2020-07-04 14:47:07 --> URI Class Initialized
DEBUG - 2020-07-04 14:47:07 --> No URI present. Default controller set.
INFO - 2020-07-04 14:47:07 --> Router Class Initialized
INFO - 2020-07-04 14:47:07 --> Output Class Initialized
INFO - 2020-07-04 14:47:07 --> Security Class Initialized
DEBUG - 2020-07-04 14:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:47:07 --> Input Class Initialized
INFO - 2020-07-04 14:47:07 --> Language Class Initialized
INFO - 2020-07-04 14:47:07 --> Language Class Initialized
INFO - 2020-07-04 14:47:07 --> Config Class Initialized
INFO - 2020-07-04 14:47:07 --> Loader Class Initialized
INFO - 2020-07-04 14:47:07 --> Helper loaded: url_helper
INFO - 2020-07-04 14:47:07 --> Helper loaded: main_helper
INFO - 2020-07-04 14:47:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:47:07 --> Controller Class Initialized
DEBUG - 2020-07-04 14:47:07 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:47:07 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:47:07 --> Final output sent to browser
DEBUG - 2020-07-04 14:47:07 --> Total execution time: 0.0079
INFO - 2020-07-04 14:47:18 --> Config Class Initialized
INFO - 2020-07-04 14:47:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:47:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:47:18 --> Utf8 Class Initialized
INFO - 2020-07-04 14:47:18 --> URI Class Initialized
DEBUG - 2020-07-04 14:47:18 --> No URI present. Default controller set.
INFO - 2020-07-04 14:47:18 --> Router Class Initialized
INFO - 2020-07-04 14:47:18 --> Output Class Initialized
INFO - 2020-07-04 14:47:18 --> Security Class Initialized
DEBUG - 2020-07-04 14:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:47:18 --> Input Class Initialized
INFO - 2020-07-04 14:47:18 --> Language Class Initialized
INFO - 2020-07-04 14:47:18 --> Language Class Initialized
INFO - 2020-07-04 14:47:18 --> Config Class Initialized
INFO - 2020-07-04 14:47:18 --> Loader Class Initialized
INFO - 2020-07-04 14:47:18 --> Helper loaded: url_helper
INFO - 2020-07-04 14:47:18 --> Helper loaded: main_helper
INFO - 2020-07-04 14:47:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:47:18 --> Controller Class Initialized
DEBUG - 2020-07-04 14:47:18 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:47:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:47:18 --> Final output sent to browser
DEBUG - 2020-07-04 14:47:18 --> Total execution time: 0.0042
INFO - 2020-07-04 14:47:44 --> Config Class Initialized
INFO - 2020-07-04 14:47:44 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:47:44 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:47:44 --> Utf8 Class Initialized
INFO - 2020-07-04 14:47:44 --> URI Class Initialized
DEBUG - 2020-07-04 14:47:44 --> No URI present. Default controller set.
INFO - 2020-07-04 14:47:44 --> Router Class Initialized
INFO - 2020-07-04 14:47:44 --> Output Class Initialized
INFO - 2020-07-04 14:47:44 --> Security Class Initialized
DEBUG - 2020-07-04 14:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:47:44 --> Input Class Initialized
INFO - 2020-07-04 14:47:44 --> Language Class Initialized
INFO - 2020-07-04 14:47:44 --> Language Class Initialized
INFO - 2020-07-04 14:47:44 --> Config Class Initialized
INFO - 2020-07-04 14:47:44 --> Loader Class Initialized
INFO - 2020-07-04 14:47:44 --> Helper loaded: url_helper
INFO - 2020-07-04 14:47:44 --> Helper loaded: main_helper
INFO - 2020-07-04 14:47:44 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:47:44 --> Controller Class Initialized
DEBUG - 2020-07-04 14:47:44 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:47:44 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:47:44 --> Final output sent to browser
DEBUG - 2020-07-04 14:47:44 --> Total execution time: 0.0079
INFO - 2020-07-04 14:48:57 --> Config Class Initialized
INFO - 2020-07-04 14:48:57 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:48:57 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:48:57 --> Utf8 Class Initialized
INFO - 2020-07-04 14:48:57 --> URI Class Initialized
DEBUG - 2020-07-04 14:48:57 --> No URI present. Default controller set.
INFO - 2020-07-04 14:48:57 --> Router Class Initialized
INFO - 2020-07-04 14:48:57 --> Output Class Initialized
INFO - 2020-07-04 14:48:57 --> Security Class Initialized
DEBUG - 2020-07-04 14:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:48:57 --> Input Class Initialized
INFO - 2020-07-04 14:48:57 --> Language Class Initialized
INFO - 2020-07-04 14:48:57 --> Language Class Initialized
INFO - 2020-07-04 14:48:57 --> Config Class Initialized
INFO - 2020-07-04 14:48:57 --> Loader Class Initialized
INFO - 2020-07-04 14:48:57 --> Helper loaded: url_helper
INFO - 2020-07-04 14:48:57 --> Helper loaded: main_helper
INFO - 2020-07-04 14:48:57 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:48:57 --> Controller Class Initialized
DEBUG - 2020-07-04 14:48:57 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:48:57 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:48:57 --> Final output sent to browser
DEBUG - 2020-07-04 14:48:57 --> Total execution time: 0.0060
INFO - 2020-07-04 14:49:13 --> Config Class Initialized
INFO - 2020-07-04 14:49:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:49:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:49:13 --> Utf8 Class Initialized
INFO - 2020-07-04 14:49:13 --> URI Class Initialized
DEBUG - 2020-07-04 14:49:13 --> No URI present. Default controller set.
INFO - 2020-07-04 14:49:13 --> Router Class Initialized
INFO - 2020-07-04 14:49:13 --> Output Class Initialized
INFO - 2020-07-04 14:49:13 --> Security Class Initialized
DEBUG - 2020-07-04 14:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:49:13 --> Input Class Initialized
INFO - 2020-07-04 14:49:13 --> Language Class Initialized
INFO - 2020-07-04 14:49:13 --> Language Class Initialized
INFO - 2020-07-04 14:49:13 --> Config Class Initialized
INFO - 2020-07-04 14:49:13 --> Loader Class Initialized
INFO - 2020-07-04 14:49:13 --> Helper loaded: url_helper
INFO - 2020-07-04 14:49:13 --> Helper loaded: main_helper
INFO - 2020-07-04 14:49:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:49:13 --> Controller Class Initialized
DEBUG - 2020-07-04 14:49:13 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:49:13 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:49:13 --> Final output sent to browser
DEBUG - 2020-07-04 14:49:13 --> Total execution time: 0.0046
INFO - 2020-07-04 14:49:57 --> Config Class Initialized
INFO - 2020-07-04 14:49:57 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:49:57 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:49:57 --> Utf8 Class Initialized
INFO - 2020-07-04 14:49:57 --> URI Class Initialized
DEBUG - 2020-07-04 14:49:57 --> No URI present. Default controller set.
INFO - 2020-07-04 14:49:57 --> Router Class Initialized
INFO - 2020-07-04 14:49:57 --> Output Class Initialized
INFO - 2020-07-04 14:49:57 --> Security Class Initialized
DEBUG - 2020-07-04 14:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:49:57 --> Input Class Initialized
INFO - 2020-07-04 14:49:57 --> Language Class Initialized
INFO - 2020-07-04 14:49:57 --> Language Class Initialized
INFO - 2020-07-04 14:49:57 --> Config Class Initialized
INFO - 2020-07-04 14:49:57 --> Loader Class Initialized
INFO - 2020-07-04 14:49:57 --> Helper loaded: url_helper
INFO - 2020-07-04 14:49:57 --> Helper loaded: main_helper
INFO - 2020-07-04 14:49:57 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:49:57 --> Controller Class Initialized
DEBUG - 2020-07-04 14:49:57 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:49:57 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:49:57 --> Final output sent to browser
DEBUG - 2020-07-04 14:49:57 --> Total execution time: 0.0050
INFO - 2020-07-04 14:50:09 --> Config Class Initialized
INFO - 2020-07-04 14:50:09 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:50:09 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:50:09 --> Utf8 Class Initialized
INFO - 2020-07-04 14:50:09 --> URI Class Initialized
DEBUG - 2020-07-04 14:50:09 --> No URI present. Default controller set.
INFO - 2020-07-04 14:50:09 --> Router Class Initialized
INFO - 2020-07-04 14:50:09 --> Output Class Initialized
INFO - 2020-07-04 14:50:09 --> Security Class Initialized
DEBUG - 2020-07-04 14:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:50:09 --> Input Class Initialized
INFO - 2020-07-04 14:50:09 --> Language Class Initialized
INFO - 2020-07-04 14:50:09 --> Language Class Initialized
INFO - 2020-07-04 14:50:09 --> Config Class Initialized
INFO - 2020-07-04 14:50:09 --> Loader Class Initialized
INFO - 2020-07-04 14:50:09 --> Helper loaded: url_helper
INFO - 2020-07-04 14:50:09 --> Helper loaded: main_helper
INFO - 2020-07-04 14:50:09 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:50:09 --> Controller Class Initialized
DEBUG - 2020-07-04 14:50:09 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:50:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:50:09 --> Final output sent to browser
DEBUG - 2020-07-04 14:50:09 --> Total execution time: 0.0043
INFO - 2020-07-04 14:51:21 --> Config Class Initialized
INFO - 2020-07-04 14:51:21 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:51:21 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:51:21 --> Utf8 Class Initialized
INFO - 2020-07-04 14:51:21 --> URI Class Initialized
DEBUG - 2020-07-04 14:51:21 --> No URI present. Default controller set.
INFO - 2020-07-04 14:51:21 --> Router Class Initialized
INFO - 2020-07-04 14:51:21 --> Output Class Initialized
INFO - 2020-07-04 14:51:21 --> Security Class Initialized
DEBUG - 2020-07-04 14:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:51:21 --> Input Class Initialized
INFO - 2020-07-04 14:51:21 --> Language Class Initialized
INFO - 2020-07-04 14:51:21 --> Language Class Initialized
INFO - 2020-07-04 14:51:21 --> Config Class Initialized
INFO - 2020-07-04 14:51:21 --> Loader Class Initialized
INFO - 2020-07-04 14:51:21 --> Helper loaded: url_helper
INFO - 2020-07-04 14:51:21 --> Helper loaded: main_helper
INFO - 2020-07-04 14:51:21 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:51:21 --> Controller Class Initialized
DEBUG - 2020-07-04 14:51:21 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:51:21 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:51:21 --> Final output sent to browser
DEBUG - 2020-07-04 14:51:21 --> Total execution time: 0.0042
INFO - 2020-07-04 14:51:45 --> Config Class Initialized
INFO - 2020-07-04 14:51:45 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:51:45 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:51:45 --> Utf8 Class Initialized
INFO - 2020-07-04 14:51:45 --> URI Class Initialized
DEBUG - 2020-07-04 14:51:45 --> No URI present. Default controller set.
INFO - 2020-07-04 14:51:45 --> Router Class Initialized
INFO - 2020-07-04 14:51:45 --> Output Class Initialized
INFO - 2020-07-04 14:51:45 --> Security Class Initialized
DEBUG - 2020-07-04 14:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:51:45 --> Input Class Initialized
INFO - 2020-07-04 14:51:45 --> Language Class Initialized
INFO - 2020-07-04 14:51:45 --> Language Class Initialized
INFO - 2020-07-04 14:51:45 --> Config Class Initialized
INFO - 2020-07-04 14:51:45 --> Loader Class Initialized
INFO - 2020-07-04 14:51:45 --> Helper loaded: url_helper
INFO - 2020-07-04 14:51:45 --> Helper loaded: main_helper
INFO - 2020-07-04 14:51:45 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:51:45 --> Controller Class Initialized
DEBUG - 2020-07-04 14:51:45 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:51:45 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:51:45 --> Final output sent to browser
DEBUG - 2020-07-04 14:51:45 --> Total execution time: 0.0040
INFO - 2020-07-04 14:52:38 --> Config Class Initialized
INFO - 2020-07-04 14:52:38 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:52:38 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:52:38 --> Utf8 Class Initialized
INFO - 2020-07-04 14:52:38 --> URI Class Initialized
DEBUG - 2020-07-04 14:52:38 --> No URI present. Default controller set.
INFO - 2020-07-04 14:52:38 --> Router Class Initialized
INFO - 2020-07-04 14:52:38 --> Output Class Initialized
INFO - 2020-07-04 14:52:38 --> Security Class Initialized
DEBUG - 2020-07-04 14:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:52:38 --> Input Class Initialized
INFO - 2020-07-04 14:52:38 --> Language Class Initialized
INFO - 2020-07-04 14:52:38 --> Language Class Initialized
INFO - 2020-07-04 14:52:38 --> Config Class Initialized
INFO - 2020-07-04 14:52:38 --> Loader Class Initialized
INFO - 2020-07-04 14:52:38 --> Helper loaded: url_helper
INFO - 2020-07-04 14:52:38 --> Helper loaded: main_helper
INFO - 2020-07-04 14:52:38 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:52:38 --> Controller Class Initialized
DEBUG - 2020-07-04 14:52:38 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:52:38 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:52:38 --> Final output sent to browser
DEBUG - 2020-07-04 14:52:38 --> Total execution time: 0.0078
INFO - 2020-07-04 14:52:47 --> Config Class Initialized
INFO - 2020-07-04 14:52:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:52:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:52:47 --> Utf8 Class Initialized
INFO - 2020-07-04 14:52:47 --> URI Class Initialized
DEBUG - 2020-07-04 14:52:47 --> No URI present. Default controller set.
INFO - 2020-07-04 14:52:47 --> Router Class Initialized
INFO - 2020-07-04 14:52:47 --> Output Class Initialized
INFO - 2020-07-04 14:52:47 --> Security Class Initialized
DEBUG - 2020-07-04 14:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:52:47 --> Input Class Initialized
INFO - 2020-07-04 14:52:47 --> Language Class Initialized
INFO - 2020-07-04 14:52:47 --> Language Class Initialized
INFO - 2020-07-04 14:52:47 --> Config Class Initialized
INFO - 2020-07-04 14:52:47 --> Loader Class Initialized
INFO - 2020-07-04 14:52:47 --> Helper loaded: url_helper
INFO - 2020-07-04 14:52:47 --> Helper loaded: main_helper
INFO - 2020-07-04 14:52:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:52:47 --> Controller Class Initialized
DEBUG - 2020-07-04 14:52:47 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:52:47 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:52:47 --> Final output sent to browser
DEBUG - 2020-07-04 14:52:47 --> Total execution time: 0.0049
INFO - 2020-07-04 14:53:19 --> Config Class Initialized
INFO - 2020-07-04 14:53:19 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:53:19 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:53:19 --> Utf8 Class Initialized
INFO - 2020-07-04 14:53:19 --> URI Class Initialized
DEBUG - 2020-07-04 14:53:19 --> No URI present. Default controller set.
INFO - 2020-07-04 14:53:19 --> Router Class Initialized
INFO - 2020-07-04 14:53:19 --> Output Class Initialized
INFO - 2020-07-04 14:53:19 --> Security Class Initialized
DEBUG - 2020-07-04 14:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:53:19 --> Input Class Initialized
INFO - 2020-07-04 14:53:19 --> Language Class Initialized
INFO - 2020-07-04 14:53:19 --> Language Class Initialized
INFO - 2020-07-04 14:53:19 --> Config Class Initialized
INFO - 2020-07-04 14:53:19 --> Loader Class Initialized
INFO - 2020-07-04 14:53:19 --> Helper loaded: url_helper
INFO - 2020-07-04 14:53:19 --> Helper loaded: main_helper
INFO - 2020-07-04 14:53:19 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:53:19 --> Controller Class Initialized
DEBUG - 2020-07-04 14:53:19 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:53:19 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:53:19 --> Final output sent to browser
DEBUG - 2020-07-04 14:53:19 --> Total execution time: 0.0041
INFO - 2020-07-04 14:53:40 --> Config Class Initialized
INFO - 2020-07-04 14:53:40 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:53:40 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:53:40 --> Utf8 Class Initialized
INFO - 2020-07-04 14:53:40 --> URI Class Initialized
DEBUG - 2020-07-04 14:53:40 --> No URI present. Default controller set.
INFO - 2020-07-04 14:53:40 --> Router Class Initialized
INFO - 2020-07-04 14:53:40 --> Output Class Initialized
INFO - 2020-07-04 14:53:40 --> Security Class Initialized
DEBUG - 2020-07-04 14:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:53:40 --> Input Class Initialized
INFO - 2020-07-04 14:53:40 --> Language Class Initialized
INFO - 2020-07-04 14:53:40 --> Language Class Initialized
INFO - 2020-07-04 14:53:40 --> Config Class Initialized
INFO - 2020-07-04 14:53:40 --> Loader Class Initialized
INFO - 2020-07-04 14:53:40 --> Helper loaded: url_helper
INFO - 2020-07-04 14:53:40 --> Helper loaded: main_helper
INFO - 2020-07-04 14:53:40 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:53:40 --> Controller Class Initialized
DEBUG - 2020-07-04 14:53:40 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:53:40 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:53:40 --> Final output sent to browser
DEBUG - 2020-07-04 14:53:40 --> Total execution time: 0.0060
INFO - 2020-07-04 14:55:04 --> Config Class Initialized
INFO - 2020-07-04 14:55:04 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:55:04 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:55:04 --> Utf8 Class Initialized
INFO - 2020-07-04 14:55:04 --> URI Class Initialized
DEBUG - 2020-07-04 14:55:04 --> No URI present. Default controller set.
INFO - 2020-07-04 14:55:04 --> Router Class Initialized
INFO - 2020-07-04 14:55:04 --> Output Class Initialized
INFO - 2020-07-04 14:55:04 --> Security Class Initialized
DEBUG - 2020-07-04 14:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:55:04 --> Input Class Initialized
INFO - 2020-07-04 14:55:04 --> Language Class Initialized
INFO - 2020-07-04 14:55:04 --> Language Class Initialized
INFO - 2020-07-04 14:55:04 --> Config Class Initialized
INFO - 2020-07-04 14:55:04 --> Loader Class Initialized
INFO - 2020-07-04 14:55:04 --> Helper loaded: url_helper
INFO - 2020-07-04 14:55:04 --> Helper loaded: main_helper
INFO - 2020-07-04 14:55:04 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:55:04 --> Controller Class Initialized
DEBUG - 2020-07-04 14:55:04 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:55:04 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:55:04 --> Final output sent to browser
DEBUG - 2020-07-04 14:55:04 --> Total execution time: 0.0035
INFO - 2020-07-04 14:55:10 --> Config Class Initialized
INFO - 2020-07-04 14:55:10 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:55:10 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:55:10 --> Utf8 Class Initialized
INFO - 2020-07-04 14:55:10 --> URI Class Initialized
DEBUG - 2020-07-04 14:55:10 --> No URI present. Default controller set.
INFO - 2020-07-04 14:55:10 --> Router Class Initialized
INFO - 2020-07-04 14:55:10 --> Output Class Initialized
INFO - 2020-07-04 14:55:10 --> Security Class Initialized
DEBUG - 2020-07-04 14:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:55:10 --> Input Class Initialized
INFO - 2020-07-04 14:55:10 --> Language Class Initialized
INFO - 2020-07-04 14:55:10 --> Language Class Initialized
INFO - 2020-07-04 14:55:10 --> Config Class Initialized
INFO - 2020-07-04 14:55:10 --> Loader Class Initialized
INFO - 2020-07-04 14:55:10 --> Helper loaded: url_helper
INFO - 2020-07-04 14:55:10 --> Helper loaded: main_helper
INFO - 2020-07-04 14:55:10 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:55:10 --> Controller Class Initialized
DEBUG - 2020-07-04 14:55:10 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:55:10 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:55:10 --> Final output sent to browser
DEBUG - 2020-07-04 14:55:10 --> Total execution time: 0.0046
INFO - 2020-07-04 14:55:46 --> Config Class Initialized
INFO - 2020-07-04 14:55:46 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:55:46 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:55:46 --> Utf8 Class Initialized
INFO - 2020-07-04 14:55:46 --> URI Class Initialized
DEBUG - 2020-07-04 14:55:46 --> No URI present. Default controller set.
INFO - 2020-07-04 14:55:46 --> Router Class Initialized
INFO - 2020-07-04 14:55:46 --> Output Class Initialized
INFO - 2020-07-04 14:55:46 --> Security Class Initialized
DEBUG - 2020-07-04 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:55:46 --> Input Class Initialized
INFO - 2020-07-04 14:55:46 --> Language Class Initialized
INFO - 2020-07-04 14:55:46 --> Language Class Initialized
INFO - 2020-07-04 14:55:46 --> Config Class Initialized
INFO - 2020-07-04 14:55:46 --> Loader Class Initialized
INFO - 2020-07-04 14:55:46 --> Helper loaded: url_helper
INFO - 2020-07-04 14:55:46 --> Helper loaded: main_helper
INFO - 2020-07-04 14:55:46 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:55:46 --> Controller Class Initialized
DEBUG - 2020-07-04 14:55:46 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:55:46 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:55:46 --> Final output sent to browser
DEBUG - 2020-07-04 14:55:46 --> Total execution time: 0.0061
INFO - 2020-07-04 14:56:44 --> Config Class Initialized
INFO - 2020-07-04 14:56:44 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:56:44 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:56:44 --> Utf8 Class Initialized
INFO - 2020-07-04 14:56:44 --> URI Class Initialized
DEBUG - 2020-07-04 14:56:44 --> No URI present. Default controller set.
INFO - 2020-07-04 14:56:44 --> Router Class Initialized
INFO - 2020-07-04 14:56:44 --> Output Class Initialized
INFO - 2020-07-04 14:56:44 --> Security Class Initialized
DEBUG - 2020-07-04 14:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:56:44 --> Input Class Initialized
INFO - 2020-07-04 14:56:44 --> Language Class Initialized
INFO - 2020-07-04 14:56:44 --> Language Class Initialized
INFO - 2020-07-04 14:56:44 --> Config Class Initialized
INFO - 2020-07-04 14:56:44 --> Loader Class Initialized
INFO - 2020-07-04 14:56:44 --> Helper loaded: url_helper
INFO - 2020-07-04 14:56:44 --> Helper loaded: main_helper
INFO - 2020-07-04 14:56:44 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:56:44 --> Controller Class Initialized
DEBUG - 2020-07-04 14:56:44 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:56:44 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:56:44 --> Final output sent to browser
DEBUG - 2020-07-04 14:56:44 --> Total execution time: 0.0048
INFO - 2020-07-04 14:56:54 --> Config Class Initialized
INFO - 2020-07-04 14:56:54 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:56:54 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:56:54 --> Utf8 Class Initialized
INFO - 2020-07-04 14:56:54 --> URI Class Initialized
DEBUG - 2020-07-04 14:56:54 --> No URI present. Default controller set.
INFO - 2020-07-04 14:56:54 --> Router Class Initialized
INFO - 2020-07-04 14:56:54 --> Output Class Initialized
INFO - 2020-07-04 14:56:54 --> Security Class Initialized
DEBUG - 2020-07-04 14:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:56:54 --> Input Class Initialized
INFO - 2020-07-04 14:56:54 --> Language Class Initialized
INFO - 2020-07-04 14:56:54 --> Language Class Initialized
INFO - 2020-07-04 14:56:54 --> Config Class Initialized
INFO - 2020-07-04 14:56:54 --> Loader Class Initialized
INFO - 2020-07-04 14:56:54 --> Helper loaded: url_helper
INFO - 2020-07-04 14:56:54 --> Helper loaded: main_helper
INFO - 2020-07-04 14:56:54 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:56:54 --> Controller Class Initialized
DEBUG - 2020-07-04 14:56:54 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:56:54 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:56:54 --> Final output sent to browser
DEBUG - 2020-07-04 14:56:54 --> Total execution time: 0.0038
INFO - 2020-07-04 14:57:07 --> Config Class Initialized
INFO - 2020-07-04 14:57:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:57:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:57:07 --> Utf8 Class Initialized
INFO - 2020-07-04 14:57:07 --> URI Class Initialized
DEBUG - 2020-07-04 14:57:07 --> No URI present. Default controller set.
INFO - 2020-07-04 14:57:07 --> Router Class Initialized
INFO - 2020-07-04 14:57:07 --> Output Class Initialized
INFO - 2020-07-04 14:57:07 --> Security Class Initialized
DEBUG - 2020-07-04 14:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:57:07 --> Input Class Initialized
INFO - 2020-07-04 14:57:07 --> Language Class Initialized
INFO - 2020-07-04 14:57:07 --> Language Class Initialized
INFO - 2020-07-04 14:57:07 --> Config Class Initialized
INFO - 2020-07-04 14:57:07 --> Loader Class Initialized
INFO - 2020-07-04 14:57:07 --> Helper loaded: url_helper
INFO - 2020-07-04 14:57:07 --> Helper loaded: main_helper
INFO - 2020-07-04 14:57:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:57:07 --> Controller Class Initialized
DEBUG - 2020-07-04 14:57:07 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:57:07 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:57:07 --> Final output sent to browser
DEBUG - 2020-07-04 14:57:07 --> Total execution time: 0.0038
INFO - 2020-07-04 14:57:17 --> Config Class Initialized
INFO - 2020-07-04 14:57:17 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:57:17 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:57:17 --> Utf8 Class Initialized
INFO - 2020-07-04 14:57:17 --> URI Class Initialized
DEBUG - 2020-07-04 14:57:17 --> No URI present. Default controller set.
INFO - 2020-07-04 14:57:17 --> Router Class Initialized
INFO - 2020-07-04 14:57:17 --> Output Class Initialized
INFO - 2020-07-04 14:57:17 --> Security Class Initialized
DEBUG - 2020-07-04 14:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:57:17 --> Input Class Initialized
INFO - 2020-07-04 14:57:17 --> Language Class Initialized
INFO - 2020-07-04 14:57:17 --> Language Class Initialized
INFO - 2020-07-04 14:57:17 --> Config Class Initialized
INFO - 2020-07-04 14:57:17 --> Loader Class Initialized
INFO - 2020-07-04 14:57:17 --> Helper loaded: url_helper
INFO - 2020-07-04 14:57:17 --> Helper loaded: main_helper
INFO - 2020-07-04 14:57:17 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:57:17 --> Controller Class Initialized
DEBUG - 2020-07-04 14:57:17 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:57:17 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:57:17 --> Final output sent to browser
DEBUG - 2020-07-04 14:57:17 --> Total execution time: 0.0037
INFO - 2020-07-04 14:57:40 --> Config Class Initialized
INFO - 2020-07-04 14:57:40 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:57:40 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:57:40 --> Utf8 Class Initialized
INFO - 2020-07-04 14:57:40 --> URI Class Initialized
DEBUG - 2020-07-04 14:57:40 --> No URI present. Default controller set.
INFO - 2020-07-04 14:57:40 --> Router Class Initialized
INFO - 2020-07-04 14:57:40 --> Output Class Initialized
INFO - 2020-07-04 14:57:40 --> Security Class Initialized
DEBUG - 2020-07-04 14:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:57:40 --> Input Class Initialized
INFO - 2020-07-04 14:57:40 --> Language Class Initialized
INFO - 2020-07-04 14:57:40 --> Language Class Initialized
INFO - 2020-07-04 14:57:40 --> Config Class Initialized
INFO - 2020-07-04 14:57:40 --> Loader Class Initialized
INFO - 2020-07-04 14:57:40 --> Helper loaded: url_helper
INFO - 2020-07-04 14:57:40 --> Helper loaded: main_helper
INFO - 2020-07-04 14:57:40 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:57:40 --> Controller Class Initialized
DEBUG - 2020-07-04 14:57:40 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:57:40 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:57:40 --> Final output sent to browser
DEBUG - 2020-07-04 14:57:40 --> Total execution time: 0.0057
INFO - 2020-07-04 14:57:55 --> Config Class Initialized
INFO - 2020-07-04 14:57:55 --> Hooks Class Initialized
DEBUG - 2020-07-04 14:57:55 --> UTF-8 Support Enabled
INFO - 2020-07-04 14:57:55 --> Utf8 Class Initialized
INFO - 2020-07-04 14:57:55 --> URI Class Initialized
DEBUG - 2020-07-04 14:57:55 --> No URI present. Default controller set.
INFO - 2020-07-04 14:57:55 --> Router Class Initialized
INFO - 2020-07-04 14:57:55 --> Output Class Initialized
INFO - 2020-07-04 14:57:55 --> Security Class Initialized
DEBUG - 2020-07-04 14:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 14:57:55 --> Input Class Initialized
INFO - 2020-07-04 14:57:55 --> Language Class Initialized
INFO - 2020-07-04 14:57:55 --> Language Class Initialized
INFO - 2020-07-04 14:57:55 --> Config Class Initialized
INFO - 2020-07-04 14:57:55 --> Loader Class Initialized
INFO - 2020-07-04 14:57:55 --> Helper loaded: url_helper
INFO - 2020-07-04 14:57:55 --> Helper loaded: main_helper
INFO - 2020-07-04 14:57:55 --> Database Driver Class Initialized
DEBUG - 2020-07-04 14:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 14:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 14:57:55 --> Controller Class Initialized
DEBUG - 2020-07-04 14:57:55 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 14:57:55 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 14:57:55 --> Final output sent to browser
DEBUG - 2020-07-04 14:57:55 --> Total execution time: 0.0037
INFO - 2020-07-04 15:00:43 --> Config Class Initialized
INFO - 2020-07-04 15:00:43 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:00:43 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:00:43 --> Utf8 Class Initialized
INFO - 2020-07-04 15:00:43 --> URI Class Initialized
DEBUG - 2020-07-04 15:00:43 --> No URI present. Default controller set.
INFO - 2020-07-04 15:00:43 --> Router Class Initialized
INFO - 2020-07-04 15:00:43 --> Output Class Initialized
INFO - 2020-07-04 15:00:43 --> Security Class Initialized
DEBUG - 2020-07-04 15:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:00:43 --> Input Class Initialized
INFO - 2020-07-04 15:00:43 --> Language Class Initialized
INFO - 2020-07-04 15:00:43 --> Language Class Initialized
INFO - 2020-07-04 15:00:43 --> Config Class Initialized
INFO - 2020-07-04 15:00:43 --> Loader Class Initialized
INFO - 2020-07-04 15:00:43 --> Helper loaded: url_helper
INFO - 2020-07-04 15:00:43 --> Helper loaded: main_helper
INFO - 2020-07-04 15:00:43 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:00:43 --> Controller Class Initialized
DEBUG - 2020-07-04 15:00:43 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:00:43 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:00:43 --> Final output sent to browser
DEBUG - 2020-07-04 15:00:43 --> Total execution time: 0.0073
INFO - 2020-07-04 15:01:29 --> Config Class Initialized
INFO - 2020-07-04 15:01:29 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:01:29 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:01:29 --> Utf8 Class Initialized
INFO - 2020-07-04 15:01:29 --> URI Class Initialized
DEBUG - 2020-07-04 15:01:29 --> No URI present. Default controller set.
INFO - 2020-07-04 15:01:29 --> Router Class Initialized
INFO - 2020-07-04 15:01:29 --> Output Class Initialized
INFO - 2020-07-04 15:01:29 --> Security Class Initialized
DEBUG - 2020-07-04 15:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:01:29 --> Input Class Initialized
INFO - 2020-07-04 15:01:29 --> Language Class Initialized
INFO - 2020-07-04 15:01:29 --> Language Class Initialized
INFO - 2020-07-04 15:01:29 --> Config Class Initialized
INFO - 2020-07-04 15:01:29 --> Loader Class Initialized
INFO - 2020-07-04 15:01:29 --> Helper loaded: url_helper
INFO - 2020-07-04 15:01:29 --> Helper loaded: main_helper
INFO - 2020-07-04 15:01:29 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:01:29 --> Controller Class Initialized
DEBUG - 2020-07-04 15:01:29 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:01:29 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:01:29 --> Final output sent to browser
DEBUG - 2020-07-04 15:01:29 --> Total execution time: 0.0056
INFO - 2020-07-04 15:01:41 --> Config Class Initialized
INFO - 2020-07-04 15:01:41 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:01:41 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:01:41 --> Utf8 Class Initialized
INFO - 2020-07-04 15:01:41 --> URI Class Initialized
DEBUG - 2020-07-04 15:01:41 --> No URI present. Default controller set.
INFO - 2020-07-04 15:01:41 --> Router Class Initialized
INFO - 2020-07-04 15:01:41 --> Output Class Initialized
INFO - 2020-07-04 15:01:41 --> Security Class Initialized
DEBUG - 2020-07-04 15:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:01:41 --> Input Class Initialized
INFO - 2020-07-04 15:01:41 --> Language Class Initialized
INFO - 2020-07-04 15:01:41 --> Language Class Initialized
INFO - 2020-07-04 15:01:41 --> Config Class Initialized
INFO - 2020-07-04 15:01:41 --> Loader Class Initialized
INFO - 2020-07-04 15:01:41 --> Helper loaded: url_helper
INFO - 2020-07-04 15:01:41 --> Helper loaded: main_helper
INFO - 2020-07-04 15:01:41 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:01:41 --> Controller Class Initialized
DEBUG - 2020-07-04 15:01:41 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:01:41 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:01:41 --> Final output sent to browser
DEBUG - 2020-07-04 15:01:41 --> Total execution time: 0.0047
INFO - 2020-07-04 15:01:57 --> Config Class Initialized
INFO - 2020-07-04 15:01:57 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:01:57 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:01:57 --> Utf8 Class Initialized
INFO - 2020-07-04 15:01:57 --> URI Class Initialized
DEBUG - 2020-07-04 15:01:57 --> No URI present. Default controller set.
INFO - 2020-07-04 15:01:57 --> Router Class Initialized
INFO - 2020-07-04 15:01:57 --> Output Class Initialized
INFO - 2020-07-04 15:01:57 --> Security Class Initialized
DEBUG - 2020-07-04 15:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:01:57 --> Input Class Initialized
INFO - 2020-07-04 15:01:57 --> Language Class Initialized
INFO - 2020-07-04 15:01:57 --> Language Class Initialized
INFO - 2020-07-04 15:01:57 --> Config Class Initialized
INFO - 2020-07-04 15:01:57 --> Loader Class Initialized
INFO - 2020-07-04 15:01:57 --> Helper loaded: url_helper
INFO - 2020-07-04 15:01:57 --> Helper loaded: main_helper
INFO - 2020-07-04 15:01:57 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:01:57 --> Controller Class Initialized
DEBUG - 2020-07-04 15:01:57 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:01:57 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:01:57 --> Final output sent to browser
DEBUG - 2020-07-04 15:01:57 --> Total execution time: 0.0042
INFO - 2020-07-04 15:02:05 --> Config Class Initialized
INFO - 2020-07-04 15:02:05 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:02:05 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:02:05 --> Utf8 Class Initialized
INFO - 2020-07-04 15:02:05 --> URI Class Initialized
DEBUG - 2020-07-04 15:02:05 --> No URI present. Default controller set.
INFO - 2020-07-04 15:02:05 --> Router Class Initialized
INFO - 2020-07-04 15:02:05 --> Output Class Initialized
INFO - 2020-07-04 15:02:05 --> Security Class Initialized
DEBUG - 2020-07-04 15:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:02:05 --> Input Class Initialized
INFO - 2020-07-04 15:02:05 --> Language Class Initialized
INFO - 2020-07-04 15:02:05 --> Language Class Initialized
INFO - 2020-07-04 15:02:05 --> Config Class Initialized
INFO - 2020-07-04 15:02:05 --> Loader Class Initialized
INFO - 2020-07-04 15:02:05 --> Helper loaded: url_helper
INFO - 2020-07-04 15:02:05 --> Helper loaded: main_helper
INFO - 2020-07-04 15:02:05 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:02:05 --> Controller Class Initialized
DEBUG - 2020-07-04 15:02:05 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:02:05 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:02:05 --> Final output sent to browser
DEBUG - 2020-07-04 15:02:05 --> Total execution time: 0.0043
INFO - 2020-07-04 15:03:50 --> Config Class Initialized
INFO - 2020-07-04 15:03:50 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:03:50 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:03:50 --> Utf8 Class Initialized
INFO - 2020-07-04 15:03:50 --> URI Class Initialized
DEBUG - 2020-07-04 15:03:50 --> No URI present. Default controller set.
INFO - 2020-07-04 15:03:50 --> Router Class Initialized
INFO - 2020-07-04 15:03:50 --> Output Class Initialized
INFO - 2020-07-04 15:03:50 --> Security Class Initialized
DEBUG - 2020-07-04 15:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:03:50 --> Input Class Initialized
INFO - 2020-07-04 15:03:50 --> Language Class Initialized
INFO - 2020-07-04 15:03:50 --> Language Class Initialized
INFO - 2020-07-04 15:03:50 --> Config Class Initialized
INFO - 2020-07-04 15:03:50 --> Loader Class Initialized
INFO - 2020-07-04 15:03:50 --> Helper loaded: url_helper
INFO - 2020-07-04 15:03:50 --> Helper loaded: main_helper
INFO - 2020-07-04 15:03:50 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:03:50 --> Controller Class Initialized
DEBUG - 2020-07-04 15:03:50 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:03:50 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:03:50 --> Final output sent to browser
DEBUG - 2020-07-04 15:03:50 --> Total execution time: 0.0056
INFO - 2020-07-04 15:06:30 --> Config Class Initialized
INFO - 2020-07-04 15:06:30 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:06:30 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:06:30 --> Utf8 Class Initialized
INFO - 2020-07-04 15:06:30 --> URI Class Initialized
DEBUG - 2020-07-04 15:06:30 --> No URI present. Default controller set.
INFO - 2020-07-04 15:06:30 --> Router Class Initialized
INFO - 2020-07-04 15:06:30 --> Output Class Initialized
INFO - 2020-07-04 15:06:30 --> Security Class Initialized
DEBUG - 2020-07-04 15:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:06:30 --> Input Class Initialized
INFO - 2020-07-04 15:06:30 --> Language Class Initialized
INFO - 2020-07-04 15:06:30 --> Language Class Initialized
INFO - 2020-07-04 15:06:30 --> Config Class Initialized
INFO - 2020-07-04 15:06:30 --> Loader Class Initialized
INFO - 2020-07-04 15:06:30 --> Helper loaded: url_helper
INFO - 2020-07-04 15:06:30 --> Helper loaded: main_helper
INFO - 2020-07-04 15:06:30 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:06:30 --> Controller Class Initialized
DEBUG - 2020-07-04 15:06:30 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:06:30 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:06:30 --> Final output sent to browser
DEBUG - 2020-07-04 15:06:30 --> Total execution time: 0.0042
INFO - 2020-07-04 15:06:32 --> Config Class Initialized
INFO - 2020-07-04 15:06:32 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:06:32 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:06:32 --> Utf8 Class Initialized
INFO - 2020-07-04 15:06:32 --> URI Class Initialized
DEBUG - 2020-07-04 15:06:32 --> No URI present. Default controller set.
INFO - 2020-07-04 15:06:32 --> Router Class Initialized
INFO - 2020-07-04 15:06:32 --> Output Class Initialized
INFO - 2020-07-04 15:06:32 --> Security Class Initialized
DEBUG - 2020-07-04 15:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:06:32 --> Input Class Initialized
INFO - 2020-07-04 15:06:32 --> Language Class Initialized
INFO - 2020-07-04 15:06:32 --> Language Class Initialized
INFO - 2020-07-04 15:06:32 --> Config Class Initialized
INFO - 2020-07-04 15:06:32 --> Loader Class Initialized
INFO - 2020-07-04 15:06:32 --> Helper loaded: url_helper
INFO - 2020-07-04 15:06:32 --> Helper loaded: main_helper
INFO - 2020-07-04 15:06:32 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:06:32 --> Controller Class Initialized
DEBUG - 2020-07-04 15:06:32 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:06:32 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:06:32 --> Final output sent to browser
DEBUG - 2020-07-04 15:06:32 --> Total execution time: 0.0060
INFO - 2020-07-04 15:06:48 --> Config Class Initialized
INFO - 2020-07-04 15:06:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:06:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:06:48 --> Utf8 Class Initialized
INFO - 2020-07-04 15:06:48 --> URI Class Initialized
DEBUG - 2020-07-04 15:06:48 --> No URI present. Default controller set.
INFO - 2020-07-04 15:06:48 --> Router Class Initialized
INFO - 2020-07-04 15:06:48 --> Output Class Initialized
INFO - 2020-07-04 15:06:48 --> Security Class Initialized
DEBUG - 2020-07-04 15:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:06:48 --> Input Class Initialized
INFO - 2020-07-04 15:06:48 --> Language Class Initialized
INFO - 2020-07-04 15:06:48 --> Language Class Initialized
INFO - 2020-07-04 15:06:48 --> Config Class Initialized
INFO - 2020-07-04 15:06:48 --> Loader Class Initialized
INFO - 2020-07-04 15:06:48 --> Helper loaded: url_helper
INFO - 2020-07-04 15:06:48 --> Helper loaded: main_helper
INFO - 2020-07-04 15:06:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:06:48 --> Controller Class Initialized
DEBUG - 2020-07-04 15:06:48 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:06:48 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:06:48 --> Final output sent to browser
DEBUG - 2020-07-04 15:06:48 --> Total execution time: 0.0046
INFO - 2020-07-04 15:06:56 --> Config Class Initialized
INFO - 2020-07-04 15:06:56 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:06:56 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:06:56 --> Utf8 Class Initialized
INFO - 2020-07-04 15:06:56 --> URI Class Initialized
DEBUG - 2020-07-04 15:06:56 --> No URI present. Default controller set.
INFO - 2020-07-04 15:06:56 --> Router Class Initialized
INFO - 2020-07-04 15:06:56 --> Output Class Initialized
INFO - 2020-07-04 15:06:56 --> Security Class Initialized
DEBUG - 2020-07-04 15:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:06:56 --> Input Class Initialized
INFO - 2020-07-04 15:06:56 --> Language Class Initialized
INFO - 2020-07-04 15:06:56 --> Language Class Initialized
INFO - 2020-07-04 15:06:56 --> Config Class Initialized
INFO - 2020-07-04 15:06:56 --> Loader Class Initialized
INFO - 2020-07-04 15:06:56 --> Helper loaded: url_helper
INFO - 2020-07-04 15:06:56 --> Helper loaded: main_helper
INFO - 2020-07-04 15:06:56 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:06:56 --> Controller Class Initialized
DEBUG - 2020-07-04 15:06:56 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:06:56 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:06:56 --> Final output sent to browser
DEBUG - 2020-07-04 15:06:56 --> Total execution time: 0.0033
INFO - 2020-07-04 15:07:05 --> Config Class Initialized
INFO - 2020-07-04 15:07:05 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:07:05 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:07:05 --> Utf8 Class Initialized
INFO - 2020-07-04 15:07:05 --> URI Class Initialized
DEBUG - 2020-07-04 15:07:05 --> No URI present. Default controller set.
INFO - 2020-07-04 15:07:05 --> Router Class Initialized
INFO - 2020-07-04 15:07:05 --> Output Class Initialized
INFO - 2020-07-04 15:07:05 --> Security Class Initialized
DEBUG - 2020-07-04 15:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:07:05 --> Input Class Initialized
INFO - 2020-07-04 15:07:05 --> Language Class Initialized
INFO - 2020-07-04 15:07:05 --> Language Class Initialized
INFO - 2020-07-04 15:07:05 --> Config Class Initialized
INFO - 2020-07-04 15:07:05 --> Loader Class Initialized
INFO - 2020-07-04 15:07:05 --> Helper loaded: url_helper
INFO - 2020-07-04 15:07:05 --> Helper loaded: main_helper
INFO - 2020-07-04 15:07:05 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:07:05 --> Controller Class Initialized
DEBUG - 2020-07-04 15:07:05 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:07:05 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:07:05 --> Final output sent to browser
DEBUG - 2020-07-04 15:07:05 --> Total execution time: 0.0037
INFO - 2020-07-04 15:07:12 --> Config Class Initialized
INFO - 2020-07-04 15:07:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:07:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:07:12 --> Utf8 Class Initialized
INFO - 2020-07-04 15:07:12 --> URI Class Initialized
DEBUG - 2020-07-04 15:07:12 --> No URI present. Default controller set.
INFO - 2020-07-04 15:07:12 --> Router Class Initialized
INFO - 2020-07-04 15:07:12 --> Output Class Initialized
INFO - 2020-07-04 15:07:12 --> Security Class Initialized
DEBUG - 2020-07-04 15:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:07:12 --> Input Class Initialized
INFO - 2020-07-04 15:07:12 --> Language Class Initialized
INFO - 2020-07-04 15:07:12 --> Language Class Initialized
INFO - 2020-07-04 15:07:12 --> Config Class Initialized
INFO - 2020-07-04 15:07:12 --> Loader Class Initialized
INFO - 2020-07-04 15:07:12 --> Helper loaded: url_helper
INFO - 2020-07-04 15:07:12 --> Helper loaded: main_helper
INFO - 2020-07-04 15:07:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:07:12 --> Controller Class Initialized
DEBUG - 2020-07-04 15:07:12 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:07:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:07:12 --> Final output sent to browser
DEBUG - 2020-07-04 15:07:12 --> Total execution time: 0.0038
INFO - 2020-07-04 15:07:36 --> Config Class Initialized
INFO - 2020-07-04 15:07:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:07:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:07:36 --> Utf8 Class Initialized
INFO - 2020-07-04 15:07:36 --> URI Class Initialized
DEBUG - 2020-07-04 15:07:36 --> No URI present. Default controller set.
INFO - 2020-07-04 15:07:36 --> Router Class Initialized
INFO - 2020-07-04 15:07:36 --> Output Class Initialized
INFO - 2020-07-04 15:07:36 --> Security Class Initialized
DEBUG - 2020-07-04 15:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:07:36 --> Input Class Initialized
INFO - 2020-07-04 15:07:36 --> Language Class Initialized
INFO - 2020-07-04 15:07:36 --> Language Class Initialized
INFO - 2020-07-04 15:07:36 --> Config Class Initialized
INFO - 2020-07-04 15:07:36 --> Loader Class Initialized
INFO - 2020-07-04 15:07:36 --> Helper loaded: url_helper
INFO - 2020-07-04 15:07:36 --> Helper loaded: main_helper
INFO - 2020-07-04 15:07:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:07:36 --> Controller Class Initialized
DEBUG - 2020-07-04 15:07:36 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:07:36 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:07:36 --> Final output sent to browser
DEBUG - 2020-07-04 15:07:36 --> Total execution time: 0.0041
INFO - 2020-07-04 15:08:36 --> Config Class Initialized
INFO - 2020-07-04 15:08:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:08:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:08:36 --> Utf8 Class Initialized
INFO - 2020-07-04 15:08:36 --> URI Class Initialized
DEBUG - 2020-07-04 15:08:36 --> No URI present. Default controller set.
INFO - 2020-07-04 15:08:36 --> Router Class Initialized
INFO - 2020-07-04 15:08:36 --> Output Class Initialized
INFO - 2020-07-04 15:08:36 --> Security Class Initialized
DEBUG - 2020-07-04 15:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:08:36 --> Input Class Initialized
INFO - 2020-07-04 15:08:36 --> Language Class Initialized
INFO - 2020-07-04 15:08:36 --> Language Class Initialized
INFO - 2020-07-04 15:08:36 --> Config Class Initialized
INFO - 2020-07-04 15:08:36 --> Loader Class Initialized
INFO - 2020-07-04 15:08:36 --> Helper loaded: url_helper
INFO - 2020-07-04 15:08:36 --> Helper loaded: main_helper
INFO - 2020-07-04 15:08:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:08:36 --> Controller Class Initialized
DEBUG - 2020-07-04 15:08:36 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:08:36 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:08:36 --> Final output sent to browser
DEBUG - 2020-07-04 15:08:36 --> Total execution time: 0.0036
INFO - 2020-07-04 15:08:57 --> Config Class Initialized
INFO - 2020-07-04 15:08:57 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:08:57 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:08:57 --> Utf8 Class Initialized
INFO - 2020-07-04 15:08:57 --> URI Class Initialized
DEBUG - 2020-07-04 15:08:57 --> No URI present. Default controller set.
INFO - 2020-07-04 15:08:57 --> Router Class Initialized
INFO - 2020-07-04 15:08:57 --> Output Class Initialized
INFO - 2020-07-04 15:08:57 --> Security Class Initialized
DEBUG - 2020-07-04 15:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:08:57 --> Input Class Initialized
INFO - 2020-07-04 15:08:57 --> Language Class Initialized
INFO - 2020-07-04 15:08:57 --> Language Class Initialized
INFO - 2020-07-04 15:08:57 --> Config Class Initialized
INFO - 2020-07-04 15:08:57 --> Loader Class Initialized
INFO - 2020-07-04 15:08:57 --> Helper loaded: url_helper
INFO - 2020-07-04 15:08:57 --> Helper loaded: main_helper
INFO - 2020-07-04 15:08:57 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:08:57 --> Controller Class Initialized
DEBUG - 2020-07-04 15:08:57 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 15:08:57 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:08:57 --> Final output sent to browser
DEBUG - 2020-07-04 15:08:57 --> Total execution time: 0.0036
INFO - 2020-07-04 15:10:15 --> Config Class Initialized
INFO - 2020-07-04 15:10:15 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:10:15 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:10:15 --> Utf8 Class Initialized
INFO - 2020-07-04 15:10:15 --> URI Class Initialized
INFO - 2020-07-04 15:10:15 --> Router Class Initialized
INFO - 2020-07-04 15:10:15 --> Output Class Initialized
INFO - 2020-07-04 15:10:15 --> Security Class Initialized
DEBUG - 2020-07-04 15:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:10:15 --> Input Class Initialized
INFO - 2020-07-04 15:10:15 --> Language Class Initialized
INFO - 2020-07-04 15:10:15 --> Language Class Initialized
INFO - 2020-07-04 15:10:15 --> Config Class Initialized
INFO - 2020-07-04 15:10:15 --> Loader Class Initialized
INFO - 2020-07-04 15:10:15 --> Helper loaded: url_helper
INFO - 2020-07-04 15:10:15 --> Helper loaded: main_helper
INFO - 2020-07-04 15:10:15 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:10:15 --> Controller Class Initialized
INFO - 2020-07-04 15:10:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:10:15 --> Pagination Class Initialized
ERROR - 2020-07-04 15:10:15 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:10:15 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:10:15 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:10:20 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:10:20 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:10:20 --> Final output sent to browser
DEBUG - 2020-07-04 15:10:20 --> Total execution time: 4.4755
INFO - 2020-07-04 15:12:10 --> Config Class Initialized
INFO - 2020-07-04 15:12:10 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:12:10 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:12:10 --> Utf8 Class Initialized
INFO - 2020-07-04 15:12:10 --> URI Class Initialized
INFO - 2020-07-04 15:12:10 --> Router Class Initialized
INFO - 2020-07-04 15:12:10 --> Output Class Initialized
INFO - 2020-07-04 15:12:10 --> Security Class Initialized
DEBUG - 2020-07-04 15:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:12:10 --> Input Class Initialized
INFO - 2020-07-04 15:12:10 --> Language Class Initialized
INFO - 2020-07-04 15:12:10 --> Language Class Initialized
INFO - 2020-07-04 15:12:10 --> Config Class Initialized
INFO - 2020-07-04 15:12:10 --> Loader Class Initialized
INFO - 2020-07-04 15:12:10 --> Helper loaded: url_helper
INFO - 2020-07-04 15:12:10 --> Helper loaded: main_helper
INFO - 2020-07-04 15:12:10 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:12:10 --> Controller Class Initialized
INFO - 2020-07-04 15:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:12:10 --> Pagination Class Initialized
ERROR - 2020-07-04 15:12:10 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:12:10 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:12:10 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:12:10 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:12:10 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:12:10 --> Final output sent to browser
DEBUG - 2020-07-04 15:12:10 --> Total execution time: 0.0064
INFO - 2020-07-04 15:12:24 --> Config Class Initialized
INFO - 2020-07-04 15:12:24 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:12:24 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:12:24 --> Utf8 Class Initialized
INFO - 2020-07-04 15:12:24 --> URI Class Initialized
INFO - 2020-07-04 15:12:24 --> Router Class Initialized
INFO - 2020-07-04 15:12:24 --> Output Class Initialized
INFO - 2020-07-04 15:12:24 --> Security Class Initialized
DEBUG - 2020-07-04 15:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:12:24 --> Input Class Initialized
INFO - 2020-07-04 15:12:24 --> Language Class Initialized
INFO - 2020-07-04 15:12:24 --> Language Class Initialized
INFO - 2020-07-04 15:12:24 --> Config Class Initialized
INFO - 2020-07-04 15:12:24 --> Loader Class Initialized
INFO - 2020-07-04 15:12:24 --> Helper loaded: url_helper
INFO - 2020-07-04 15:12:24 --> Helper loaded: main_helper
INFO - 2020-07-04 15:12:24 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:12:24 --> Controller Class Initialized
INFO - 2020-07-04 15:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:12:24 --> Pagination Class Initialized
ERROR - 2020-07-04 15:12:24 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:12:24 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:12:24 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:12:24 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:12:24 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:12:24 --> Final output sent to browser
DEBUG - 2020-07-04 15:12:24 --> Total execution time: 0.0056
INFO - 2020-07-04 15:12:30 --> Config Class Initialized
INFO - 2020-07-04 15:12:30 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:12:30 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:12:30 --> Utf8 Class Initialized
INFO - 2020-07-04 15:12:30 --> URI Class Initialized
INFO - 2020-07-04 15:12:30 --> Router Class Initialized
INFO - 2020-07-04 15:12:30 --> Output Class Initialized
INFO - 2020-07-04 15:12:30 --> Security Class Initialized
DEBUG - 2020-07-04 15:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:12:30 --> Input Class Initialized
INFO - 2020-07-04 15:12:30 --> Language Class Initialized
INFO - 2020-07-04 15:12:30 --> Language Class Initialized
INFO - 2020-07-04 15:12:30 --> Config Class Initialized
INFO - 2020-07-04 15:12:30 --> Loader Class Initialized
INFO - 2020-07-04 15:12:30 --> Helper loaded: url_helper
INFO - 2020-07-04 15:12:30 --> Helper loaded: main_helper
INFO - 2020-07-04 15:12:30 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:12:30 --> Controller Class Initialized
INFO - 2020-07-04 15:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:12:30 --> Pagination Class Initialized
ERROR - 2020-07-04 15:12:30 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:12:30 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:12:30 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:12:30 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:12:30 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:12:30 --> Final output sent to browser
DEBUG - 2020-07-04 15:12:30 --> Total execution time: 0.0041
INFO - 2020-07-04 15:14:13 --> Config Class Initialized
INFO - 2020-07-04 15:14:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:14:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:14:13 --> Utf8 Class Initialized
INFO - 2020-07-04 15:14:13 --> URI Class Initialized
INFO - 2020-07-04 15:14:13 --> Router Class Initialized
INFO - 2020-07-04 15:14:13 --> Output Class Initialized
INFO - 2020-07-04 15:14:13 --> Security Class Initialized
DEBUG - 2020-07-04 15:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:14:13 --> Input Class Initialized
INFO - 2020-07-04 15:14:13 --> Language Class Initialized
INFO - 2020-07-04 15:14:13 --> Language Class Initialized
INFO - 2020-07-04 15:14:13 --> Config Class Initialized
INFO - 2020-07-04 15:14:13 --> Loader Class Initialized
INFO - 2020-07-04 15:14:13 --> Helper loaded: url_helper
INFO - 2020-07-04 15:14:13 --> Helper loaded: main_helper
INFO - 2020-07-04 15:14:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:14:13 --> Controller Class Initialized
INFO - 2020-07-04 15:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:14:13 --> Pagination Class Initialized
ERROR - 2020-07-04 15:14:13 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:14:13 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:14:13 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:14:13 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:14:13 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:14:13 --> Final output sent to browser
DEBUG - 2020-07-04 15:14:13 --> Total execution time: 0.0072
INFO - 2020-07-04 15:15:19 --> Config Class Initialized
INFO - 2020-07-04 15:15:19 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:15:19 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:15:19 --> Utf8 Class Initialized
INFO - 2020-07-04 15:15:19 --> URI Class Initialized
INFO - 2020-07-04 15:15:19 --> Router Class Initialized
INFO - 2020-07-04 15:15:19 --> Output Class Initialized
INFO - 2020-07-04 15:15:19 --> Security Class Initialized
DEBUG - 2020-07-04 15:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:15:19 --> Input Class Initialized
INFO - 2020-07-04 15:15:19 --> Language Class Initialized
INFO - 2020-07-04 15:15:19 --> Language Class Initialized
INFO - 2020-07-04 15:15:19 --> Config Class Initialized
INFO - 2020-07-04 15:15:19 --> Loader Class Initialized
INFO - 2020-07-04 15:15:19 --> Helper loaded: url_helper
INFO - 2020-07-04 15:15:19 --> Helper loaded: main_helper
INFO - 2020-07-04 15:15:19 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:15:19 --> Controller Class Initialized
INFO - 2020-07-04 15:15:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:15:19 --> Pagination Class Initialized
ERROR - 2020-07-04 15:15:19 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:15:19 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:15:19 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:15:19 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:15:19 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:15:19 --> Final output sent to browser
DEBUG - 2020-07-04 15:15:19 --> Total execution time: 0.0063
INFO - 2020-07-04 15:15:29 --> Config Class Initialized
INFO - 2020-07-04 15:15:29 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:15:29 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:15:29 --> Utf8 Class Initialized
INFO - 2020-07-04 15:15:29 --> URI Class Initialized
INFO - 2020-07-04 15:15:29 --> Router Class Initialized
INFO - 2020-07-04 15:15:29 --> Output Class Initialized
INFO - 2020-07-04 15:15:29 --> Security Class Initialized
DEBUG - 2020-07-04 15:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:15:29 --> Input Class Initialized
INFO - 2020-07-04 15:15:29 --> Language Class Initialized
INFO - 2020-07-04 15:15:29 --> Language Class Initialized
INFO - 2020-07-04 15:15:29 --> Config Class Initialized
INFO - 2020-07-04 15:15:29 --> Loader Class Initialized
INFO - 2020-07-04 15:15:29 --> Helper loaded: url_helper
INFO - 2020-07-04 15:15:29 --> Helper loaded: main_helper
INFO - 2020-07-04 15:15:29 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:15:29 --> Controller Class Initialized
INFO - 2020-07-04 15:15:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:15:29 --> Pagination Class Initialized
ERROR - 2020-07-04 15:15:29 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:15:29 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:15:29 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:15:31 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:15:31 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:15:31 --> Final output sent to browser
DEBUG - 2020-07-04 15:15:31 --> Total execution time: 2.5721
INFO - 2020-07-04 15:15:50 --> Config Class Initialized
INFO - 2020-07-04 15:15:50 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:15:50 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:15:50 --> Utf8 Class Initialized
INFO - 2020-07-04 15:15:50 --> URI Class Initialized
INFO - 2020-07-04 15:15:50 --> Router Class Initialized
INFO - 2020-07-04 15:15:50 --> Output Class Initialized
INFO - 2020-07-04 15:15:50 --> Security Class Initialized
DEBUG - 2020-07-04 15:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:15:50 --> Input Class Initialized
INFO - 2020-07-04 15:15:50 --> Language Class Initialized
INFO - 2020-07-04 15:15:50 --> Language Class Initialized
INFO - 2020-07-04 15:15:50 --> Config Class Initialized
INFO - 2020-07-04 15:15:50 --> Loader Class Initialized
INFO - 2020-07-04 15:15:50 --> Helper loaded: url_helper
INFO - 2020-07-04 15:15:50 --> Helper loaded: main_helper
INFO - 2020-07-04 15:15:50 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:15:50 --> Controller Class Initialized
INFO - 2020-07-04 15:15:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:15:50 --> Pagination Class Initialized
ERROR - 2020-07-04 15:15:50 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:15:50 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:15:50 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:15:50 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:15:50 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:15:50 --> Final output sent to browser
DEBUG - 2020-07-04 15:15:50 --> Total execution time: 0.0072
INFO - 2020-07-04 15:17:08 --> Config Class Initialized
INFO - 2020-07-04 15:17:08 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:17:08 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:17:08 --> Utf8 Class Initialized
INFO - 2020-07-04 15:17:08 --> URI Class Initialized
INFO - 2020-07-04 15:17:08 --> Router Class Initialized
INFO - 2020-07-04 15:17:08 --> Output Class Initialized
INFO - 2020-07-04 15:17:08 --> Security Class Initialized
DEBUG - 2020-07-04 15:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:17:08 --> Input Class Initialized
INFO - 2020-07-04 15:17:08 --> Language Class Initialized
INFO - 2020-07-04 15:17:08 --> Language Class Initialized
INFO - 2020-07-04 15:17:08 --> Config Class Initialized
INFO - 2020-07-04 15:17:08 --> Loader Class Initialized
INFO - 2020-07-04 15:17:08 --> Helper loaded: url_helper
INFO - 2020-07-04 15:17:08 --> Helper loaded: main_helper
INFO - 2020-07-04 15:17:08 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:17:08 --> Controller Class Initialized
INFO - 2020-07-04 15:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:17:08 --> Pagination Class Initialized
ERROR - 2020-07-04 15:17:08 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:17:08 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:17:08 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:17:08 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:17:08 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:17:08 --> Final output sent to browser
DEBUG - 2020-07-04 15:17:08 --> Total execution time: 0.0054
INFO - 2020-07-04 15:18:02 --> Config Class Initialized
INFO - 2020-07-04 15:18:02 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:18:02 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:18:02 --> Utf8 Class Initialized
INFO - 2020-07-04 15:18:02 --> URI Class Initialized
INFO - 2020-07-04 15:18:02 --> Router Class Initialized
INFO - 2020-07-04 15:18:02 --> Output Class Initialized
INFO - 2020-07-04 15:18:02 --> Security Class Initialized
DEBUG - 2020-07-04 15:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:18:02 --> Input Class Initialized
INFO - 2020-07-04 15:18:02 --> Language Class Initialized
INFO - 2020-07-04 15:18:02 --> Language Class Initialized
INFO - 2020-07-04 15:18:02 --> Config Class Initialized
INFO - 2020-07-04 15:18:02 --> Loader Class Initialized
INFO - 2020-07-04 15:18:02 --> Helper loaded: url_helper
INFO - 2020-07-04 15:18:02 --> Helper loaded: main_helper
INFO - 2020-07-04 15:18:02 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:18:02 --> Controller Class Initialized
INFO - 2020-07-04 15:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:18:02 --> Pagination Class Initialized
ERROR - 2020-07-04 15:18:02 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:18:02 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:18:02 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:18:02 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:18:02 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:18:02 --> Final output sent to browser
DEBUG - 2020-07-04 15:18:02 --> Total execution time: 0.0052
INFO - 2020-07-04 15:18:25 --> Config Class Initialized
INFO - 2020-07-04 15:18:25 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:18:25 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:18:25 --> Utf8 Class Initialized
INFO - 2020-07-04 15:18:25 --> URI Class Initialized
INFO - 2020-07-04 15:18:25 --> Router Class Initialized
INFO - 2020-07-04 15:18:25 --> Output Class Initialized
INFO - 2020-07-04 15:18:25 --> Security Class Initialized
DEBUG - 2020-07-04 15:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:18:25 --> Input Class Initialized
INFO - 2020-07-04 15:18:25 --> Language Class Initialized
INFO - 2020-07-04 15:18:25 --> Language Class Initialized
INFO - 2020-07-04 15:18:25 --> Config Class Initialized
INFO - 2020-07-04 15:18:25 --> Loader Class Initialized
INFO - 2020-07-04 15:18:25 --> Helper loaded: url_helper
INFO - 2020-07-04 15:18:25 --> Helper loaded: main_helper
INFO - 2020-07-04 15:18:25 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:18:25 --> Controller Class Initialized
INFO - 2020-07-04 15:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:18:25 --> Pagination Class Initialized
ERROR - 2020-07-04 15:18:25 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:18:25 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:18:25 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:18:25 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:18:25 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:18:25 --> Final output sent to browser
DEBUG - 2020-07-04 15:18:25 --> Total execution time: 0.0042
INFO - 2020-07-04 15:19:06 --> Config Class Initialized
INFO - 2020-07-04 15:19:06 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:19:06 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:19:06 --> Utf8 Class Initialized
INFO - 2020-07-04 15:19:06 --> URI Class Initialized
INFO - 2020-07-04 15:19:06 --> Router Class Initialized
INFO - 2020-07-04 15:19:06 --> Output Class Initialized
INFO - 2020-07-04 15:19:06 --> Security Class Initialized
DEBUG - 2020-07-04 15:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:19:06 --> Input Class Initialized
INFO - 2020-07-04 15:19:06 --> Language Class Initialized
INFO - 2020-07-04 15:19:06 --> Language Class Initialized
INFO - 2020-07-04 15:19:06 --> Config Class Initialized
INFO - 2020-07-04 15:19:06 --> Loader Class Initialized
INFO - 2020-07-04 15:19:06 --> Helper loaded: url_helper
INFO - 2020-07-04 15:19:06 --> Helper loaded: main_helper
INFO - 2020-07-04 15:19:06 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:19:06 --> Controller Class Initialized
INFO - 2020-07-04 15:19:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:19:06 --> Pagination Class Initialized
ERROR - 2020-07-04 15:19:06 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:19:06 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:19:06 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:19:06 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:19:06 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:19:06 --> Final output sent to browser
DEBUG - 2020-07-04 15:19:06 --> Total execution time: 0.0067
INFO - 2020-07-04 15:56:37 --> Config Class Initialized
INFO - 2020-07-04 15:56:37 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:56:37 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:56:37 --> Utf8 Class Initialized
INFO - 2020-07-04 15:56:37 --> URI Class Initialized
INFO - 2020-07-04 15:56:37 --> Router Class Initialized
INFO - 2020-07-04 15:56:37 --> Output Class Initialized
INFO - 2020-07-04 15:56:37 --> Security Class Initialized
DEBUG - 2020-07-04 15:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:56:37 --> Input Class Initialized
INFO - 2020-07-04 15:56:37 --> Language Class Initialized
INFO - 2020-07-04 15:56:37 --> Language Class Initialized
INFO - 2020-07-04 15:56:37 --> Config Class Initialized
INFO - 2020-07-04 15:56:37 --> Loader Class Initialized
INFO - 2020-07-04 15:56:37 --> Helper loaded: url_helper
INFO - 2020-07-04 15:56:37 --> Helper loaded: main_helper
INFO - 2020-07-04 15:56:37 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:56:37 --> Controller Class Initialized
INFO - 2020-07-04 15:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:56:37 --> Pagination Class Initialized
ERROR - 2020-07-04 15:56:37 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:56:37 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:56:37 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:56:39 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:56:39 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:56:39 --> Final output sent to browser
DEBUG - 2020-07-04 15:56:39 --> Total execution time: 1.9328
INFO - 2020-07-04 15:57:01 --> Config Class Initialized
INFO - 2020-07-04 15:57:01 --> Hooks Class Initialized
DEBUG - 2020-07-04 15:57:01 --> UTF-8 Support Enabled
INFO - 2020-07-04 15:57:01 --> Utf8 Class Initialized
INFO - 2020-07-04 15:57:01 --> URI Class Initialized
INFO - 2020-07-04 15:57:01 --> Router Class Initialized
INFO - 2020-07-04 15:57:01 --> Output Class Initialized
INFO - 2020-07-04 15:57:01 --> Security Class Initialized
DEBUG - 2020-07-04 15:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 15:57:01 --> Input Class Initialized
INFO - 2020-07-04 15:57:01 --> Language Class Initialized
INFO - 2020-07-04 15:57:01 --> Language Class Initialized
INFO - 2020-07-04 15:57:01 --> Config Class Initialized
INFO - 2020-07-04 15:57:01 --> Loader Class Initialized
INFO - 2020-07-04 15:57:01 --> Helper loaded: url_helper
INFO - 2020-07-04 15:57:01 --> Helper loaded: main_helper
INFO - 2020-07-04 15:57:01 --> Database Driver Class Initialized
DEBUG - 2020-07-04 15:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 15:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 15:57:01 --> Controller Class Initialized
INFO - 2020-07-04 15:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 15:57:01 --> Pagination Class Initialized
ERROR - 2020-07-04 15:57:01 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 15:57:01 --> Helper loaded: file_helper
DEBUG - 2020-07-04 15:57:01 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 15:57:01 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 15:57:01 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 15:57:01 --> Final output sent to browser
DEBUG - 2020-07-04 15:57:01 --> Total execution time: 0.0049
INFO - 2020-07-04 16:01:18 --> Config Class Initialized
INFO - 2020-07-04 16:01:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:01:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:01:18 --> Utf8 Class Initialized
INFO - 2020-07-04 16:01:18 --> URI Class Initialized
INFO - 2020-07-04 16:01:18 --> Router Class Initialized
INFO - 2020-07-04 16:01:18 --> Output Class Initialized
INFO - 2020-07-04 16:01:18 --> Security Class Initialized
DEBUG - 2020-07-04 16:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:01:18 --> Input Class Initialized
INFO - 2020-07-04 16:01:18 --> Language Class Initialized
INFO - 2020-07-04 16:01:18 --> Language Class Initialized
INFO - 2020-07-04 16:01:18 --> Config Class Initialized
INFO - 2020-07-04 16:01:18 --> Loader Class Initialized
INFO - 2020-07-04 16:01:18 --> Helper loaded: url_helper
INFO - 2020-07-04 16:01:18 --> Helper loaded: main_helper
INFO - 2020-07-04 16:01:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:01:18 --> Controller Class Initialized
INFO - 2020-07-04 16:01:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 16:01:18 --> Pagination Class Initialized
ERROR - 2020-07-04 16:01:18 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 16:01:18 --> Helper loaded: file_helper
DEBUG - 2020-07-04 16:01:18 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 16:01:18 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 16:01:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:01:18 --> Final output sent to browser
DEBUG - 2020-07-04 16:01:18 --> Total execution time: 0.0046
INFO - 2020-07-04 16:01:36 --> Config Class Initialized
INFO - 2020-07-04 16:01:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:01:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:01:36 --> Utf8 Class Initialized
INFO - 2020-07-04 16:01:36 --> URI Class Initialized
INFO - 2020-07-04 16:01:36 --> Router Class Initialized
INFO - 2020-07-04 16:01:36 --> Output Class Initialized
INFO - 2020-07-04 16:01:36 --> Security Class Initialized
DEBUG - 2020-07-04 16:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:01:36 --> Input Class Initialized
INFO - 2020-07-04 16:01:36 --> Language Class Initialized
INFO - 2020-07-04 16:01:36 --> Language Class Initialized
INFO - 2020-07-04 16:01:36 --> Config Class Initialized
INFO - 2020-07-04 16:01:36 --> Loader Class Initialized
INFO - 2020-07-04 16:01:36 --> Helper loaded: url_helper
INFO - 2020-07-04 16:01:36 --> Helper loaded: main_helper
INFO - 2020-07-04 16:01:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:01:36 --> Controller Class Initialized
INFO - 2020-07-04 16:01:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 16:01:36 --> Pagination Class Initialized
ERROR - 2020-07-04 16:01:36 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 16:01:36 --> Helper loaded: file_helper
DEBUG - 2020-07-04 16:01:36 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 16:01:36 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 16:01:36 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:01:36 --> Final output sent to browser
DEBUG - 2020-07-04 16:01:36 --> Total execution time: 0.0045
INFO - 2020-07-04 16:01:52 --> Config Class Initialized
INFO - 2020-07-04 16:01:52 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:01:52 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:01:52 --> Utf8 Class Initialized
INFO - 2020-07-04 16:01:52 --> URI Class Initialized
INFO - 2020-07-04 16:01:52 --> Router Class Initialized
INFO - 2020-07-04 16:01:52 --> Output Class Initialized
INFO - 2020-07-04 16:01:52 --> Security Class Initialized
DEBUG - 2020-07-04 16:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:01:52 --> Input Class Initialized
INFO - 2020-07-04 16:01:52 --> Language Class Initialized
INFO - 2020-07-04 16:01:52 --> Language Class Initialized
INFO - 2020-07-04 16:01:52 --> Config Class Initialized
INFO - 2020-07-04 16:01:52 --> Loader Class Initialized
INFO - 2020-07-04 16:01:52 --> Helper loaded: url_helper
INFO - 2020-07-04 16:01:52 --> Helper loaded: main_helper
INFO - 2020-07-04 16:01:52 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:01:52 --> Controller Class Initialized
INFO - 2020-07-04 16:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 16:01:52 --> Pagination Class Initialized
ERROR - 2020-07-04 16:01:52 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 16:01:52 --> Helper loaded: file_helper
DEBUG - 2020-07-04 16:01:52 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 16:01:55 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 16:01:55 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:01:55 --> Final output sent to browser
DEBUG - 2020-07-04 16:01:55 --> Total execution time: 2.3468
INFO - 2020-07-04 16:02:03 --> Config Class Initialized
INFO - 2020-07-04 16:02:03 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:02:03 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:02:03 --> Utf8 Class Initialized
INFO - 2020-07-04 16:02:03 --> URI Class Initialized
INFO - 2020-07-04 16:02:03 --> Router Class Initialized
INFO - 2020-07-04 16:02:03 --> Output Class Initialized
INFO - 2020-07-04 16:02:03 --> Security Class Initialized
DEBUG - 2020-07-04 16:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:02:03 --> Input Class Initialized
INFO - 2020-07-04 16:02:03 --> Language Class Initialized
INFO - 2020-07-04 16:02:03 --> Language Class Initialized
INFO - 2020-07-04 16:02:03 --> Config Class Initialized
INFO - 2020-07-04 16:02:03 --> Loader Class Initialized
INFO - 2020-07-04 16:02:03 --> Helper loaded: url_helper
INFO - 2020-07-04 16:02:03 --> Helper loaded: main_helper
INFO - 2020-07-04 16:02:03 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:02:03 --> Controller Class Initialized
INFO - 2020-07-04 16:02:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 16:02:03 --> Pagination Class Initialized
ERROR - 2020-07-04 16:02:03 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 16:02:03 --> Helper loaded: file_helper
DEBUG - 2020-07-04 16:02:03 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 16:02:04 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 16:02:04 --> Final output sent to browser
DEBUG - 2020-07-04 16:02:04 --> Total execution time: 1.6344
INFO - 2020-07-04 16:02:12 --> Config Class Initialized
INFO - 2020-07-04 16:02:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:02:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:02:12 --> Utf8 Class Initialized
INFO - 2020-07-04 16:02:12 --> URI Class Initialized
INFO - 2020-07-04 16:02:12 --> Router Class Initialized
INFO - 2020-07-04 16:02:12 --> Output Class Initialized
INFO - 2020-07-04 16:02:12 --> Security Class Initialized
DEBUG - 2020-07-04 16:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:02:12 --> Input Class Initialized
INFO - 2020-07-04 16:02:12 --> Language Class Initialized
INFO - 2020-07-04 16:02:12 --> Language Class Initialized
INFO - 2020-07-04 16:02:12 --> Config Class Initialized
INFO - 2020-07-04 16:02:12 --> Loader Class Initialized
INFO - 2020-07-04 16:02:12 --> Helper loaded: url_helper
INFO - 2020-07-04 16:02:12 --> Helper loaded: main_helper
INFO - 2020-07-04 16:02:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:02:12 --> Controller Class Initialized
INFO - 2020-07-04 16:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 16:02:12 --> Pagination Class Initialized
ERROR - 2020-07-04 16:02:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 16:02:12 --> Helper loaded: file_helper
DEBUG - 2020-07-04 16:02:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 16:02:13 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 16:02:13 --> Final output sent to browser
DEBUG - 2020-07-04 16:02:13 --> Total execution time: 1.6395
INFO - 2020-07-04 16:02:40 --> Config Class Initialized
INFO - 2020-07-04 16:02:40 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:02:40 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:02:40 --> Utf8 Class Initialized
INFO - 2020-07-04 16:02:40 --> URI Class Initialized
INFO - 2020-07-04 16:02:40 --> Router Class Initialized
INFO - 2020-07-04 16:02:40 --> Output Class Initialized
INFO - 2020-07-04 16:02:40 --> Security Class Initialized
DEBUG - 2020-07-04 16:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:02:40 --> Input Class Initialized
INFO - 2020-07-04 16:02:40 --> Language Class Initialized
INFO - 2020-07-04 16:02:40 --> Language Class Initialized
INFO - 2020-07-04 16:02:40 --> Config Class Initialized
INFO - 2020-07-04 16:02:40 --> Loader Class Initialized
INFO - 2020-07-04 16:02:40 --> Helper loaded: url_helper
INFO - 2020-07-04 16:02:40 --> Helper loaded: main_helper
INFO - 2020-07-04 16:02:40 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:02:40 --> Controller Class Initialized
INFO - 2020-07-04 16:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 16:02:40 --> Pagination Class Initialized
ERROR - 2020-07-04 16:02:40 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 16:02:40 --> Helper loaded: file_helper
DEBUG - 2020-07-04 16:02:40 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 16:02:40 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 16:02:40 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:02:40 --> Final output sent to browser
DEBUG - 2020-07-04 16:02:40 --> Total execution time: 0.0080
INFO - 2020-07-04 16:02:47 --> Config Class Initialized
INFO - 2020-07-04 16:02:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:02:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:02:47 --> Utf8 Class Initialized
INFO - 2020-07-04 16:02:47 --> URI Class Initialized
INFO - 2020-07-04 16:02:47 --> Router Class Initialized
INFO - 2020-07-04 16:02:47 --> Output Class Initialized
INFO - 2020-07-04 16:02:47 --> Security Class Initialized
DEBUG - 2020-07-04 16:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:02:47 --> Input Class Initialized
INFO - 2020-07-04 16:02:47 --> Language Class Initialized
INFO - 2020-07-04 16:02:47 --> Language Class Initialized
INFO - 2020-07-04 16:02:47 --> Config Class Initialized
INFO - 2020-07-04 16:02:47 --> Loader Class Initialized
INFO - 2020-07-04 16:02:47 --> Helper loaded: url_helper
INFO - 2020-07-04 16:02:47 --> Helper loaded: main_helper
INFO - 2020-07-04 16:02:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:02:47 --> Controller Class Initialized
INFO - 2020-07-04 16:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 16:02:47 --> Pagination Class Initialized
ERROR - 2020-07-04 16:02:47 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 16:02:47 --> Helper loaded: file_helper
DEBUG - 2020-07-04 16:02:47 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 16:02:49 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 16:02:49 --> Final output sent to browser
DEBUG - 2020-07-04 16:02:49 --> Total execution time: 1.6362
INFO - 2020-07-04 16:03:09 --> Config Class Initialized
INFO - 2020-07-04 16:03:09 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:03:09 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:03:09 --> Utf8 Class Initialized
INFO - 2020-07-04 16:03:09 --> URI Class Initialized
INFO - 2020-07-04 16:03:09 --> Router Class Initialized
INFO - 2020-07-04 16:03:09 --> Output Class Initialized
INFO - 2020-07-04 16:03:09 --> Security Class Initialized
DEBUG - 2020-07-04 16:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:03:09 --> Input Class Initialized
INFO - 2020-07-04 16:03:09 --> Language Class Initialized
INFO - 2020-07-04 16:03:09 --> Language Class Initialized
INFO - 2020-07-04 16:03:09 --> Config Class Initialized
INFO - 2020-07-04 16:03:09 --> Loader Class Initialized
INFO - 2020-07-04 16:03:09 --> Helper loaded: url_helper
INFO - 2020-07-04 16:03:09 --> Helper loaded: main_helper
INFO - 2020-07-04 16:03:09 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:03:09 --> Controller Class Initialized
INFO - 2020-07-04 16:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 16:03:09 --> Pagination Class Initialized
ERROR - 2020-07-04 16:03:09 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 16:03:09 --> Helper loaded: file_helper
DEBUG - 2020-07-04 16:03:09 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 16:03:09 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 16:03:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:03:09 --> Final output sent to browser
DEBUG - 2020-07-04 16:03:09 --> Total execution time: 0.0063
INFO - 2020-07-04 16:03:12 --> Config Class Initialized
INFO - 2020-07-04 16:03:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:03:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:03:12 --> Utf8 Class Initialized
INFO - 2020-07-04 16:03:12 --> URI Class Initialized
INFO - 2020-07-04 16:03:12 --> Router Class Initialized
INFO - 2020-07-04 16:03:12 --> Output Class Initialized
INFO - 2020-07-04 16:03:12 --> Security Class Initialized
DEBUG - 2020-07-04 16:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:03:12 --> Input Class Initialized
INFO - 2020-07-04 16:03:12 --> Language Class Initialized
INFO - 2020-07-04 16:03:12 --> Language Class Initialized
INFO - 2020-07-04 16:03:12 --> Config Class Initialized
INFO - 2020-07-04 16:03:12 --> Loader Class Initialized
INFO - 2020-07-04 16:03:12 --> Helper loaded: url_helper
INFO - 2020-07-04 16:03:12 --> Helper loaded: main_helper
INFO - 2020-07-04 16:03:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:03:12 --> Controller Class Initialized
INFO - 2020-07-04 16:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 16:03:12 --> Pagination Class Initialized
ERROR - 2020-07-04 16:03:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 16:03:12 --> Helper loaded: file_helper
DEBUG - 2020-07-04 16:03:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 16:03:13 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 16:03:13 --> Final output sent to browser
DEBUG - 2020-07-04 16:03:13 --> Total execution time: 1.5150
INFO - 2020-07-04 16:05:39 --> Config Class Initialized
INFO - 2020-07-04 16:05:39 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:05:39 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:05:39 --> Utf8 Class Initialized
INFO - 2020-07-04 16:05:39 --> URI Class Initialized
INFO - 2020-07-04 16:05:39 --> Router Class Initialized
INFO - 2020-07-04 16:05:39 --> Output Class Initialized
INFO - 2020-07-04 16:05:39 --> Security Class Initialized
DEBUG - 2020-07-04 16:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:05:39 --> Input Class Initialized
INFO - 2020-07-04 16:05:39 --> Language Class Initialized
INFO - 2020-07-04 16:05:39 --> Language Class Initialized
INFO - 2020-07-04 16:05:39 --> Config Class Initialized
INFO - 2020-07-04 16:05:39 --> Loader Class Initialized
INFO - 2020-07-04 16:05:39 --> Helper loaded: url_helper
INFO - 2020-07-04 16:05:39 --> Helper loaded: main_helper
INFO - 2020-07-04 16:05:39 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:05:39 --> Controller Class Initialized
INFO - 2020-07-04 16:05:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 16:05:39 --> Pagination Class Initialized
ERROR - 2020-07-04 16:05:39 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 16:05:39 --> Helper loaded: file_helper
DEBUG - 2020-07-04 16:05:39 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 16:05:39 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 16:05:39 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:05:39 --> Final output sent to browser
DEBUG - 2020-07-04 16:05:39 --> Total execution time: 0.0066
INFO - 2020-07-04 16:06:35 --> Config Class Initialized
INFO - 2020-07-04 16:06:35 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:06:35 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:06:35 --> Utf8 Class Initialized
INFO - 2020-07-04 16:06:35 --> URI Class Initialized
INFO - 2020-07-04 16:06:35 --> Router Class Initialized
INFO - 2020-07-04 16:06:35 --> Output Class Initialized
INFO - 2020-07-04 16:06:35 --> Security Class Initialized
DEBUG - 2020-07-04 16:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:06:35 --> Input Class Initialized
INFO - 2020-07-04 16:06:35 --> Language Class Initialized
INFO - 2020-07-04 16:06:35 --> Language Class Initialized
INFO - 2020-07-04 16:06:35 --> Config Class Initialized
INFO - 2020-07-04 16:06:35 --> Loader Class Initialized
INFO - 2020-07-04 16:06:35 --> Helper loaded: url_helper
INFO - 2020-07-04 16:06:35 --> Helper loaded: main_helper
INFO - 2020-07-04 16:06:35 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:06:35 --> Controller Class Initialized
INFO - 2020-07-04 16:06:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 16:06:35 --> Pagination Class Initialized
ERROR - 2020-07-04 16:06:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 16:06:35 --> Helper loaded: file_helper
DEBUG - 2020-07-04 16:06:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 16:06:35 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 16:06:35 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:06:35 --> Final output sent to browser
DEBUG - 2020-07-04 16:06:35 --> Total execution time: 0.0059
INFO - 2020-07-04 16:07:19 --> Config Class Initialized
INFO - 2020-07-04 16:07:19 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:07:19 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:07:19 --> Utf8 Class Initialized
INFO - 2020-07-04 16:07:19 --> URI Class Initialized
INFO - 2020-07-04 16:07:19 --> Router Class Initialized
INFO - 2020-07-04 16:07:19 --> Output Class Initialized
INFO - 2020-07-04 16:07:19 --> Security Class Initialized
DEBUG - 2020-07-04 16:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:07:19 --> Input Class Initialized
INFO - 2020-07-04 16:07:19 --> Language Class Initialized
INFO - 2020-07-04 16:07:19 --> Language Class Initialized
INFO - 2020-07-04 16:07:19 --> Config Class Initialized
INFO - 2020-07-04 16:07:19 --> Loader Class Initialized
INFO - 2020-07-04 16:07:19 --> Helper loaded: url_helper
INFO - 2020-07-04 16:07:19 --> Helper loaded: main_helper
INFO - 2020-07-04 16:07:19 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:07:19 --> Controller Class Initialized
INFO - 2020-07-04 16:07:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 16:07:19 --> Pagination Class Initialized
ERROR - 2020-07-04 16:07:19 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 16:07:19 --> Helper loaded: file_helper
DEBUG - 2020-07-04 16:07:19 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 16:07:21 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 16:07:21 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:07:21 --> Final output sent to browser
DEBUG - 2020-07-04 16:07:21 --> Total execution time: 1.8967
INFO - 2020-07-04 16:10:25 --> Config Class Initialized
INFO - 2020-07-04 16:10:25 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:10:25 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:10:25 --> Utf8 Class Initialized
INFO - 2020-07-04 16:10:25 --> URI Class Initialized
DEBUG - 2020-07-04 16:10:25 --> No URI present. Default controller set.
INFO - 2020-07-04 16:10:25 --> Router Class Initialized
INFO - 2020-07-04 16:10:25 --> Output Class Initialized
INFO - 2020-07-04 16:10:25 --> Security Class Initialized
DEBUG - 2020-07-04 16:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:10:25 --> Input Class Initialized
INFO - 2020-07-04 16:10:25 --> Language Class Initialized
INFO - 2020-07-04 16:10:25 --> Language Class Initialized
INFO - 2020-07-04 16:10:25 --> Config Class Initialized
INFO - 2020-07-04 16:10:25 --> Loader Class Initialized
INFO - 2020-07-04 16:10:25 --> Helper loaded: url_helper
INFO - 2020-07-04 16:10:25 --> Helper loaded: main_helper
INFO - 2020-07-04 16:10:25 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:10:25 --> Controller Class Initialized
DEBUG - 2020-07-04 16:10:25 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 16:10:25 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:10:25 --> Final output sent to browser
DEBUG - 2020-07-04 16:10:25 --> Total execution time: 0.0041
INFO - 2020-07-04 16:12:07 --> Config Class Initialized
INFO - 2020-07-04 16:12:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:12:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:12:07 --> Utf8 Class Initialized
INFO - 2020-07-04 16:12:07 --> URI Class Initialized
DEBUG - 2020-07-04 16:12:07 --> No URI present. Default controller set.
INFO - 2020-07-04 16:12:07 --> Router Class Initialized
INFO - 2020-07-04 16:12:07 --> Output Class Initialized
INFO - 2020-07-04 16:12:07 --> Security Class Initialized
DEBUG - 2020-07-04 16:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:12:07 --> Input Class Initialized
INFO - 2020-07-04 16:12:07 --> Language Class Initialized
INFO - 2020-07-04 16:12:07 --> Language Class Initialized
INFO - 2020-07-04 16:12:07 --> Config Class Initialized
INFO - 2020-07-04 16:12:07 --> Loader Class Initialized
INFO - 2020-07-04 16:12:07 --> Helper loaded: url_helper
INFO - 2020-07-04 16:12:07 --> Helper loaded: main_helper
INFO - 2020-07-04 16:12:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:12:07 --> Controller Class Initialized
DEBUG - 2020-07-04 16:12:07 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 16:12:07 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:12:07 --> Final output sent to browser
DEBUG - 2020-07-04 16:12:07 --> Total execution time: 0.0040
INFO - 2020-07-04 16:12:35 --> Config Class Initialized
INFO - 2020-07-04 16:12:35 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:12:35 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:12:35 --> Utf8 Class Initialized
INFO - 2020-07-04 16:12:35 --> URI Class Initialized
INFO - 2020-07-04 16:12:35 --> Router Class Initialized
INFO - 2020-07-04 16:12:35 --> Output Class Initialized
INFO - 2020-07-04 16:12:35 --> Security Class Initialized
DEBUG - 2020-07-04 16:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:12:35 --> Input Class Initialized
INFO - 2020-07-04 16:12:35 --> Language Class Initialized
INFO - 2020-07-04 16:12:35 --> Language Class Initialized
INFO - 2020-07-04 16:12:35 --> Config Class Initialized
INFO - 2020-07-04 16:12:35 --> Loader Class Initialized
INFO - 2020-07-04 16:12:35 --> Helper loaded: url_helper
INFO - 2020-07-04 16:12:35 --> Helper loaded: main_helper
INFO - 2020-07-04 16:12:35 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:12:35 --> Controller Class Initialized
DEBUG - 2020-07-04 16:12:35 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:12:35 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:12:35 --> Final output sent to browser
DEBUG - 2020-07-04 16:12:35 --> Total execution time: 0.0086
INFO - 2020-07-04 16:12:36 --> Config Class Initialized
INFO - 2020-07-04 16:12:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:12:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:12:36 --> Utf8 Class Initialized
INFO - 2020-07-04 16:12:36 --> URI Class Initialized
INFO - 2020-07-04 16:12:36 --> Router Class Initialized
INFO - 2020-07-04 16:12:36 --> Output Class Initialized
INFO - 2020-07-04 16:12:36 --> Security Class Initialized
DEBUG - 2020-07-04 16:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:12:36 --> Input Class Initialized
INFO - 2020-07-04 16:12:36 --> Language Class Initialized
INFO - 2020-07-04 16:12:36 --> Language Class Initialized
INFO - 2020-07-04 16:12:36 --> Config Class Initialized
INFO - 2020-07-04 16:12:36 --> Loader Class Initialized
INFO - 2020-07-04 16:12:36 --> Helper loaded: url_helper
INFO - 2020-07-04 16:12:36 --> Helper loaded: main_helper
INFO - 2020-07-04 16:12:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:12:36 --> Controller Class Initialized
INFO - 2020-07-04 16:12:36 --> Final output sent to browser
DEBUG - 2020-07-04 16:12:36 --> Total execution time: 0.0049
INFO - 2020-07-04 16:14:35 --> Config Class Initialized
INFO - 2020-07-04 16:14:35 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:14:35 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:14:35 --> Utf8 Class Initialized
INFO - 2020-07-04 16:14:35 --> URI Class Initialized
INFO - 2020-07-04 16:14:35 --> Router Class Initialized
INFO - 2020-07-04 16:14:35 --> Output Class Initialized
INFO - 2020-07-04 16:14:35 --> Security Class Initialized
DEBUG - 2020-07-04 16:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:14:35 --> Input Class Initialized
INFO - 2020-07-04 16:14:35 --> Language Class Initialized
INFO - 2020-07-04 16:14:35 --> Language Class Initialized
INFO - 2020-07-04 16:14:35 --> Config Class Initialized
INFO - 2020-07-04 16:14:35 --> Loader Class Initialized
INFO - 2020-07-04 16:14:35 --> Helper loaded: url_helper
INFO - 2020-07-04 16:14:35 --> Helper loaded: main_helper
INFO - 2020-07-04 16:14:35 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:14:35 --> Controller Class Initialized
DEBUG - 2020-07-04 16:14:35 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:14:35 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:14:35 --> Final output sent to browser
DEBUG - 2020-07-04 16:14:35 --> Total execution time: 0.0040
INFO - 2020-07-04 16:14:36 --> Config Class Initialized
INFO - 2020-07-04 16:14:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:14:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:14:36 --> Utf8 Class Initialized
INFO - 2020-07-04 16:14:36 --> URI Class Initialized
INFO - 2020-07-04 16:14:36 --> Router Class Initialized
INFO - 2020-07-04 16:14:36 --> Output Class Initialized
INFO - 2020-07-04 16:14:36 --> Security Class Initialized
DEBUG - 2020-07-04 16:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:14:36 --> Input Class Initialized
INFO - 2020-07-04 16:14:36 --> Language Class Initialized
INFO - 2020-07-04 16:14:36 --> Language Class Initialized
INFO - 2020-07-04 16:14:36 --> Config Class Initialized
INFO - 2020-07-04 16:14:36 --> Loader Class Initialized
INFO - 2020-07-04 16:14:36 --> Helper loaded: url_helper
INFO - 2020-07-04 16:14:36 --> Helper loaded: main_helper
INFO - 2020-07-04 16:14:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:14:36 --> Controller Class Initialized
INFO - 2020-07-04 16:14:36 --> Final output sent to browser
DEBUG - 2020-07-04 16:14:36 --> Total execution time: 0.0054
INFO - 2020-07-04 16:14:51 --> Config Class Initialized
INFO - 2020-07-04 16:14:51 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:14:51 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:14:51 --> Utf8 Class Initialized
INFO - 2020-07-04 16:14:51 --> URI Class Initialized
INFO - 2020-07-04 16:14:51 --> Router Class Initialized
INFO - 2020-07-04 16:14:51 --> Output Class Initialized
INFO - 2020-07-04 16:14:51 --> Security Class Initialized
DEBUG - 2020-07-04 16:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:14:51 --> Input Class Initialized
INFO - 2020-07-04 16:14:51 --> Language Class Initialized
INFO - 2020-07-04 16:14:51 --> Language Class Initialized
INFO - 2020-07-04 16:14:51 --> Config Class Initialized
INFO - 2020-07-04 16:14:51 --> Loader Class Initialized
INFO - 2020-07-04 16:14:51 --> Helper loaded: url_helper
INFO - 2020-07-04 16:14:51 --> Helper loaded: main_helper
INFO - 2020-07-04 16:14:51 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:14:51 --> Controller Class Initialized
DEBUG - 2020-07-04 16:14:51 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:14:51 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:14:51 --> Final output sent to browser
DEBUG - 2020-07-04 16:14:51 --> Total execution time: 0.0046
INFO - 2020-07-04 16:14:52 --> Config Class Initialized
INFO - 2020-07-04 16:14:52 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:14:52 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:14:52 --> Utf8 Class Initialized
INFO - 2020-07-04 16:14:52 --> URI Class Initialized
INFO - 2020-07-04 16:14:52 --> Router Class Initialized
INFO - 2020-07-04 16:14:52 --> Output Class Initialized
INFO - 2020-07-04 16:14:52 --> Security Class Initialized
DEBUG - 2020-07-04 16:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:14:52 --> Input Class Initialized
INFO - 2020-07-04 16:14:52 --> Language Class Initialized
INFO - 2020-07-04 16:14:52 --> Language Class Initialized
INFO - 2020-07-04 16:14:52 --> Config Class Initialized
INFO - 2020-07-04 16:14:52 --> Loader Class Initialized
INFO - 2020-07-04 16:14:52 --> Helper loaded: url_helper
INFO - 2020-07-04 16:14:52 --> Helper loaded: main_helper
INFO - 2020-07-04 16:14:52 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:14:52 --> Controller Class Initialized
INFO - 2020-07-04 16:14:52 --> Final output sent to browser
DEBUG - 2020-07-04 16:14:52 --> Total execution time: 0.0055
INFO - 2020-07-04 16:15:02 --> Config Class Initialized
INFO - 2020-07-04 16:15:02 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:15:02 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:15:02 --> Utf8 Class Initialized
INFO - 2020-07-04 16:15:02 --> URI Class Initialized
INFO - 2020-07-04 16:15:02 --> Router Class Initialized
INFO - 2020-07-04 16:15:02 --> Output Class Initialized
INFO - 2020-07-04 16:15:02 --> Security Class Initialized
DEBUG - 2020-07-04 16:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:15:02 --> Input Class Initialized
INFO - 2020-07-04 16:15:02 --> Language Class Initialized
INFO - 2020-07-04 16:15:02 --> Language Class Initialized
INFO - 2020-07-04 16:15:02 --> Config Class Initialized
INFO - 2020-07-04 16:15:02 --> Loader Class Initialized
INFO - 2020-07-04 16:15:02 --> Helper loaded: url_helper
INFO - 2020-07-04 16:15:02 --> Helper loaded: main_helper
INFO - 2020-07-04 16:15:02 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:15:02 --> Controller Class Initialized
DEBUG - 2020-07-04 16:15:02 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:15:02 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:15:02 --> Final output sent to browser
DEBUG - 2020-07-04 16:15:02 --> Total execution time: 0.0035
INFO - 2020-07-04 16:15:02 --> Config Class Initialized
INFO - 2020-07-04 16:15:02 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:15:02 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:15:02 --> Utf8 Class Initialized
INFO - 2020-07-04 16:15:02 --> URI Class Initialized
INFO - 2020-07-04 16:15:02 --> Router Class Initialized
INFO - 2020-07-04 16:15:02 --> Output Class Initialized
INFO - 2020-07-04 16:15:02 --> Security Class Initialized
DEBUG - 2020-07-04 16:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:15:02 --> Input Class Initialized
INFO - 2020-07-04 16:15:02 --> Language Class Initialized
INFO - 2020-07-04 16:15:02 --> Language Class Initialized
INFO - 2020-07-04 16:15:02 --> Config Class Initialized
INFO - 2020-07-04 16:15:02 --> Loader Class Initialized
INFO - 2020-07-04 16:15:02 --> Helper loaded: url_helper
INFO - 2020-07-04 16:15:02 --> Helper loaded: main_helper
INFO - 2020-07-04 16:15:02 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:15:02 --> Controller Class Initialized
INFO - 2020-07-04 16:15:02 --> Final output sent to browser
DEBUG - 2020-07-04 16:15:02 --> Total execution time: 0.0045
INFO - 2020-07-04 16:16:03 --> Config Class Initialized
INFO - 2020-07-04 16:16:03 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:16:03 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:16:03 --> Utf8 Class Initialized
INFO - 2020-07-04 16:16:03 --> URI Class Initialized
INFO - 2020-07-04 16:16:03 --> Router Class Initialized
INFO - 2020-07-04 16:16:03 --> Output Class Initialized
INFO - 2020-07-04 16:16:03 --> Security Class Initialized
DEBUG - 2020-07-04 16:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:16:03 --> Input Class Initialized
INFO - 2020-07-04 16:16:03 --> Language Class Initialized
INFO - 2020-07-04 16:16:03 --> Language Class Initialized
INFO - 2020-07-04 16:16:03 --> Config Class Initialized
INFO - 2020-07-04 16:16:03 --> Loader Class Initialized
INFO - 2020-07-04 16:16:03 --> Helper loaded: url_helper
INFO - 2020-07-04 16:16:03 --> Helper loaded: main_helper
INFO - 2020-07-04 16:16:03 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:16:03 --> Controller Class Initialized
DEBUG - 2020-07-04 16:16:03 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:16:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:16:03 --> Final output sent to browser
DEBUG - 2020-07-04 16:16:03 --> Total execution time: 0.0037
INFO - 2020-07-04 16:16:04 --> Config Class Initialized
INFO - 2020-07-04 16:16:04 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:16:04 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:16:04 --> Utf8 Class Initialized
INFO - 2020-07-04 16:16:04 --> URI Class Initialized
INFO - 2020-07-04 16:16:04 --> Router Class Initialized
INFO - 2020-07-04 16:16:04 --> Output Class Initialized
INFO - 2020-07-04 16:16:04 --> Security Class Initialized
DEBUG - 2020-07-04 16:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:16:04 --> Input Class Initialized
INFO - 2020-07-04 16:16:04 --> Language Class Initialized
INFO - 2020-07-04 16:16:04 --> Language Class Initialized
INFO - 2020-07-04 16:16:04 --> Config Class Initialized
INFO - 2020-07-04 16:16:04 --> Loader Class Initialized
INFO - 2020-07-04 16:16:04 --> Helper loaded: url_helper
INFO - 2020-07-04 16:16:04 --> Helper loaded: main_helper
INFO - 2020-07-04 16:16:04 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:16:04 --> Controller Class Initialized
INFO - 2020-07-04 16:16:04 --> Final output sent to browser
DEBUG - 2020-07-04 16:16:04 --> Total execution time: 0.0052
INFO - 2020-07-04 16:16:40 --> Config Class Initialized
INFO - 2020-07-04 16:16:40 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:16:40 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:16:40 --> Utf8 Class Initialized
INFO - 2020-07-04 16:16:40 --> URI Class Initialized
INFO - 2020-07-04 16:16:40 --> Router Class Initialized
INFO - 2020-07-04 16:16:40 --> Output Class Initialized
INFO - 2020-07-04 16:16:40 --> Security Class Initialized
DEBUG - 2020-07-04 16:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:16:40 --> Input Class Initialized
INFO - 2020-07-04 16:16:40 --> Language Class Initialized
INFO - 2020-07-04 16:16:40 --> Language Class Initialized
INFO - 2020-07-04 16:16:40 --> Config Class Initialized
INFO - 2020-07-04 16:16:40 --> Loader Class Initialized
INFO - 2020-07-04 16:16:40 --> Helper loaded: url_helper
INFO - 2020-07-04 16:16:40 --> Helper loaded: main_helper
INFO - 2020-07-04 16:16:40 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:16:40 --> Controller Class Initialized
DEBUG - 2020-07-04 16:16:40 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:16:40 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:16:40 --> Final output sent to browser
DEBUG - 2020-07-04 16:16:40 --> Total execution time: 0.0048
INFO - 2020-07-04 16:17:12 --> Config Class Initialized
INFO - 2020-07-04 16:17:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:17:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:17:12 --> Utf8 Class Initialized
INFO - 2020-07-04 16:17:12 --> URI Class Initialized
INFO - 2020-07-04 16:17:12 --> Router Class Initialized
INFO - 2020-07-04 16:17:12 --> Output Class Initialized
INFO - 2020-07-04 16:17:12 --> Security Class Initialized
DEBUG - 2020-07-04 16:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:17:12 --> Input Class Initialized
INFO - 2020-07-04 16:17:12 --> Language Class Initialized
INFO - 2020-07-04 16:17:12 --> Language Class Initialized
INFO - 2020-07-04 16:17:12 --> Config Class Initialized
INFO - 2020-07-04 16:17:12 --> Loader Class Initialized
INFO - 2020-07-04 16:17:12 --> Helper loaded: url_helper
INFO - 2020-07-04 16:17:12 --> Helper loaded: main_helper
INFO - 2020-07-04 16:17:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:17:12 --> Controller Class Initialized
DEBUG - 2020-07-04 16:17:12 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:17:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:17:12 --> Final output sent to browser
DEBUG - 2020-07-04 16:17:12 --> Total execution time: 0.0056
INFO - 2020-07-04 16:17:13 --> Config Class Initialized
INFO - 2020-07-04 16:17:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:17:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:17:13 --> Utf8 Class Initialized
INFO - 2020-07-04 16:17:13 --> URI Class Initialized
INFO - 2020-07-04 16:17:13 --> Router Class Initialized
INFO - 2020-07-04 16:17:13 --> Output Class Initialized
INFO - 2020-07-04 16:17:13 --> Security Class Initialized
DEBUG - 2020-07-04 16:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:17:13 --> Input Class Initialized
INFO - 2020-07-04 16:17:13 --> Language Class Initialized
INFO - 2020-07-04 16:17:13 --> Language Class Initialized
INFO - 2020-07-04 16:17:13 --> Config Class Initialized
INFO - 2020-07-04 16:17:13 --> Loader Class Initialized
INFO - 2020-07-04 16:17:13 --> Helper loaded: url_helper
INFO - 2020-07-04 16:17:13 --> Helper loaded: main_helper
INFO - 2020-07-04 16:17:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:17:13 --> Controller Class Initialized
INFO - 2020-07-04 16:17:13 --> Final output sent to browser
DEBUG - 2020-07-04 16:17:13 --> Total execution time: 0.0045
INFO - 2020-07-04 16:17:40 --> Config Class Initialized
INFO - 2020-07-04 16:17:40 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:17:40 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:17:40 --> Utf8 Class Initialized
INFO - 2020-07-04 16:17:40 --> URI Class Initialized
INFO - 2020-07-04 16:17:40 --> Router Class Initialized
INFO - 2020-07-04 16:17:40 --> Output Class Initialized
INFO - 2020-07-04 16:17:40 --> Security Class Initialized
DEBUG - 2020-07-04 16:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:17:40 --> Input Class Initialized
INFO - 2020-07-04 16:17:40 --> Language Class Initialized
INFO - 2020-07-04 16:17:40 --> Language Class Initialized
INFO - 2020-07-04 16:17:40 --> Config Class Initialized
INFO - 2020-07-04 16:17:40 --> Loader Class Initialized
INFO - 2020-07-04 16:17:40 --> Helper loaded: url_helper
INFO - 2020-07-04 16:17:40 --> Helper loaded: main_helper
INFO - 2020-07-04 16:17:40 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:17:40 --> Controller Class Initialized
DEBUG - 2020-07-04 16:17:40 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:17:40 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:17:40 --> Final output sent to browser
DEBUG - 2020-07-04 16:17:40 --> Total execution time: 0.0043
INFO - 2020-07-04 16:17:41 --> Config Class Initialized
INFO - 2020-07-04 16:17:41 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:17:41 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:17:41 --> Utf8 Class Initialized
INFO - 2020-07-04 16:17:41 --> URI Class Initialized
INFO - 2020-07-04 16:17:41 --> Router Class Initialized
INFO - 2020-07-04 16:17:41 --> Output Class Initialized
INFO - 2020-07-04 16:17:41 --> Security Class Initialized
DEBUG - 2020-07-04 16:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:17:41 --> Input Class Initialized
INFO - 2020-07-04 16:17:41 --> Language Class Initialized
INFO - 2020-07-04 16:17:41 --> Language Class Initialized
INFO - 2020-07-04 16:17:41 --> Config Class Initialized
INFO - 2020-07-04 16:17:41 --> Loader Class Initialized
INFO - 2020-07-04 16:17:41 --> Helper loaded: url_helper
INFO - 2020-07-04 16:17:41 --> Helper loaded: main_helper
INFO - 2020-07-04 16:17:41 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:17:41 --> Controller Class Initialized
INFO - 2020-07-04 16:17:41 --> Final output sent to browser
DEBUG - 2020-07-04 16:17:41 --> Total execution time: 0.0062
INFO - 2020-07-04 16:18:36 --> Config Class Initialized
INFO - 2020-07-04 16:18:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:18:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:18:36 --> Utf8 Class Initialized
INFO - 2020-07-04 16:18:36 --> URI Class Initialized
INFO - 2020-07-04 16:18:36 --> Router Class Initialized
INFO - 2020-07-04 16:18:36 --> Output Class Initialized
INFO - 2020-07-04 16:18:36 --> Security Class Initialized
DEBUG - 2020-07-04 16:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:18:36 --> Input Class Initialized
INFO - 2020-07-04 16:18:36 --> Language Class Initialized
INFO - 2020-07-04 16:18:36 --> Language Class Initialized
INFO - 2020-07-04 16:18:36 --> Config Class Initialized
INFO - 2020-07-04 16:18:36 --> Loader Class Initialized
INFO - 2020-07-04 16:18:36 --> Helper loaded: url_helper
INFO - 2020-07-04 16:18:36 --> Helper loaded: main_helper
INFO - 2020-07-04 16:18:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:18:36 --> Controller Class Initialized
DEBUG - 2020-07-04 16:18:36 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:18:36 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:18:36 --> Final output sent to browser
DEBUG - 2020-07-04 16:18:36 --> Total execution time: 0.0042
INFO - 2020-07-04 16:18:37 --> Config Class Initialized
INFO - 2020-07-04 16:18:37 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:18:37 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:18:37 --> Utf8 Class Initialized
INFO - 2020-07-04 16:18:37 --> URI Class Initialized
INFO - 2020-07-04 16:18:37 --> Router Class Initialized
INFO - 2020-07-04 16:18:37 --> Output Class Initialized
INFO - 2020-07-04 16:18:37 --> Security Class Initialized
DEBUG - 2020-07-04 16:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:18:37 --> Input Class Initialized
INFO - 2020-07-04 16:18:37 --> Language Class Initialized
INFO - 2020-07-04 16:18:37 --> Language Class Initialized
INFO - 2020-07-04 16:18:37 --> Config Class Initialized
INFO - 2020-07-04 16:18:37 --> Loader Class Initialized
INFO - 2020-07-04 16:18:37 --> Helper loaded: url_helper
INFO - 2020-07-04 16:18:37 --> Helper loaded: main_helper
INFO - 2020-07-04 16:18:37 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:18:37 --> Controller Class Initialized
INFO - 2020-07-04 16:18:37 --> Final output sent to browser
DEBUG - 2020-07-04 16:18:37 --> Total execution time: 0.0047
INFO - 2020-07-04 16:19:45 --> Config Class Initialized
INFO - 2020-07-04 16:19:45 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:19:45 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:19:45 --> Utf8 Class Initialized
INFO - 2020-07-04 16:19:45 --> URI Class Initialized
INFO - 2020-07-04 16:19:45 --> Router Class Initialized
INFO - 2020-07-04 16:19:45 --> Output Class Initialized
INFO - 2020-07-04 16:19:45 --> Security Class Initialized
DEBUG - 2020-07-04 16:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:19:45 --> Input Class Initialized
INFO - 2020-07-04 16:19:45 --> Language Class Initialized
INFO - 2020-07-04 16:19:45 --> Language Class Initialized
INFO - 2020-07-04 16:19:45 --> Config Class Initialized
INFO - 2020-07-04 16:19:45 --> Loader Class Initialized
INFO - 2020-07-04 16:19:45 --> Helper loaded: url_helper
INFO - 2020-07-04 16:19:45 --> Helper loaded: main_helper
INFO - 2020-07-04 16:19:45 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:19:45 --> Controller Class Initialized
DEBUG - 2020-07-04 16:19:45 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:19:45 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:19:45 --> Final output sent to browser
DEBUG - 2020-07-04 16:19:45 --> Total execution time: 0.0061
INFO - 2020-07-04 16:19:46 --> Config Class Initialized
INFO - 2020-07-04 16:19:46 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:19:46 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:19:46 --> Utf8 Class Initialized
INFO - 2020-07-04 16:19:46 --> URI Class Initialized
INFO - 2020-07-04 16:19:46 --> Router Class Initialized
INFO - 2020-07-04 16:19:46 --> Output Class Initialized
INFO - 2020-07-04 16:19:46 --> Security Class Initialized
DEBUG - 2020-07-04 16:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:19:46 --> Input Class Initialized
INFO - 2020-07-04 16:19:46 --> Language Class Initialized
INFO - 2020-07-04 16:19:46 --> Language Class Initialized
INFO - 2020-07-04 16:19:46 --> Config Class Initialized
INFO - 2020-07-04 16:19:46 --> Loader Class Initialized
INFO - 2020-07-04 16:19:46 --> Helper loaded: url_helper
INFO - 2020-07-04 16:19:46 --> Helper loaded: main_helper
INFO - 2020-07-04 16:19:46 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:19:46 --> Controller Class Initialized
INFO - 2020-07-04 16:19:46 --> Final output sent to browser
DEBUG - 2020-07-04 16:19:46 --> Total execution time: 0.0045
INFO - 2020-07-04 16:20:27 --> Config Class Initialized
INFO - 2020-07-04 16:20:27 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:20:27 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:20:27 --> Utf8 Class Initialized
INFO - 2020-07-04 16:20:27 --> URI Class Initialized
INFO - 2020-07-04 16:20:27 --> Router Class Initialized
INFO - 2020-07-04 16:20:27 --> Output Class Initialized
INFO - 2020-07-04 16:20:27 --> Security Class Initialized
DEBUG - 2020-07-04 16:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:20:27 --> Input Class Initialized
INFO - 2020-07-04 16:20:27 --> Language Class Initialized
INFO - 2020-07-04 16:20:27 --> Language Class Initialized
INFO - 2020-07-04 16:20:27 --> Config Class Initialized
INFO - 2020-07-04 16:20:27 --> Loader Class Initialized
INFO - 2020-07-04 16:20:27 --> Helper loaded: url_helper
INFO - 2020-07-04 16:20:27 --> Helper loaded: main_helper
INFO - 2020-07-04 16:20:27 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:20:27 --> Controller Class Initialized
DEBUG - 2020-07-04 16:20:27 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:20:27 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:20:27 --> Final output sent to browser
DEBUG - 2020-07-04 16:20:27 --> Total execution time: 0.0048
INFO - 2020-07-04 16:20:28 --> Config Class Initialized
INFO - 2020-07-04 16:20:28 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:20:28 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:20:28 --> Utf8 Class Initialized
INFO - 2020-07-04 16:20:28 --> URI Class Initialized
INFO - 2020-07-04 16:20:28 --> Router Class Initialized
INFO - 2020-07-04 16:20:28 --> Output Class Initialized
INFO - 2020-07-04 16:20:28 --> Security Class Initialized
DEBUG - 2020-07-04 16:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:20:28 --> Input Class Initialized
INFO - 2020-07-04 16:20:28 --> Language Class Initialized
INFO - 2020-07-04 16:20:28 --> Language Class Initialized
INFO - 2020-07-04 16:20:28 --> Config Class Initialized
INFO - 2020-07-04 16:20:28 --> Loader Class Initialized
INFO - 2020-07-04 16:20:28 --> Helper loaded: url_helper
INFO - 2020-07-04 16:20:28 --> Helper loaded: main_helper
INFO - 2020-07-04 16:20:28 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:20:28 --> Controller Class Initialized
INFO - 2020-07-04 16:20:28 --> Final output sent to browser
DEBUG - 2020-07-04 16:20:28 --> Total execution time: 0.0063
INFO - 2020-07-04 16:21:16 --> Config Class Initialized
INFO - 2020-07-04 16:21:16 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:21:16 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:21:16 --> Utf8 Class Initialized
INFO - 2020-07-04 16:21:16 --> URI Class Initialized
INFO - 2020-07-04 16:21:16 --> Router Class Initialized
INFO - 2020-07-04 16:21:16 --> Output Class Initialized
INFO - 2020-07-04 16:21:16 --> Security Class Initialized
DEBUG - 2020-07-04 16:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:21:16 --> Input Class Initialized
INFO - 2020-07-04 16:21:16 --> Language Class Initialized
INFO - 2020-07-04 16:21:16 --> Language Class Initialized
INFO - 2020-07-04 16:21:16 --> Config Class Initialized
INFO - 2020-07-04 16:21:16 --> Loader Class Initialized
INFO - 2020-07-04 16:21:16 --> Helper loaded: url_helper
INFO - 2020-07-04 16:21:16 --> Helper loaded: main_helper
INFO - 2020-07-04 16:21:16 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:21:16 --> Controller Class Initialized
DEBUG - 2020-07-04 16:21:16 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:21:16 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:21:16 --> Final output sent to browser
DEBUG - 2020-07-04 16:21:16 --> Total execution time: 0.0032
INFO - 2020-07-04 16:21:17 --> Config Class Initialized
INFO - 2020-07-04 16:21:17 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:21:17 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:21:17 --> Utf8 Class Initialized
INFO - 2020-07-04 16:21:17 --> URI Class Initialized
INFO - 2020-07-04 16:21:17 --> Router Class Initialized
INFO - 2020-07-04 16:21:17 --> Output Class Initialized
INFO - 2020-07-04 16:21:17 --> Security Class Initialized
DEBUG - 2020-07-04 16:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:21:17 --> Input Class Initialized
INFO - 2020-07-04 16:21:17 --> Language Class Initialized
INFO - 2020-07-04 16:21:17 --> Language Class Initialized
INFO - 2020-07-04 16:21:17 --> Config Class Initialized
INFO - 2020-07-04 16:21:17 --> Loader Class Initialized
INFO - 2020-07-04 16:21:17 --> Helper loaded: url_helper
INFO - 2020-07-04 16:21:17 --> Helper loaded: main_helper
INFO - 2020-07-04 16:21:17 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:21:17 --> Controller Class Initialized
INFO - 2020-07-04 16:21:17 --> Final output sent to browser
DEBUG - 2020-07-04 16:21:17 --> Total execution time: 0.0053
INFO - 2020-07-04 16:21:55 --> Config Class Initialized
INFO - 2020-07-04 16:21:55 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:21:55 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:21:55 --> Utf8 Class Initialized
INFO - 2020-07-04 16:21:55 --> URI Class Initialized
INFO - 2020-07-04 16:21:55 --> Router Class Initialized
INFO - 2020-07-04 16:21:55 --> Output Class Initialized
INFO - 2020-07-04 16:21:55 --> Security Class Initialized
DEBUG - 2020-07-04 16:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:21:55 --> Input Class Initialized
INFO - 2020-07-04 16:21:55 --> Language Class Initialized
INFO - 2020-07-04 16:21:55 --> Language Class Initialized
INFO - 2020-07-04 16:21:55 --> Config Class Initialized
INFO - 2020-07-04 16:21:55 --> Loader Class Initialized
INFO - 2020-07-04 16:21:55 --> Helper loaded: url_helper
INFO - 2020-07-04 16:21:55 --> Helper loaded: main_helper
INFO - 2020-07-04 16:21:55 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:21:55 --> Controller Class Initialized
DEBUG - 2020-07-04 16:21:55 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:21:55 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:21:55 --> Final output sent to browser
DEBUG - 2020-07-04 16:21:55 --> Total execution time: 0.0033
INFO - 2020-07-04 16:21:56 --> Config Class Initialized
INFO - 2020-07-04 16:21:56 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:21:56 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:21:56 --> Utf8 Class Initialized
INFO - 2020-07-04 16:21:56 --> URI Class Initialized
INFO - 2020-07-04 16:21:56 --> Router Class Initialized
INFO - 2020-07-04 16:21:56 --> Output Class Initialized
INFO - 2020-07-04 16:21:56 --> Security Class Initialized
DEBUG - 2020-07-04 16:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:21:56 --> Input Class Initialized
INFO - 2020-07-04 16:21:56 --> Language Class Initialized
INFO - 2020-07-04 16:21:56 --> Language Class Initialized
INFO - 2020-07-04 16:21:56 --> Config Class Initialized
INFO - 2020-07-04 16:21:56 --> Loader Class Initialized
INFO - 2020-07-04 16:21:56 --> Helper loaded: url_helper
INFO - 2020-07-04 16:21:56 --> Helper loaded: main_helper
INFO - 2020-07-04 16:21:56 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:21:56 --> Controller Class Initialized
INFO - 2020-07-04 16:21:56 --> Final output sent to browser
DEBUG - 2020-07-04 16:21:56 --> Total execution time: 0.0069
INFO - 2020-07-04 16:22:08 --> Config Class Initialized
INFO - 2020-07-04 16:22:08 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:22:08 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:22:08 --> Utf8 Class Initialized
INFO - 2020-07-04 16:22:08 --> URI Class Initialized
INFO - 2020-07-04 16:22:08 --> Router Class Initialized
INFO - 2020-07-04 16:22:08 --> Output Class Initialized
INFO - 2020-07-04 16:22:08 --> Security Class Initialized
DEBUG - 2020-07-04 16:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:22:08 --> Input Class Initialized
INFO - 2020-07-04 16:22:08 --> Language Class Initialized
INFO - 2020-07-04 16:22:08 --> Language Class Initialized
INFO - 2020-07-04 16:22:08 --> Config Class Initialized
INFO - 2020-07-04 16:22:08 --> Loader Class Initialized
INFO - 2020-07-04 16:22:08 --> Helper loaded: url_helper
INFO - 2020-07-04 16:22:08 --> Helper loaded: main_helper
INFO - 2020-07-04 16:22:08 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:22:08 --> Controller Class Initialized
DEBUG - 2020-07-04 16:22:08 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:22:08 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:22:08 --> Final output sent to browser
DEBUG - 2020-07-04 16:22:08 --> Total execution time: 0.0036
INFO - 2020-07-04 16:22:09 --> Config Class Initialized
INFO - 2020-07-04 16:22:09 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:22:09 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:22:09 --> Utf8 Class Initialized
INFO - 2020-07-04 16:22:09 --> URI Class Initialized
INFO - 2020-07-04 16:22:09 --> Router Class Initialized
INFO - 2020-07-04 16:22:09 --> Output Class Initialized
INFO - 2020-07-04 16:22:09 --> Security Class Initialized
DEBUG - 2020-07-04 16:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:22:09 --> Input Class Initialized
INFO - 2020-07-04 16:22:09 --> Language Class Initialized
INFO - 2020-07-04 16:22:09 --> Language Class Initialized
INFO - 2020-07-04 16:22:09 --> Config Class Initialized
INFO - 2020-07-04 16:22:09 --> Loader Class Initialized
INFO - 2020-07-04 16:22:09 --> Helper loaded: url_helper
INFO - 2020-07-04 16:22:09 --> Helper loaded: main_helper
INFO - 2020-07-04 16:22:09 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:22:09 --> Controller Class Initialized
INFO - 2020-07-04 16:22:09 --> Final output sent to browser
DEBUG - 2020-07-04 16:22:09 --> Total execution time: 0.0042
INFO - 2020-07-04 16:25:12 --> Config Class Initialized
INFO - 2020-07-04 16:25:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:25:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:25:12 --> Utf8 Class Initialized
INFO - 2020-07-04 16:25:12 --> URI Class Initialized
INFO - 2020-07-04 16:25:12 --> Router Class Initialized
INFO - 2020-07-04 16:25:12 --> Output Class Initialized
INFO - 2020-07-04 16:25:12 --> Security Class Initialized
DEBUG - 2020-07-04 16:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:25:12 --> Input Class Initialized
INFO - 2020-07-04 16:25:12 --> Language Class Initialized
INFO - 2020-07-04 16:25:12 --> Language Class Initialized
INFO - 2020-07-04 16:25:12 --> Config Class Initialized
INFO - 2020-07-04 16:25:12 --> Loader Class Initialized
INFO - 2020-07-04 16:25:12 --> Helper loaded: url_helper
INFO - 2020-07-04 16:25:12 --> Helper loaded: main_helper
INFO - 2020-07-04 16:25:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:25:12 --> Controller Class Initialized
DEBUG - 2020-07-04 16:25:12 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:25:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:25:12 --> Final output sent to browser
DEBUG - 2020-07-04 16:25:12 --> Total execution time: 0.0051
INFO - 2020-07-04 16:25:14 --> Config Class Initialized
INFO - 2020-07-04 16:25:14 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:25:14 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:25:14 --> Utf8 Class Initialized
INFO - 2020-07-04 16:25:14 --> URI Class Initialized
INFO - 2020-07-04 16:25:14 --> Router Class Initialized
INFO - 2020-07-04 16:25:14 --> Output Class Initialized
INFO - 2020-07-04 16:25:14 --> Security Class Initialized
DEBUG - 2020-07-04 16:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:25:14 --> Input Class Initialized
INFO - 2020-07-04 16:25:14 --> Language Class Initialized
INFO - 2020-07-04 16:25:14 --> Language Class Initialized
INFO - 2020-07-04 16:25:14 --> Config Class Initialized
INFO - 2020-07-04 16:25:14 --> Loader Class Initialized
INFO - 2020-07-04 16:25:14 --> Helper loaded: url_helper
INFO - 2020-07-04 16:25:14 --> Helper loaded: main_helper
INFO - 2020-07-04 16:25:14 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:25:14 --> Controller Class Initialized
INFO - 2020-07-04 16:25:14 --> Final output sent to browser
DEBUG - 2020-07-04 16:25:14 --> Total execution time: 0.0103
INFO - 2020-07-04 16:28:59 --> Config Class Initialized
INFO - 2020-07-04 16:28:59 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:28:59 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:28:59 --> Utf8 Class Initialized
INFO - 2020-07-04 16:28:59 --> URI Class Initialized
INFO - 2020-07-04 16:28:59 --> Router Class Initialized
INFO - 2020-07-04 16:28:59 --> Output Class Initialized
INFO - 2020-07-04 16:28:59 --> Security Class Initialized
DEBUG - 2020-07-04 16:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:28:59 --> Input Class Initialized
INFO - 2020-07-04 16:28:59 --> Language Class Initialized
INFO - 2020-07-04 16:28:59 --> Language Class Initialized
INFO - 2020-07-04 16:28:59 --> Config Class Initialized
INFO - 2020-07-04 16:28:59 --> Loader Class Initialized
INFO - 2020-07-04 16:28:59 --> Helper loaded: url_helper
INFO - 2020-07-04 16:28:59 --> Helper loaded: main_helper
INFO - 2020-07-04 16:28:59 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:28:59 --> Controller Class Initialized
DEBUG - 2020-07-04 16:28:59 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:28:59 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:28:59 --> Final output sent to browser
DEBUG - 2020-07-04 16:28:59 --> Total execution time: 0.0039
INFO - 2020-07-04 16:29:00 --> Config Class Initialized
INFO - 2020-07-04 16:29:00 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:29:00 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:29:00 --> Utf8 Class Initialized
INFO - 2020-07-04 16:29:00 --> URI Class Initialized
INFO - 2020-07-04 16:29:00 --> Router Class Initialized
INFO - 2020-07-04 16:29:00 --> Output Class Initialized
INFO - 2020-07-04 16:29:00 --> Security Class Initialized
DEBUG - 2020-07-04 16:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:29:00 --> Input Class Initialized
INFO - 2020-07-04 16:29:00 --> Language Class Initialized
INFO - 2020-07-04 16:29:00 --> Language Class Initialized
INFO - 2020-07-04 16:29:00 --> Config Class Initialized
INFO - 2020-07-04 16:29:00 --> Loader Class Initialized
INFO - 2020-07-04 16:29:00 --> Helper loaded: url_helper
INFO - 2020-07-04 16:29:00 --> Helper loaded: main_helper
INFO - 2020-07-04 16:29:00 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:29:00 --> Controller Class Initialized
INFO - 2020-07-04 16:29:00 --> Final output sent to browser
DEBUG - 2020-07-04 16:29:00 --> Total execution time: 0.0067
INFO - 2020-07-04 16:29:09 --> Config Class Initialized
INFO - 2020-07-04 16:29:09 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:29:09 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:29:09 --> Utf8 Class Initialized
INFO - 2020-07-04 16:29:09 --> URI Class Initialized
INFO - 2020-07-04 16:29:09 --> Router Class Initialized
INFO - 2020-07-04 16:29:09 --> Output Class Initialized
INFO - 2020-07-04 16:29:09 --> Security Class Initialized
DEBUG - 2020-07-04 16:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:29:09 --> Input Class Initialized
INFO - 2020-07-04 16:29:09 --> Language Class Initialized
INFO - 2020-07-04 16:29:09 --> Language Class Initialized
INFO - 2020-07-04 16:29:09 --> Config Class Initialized
INFO - 2020-07-04 16:29:09 --> Loader Class Initialized
INFO - 2020-07-04 16:29:09 --> Helper loaded: url_helper
INFO - 2020-07-04 16:29:09 --> Helper loaded: main_helper
INFO - 2020-07-04 16:29:09 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:29:09 --> Controller Class Initialized
DEBUG - 2020-07-04 16:29:09 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:29:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:29:09 --> Final output sent to browser
DEBUG - 2020-07-04 16:29:09 --> Total execution time: 0.0068
INFO - 2020-07-04 16:29:10 --> Config Class Initialized
INFO - 2020-07-04 16:29:10 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:29:10 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:29:10 --> Utf8 Class Initialized
INFO - 2020-07-04 16:29:10 --> URI Class Initialized
INFO - 2020-07-04 16:29:10 --> Router Class Initialized
INFO - 2020-07-04 16:29:10 --> Output Class Initialized
INFO - 2020-07-04 16:29:10 --> Security Class Initialized
DEBUG - 2020-07-04 16:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:29:10 --> Input Class Initialized
INFO - 2020-07-04 16:29:10 --> Language Class Initialized
INFO - 2020-07-04 16:29:10 --> Language Class Initialized
INFO - 2020-07-04 16:29:10 --> Config Class Initialized
INFO - 2020-07-04 16:29:10 --> Loader Class Initialized
INFO - 2020-07-04 16:29:10 --> Helper loaded: url_helper
INFO - 2020-07-04 16:29:10 --> Helper loaded: main_helper
INFO - 2020-07-04 16:29:10 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:29:10 --> Controller Class Initialized
INFO - 2020-07-04 16:29:10 --> Final output sent to browser
DEBUG - 2020-07-04 16:29:10 --> Total execution time: 0.0058
INFO - 2020-07-04 16:29:20 --> Config Class Initialized
INFO - 2020-07-04 16:29:20 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:29:20 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:29:20 --> Utf8 Class Initialized
INFO - 2020-07-04 16:29:20 --> URI Class Initialized
INFO - 2020-07-04 16:29:20 --> Router Class Initialized
INFO - 2020-07-04 16:29:20 --> Output Class Initialized
INFO - 2020-07-04 16:29:20 --> Security Class Initialized
DEBUG - 2020-07-04 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:29:20 --> Input Class Initialized
INFO - 2020-07-04 16:29:20 --> Language Class Initialized
INFO - 2020-07-04 16:29:20 --> Language Class Initialized
INFO - 2020-07-04 16:29:20 --> Config Class Initialized
INFO - 2020-07-04 16:29:20 --> Loader Class Initialized
INFO - 2020-07-04 16:29:20 --> Helper loaded: url_helper
INFO - 2020-07-04 16:29:20 --> Helper loaded: main_helper
INFO - 2020-07-04 16:29:20 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:29:20 --> Controller Class Initialized
DEBUG - 2020-07-04 16:29:20 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:29:20 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:29:20 --> Final output sent to browser
DEBUG - 2020-07-04 16:29:20 --> Total execution time: 0.0045
INFO - 2020-07-04 16:29:21 --> Config Class Initialized
INFO - 2020-07-04 16:29:21 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:29:21 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:29:21 --> Utf8 Class Initialized
INFO - 2020-07-04 16:29:21 --> URI Class Initialized
INFO - 2020-07-04 16:29:21 --> Router Class Initialized
INFO - 2020-07-04 16:29:21 --> Output Class Initialized
INFO - 2020-07-04 16:29:21 --> Security Class Initialized
DEBUG - 2020-07-04 16:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:29:21 --> Input Class Initialized
INFO - 2020-07-04 16:29:21 --> Language Class Initialized
INFO - 2020-07-04 16:29:21 --> Language Class Initialized
INFO - 2020-07-04 16:29:21 --> Config Class Initialized
INFO - 2020-07-04 16:29:21 --> Loader Class Initialized
INFO - 2020-07-04 16:29:21 --> Helper loaded: url_helper
INFO - 2020-07-04 16:29:21 --> Helper loaded: main_helper
INFO - 2020-07-04 16:29:21 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:29:21 --> Controller Class Initialized
INFO - 2020-07-04 16:29:21 --> Final output sent to browser
DEBUG - 2020-07-04 16:29:21 --> Total execution time: 0.0055
INFO - 2020-07-04 16:29:25 --> Config Class Initialized
INFO - 2020-07-04 16:29:25 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:29:25 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:29:25 --> Utf8 Class Initialized
INFO - 2020-07-04 16:29:25 --> URI Class Initialized
INFO - 2020-07-04 16:29:25 --> Router Class Initialized
INFO - 2020-07-04 16:29:25 --> Output Class Initialized
INFO - 2020-07-04 16:29:25 --> Security Class Initialized
DEBUG - 2020-07-04 16:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:29:25 --> Input Class Initialized
INFO - 2020-07-04 16:29:25 --> Language Class Initialized
INFO - 2020-07-04 16:29:25 --> Language Class Initialized
INFO - 2020-07-04 16:29:25 --> Config Class Initialized
INFO - 2020-07-04 16:29:25 --> Loader Class Initialized
INFO - 2020-07-04 16:29:25 --> Helper loaded: url_helper
INFO - 2020-07-04 16:29:25 --> Helper loaded: main_helper
INFO - 2020-07-04 16:29:25 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:29:25 --> Controller Class Initialized
DEBUG - 2020-07-04 16:29:25 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:29:25 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:29:25 --> Final output sent to browser
DEBUG - 2020-07-04 16:29:25 --> Total execution time: 0.0069
INFO - 2020-07-04 16:29:26 --> Config Class Initialized
INFO - 2020-07-04 16:29:26 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:29:26 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:29:26 --> Utf8 Class Initialized
INFO - 2020-07-04 16:29:26 --> URI Class Initialized
INFO - 2020-07-04 16:29:26 --> Router Class Initialized
INFO - 2020-07-04 16:29:26 --> Output Class Initialized
INFO - 2020-07-04 16:29:26 --> Security Class Initialized
DEBUG - 2020-07-04 16:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:29:26 --> Input Class Initialized
INFO - 2020-07-04 16:29:26 --> Language Class Initialized
INFO - 2020-07-04 16:29:26 --> Language Class Initialized
INFO - 2020-07-04 16:29:26 --> Config Class Initialized
INFO - 2020-07-04 16:29:26 --> Loader Class Initialized
INFO - 2020-07-04 16:29:26 --> Helper loaded: url_helper
INFO - 2020-07-04 16:29:26 --> Helper loaded: main_helper
INFO - 2020-07-04 16:29:26 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:29:26 --> Controller Class Initialized
INFO - 2020-07-04 16:29:26 --> Final output sent to browser
DEBUG - 2020-07-04 16:29:26 --> Total execution time: 0.0065
INFO - 2020-07-04 16:29:32 --> Config Class Initialized
INFO - 2020-07-04 16:29:32 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:29:32 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:29:32 --> Utf8 Class Initialized
INFO - 2020-07-04 16:29:32 --> URI Class Initialized
INFO - 2020-07-04 16:29:32 --> Router Class Initialized
INFO - 2020-07-04 16:29:32 --> Output Class Initialized
INFO - 2020-07-04 16:29:32 --> Security Class Initialized
DEBUG - 2020-07-04 16:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:29:32 --> Input Class Initialized
INFO - 2020-07-04 16:29:32 --> Language Class Initialized
INFO - 2020-07-04 16:29:32 --> Language Class Initialized
INFO - 2020-07-04 16:29:32 --> Config Class Initialized
INFO - 2020-07-04 16:29:32 --> Loader Class Initialized
INFO - 2020-07-04 16:29:32 --> Helper loaded: url_helper
INFO - 2020-07-04 16:29:32 --> Helper loaded: main_helper
INFO - 2020-07-04 16:29:32 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:29:32 --> Controller Class Initialized
DEBUG - 2020-07-04 16:29:32 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:29:32 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:29:32 --> Final output sent to browser
DEBUG - 2020-07-04 16:29:32 --> Total execution time: 0.0037
INFO - 2020-07-04 16:29:33 --> Config Class Initialized
INFO - 2020-07-04 16:29:33 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:29:33 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:29:33 --> Utf8 Class Initialized
INFO - 2020-07-04 16:29:33 --> URI Class Initialized
INFO - 2020-07-04 16:29:33 --> Router Class Initialized
INFO - 2020-07-04 16:29:33 --> Output Class Initialized
INFO - 2020-07-04 16:29:33 --> Security Class Initialized
DEBUG - 2020-07-04 16:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:29:33 --> Input Class Initialized
INFO - 2020-07-04 16:29:33 --> Language Class Initialized
INFO - 2020-07-04 16:29:33 --> Language Class Initialized
INFO - 2020-07-04 16:29:33 --> Config Class Initialized
INFO - 2020-07-04 16:29:33 --> Loader Class Initialized
INFO - 2020-07-04 16:29:33 --> Helper loaded: url_helper
INFO - 2020-07-04 16:29:33 --> Helper loaded: main_helper
INFO - 2020-07-04 16:29:33 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:29:33 --> Controller Class Initialized
INFO - 2020-07-04 16:29:33 --> Final output sent to browser
DEBUG - 2020-07-04 16:29:33 --> Total execution time: 0.0043
INFO - 2020-07-04 16:29:37 --> Config Class Initialized
INFO - 2020-07-04 16:29:37 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:29:37 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:29:37 --> Utf8 Class Initialized
INFO - 2020-07-04 16:29:37 --> URI Class Initialized
INFO - 2020-07-04 16:29:37 --> Router Class Initialized
INFO - 2020-07-04 16:29:37 --> Output Class Initialized
INFO - 2020-07-04 16:29:37 --> Security Class Initialized
DEBUG - 2020-07-04 16:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:29:37 --> Input Class Initialized
INFO - 2020-07-04 16:29:37 --> Language Class Initialized
INFO - 2020-07-04 16:29:37 --> Language Class Initialized
INFO - 2020-07-04 16:29:37 --> Config Class Initialized
INFO - 2020-07-04 16:29:37 --> Loader Class Initialized
INFO - 2020-07-04 16:29:37 --> Helper loaded: url_helper
INFO - 2020-07-04 16:29:37 --> Helper loaded: main_helper
INFO - 2020-07-04 16:29:37 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:29:37 --> Controller Class Initialized
DEBUG - 2020-07-04 16:29:37 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:29:37 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:29:37 --> Final output sent to browser
DEBUG - 2020-07-04 16:29:37 --> Total execution time: 0.0049
INFO - 2020-07-04 16:29:38 --> Config Class Initialized
INFO - 2020-07-04 16:29:38 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:29:38 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:29:38 --> Utf8 Class Initialized
INFO - 2020-07-04 16:29:38 --> URI Class Initialized
INFO - 2020-07-04 16:29:38 --> Router Class Initialized
INFO - 2020-07-04 16:29:38 --> Output Class Initialized
INFO - 2020-07-04 16:29:38 --> Security Class Initialized
DEBUG - 2020-07-04 16:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:29:38 --> Input Class Initialized
INFO - 2020-07-04 16:29:38 --> Language Class Initialized
INFO - 2020-07-04 16:29:38 --> Language Class Initialized
INFO - 2020-07-04 16:29:38 --> Config Class Initialized
INFO - 2020-07-04 16:29:38 --> Loader Class Initialized
INFO - 2020-07-04 16:29:38 --> Helper loaded: url_helper
INFO - 2020-07-04 16:29:38 --> Helper loaded: main_helper
INFO - 2020-07-04 16:29:38 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:29:38 --> Controller Class Initialized
INFO - 2020-07-04 16:29:38 --> Final output sent to browser
DEBUG - 2020-07-04 16:29:38 --> Total execution time: 0.0061
INFO - 2020-07-04 16:30:15 --> Config Class Initialized
INFO - 2020-07-04 16:30:15 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:30:15 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:30:15 --> Utf8 Class Initialized
INFO - 2020-07-04 16:30:15 --> URI Class Initialized
INFO - 2020-07-04 16:30:15 --> Router Class Initialized
INFO - 2020-07-04 16:30:15 --> Output Class Initialized
INFO - 2020-07-04 16:30:15 --> Security Class Initialized
DEBUG - 2020-07-04 16:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:30:15 --> Input Class Initialized
INFO - 2020-07-04 16:30:15 --> Language Class Initialized
INFO - 2020-07-04 16:30:15 --> Language Class Initialized
INFO - 2020-07-04 16:30:15 --> Config Class Initialized
INFO - 2020-07-04 16:30:15 --> Loader Class Initialized
INFO - 2020-07-04 16:30:15 --> Helper loaded: url_helper
INFO - 2020-07-04 16:30:15 --> Helper loaded: main_helper
INFO - 2020-07-04 16:30:15 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:30:15 --> Controller Class Initialized
DEBUG - 2020-07-04 16:30:15 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:30:15 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:30:15 --> Final output sent to browser
DEBUG - 2020-07-04 16:30:15 --> Total execution time: 0.0038
INFO - 2020-07-04 16:30:16 --> Config Class Initialized
INFO - 2020-07-04 16:30:16 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:30:16 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:30:16 --> Utf8 Class Initialized
INFO - 2020-07-04 16:30:16 --> URI Class Initialized
INFO - 2020-07-04 16:30:16 --> Router Class Initialized
INFO - 2020-07-04 16:30:16 --> Output Class Initialized
INFO - 2020-07-04 16:30:16 --> Security Class Initialized
DEBUG - 2020-07-04 16:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:30:16 --> Input Class Initialized
INFO - 2020-07-04 16:30:16 --> Language Class Initialized
INFO - 2020-07-04 16:30:16 --> Language Class Initialized
INFO - 2020-07-04 16:30:16 --> Config Class Initialized
INFO - 2020-07-04 16:30:16 --> Loader Class Initialized
INFO - 2020-07-04 16:30:16 --> Helper loaded: url_helper
INFO - 2020-07-04 16:30:16 --> Helper loaded: main_helper
INFO - 2020-07-04 16:30:16 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:30:16 --> Controller Class Initialized
INFO - 2020-07-04 16:30:16 --> Final output sent to browser
DEBUG - 2020-07-04 16:30:16 --> Total execution time: 0.0037
INFO - 2020-07-04 16:31:14 --> Config Class Initialized
INFO - 2020-07-04 16:31:14 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:31:14 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:31:14 --> Utf8 Class Initialized
INFO - 2020-07-04 16:31:14 --> URI Class Initialized
INFO - 2020-07-04 16:31:14 --> Router Class Initialized
INFO - 2020-07-04 16:31:14 --> Output Class Initialized
INFO - 2020-07-04 16:31:14 --> Security Class Initialized
DEBUG - 2020-07-04 16:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:31:14 --> Input Class Initialized
INFO - 2020-07-04 16:31:14 --> Language Class Initialized
INFO - 2020-07-04 16:31:14 --> Language Class Initialized
INFO - 2020-07-04 16:31:14 --> Config Class Initialized
INFO - 2020-07-04 16:31:14 --> Loader Class Initialized
INFO - 2020-07-04 16:31:14 --> Helper loaded: url_helper
INFO - 2020-07-04 16:31:14 --> Helper loaded: main_helper
INFO - 2020-07-04 16:31:14 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:31:14 --> Controller Class Initialized
DEBUG - 2020-07-04 16:31:14 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:31:14 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:31:14 --> Final output sent to browser
DEBUG - 2020-07-04 16:31:14 --> Total execution time: 0.0035
INFO - 2020-07-04 16:31:15 --> Config Class Initialized
INFO - 2020-07-04 16:31:15 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:31:15 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:31:15 --> Utf8 Class Initialized
INFO - 2020-07-04 16:31:15 --> URI Class Initialized
INFO - 2020-07-04 16:31:15 --> Router Class Initialized
INFO - 2020-07-04 16:31:15 --> Output Class Initialized
INFO - 2020-07-04 16:31:15 --> Security Class Initialized
DEBUG - 2020-07-04 16:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:31:15 --> Input Class Initialized
INFO - 2020-07-04 16:31:15 --> Language Class Initialized
INFO - 2020-07-04 16:31:15 --> Language Class Initialized
INFO - 2020-07-04 16:31:15 --> Config Class Initialized
INFO - 2020-07-04 16:31:15 --> Loader Class Initialized
INFO - 2020-07-04 16:31:15 --> Helper loaded: url_helper
INFO - 2020-07-04 16:31:15 --> Helper loaded: main_helper
INFO - 2020-07-04 16:31:15 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:31:15 --> Controller Class Initialized
INFO - 2020-07-04 16:31:15 --> Final output sent to browser
DEBUG - 2020-07-04 16:31:15 --> Total execution time: 0.0051
INFO - 2020-07-04 16:31:42 --> Config Class Initialized
INFO - 2020-07-04 16:31:42 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:31:42 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:31:42 --> Utf8 Class Initialized
INFO - 2020-07-04 16:31:42 --> URI Class Initialized
INFO - 2020-07-04 16:31:42 --> Router Class Initialized
INFO - 2020-07-04 16:31:42 --> Output Class Initialized
INFO - 2020-07-04 16:31:42 --> Security Class Initialized
DEBUG - 2020-07-04 16:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:31:42 --> Input Class Initialized
INFO - 2020-07-04 16:31:42 --> Language Class Initialized
INFO - 2020-07-04 16:31:42 --> Language Class Initialized
INFO - 2020-07-04 16:31:42 --> Config Class Initialized
INFO - 2020-07-04 16:31:42 --> Loader Class Initialized
INFO - 2020-07-04 16:31:42 --> Helper loaded: url_helper
INFO - 2020-07-04 16:31:42 --> Helper loaded: main_helper
INFO - 2020-07-04 16:31:42 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:31:42 --> Controller Class Initialized
DEBUG - 2020-07-04 16:31:42 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:31:42 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:31:42 --> Final output sent to browser
DEBUG - 2020-07-04 16:31:42 --> Total execution time: 0.0047
INFO - 2020-07-04 16:31:43 --> Config Class Initialized
INFO - 2020-07-04 16:31:43 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:31:43 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:31:43 --> Utf8 Class Initialized
INFO - 2020-07-04 16:31:43 --> URI Class Initialized
INFO - 2020-07-04 16:31:43 --> Router Class Initialized
INFO - 2020-07-04 16:31:43 --> Output Class Initialized
INFO - 2020-07-04 16:31:43 --> Security Class Initialized
DEBUG - 2020-07-04 16:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:31:43 --> Input Class Initialized
INFO - 2020-07-04 16:31:43 --> Language Class Initialized
INFO - 2020-07-04 16:31:43 --> Language Class Initialized
INFO - 2020-07-04 16:31:43 --> Config Class Initialized
INFO - 2020-07-04 16:31:43 --> Loader Class Initialized
INFO - 2020-07-04 16:31:43 --> Helper loaded: url_helper
INFO - 2020-07-04 16:31:43 --> Helper loaded: main_helper
INFO - 2020-07-04 16:31:43 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:31:43 --> Controller Class Initialized
INFO - 2020-07-04 16:31:43 --> Final output sent to browser
DEBUG - 2020-07-04 16:31:43 --> Total execution time: 0.0045
INFO - 2020-07-04 16:31:58 --> Config Class Initialized
INFO - 2020-07-04 16:31:58 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:31:58 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:31:58 --> Utf8 Class Initialized
INFO - 2020-07-04 16:31:58 --> URI Class Initialized
INFO - 2020-07-04 16:31:58 --> Router Class Initialized
INFO - 2020-07-04 16:31:58 --> Output Class Initialized
INFO - 2020-07-04 16:31:58 --> Security Class Initialized
DEBUG - 2020-07-04 16:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:31:58 --> Input Class Initialized
INFO - 2020-07-04 16:31:58 --> Language Class Initialized
INFO - 2020-07-04 16:31:58 --> Language Class Initialized
INFO - 2020-07-04 16:31:58 --> Config Class Initialized
INFO - 2020-07-04 16:31:58 --> Loader Class Initialized
INFO - 2020-07-04 16:31:58 --> Helper loaded: url_helper
INFO - 2020-07-04 16:31:58 --> Helper loaded: main_helper
INFO - 2020-07-04 16:31:58 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:31:58 --> Controller Class Initialized
DEBUG - 2020-07-04 16:31:58 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:31:58 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:31:58 --> Final output sent to browser
DEBUG - 2020-07-04 16:31:58 --> Total execution time: 0.0034
INFO - 2020-07-04 16:31:58 --> Config Class Initialized
INFO - 2020-07-04 16:31:58 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:31:58 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:31:58 --> Utf8 Class Initialized
INFO - 2020-07-04 16:31:58 --> URI Class Initialized
INFO - 2020-07-04 16:31:58 --> Router Class Initialized
INFO - 2020-07-04 16:31:58 --> Output Class Initialized
INFO - 2020-07-04 16:31:58 --> Security Class Initialized
DEBUG - 2020-07-04 16:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:31:58 --> Input Class Initialized
INFO - 2020-07-04 16:31:58 --> Language Class Initialized
INFO - 2020-07-04 16:31:58 --> Language Class Initialized
INFO - 2020-07-04 16:31:58 --> Config Class Initialized
INFO - 2020-07-04 16:31:58 --> Loader Class Initialized
INFO - 2020-07-04 16:31:58 --> Helper loaded: url_helper
INFO - 2020-07-04 16:31:58 --> Helper loaded: main_helper
INFO - 2020-07-04 16:31:58 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:31:58 --> Controller Class Initialized
INFO - 2020-07-04 16:31:58 --> Final output sent to browser
DEBUG - 2020-07-04 16:31:58 --> Total execution time: 0.0086
INFO - 2020-07-04 16:32:11 --> Config Class Initialized
INFO - 2020-07-04 16:32:11 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:32:11 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:32:11 --> Utf8 Class Initialized
INFO - 2020-07-04 16:32:11 --> URI Class Initialized
INFO - 2020-07-04 16:32:11 --> Router Class Initialized
INFO - 2020-07-04 16:32:11 --> Output Class Initialized
INFO - 2020-07-04 16:32:11 --> Security Class Initialized
DEBUG - 2020-07-04 16:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:32:11 --> Input Class Initialized
INFO - 2020-07-04 16:32:11 --> Language Class Initialized
INFO - 2020-07-04 16:32:11 --> Language Class Initialized
INFO - 2020-07-04 16:32:11 --> Config Class Initialized
INFO - 2020-07-04 16:32:11 --> Loader Class Initialized
INFO - 2020-07-04 16:32:11 --> Helper loaded: url_helper
INFO - 2020-07-04 16:32:11 --> Helper loaded: main_helper
INFO - 2020-07-04 16:32:11 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:32:11 --> Controller Class Initialized
DEBUG - 2020-07-04 16:32:11 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:32:11 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:32:11 --> Final output sent to browser
DEBUG - 2020-07-04 16:32:11 --> Total execution time: 0.0036
INFO - 2020-07-04 16:32:12 --> Config Class Initialized
INFO - 2020-07-04 16:32:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:32:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:32:12 --> Utf8 Class Initialized
INFO - 2020-07-04 16:32:12 --> URI Class Initialized
INFO - 2020-07-04 16:32:12 --> Router Class Initialized
INFO - 2020-07-04 16:32:12 --> Output Class Initialized
INFO - 2020-07-04 16:32:12 --> Security Class Initialized
DEBUG - 2020-07-04 16:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:32:12 --> Input Class Initialized
INFO - 2020-07-04 16:32:12 --> Language Class Initialized
INFO - 2020-07-04 16:32:12 --> Language Class Initialized
INFO - 2020-07-04 16:32:12 --> Config Class Initialized
INFO - 2020-07-04 16:32:12 --> Loader Class Initialized
INFO - 2020-07-04 16:32:12 --> Helper loaded: url_helper
INFO - 2020-07-04 16:32:12 --> Helper loaded: main_helper
INFO - 2020-07-04 16:32:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:32:12 --> Controller Class Initialized
INFO - 2020-07-04 16:32:12 --> Final output sent to browser
DEBUG - 2020-07-04 16:32:12 --> Total execution time: 0.0054
INFO - 2020-07-04 16:32:18 --> Config Class Initialized
INFO - 2020-07-04 16:32:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:32:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:32:18 --> Utf8 Class Initialized
INFO - 2020-07-04 16:32:18 --> URI Class Initialized
INFO - 2020-07-04 16:32:18 --> Router Class Initialized
INFO - 2020-07-04 16:32:18 --> Output Class Initialized
INFO - 2020-07-04 16:32:18 --> Security Class Initialized
DEBUG - 2020-07-04 16:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:32:18 --> Input Class Initialized
INFO - 2020-07-04 16:32:18 --> Language Class Initialized
INFO - 2020-07-04 16:32:18 --> Language Class Initialized
INFO - 2020-07-04 16:32:18 --> Config Class Initialized
INFO - 2020-07-04 16:32:18 --> Loader Class Initialized
INFO - 2020-07-04 16:32:18 --> Helper loaded: url_helper
INFO - 2020-07-04 16:32:18 --> Helper loaded: main_helper
INFO - 2020-07-04 16:32:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:32:18 --> Controller Class Initialized
DEBUG - 2020-07-04 16:32:18 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:32:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:32:18 --> Final output sent to browser
DEBUG - 2020-07-04 16:32:18 --> Total execution time: 0.0040
INFO - 2020-07-04 16:32:19 --> Config Class Initialized
INFO - 2020-07-04 16:32:19 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:32:19 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:32:19 --> Utf8 Class Initialized
INFO - 2020-07-04 16:32:19 --> URI Class Initialized
INFO - 2020-07-04 16:32:19 --> Router Class Initialized
INFO - 2020-07-04 16:32:19 --> Output Class Initialized
INFO - 2020-07-04 16:32:19 --> Security Class Initialized
DEBUG - 2020-07-04 16:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:32:19 --> Input Class Initialized
INFO - 2020-07-04 16:32:19 --> Language Class Initialized
INFO - 2020-07-04 16:32:19 --> Language Class Initialized
INFO - 2020-07-04 16:32:19 --> Config Class Initialized
INFO - 2020-07-04 16:32:19 --> Loader Class Initialized
INFO - 2020-07-04 16:32:19 --> Helper loaded: url_helper
INFO - 2020-07-04 16:32:19 --> Helper loaded: main_helper
INFO - 2020-07-04 16:32:19 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:32:19 --> Controller Class Initialized
INFO - 2020-07-04 16:32:19 --> Final output sent to browser
DEBUG - 2020-07-04 16:32:19 --> Total execution time: 0.0068
INFO - 2020-07-04 16:32:41 --> Config Class Initialized
INFO - 2020-07-04 16:32:41 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:32:41 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:32:41 --> Utf8 Class Initialized
INFO - 2020-07-04 16:32:41 --> URI Class Initialized
INFO - 2020-07-04 16:32:41 --> Router Class Initialized
INFO - 2020-07-04 16:32:41 --> Output Class Initialized
INFO - 2020-07-04 16:32:41 --> Security Class Initialized
DEBUG - 2020-07-04 16:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:32:41 --> Input Class Initialized
INFO - 2020-07-04 16:32:41 --> Language Class Initialized
INFO - 2020-07-04 16:32:41 --> Language Class Initialized
INFO - 2020-07-04 16:32:41 --> Config Class Initialized
INFO - 2020-07-04 16:32:41 --> Loader Class Initialized
INFO - 2020-07-04 16:32:41 --> Helper loaded: url_helper
INFO - 2020-07-04 16:32:41 --> Helper loaded: main_helper
INFO - 2020-07-04 16:32:41 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:32:41 --> Controller Class Initialized
DEBUG - 2020-07-04 16:32:41 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:32:41 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:32:41 --> Final output sent to browser
DEBUG - 2020-07-04 16:32:41 --> Total execution time: 0.0053
INFO - 2020-07-04 16:32:42 --> Config Class Initialized
INFO - 2020-07-04 16:32:42 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:32:42 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:32:42 --> Utf8 Class Initialized
INFO - 2020-07-04 16:32:42 --> URI Class Initialized
INFO - 2020-07-04 16:32:42 --> Router Class Initialized
INFO - 2020-07-04 16:32:42 --> Output Class Initialized
INFO - 2020-07-04 16:32:42 --> Security Class Initialized
DEBUG - 2020-07-04 16:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:32:42 --> Input Class Initialized
INFO - 2020-07-04 16:32:42 --> Language Class Initialized
INFO - 2020-07-04 16:32:42 --> Language Class Initialized
INFO - 2020-07-04 16:32:42 --> Config Class Initialized
INFO - 2020-07-04 16:32:42 --> Loader Class Initialized
INFO - 2020-07-04 16:32:42 --> Helper loaded: url_helper
INFO - 2020-07-04 16:32:42 --> Helper loaded: main_helper
INFO - 2020-07-04 16:32:42 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:32:42 --> Controller Class Initialized
INFO - 2020-07-04 16:32:42 --> Final output sent to browser
DEBUG - 2020-07-04 16:32:42 --> Total execution time: 0.0040
INFO - 2020-07-04 16:32:47 --> Config Class Initialized
INFO - 2020-07-04 16:32:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:32:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:32:47 --> Utf8 Class Initialized
INFO - 2020-07-04 16:32:47 --> URI Class Initialized
INFO - 2020-07-04 16:32:47 --> Router Class Initialized
INFO - 2020-07-04 16:32:47 --> Output Class Initialized
INFO - 2020-07-04 16:32:47 --> Security Class Initialized
DEBUG - 2020-07-04 16:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:32:47 --> Input Class Initialized
INFO - 2020-07-04 16:32:47 --> Language Class Initialized
INFO - 2020-07-04 16:32:47 --> Language Class Initialized
INFO - 2020-07-04 16:32:47 --> Config Class Initialized
INFO - 2020-07-04 16:32:47 --> Loader Class Initialized
INFO - 2020-07-04 16:32:47 --> Helper loaded: url_helper
INFO - 2020-07-04 16:32:47 --> Helper loaded: main_helper
INFO - 2020-07-04 16:32:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:32:47 --> Controller Class Initialized
DEBUG - 2020-07-04 16:32:47 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:32:47 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:32:47 --> Final output sent to browser
DEBUG - 2020-07-04 16:32:47 --> Total execution time: 0.0037
INFO - 2020-07-04 16:32:48 --> Config Class Initialized
INFO - 2020-07-04 16:32:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:32:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:32:48 --> Utf8 Class Initialized
INFO - 2020-07-04 16:32:48 --> URI Class Initialized
INFO - 2020-07-04 16:32:48 --> Router Class Initialized
INFO - 2020-07-04 16:32:48 --> Output Class Initialized
INFO - 2020-07-04 16:32:48 --> Security Class Initialized
DEBUG - 2020-07-04 16:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:32:48 --> Input Class Initialized
INFO - 2020-07-04 16:32:48 --> Language Class Initialized
INFO - 2020-07-04 16:32:48 --> Language Class Initialized
INFO - 2020-07-04 16:32:48 --> Config Class Initialized
INFO - 2020-07-04 16:32:48 --> Loader Class Initialized
INFO - 2020-07-04 16:32:48 --> Helper loaded: url_helper
INFO - 2020-07-04 16:32:48 --> Helper loaded: main_helper
INFO - 2020-07-04 16:32:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:32:48 --> Controller Class Initialized
INFO - 2020-07-04 16:32:48 --> Final output sent to browser
DEBUG - 2020-07-04 16:32:48 --> Total execution time: 0.0036
INFO - 2020-07-04 16:33:06 --> Config Class Initialized
INFO - 2020-07-04 16:33:06 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:33:06 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:33:06 --> Utf8 Class Initialized
INFO - 2020-07-04 16:33:06 --> URI Class Initialized
INFO - 2020-07-04 16:33:06 --> Router Class Initialized
INFO - 2020-07-04 16:33:06 --> Output Class Initialized
INFO - 2020-07-04 16:33:06 --> Security Class Initialized
DEBUG - 2020-07-04 16:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:33:06 --> Input Class Initialized
INFO - 2020-07-04 16:33:06 --> Language Class Initialized
INFO - 2020-07-04 16:33:06 --> Language Class Initialized
INFO - 2020-07-04 16:33:06 --> Config Class Initialized
INFO - 2020-07-04 16:33:06 --> Loader Class Initialized
INFO - 2020-07-04 16:33:06 --> Helper loaded: url_helper
INFO - 2020-07-04 16:33:06 --> Helper loaded: main_helper
INFO - 2020-07-04 16:33:06 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:33:06 --> Controller Class Initialized
DEBUG - 2020-07-04 16:33:06 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:33:06 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:33:06 --> Final output sent to browser
DEBUG - 2020-07-04 16:33:06 --> Total execution time: 0.0036
INFO - 2020-07-04 16:33:07 --> Config Class Initialized
INFO - 2020-07-04 16:33:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:33:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:33:07 --> Utf8 Class Initialized
INFO - 2020-07-04 16:33:07 --> URI Class Initialized
INFO - 2020-07-04 16:33:07 --> Router Class Initialized
INFO - 2020-07-04 16:33:07 --> Output Class Initialized
INFO - 2020-07-04 16:33:07 --> Security Class Initialized
DEBUG - 2020-07-04 16:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:33:07 --> Input Class Initialized
INFO - 2020-07-04 16:33:07 --> Language Class Initialized
INFO - 2020-07-04 16:33:07 --> Language Class Initialized
INFO - 2020-07-04 16:33:07 --> Config Class Initialized
INFO - 2020-07-04 16:33:07 --> Loader Class Initialized
INFO - 2020-07-04 16:33:07 --> Helper loaded: url_helper
INFO - 2020-07-04 16:33:07 --> Helper loaded: main_helper
INFO - 2020-07-04 16:33:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:33:07 --> Controller Class Initialized
INFO - 2020-07-04 16:33:07 --> Final output sent to browser
DEBUG - 2020-07-04 16:33:07 --> Total execution time: 0.0076
INFO - 2020-07-04 16:33:39 --> Config Class Initialized
INFO - 2020-07-04 16:33:39 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:33:39 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:33:39 --> Utf8 Class Initialized
INFO - 2020-07-04 16:33:39 --> URI Class Initialized
INFO - 2020-07-04 16:33:39 --> Router Class Initialized
INFO - 2020-07-04 16:33:39 --> Output Class Initialized
INFO - 2020-07-04 16:33:39 --> Security Class Initialized
DEBUG - 2020-07-04 16:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:33:39 --> Input Class Initialized
INFO - 2020-07-04 16:33:39 --> Language Class Initialized
INFO - 2020-07-04 16:33:39 --> Language Class Initialized
INFO - 2020-07-04 16:33:39 --> Config Class Initialized
INFO - 2020-07-04 16:33:39 --> Loader Class Initialized
INFO - 2020-07-04 16:33:39 --> Helper loaded: url_helper
INFO - 2020-07-04 16:33:39 --> Helper loaded: main_helper
INFO - 2020-07-04 16:33:39 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:33:39 --> Controller Class Initialized
DEBUG - 2020-07-04 16:33:39 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:33:39 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:33:39 --> Final output sent to browser
DEBUG - 2020-07-04 16:33:39 --> Total execution time: 0.0037
INFO - 2020-07-04 16:33:40 --> Config Class Initialized
INFO - 2020-07-04 16:33:40 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:33:40 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:33:40 --> Utf8 Class Initialized
INFO - 2020-07-04 16:33:40 --> URI Class Initialized
INFO - 2020-07-04 16:33:40 --> Router Class Initialized
INFO - 2020-07-04 16:33:40 --> Output Class Initialized
INFO - 2020-07-04 16:33:40 --> Security Class Initialized
DEBUG - 2020-07-04 16:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:33:40 --> Input Class Initialized
INFO - 2020-07-04 16:33:40 --> Language Class Initialized
INFO - 2020-07-04 16:33:40 --> Language Class Initialized
INFO - 2020-07-04 16:33:40 --> Config Class Initialized
INFO - 2020-07-04 16:33:40 --> Loader Class Initialized
INFO - 2020-07-04 16:33:40 --> Helper loaded: url_helper
INFO - 2020-07-04 16:33:40 --> Helper loaded: main_helper
INFO - 2020-07-04 16:33:40 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:33:40 --> Controller Class Initialized
INFO - 2020-07-04 16:33:40 --> Final output sent to browser
DEBUG - 2020-07-04 16:33:40 --> Total execution time: 0.0043
INFO - 2020-07-04 16:34:12 --> Config Class Initialized
INFO - 2020-07-04 16:34:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:34:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:34:12 --> Utf8 Class Initialized
INFO - 2020-07-04 16:34:12 --> URI Class Initialized
INFO - 2020-07-04 16:34:12 --> Router Class Initialized
INFO - 2020-07-04 16:34:12 --> Output Class Initialized
INFO - 2020-07-04 16:34:12 --> Security Class Initialized
DEBUG - 2020-07-04 16:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:34:12 --> Input Class Initialized
INFO - 2020-07-04 16:34:12 --> Language Class Initialized
INFO - 2020-07-04 16:34:12 --> Language Class Initialized
INFO - 2020-07-04 16:34:12 --> Config Class Initialized
INFO - 2020-07-04 16:34:12 --> Loader Class Initialized
INFO - 2020-07-04 16:34:12 --> Helper loaded: url_helper
INFO - 2020-07-04 16:34:12 --> Helper loaded: main_helper
INFO - 2020-07-04 16:34:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:34:12 --> Controller Class Initialized
DEBUG - 2020-07-04 16:34:12 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:34:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:34:12 --> Final output sent to browser
DEBUG - 2020-07-04 16:34:12 --> Total execution time: 0.0045
INFO - 2020-07-04 16:34:13 --> Config Class Initialized
INFO - 2020-07-04 16:34:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:34:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:34:13 --> Utf8 Class Initialized
INFO - 2020-07-04 16:34:13 --> URI Class Initialized
INFO - 2020-07-04 16:34:13 --> Router Class Initialized
INFO - 2020-07-04 16:34:13 --> Output Class Initialized
INFO - 2020-07-04 16:34:13 --> Security Class Initialized
DEBUG - 2020-07-04 16:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:34:13 --> Input Class Initialized
INFO - 2020-07-04 16:34:13 --> Language Class Initialized
INFO - 2020-07-04 16:34:13 --> Language Class Initialized
INFO - 2020-07-04 16:34:13 --> Config Class Initialized
INFO - 2020-07-04 16:34:13 --> Loader Class Initialized
INFO - 2020-07-04 16:34:13 --> Helper loaded: url_helper
INFO - 2020-07-04 16:34:13 --> Helper loaded: main_helper
INFO - 2020-07-04 16:34:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:34:13 --> Controller Class Initialized
INFO - 2020-07-04 16:34:13 --> Final output sent to browser
DEBUG - 2020-07-04 16:34:13 --> Total execution time: 0.0059
INFO - 2020-07-04 16:34:41 --> Config Class Initialized
INFO - 2020-07-04 16:34:41 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:34:41 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:34:41 --> Utf8 Class Initialized
INFO - 2020-07-04 16:34:41 --> URI Class Initialized
INFO - 2020-07-04 16:34:41 --> Router Class Initialized
INFO - 2020-07-04 16:34:41 --> Output Class Initialized
INFO - 2020-07-04 16:34:41 --> Security Class Initialized
DEBUG - 2020-07-04 16:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:34:41 --> Input Class Initialized
INFO - 2020-07-04 16:34:41 --> Language Class Initialized
INFO - 2020-07-04 16:34:41 --> Language Class Initialized
INFO - 2020-07-04 16:34:41 --> Config Class Initialized
INFO - 2020-07-04 16:34:41 --> Loader Class Initialized
INFO - 2020-07-04 16:34:41 --> Helper loaded: url_helper
INFO - 2020-07-04 16:34:41 --> Helper loaded: main_helper
INFO - 2020-07-04 16:34:41 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:34:41 --> Controller Class Initialized
DEBUG - 2020-07-04 16:34:41 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:34:41 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:34:41 --> Final output sent to browser
DEBUG - 2020-07-04 16:34:41 --> Total execution time: 0.0038
INFO - 2020-07-04 16:34:42 --> Config Class Initialized
INFO - 2020-07-04 16:34:42 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:34:42 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:34:42 --> Utf8 Class Initialized
INFO - 2020-07-04 16:34:42 --> URI Class Initialized
INFO - 2020-07-04 16:34:42 --> Router Class Initialized
INFO - 2020-07-04 16:34:42 --> Output Class Initialized
INFO - 2020-07-04 16:34:42 --> Security Class Initialized
DEBUG - 2020-07-04 16:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:34:42 --> Input Class Initialized
INFO - 2020-07-04 16:34:42 --> Language Class Initialized
INFO - 2020-07-04 16:34:42 --> Language Class Initialized
INFO - 2020-07-04 16:34:42 --> Config Class Initialized
INFO - 2020-07-04 16:34:42 --> Loader Class Initialized
INFO - 2020-07-04 16:34:42 --> Helper loaded: url_helper
INFO - 2020-07-04 16:34:42 --> Helper loaded: main_helper
INFO - 2020-07-04 16:34:42 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:34:42 --> Controller Class Initialized
INFO - 2020-07-04 16:34:42 --> Final output sent to browser
DEBUG - 2020-07-04 16:34:42 --> Total execution time: 0.0040
INFO - 2020-07-04 16:35:16 --> Config Class Initialized
INFO - 2020-07-04 16:35:16 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:35:16 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:35:16 --> Utf8 Class Initialized
INFO - 2020-07-04 16:35:16 --> URI Class Initialized
INFO - 2020-07-04 16:35:16 --> Router Class Initialized
INFO - 2020-07-04 16:35:16 --> Output Class Initialized
INFO - 2020-07-04 16:35:16 --> Security Class Initialized
DEBUG - 2020-07-04 16:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:35:16 --> Input Class Initialized
INFO - 2020-07-04 16:35:16 --> Language Class Initialized
INFO - 2020-07-04 16:35:16 --> Language Class Initialized
INFO - 2020-07-04 16:35:16 --> Config Class Initialized
INFO - 2020-07-04 16:35:16 --> Loader Class Initialized
INFO - 2020-07-04 16:35:16 --> Helper loaded: url_helper
INFO - 2020-07-04 16:35:16 --> Helper loaded: main_helper
INFO - 2020-07-04 16:35:16 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:35:16 --> Controller Class Initialized
DEBUG - 2020-07-04 16:35:16 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:35:16 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:35:16 --> Final output sent to browser
DEBUG - 2020-07-04 16:35:16 --> Total execution time: 0.0062
INFO - 2020-07-04 16:35:17 --> Config Class Initialized
INFO - 2020-07-04 16:35:17 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:35:17 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:35:17 --> Utf8 Class Initialized
INFO - 2020-07-04 16:35:17 --> URI Class Initialized
INFO - 2020-07-04 16:35:17 --> Router Class Initialized
INFO - 2020-07-04 16:35:17 --> Output Class Initialized
INFO - 2020-07-04 16:35:17 --> Security Class Initialized
DEBUG - 2020-07-04 16:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:35:17 --> Input Class Initialized
INFO - 2020-07-04 16:35:17 --> Language Class Initialized
INFO - 2020-07-04 16:35:17 --> Language Class Initialized
INFO - 2020-07-04 16:35:17 --> Config Class Initialized
INFO - 2020-07-04 16:35:17 --> Loader Class Initialized
INFO - 2020-07-04 16:35:17 --> Helper loaded: url_helper
INFO - 2020-07-04 16:35:17 --> Helper loaded: main_helper
INFO - 2020-07-04 16:35:17 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:35:17 --> Controller Class Initialized
INFO - 2020-07-04 16:35:17 --> Final output sent to browser
DEBUG - 2020-07-04 16:35:17 --> Total execution time: 0.0045
INFO - 2020-07-04 16:36:11 --> Config Class Initialized
INFO - 2020-07-04 16:36:11 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:36:11 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:36:11 --> Utf8 Class Initialized
INFO - 2020-07-04 16:36:11 --> URI Class Initialized
INFO - 2020-07-04 16:36:11 --> Router Class Initialized
INFO - 2020-07-04 16:36:11 --> Output Class Initialized
INFO - 2020-07-04 16:36:11 --> Security Class Initialized
DEBUG - 2020-07-04 16:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:36:11 --> Input Class Initialized
INFO - 2020-07-04 16:36:11 --> Language Class Initialized
INFO - 2020-07-04 16:36:11 --> Language Class Initialized
INFO - 2020-07-04 16:36:11 --> Config Class Initialized
INFO - 2020-07-04 16:36:11 --> Loader Class Initialized
INFO - 2020-07-04 16:36:11 --> Helper loaded: url_helper
INFO - 2020-07-04 16:36:11 --> Helper loaded: main_helper
INFO - 2020-07-04 16:36:11 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:36:11 --> Controller Class Initialized
DEBUG - 2020-07-04 16:36:11 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:36:11 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:36:11 --> Final output sent to browser
DEBUG - 2020-07-04 16:36:11 --> Total execution time: 0.0036
INFO - 2020-07-04 16:36:12 --> Config Class Initialized
INFO - 2020-07-04 16:36:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:36:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:36:12 --> Utf8 Class Initialized
INFO - 2020-07-04 16:36:12 --> URI Class Initialized
INFO - 2020-07-04 16:36:12 --> Router Class Initialized
INFO - 2020-07-04 16:36:12 --> Output Class Initialized
INFO - 2020-07-04 16:36:12 --> Security Class Initialized
DEBUG - 2020-07-04 16:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:36:12 --> Input Class Initialized
INFO - 2020-07-04 16:36:12 --> Language Class Initialized
INFO - 2020-07-04 16:36:12 --> Language Class Initialized
INFO - 2020-07-04 16:36:12 --> Config Class Initialized
INFO - 2020-07-04 16:36:12 --> Loader Class Initialized
INFO - 2020-07-04 16:36:12 --> Helper loaded: url_helper
INFO - 2020-07-04 16:36:12 --> Helper loaded: main_helper
INFO - 2020-07-04 16:36:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:36:12 --> Controller Class Initialized
INFO - 2020-07-04 16:36:12 --> Final output sent to browser
DEBUG - 2020-07-04 16:36:12 --> Total execution time: 0.0063
INFO - 2020-07-04 16:36:21 --> Config Class Initialized
INFO - 2020-07-04 16:36:21 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:36:21 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:36:21 --> Utf8 Class Initialized
INFO - 2020-07-04 16:36:21 --> URI Class Initialized
INFO - 2020-07-04 16:36:21 --> Router Class Initialized
INFO - 2020-07-04 16:36:21 --> Output Class Initialized
INFO - 2020-07-04 16:36:21 --> Security Class Initialized
DEBUG - 2020-07-04 16:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:36:21 --> Input Class Initialized
INFO - 2020-07-04 16:36:21 --> Language Class Initialized
INFO - 2020-07-04 16:36:21 --> Language Class Initialized
INFO - 2020-07-04 16:36:21 --> Config Class Initialized
INFO - 2020-07-04 16:36:21 --> Loader Class Initialized
INFO - 2020-07-04 16:36:21 --> Helper loaded: url_helper
INFO - 2020-07-04 16:36:21 --> Helper loaded: main_helper
INFO - 2020-07-04 16:36:21 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:36:21 --> Controller Class Initialized
DEBUG - 2020-07-04 16:36:21 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:36:21 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:36:21 --> Final output sent to browser
DEBUG - 2020-07-04 16:36:21 --> Total execution time: 0.0035
INFO - 2020-07-04 16:36:22 --> Config Class Initialized
INFO - 2020-07-04 16:36:22 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:36:22 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:36:22 --> Utf8 Class Initialized
INFO - 2020-07-04 16:36:22 --> URI Class Initialized
INFO - 2020-07-04 16:36:22 --> Router Class Initialized
INFO - 2020-07-04 16:36:22 --> Output Class Initialized
INFO - 2020-07-04 16:36:22 --> Security Class Initialized
DEBUG - 2020-07-04 16:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:36:22 --> Input Class Initialized
INFO - 2020-07-04 16:36:22 --> Language Class Initialized
INFO - 2020-07-04 16:36:22 --> Language Class Initialized
INFO - 2020-07-04 16:36:22 --> Config Class Initialized
INFO - 2020-07-04 16:36:22 --> Loader Class Initialized
INFO - 2020-07-04 16:36:22 --> Helper loaded: url_helper
INFO - 2020-07-04 16:36:22 --> Helper loaded: main_helper
INFO - 2020-07-04 16:36:22 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:36:22 --> Controller Class Initialized
INFO - 2020-07-04 16:36:22 --> Final output sent to browser
DEBUG - 2020-07-04 16:36:22 --> Total execution time: 0.0072
INFO - 2020-07-04 16:37:47 --> Config Class Initialized
INFO - 2020-07-04 16:37:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:37:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:37:47 --> Utf8 Class Initialized
INFO - 2020-07-04 16:37:47 --> URI Class Initialized
INFO - 2020-07-04 16:37:47 --> Router Class Initialized
INFO - 2020-07-04 16:37:47 --> Output Class Initialized
INFO - 2020-07-04 16:37:47 --> Security Class Initialized
DEBUG - 2020-07-04 16:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:37:47 --> Input Class Initialized
INFO - 2020-07-04 16:37:47 --> Language Class Initialized
INFO - 2020-07-04 16:37:47 --> Language Class Initialized
INFO - 2020-07-04 16:37:47 --> Config Class Initialized
INFO - 2020-07-04 16:37:47 --> Loader Class Initialized
INFO - 2020-07-04 16:37:47 --> Helper loaded: url_helper
INFO - 2020-07-04 16:37:47 --> Helper loaded: main_helper
INFO - 2020-07-04 16:37:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:37:47 --> Controller Class Initialized
DEBUG - 2020-07-04 16:37:47 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:37:47 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:37:47 --> Final output sent to browser
DEBUG - 2020-07-04 16:37:47 --> Total execution time: 0.0043
INFO - 2020-07-04 16:37:47 --> Config Class Initialized
INFO - 2020-07-04 16:37:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:37:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:37:47 --> Utf8 Class Initialized
INFO - 2020-07-04 16:37:47 --> URI Class Initialized
INFO - 2020-07-04 16:37:47 --> Router Class Initialized
INFO - 2020-07-04 16:37:47 --> Output Class Initialized
INFO - 2020-07-04 16:37:47 --> Security Class Initialized
DEBUG - 2020-07-04 16:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:37:47 --> Input Class Initialized
INFO - 2020-07-04 16:37:47 --> Language Class Initialized
INFO - 2020-07-04 16:37:47 --> Language Class Initialized
INFO - 2020-07-04 16:37:47 --> Config Class Initialized
INFO - 2020-07-04 16:37:47 --> Loader Class Initialized
INFO - 2020-07-04 16:37:47 --> Helper loaded: url_helper
INFO - 2020-07-04 16:37:47 --> Helper loaded: main_helper
INFO - 2020-07-04 16:37:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:37:47 --> Controller Class Initialized
INFO - 2020-07-04 16:37:47 --> Final output sent to browser
DEBUG - 2020-07-04 16:37:47 --> Total execution time: 0.0068
INFO - 2020-07-04 16:39:04 --> Config Class Initialized
INFO - 2020-07-04 16:39:04 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:39:04 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:39:04 --> Utf8 Class Initialized
INFO - 2020-07-04 16:39:04 --> URI Class Initialized
INFO - 2020-07-04 16:39:04 --> Router Class Initialized
INFO - 2020-07-04 16:39:04 --> Output Class Initialized
INFO - 2020-07-04 16:39:04 --> Security Class Initialized
DEBUG - 2020-07-04 16:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:39:04 --> Input Class Initialized
INFO - 2020-07-04 16:39:04 --> Language Class Initialized
INFO - 2020-07-04 16:39:04 --> Language Class Initialized
INFO - 2020-07-04 16:39:04 --> Config Class Initialized
INFO - 2020-07-04 16:39:04 --> Loader Class Initialized
INFO - 2020-07-04 16:39:04 --> Helper loaded: url_helper
INFO - 2020-07-04 16:39:04 --> Helper loaded: main_helper
INFO - 2020-07-04 16:39:04 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:39:04 --> Controller Class Initialized
DEBUG - 2020-07-04 16:39:04 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:39:04 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:39:04 --> Final output sent to browser
DEBUG - 2020-07-04 16:39:04 --> Total execution time: 0.0044
INFO - 2020-07-04 16:39:05 --> Config Class Initialized
INFO - 2020-07-04 16:39:05 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:39:05 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:39:05 --> Utf8 Class Initialized
INFO - 2020-07-04 16:39:05 --> URI Class Initialized
INFO - 2020-07-04 16:39:05 --> Router Class Initialized
INFO - 2020-07-04 16:39:05 --> Output Class Initialized
INFO - 2020-07-04 16:39:05 --> Security Class Initialized
DEBUG - 2020-07-04 16:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:39:05 --> Input Class Initialized
INFO - 2020-07-04 16:39:05 --> Language Class Initialized
INFO - 2020-07-04 16:39:05 --> Language Class Initialized
INFO - 2020-07-04 16:39:05 --> Config Class Initialized
INFO - 2020-07-04 16:39:05 --> Loader Class Initialized
INFO - 2020-07-04 16:39:05 --> Helper loaded: url_helper
INFO - 2020-07-04 16:39:05 --> Helper loaded: main_helper
INFO - 2020-07-04 16:39:05 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:39:05 --> Controller Class Initialized
INFO - 2020-07-04 16:39:05 --> Final output sent to browser
DEBUG - 2020-07-04 16:39:05 --> Total execution time: 0.0060
INFO - 2020-07-04 16:40:13 --> Config Class Initialized
INFO - 2020-07-04 16:40:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:40:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:40:13 --> Utf8 Class Initialized
INFO - 2020-07-04 16:40:13 --> URI Class Initialized
INFO - 2020-07-04 16:40:13 --> Router Class Initialized
INFO - 2020-07-04 16:40:13 --> Output Class Initialized
INFO - 2020-07-04 16:40:13 --> Security Class Initialized
DEBUG - 2020-07-04 16:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:40:13 --> Input Class Initialized
INFO - 2020-07-04 16:40:13 --> Language Class Initialized
INFO - 2020-07-04 16:40:13 --> Language Class Initialized
INFO - 2020-07-04 16:40:13 --> Config Class Initialized
INFO - 2020-07-04 16:40:13 --> Loader Class Initialized
INFO - 2020-07-04 16:40:13 --> Helper loaded: url_helper
INFO - 2020-07-04 16:40:13 --> Helper loaded: main_helper
INFO - 2020-07-04 16:40:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:40:13 --> Controller Class Initialized
DEBUG - 2020-07-04 16:40:13 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:40:13 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:40:13 --> Final output sent to browser
DEBUG - 2020-07-04 16:40:13 --> Total execution time: 0.0033
INFO - 2020-07-04 16:40:14 --> Config Class Initialized
INFO - 2020-07-04 16:40:14 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:40:14 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:40:14 --> Utf8 Class Initialized
INFO - 2020-07-04 16:40:14 --> URI Class Initialized
INFO - 2020-07-04 16:40:14 --> Router Class Initialized
INFO - 2020-07-04 16:40:14 --> Output Class Initialized
INFO - 2020-07-04 16:40:14 --> Security Class Initialized
DEBUG - 2020-07-04 16:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:40:14 --> Input Class Initialized
INFO - 2020-07-04 16:40:14 --> Language Class Initialized
INFO - 2020-07-04 16:40:14 --> Language Class Initialized
INFO - 2020-07-04 16:40:14 --> Config Class Initialized
INFO - 2020-07-04 16:40:14 --> Loader Class Initialized
INFO - 2020-07-04 16:40:14 --> Helper loaded: url_helper
INFO - 2020-07-04 16:40:14 --> Helper loaded: main_helper
INFO - 2020-07-04 16:40:14 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:40:14 --> Controller Class Initialized
INFO - 2020-07-04 16:40:14 --> Final output sent to browser
DEBUG - 2020-07-04 16:40:14 --> Total execution time: 0.0048
INFO - 2020-07-04 16:41:32 --> Config Class Initialized
INFO - 2020-07-04 16:41:32 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:41:32 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:41:32 --> Utf8 Class Initialized
INFO - 2020-07-04 16:41:32 --> URI Class Initialized
INFO - 2020-07-04 16:41:32 --> Router Class Initialized
INFO - 2020-07-04 16:41:32 --> Output Class Initialized
INFO - 2020-07-04 16:41:32 --> Security Class Initialized
DEBUG - 2020-07-04 16:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:41:32 --> Input Class Initialized
INFO - 2020-07-04 16:41:32 --> Language Class Initialized
INFO - 2020-07-04 16:41:32 --> Language Class Initialized
INFO - 2020-07-04 16:41:32 --> Config Class Initialized
INFO - 2020-07-04 16:41:32 --> Loader Class Initialized
INFO - 2020-07-04 16:41:32 --> Helper loaded: url_helper
INFO - 2020-07-04 16:41:32 --> Helper loaded: main_helper
INFO - 2020-07-04 16:41:32 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:41:32 --> Controller Class Initialized
DEBUG - 2020-07-04 16:41:32 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:41:32 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:41:32 --> Final output sent to browser
DEBUG - 2020-07-04 16:41:32 --> Total execution time: 0.0047
INFO - 2020-07-04 16:41:33 --> Config Class Initialized
INFO - 2020-07-04 16:41:33 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:41:33 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:41:33 --> Utf8 Class Initialized
INFO - 2020-07-04 16:41:33 --> URI Class Initialized
INFO - 2020-07-04 16:41:33 --> Router Class Initialized
INFO - 2020-07-04 16:41:33 --> Output Class Initialized
INFO - 2020-07-04 16:41:33 --> Security Class Initialized
DEBUG - 2020-07-04 16:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:41:33 --> Input Class Initialized
INFO - 2020-07-04 16:41:33 --> Language Class Initialized
INFO - 2020-07-04 16:41:33 --> Language Class Initialized
INFO - 2020-07-04 16:41:33 --> Config Class Initialized
INFO - 2020-07-04 16:41:33 --> Loader Class Initialized
INFO - 2020-07-04 16:41:33 --> Helper loaded: url_helper
INFO - 2020-07-04 16:41:33 --> Helper loaded: main_helper
INFO - 2020-07-04 16:41:33 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:41:33 --> Controller Class Initialized
INFO - 2020-07-04 16:41:33 --> Final output sent to browser
DEBUG - 2020-07-04 16:41:33 --> Total execution time: 0.0037
INFO - 2020-07-04 16:42:03 --> Config Class Initialized
INFO - 2020-07-04 16:42:03 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:42:03 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:42:03 --> Utf8 Class Initialized
INFO - 2020-07-04 16:42:03 --> URI Class Initialized
INFO - 2020-07-04 16:42:03 --> Router Class Initialized
INFO - 2020-07-04 16:42:03 --> Output Class Initialized
INFO - 2020-07-04 16:42:03 --> Security Class Initialized
DEBUG - 2020-07-04 16:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:42:03 --> Input Class Initialized
INFO - 2020-07-04 16:42:03 --> Language Class Initialized
INFO - 2020-07-04 16:42:03 --> Language Class Initialized
INFO - 2020-07-04 16:42:03 --> Config Class Initialized
INFO - 2020-07-04 16:42:03 --> Loader Class Initialized
INFO - 2020-07-04 16:42:03 --> Helper loaded: url_helper
INFO - 2020-07-04 16:42:03 --> Helper loaded: main_helper
INFO - 2020-07-04 16:42:03 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:42:03 --> Controller Class Initialized
DEBUG - 2020-07-04 16:42:03 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:42:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:42:03 --> Final output sent to browser
DEBUG - 2020-07-04 16:42:03 --> Total execution time: 0.0035
INFO - 2020-07-04 16:42:04 --> Config Class Initialized
INFO - 2020-07-04 16:42:04 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:42:04 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:42:04 --> Utf8 Class Initialized
INFO - 2020-07-04 16:42:04 --> URI Class Initialized
INFO - 2020-07-04 16:42:04 --> Router Class Initialized
INFO - 2020-07-04 16:42:04 --> Output Class Initialized
INFO - 2020-07-04 16:42:04 --> Security Class Initialized
DEBUG - 2020-07-04 16:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:42:04 --> Input Class Initialized
INFO - 2020-07-04 16:42:04 --> Language Class Initialized
INFO - 2020-07-04 16:42:04 --> Language Class Initialized
INFO - 2020-07-04 16:42:04 --> Config Class Initialized
INFO - 2020-07-04 16:42:04 --> Loader Class Initialized
INFO - 2020-07-04 16:42:04 --> Helper loaded: url_helper
INFO - 2020-07-04 16:42:04 --> Helper loaded: main_helper
INFO - 2020-07-04 16:42:04 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:42:04 --> Controller Class Initialized
INFO - 2020-07-04 16:42:04 --> Final output sent to browser
DEBUG - 2020-07-04 16:42:04 --> Total execution time: 0.0075
INFO - 2020-07-04 16:46:39 --> Config Class Initialized
INFO - 2020-07-04 16:46:39 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:46:39 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:46:39 --> Utf8 Class Initialized
INFO - 2020-07-04 16:46:39 --> URI Class Initialized
INFO - 2020-07-04 16:46:39 --> Router Class Initialized
INFO - 2020-07-04 16:46:39 --> Output Class Initialized
INFO - 2020-07-04 16:46:39 --> Security Class Initialized
DEBUG - 2020-07-04 16:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:46:39 --> Input Class Initialized
INFO - 2020-07-04 16:46:39 --> Language Class Initialized
INFO - 2020-07-04 16:46:39 --> Language Class Initialized
INFO - 2020-07-04 16:46:39 --> Config Class Initialized
INFO - 2020-07-04 16:46:39 --> Loader Class Initialized
INFO - 2020-07-04 16:46:39 --> Helper loaded: url_helper
INFO - 2020-07-04 16:46:39 --> Helper loaded: main_helper
INFO - 2020-07-04 16:46:39 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:46:39 --> Controller Class Initialized
DEBUG - 2020-07-04 16:46:39 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:46:39 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:46:39 --> Final output sent to browser
DEBUG - 2020-07-04 16:46:39 --> Total execution time: 0.0083
INFO - 2020-07-04 16:46:40 --> Config Class Initialized
INFO - 2020-07-04 16:46:40 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:46:40 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:46:40 --> Utf8 Class Initialized
INFO - 2020-07-04 16:46:40 --> URI Class Initialized
INFO - 2020-07-04 16:46:40 --> Router Class Initialized
INFO - 2020-07-04 16:46:40 --> Output Class Initialized
INFO - 2020-07-04 16:46:40 --> Security Class Initialized
DEBUG - 2020-07-04 16:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:46:40 --> Input Class Initialized
INFO - 2020-07-04 16:46:40 --> Language Class Initialized
INFO - 2020-07-04 16:46:40 --> Language Class Initialized
INFO - 2020-07-04 16:46:40 --> Config Class Initialized
INFO - 2020-07-04 16:46:40 --> Loader Class Initialized
INFO - 2020-07-04 16:46:40 --> Helper loaded: url_helper
INFO - 2020-07-04 16:46:40 --> Helper loaded: main_helper
INFO - 2020-07-04 16:46:40 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:46:40 --> Controller Class Initialized
INFO - 2020-07-04 16:46:40 --> Final output sent to browser
DEBUG - 2020-07-04 16:46:40 --> Total execution time: 0.0062
INFO - 2020-07-04 16:46:48 --> Config Class Initialized
INFO - 2020-07-04 16:46:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:46:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:46:48 --> Utf8 Class Initialized
INFO - 2020-07-04 16:46:48 --> URI Class Initialized
INFO - 2020-07-04 16:46:48 --> Router Class Initialized
INFO - 2020-07-04 16:46:48 --> Output Class Initialized
INFO - 2020-07-04 16:46:48 --> Security Class Initialized
DEBUG - 2020-07-04 16:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:46:48 --> Input Class Initialized
INFO - 2020-07-04 16:46:48 --> Language Class Initialized
INFO - 2020-07-04 16:46:48 --> Language Class Initialized
INFO - 2020-07-04 16:46:48 --> Config Class Initialized
INFO - 2020-07-04 16:46:48 --> Loader Class Initialized
INFO - 2020-07-04 16:46:48 --> Helper loaded: url_helper
INFO - 2020-07-04 16:46:48 --> Helper loaded: main_helper
INFO - 2020-07-04 16:46:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:46:48 --> Controller Class Initialized
DEBUG - 2020-07-04 16:46:48 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:46:48 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:46:48 --> Final output sent to browser
DEBUG - 2020-07-04 16:46:48 --> Total execution time: 0.0036
INFO - 2020-07-04 16:46:49 --> Config Class Initialized
INFO - 2020-07-04 16:46:49 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:46:49 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:46:49 --> Utf8 Class Initialized
INFO - 2020-07-04 16:46:49 --> URI Class Initialized
INFO - 2020-07-04 16:46:49 --> Router Class Initialized
INFO - 2020-07-04 16:46:49 --> Output Class Initialized
INFO - 2020-07-04 16:46:49 --> Security Class Initialized
DEBUG - 2020-07-04 16:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:46:49 --> Input Class Initialized
INFO - 2020-07-04 16:46:49 --> Language Class Initialized
INFO - 2020-07-04 16:46:49 --> Language Class Initialized
INFO - 2020-07-04 16:46:49 --> Config Class Initialized
INFO - 2020-07-04 16:46:49 --> Loader Class Initialized
INFO - 2020-07-04 16:46:49 --> Helper loaded: url_helper
INFO - 2020-07-04 16:46:49 --> Helper loaded: main_helper
INFO - 2020-07-04 16:46:49 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:46:49 --> Controller Class Initialized
INFO - 2020-07-04 16:46:49 --> Final output sent to browser
DEBUG - 2020-07-04 16:46:49 --> Total execution time: 0.0041
INFO - 2020-07-04 16:48:09 --> Config Class Initialized
INFO - 2020-07-04 16:48:09 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:48:09 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:48:09 --> Utf8 Class Initialized
INFO - 2020-07-04 16:48:09 --> URI Class Initialized
INFO - 2020-07-04 16:48:09 --> Router Class Initialized
INFO - 2020-07-04 16:48:09 --> Output Class Initialized
INFO - 2020-07-04 16:48:09 --> Security Class Initialized
DEBUG - 2020-07-04 16:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:48:09 --> Input Class Initialized
INFO - 2020-07-04 16:48:09 --> Language Class Initialized
INFO - 2020-07-04 16:48:09 --> Language Class Initialized
INFO - 2020-07-04 16:48:09 --> Config Class Initialized
INFO - 2020-07-04 16:48:09 --> Loader Class Initialized
INFO - 2020-07-04 16:48:09 --> Helper loaded: url_helper
INFO - 2020-07-04 16:48:09 --> Helper loaded: main_helper
INFO - 2020-07-04 16:48:09 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:48:09 --> Controller Class Initialized
DEBUG - 2020-07-04 16:48:09 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:48:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:48:09 --> Final output sent to browser
DEBUG - 2020-07-04 16:48:09 --> Total execution time: 0.0052
INFO - 2020-07-04 16:48:10 --> Config Class Initialized
INFO - 2020-07-04 16:48:10 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:48:10 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:48:10 --> Utf8 Class Initialized
INFO - 2020-07-04 16:48:10 --> URI Class Initialized
INFO - 2020-07-04 16:48:10 --> Router Class Initialized
INFO - 2020-07-04 16:48:10 --> Output Class Initialized
INFO - 2020-07-04 16:48:10 --> Security Class Initialized
DEBUG - 2020-07-04 16:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:48:10 --> Input Class Initialized
INFO - 2020-07-04 16:48:10 --> Language Class Initialized
INFO - 2020-07-04 16:48:10 --> Language Class Initialized
INFO - 2020-07-04 16:48:10 --> Config Class Initialized
INFO - 2020-07-04 16:48:10 --> Loader Class Initialized
INFO - 2020-07-04 16:48:10 --> Helper loaded: url_helper
INFO - 2020-07-04 16:48:10 --> Helper loaded: main_helper
INFO - 2020-07-04 16:48:10 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:48:10 --> Controller Class Initialized
INFO - 2020-07-04 16:48:10 --> Final output sent to browser
DEBUG - 2020-07-04 16:48:10 --> Total execution time: 0.0076
INFO - 2020-07-04 16:48:30 --> Config Class Initialized
INFO - 2020-07-04 16:48:30 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:48:30 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:48:30 --> Utf8 Class Initialized
INFO - 2020-07-04 16:48:30 --> URI Class Initialized
INFO - 2020-07-04 16:48:30 --> Router Class Initialized
INFO - 2020-07-04 16:48:30 --> Output Class Initialized
INFO - 2020-07-04 16:48:30 --> Security Class Initialized
DEBUG - 2020-07-04 16:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:48:30 --> Input Class Initialized
INFO - 2020-07-04 16:48:30 --> Language Class Initialized
INFO - 2020-07-04 16:48:30 --> Language Class Initialized
INFO - 2020-07-04 16:48:30 --> Config Class Initialized
INFO - 2020-07-04 16:48:30 --> Loader Class Initialized
INFO - 2020-07-04 16:48:30 --> Helper loaded: url_helper
INFO - 2020-07-04 16:48:30 --> Helper loaded: main_helper
INFO - 2020-07-04 16:48:30 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:48:31 --> Controller Class Initialized
DEBUG - 2020-07-04 16:48:31 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:48:31 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:48:31 --> Final output sent to browser
DEBUG - 2020-07-04 16:48:31 --> Total execution time: 0.0058
INFO - 2020-07-04 16:48:32 --> Config Class Initialized
INFO - 2020-07-04 16:48:32 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:48:32 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:48:32 --> Utf8 Class Initialized
INFO - 2020-07-04 16:48:32 --> URI Class Initialized
INFO - 2020-07-04 16:48:32 --> Router Class Initialized
INFO - 2020-07-04 16:48:32 --> Output Class Initialized
INFO - 2020-07-04 16:48:32 --> Security Class Initialized
DEBUG - 2020-07-04 16:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:48:32 --> Input Class Initialized
INFO - 2020-07-04 16:48:32 --> Language Class Initialized
INFO - 2020-07-04 16:48:32 --> Language Class Initialized
INFO - 2020-07-04 16:48:32 --> Config Class Initialized
INFO - 2020-07-04 16:48:32 --> Loader Class Initialized
INFO - 2020-07-04 16:48:32 --> Helper loaded: url_helper
INFO - 2020-07-04 16:48:32 --> Helper loaded: main_helper
INFO - 2020-07-04 16:48:32 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:48:32 --> Controller Class Initialized
INFO - 2020-07-04 16:48:32 --> Final output sent to browser
DEBUG - 2020-07-04 16:48:32 --> Total execution time: 0.0051
INFO - 2020-07-04 16:49:32 --> Config Class Initialized
INFO - 2020-07-04 16:49:32 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:49:32 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:49:32 --> Utf8 Class Initialized
INFO - 2020-07-04 16:49:32 --> URI Class Initialized
INFO - 2020-07-04 16:49:32 --> Router Class Initialized
INFO - 2020-07-04 16:49:32 --> Output Class Initialized
INFO - 2020-07-04 16:49:32 --> Security Class Initialized
DEBUG - 2020-07-04 16:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:49:32 --> Input Class Initialized
INFO - 2020-07-04 16:49:32 --> Language Class Initialized
INFO - 2020-07-04 16:49:32 --> Language Class Initialized
INFO - 2020-07-04 16:49:32 --> Config Class Initialized
INFO - 2020-07-04 16:49:32 --> Loader Class Initialized
INFO - 2020-07-04 16:49:32 --> Helper loaded: url_helper
INFO - 2020-07-04 16:49:32 --> Helper loaded: main_helper
INFO - 2020-07-04 16:49:32 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:49:32 --> Controller Class Initialized
DEBUG - 2020-07-04 16:49:32 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:49:32 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:49:32 --> Final output sent to browser
DEBUG - 2020-07-04 16:49:32 --> Total execution time: 0.0065
INFO - 2020-07-04 16:49:34 --> Config Class Initialized
INFO - 2020-07-04 16:49:34 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:49:34 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:49:34 --> Utf8 Class Initialized
INFO - 2020-07-04 16:49:34 --> URI Class Initialized
INFO - 2020-07-04 16:49:34 --> Router Class Initialized
INFO - 2020-07-04 16:49:34 --> Output Class Initialized
INFO - 2020-07-04 16:49:34 --> Security Class Initialized
DEBUG - 2020-07-04 16:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:49:34 --> Input Class Initialized
INFO - 2020-07-04 16:49:34 --> Language Class Initialized
INFO - 2020-07-04 16:49:34 --> Language Class Initialized
INFO - 2020-07-04 16:49:34 --> Config Class Initialized
INFO - 2020-07-04 16:49:34 --> Loader Class Initialized
INFO - 2020-07-04 16:49:34 --> Helper loaded: url_helper
INFO - 2020-07-04 16:49:34 --> Helper loaded: main_helper
INFO - 2020-07-04 16:49:34 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:49:34 --> Controller Class Initialized
INFO - 2020-07-04 16:49:34 --> Final output sent to browser
DEBUG - 2020-07-04 16:49:34 --> Total execution time: 0.0066
INFO - 2020-07-04 16:49:52 --> Config Class Initialized
INFO - 2020-07-04 16:49:52 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:49:52 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:49:52 --> Utf8 Class Initialized
INFO - 2020-07-04 16:49:52 --> URI Class Initialized
INFO - 2020-07-04 16:49:52 --> Router Class Initialized
INFO - 2020-07-04 16:49:52 --> Output Class Initialized
INFO - 2020-07-04 16:49:52 --> Security Class Initialized
DEBUG - 2020-07-04 16:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:49:52 --> Input Class Initialized
INFO - 2020-07-04 16:49:52 --> Language Class Initialized
INFO - 2020-07-04 16:49:52 --> Language Class Initialized
INFO - 2020-07-04 16:49:52 --> Config Class Initialized
INFO - 2020-07-04 16:49:52 --> Loader Class Initialized
INFO - 2020-07-04 16:49:52 --> Helper loaded: url_helper
INFO - 2020-07-04 16:49:52 --> Helper loaded: main_helper
INFO - 2020-07-04 16:49:52 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:49:52 --> Controller Class Initialized
DEBUG - 2020-07-04 16:49:52 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:49:52 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:49:52 --> Final output sent to browser
DEBUG - 2020-07-04 16:49:52 --> Total execution time: 0.0045
INFO - 2020-07-04 16:49:53 --> Config Class Initialized
INFO - 2020-07-04 16:49:53 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:49:53 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:49:53 --> Utf8 Class Initialized
INFO - 2020-07-04 16:49:53 --> URI Class Initialized
INFO - 2020-07-04 16:49:53 --> Router Class Initialized
INFO - 2020-07-04 16:49:53 --> Output Class Initialized
INFO - 2020-07-04 16:49:53 --> Security Class Initialized
DEBUG - 2020-07-04 16:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:49:53 --> Input Class Initialized
INFO - 2020-07-04 16:49:53 --> Language Class Initialized
INFO - 2020-07-04 16:49:53 --> Language Class Initialized
INFO - 2020-07-04 16:49:53 --> Config Class Initialized
INFO - 2020-07-04 16:49:53 --> Loader Class Initialized
INFO - 2020-07-04 16:49:53 --> Helper loaded: url_helper
INFO - 2020-07-04 16:49:53 --> Helper loaded: main_helper
INFO - 2020-07-04 16:49:53 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:49:53 --> Controller Class Initialized
INFO - 2020-07-04 16:49:53 --> Final output sent to browser
DEBUG - 2020-07-04 16:49:53 --> Total execution time: 0.0145
INFO - 2020-07-04 16:50:21 --> Config Class Initialized
INFO - 2020-07-04 16:50:21 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:50:21 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:50:21 --> Utf8 Class Initialized
INFO - 2020-07-04 16:50:21 --> URI Class Initialized
INFO - 2020-07-04 16:50:21 --> Router Class Initialized
INFO - 2020-07-04 16:50:21 --> Output Class Initialized
INFO - 2020-07-04 16:50:21 --> Security Class Initialized
DEBUG - 2020-07-04 16:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:50:21 --> Input Class Initialized
INFO - 2020-07-04 16:50:21 --> Language Class Initialized
INFO - 2020-07-04 16:50:21 --> Language Class Initialized
INFO - 2020-07-04 16:50:21 --> Config Class Initialized
INFO - 2020-07-04 16:50:21 --> Loader Class Initialized
INFO - 2020-07-04 16:50:21 --> Helper loaded: url_helper
INFO - 2020-07-04 16:50:21 --> Helper loaded: main_helper
INFO - 2020-07-04 16:50:21 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:50:21 --> Controller Class Initialized
DEBUG - 2020-07-04 16:50:21 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:50:21 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:50:21 --> Final output sent to browser
DEBUG - 2020-07-04 16:50:21 --> Total execution time: 0.0042
INFO - 2020-07-04 16:50:23 --> Config Class Initialized
INFO - 2020-07-04 16:50:23 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:50:23 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:50:23 --> Utf8 Class Initialized
INFO - 2020-07-04 16:50:23 --> URI Class Initialized
INFO - 2020-07-04 16:50:23 --> Router Class Initialized
INFO - 2020-07-04 16:50:23 --> Output Class Initialized
INFO - 2020-07-04 16:50:23 --> Security Class Initialized
DEBUG - 2020-07-04 16:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:50:23 --> Input Class Initialized
INFO - 2020-07-04 16:50:23 --> Language Class Initialized
INFO - 2020-07-04 16:50:23 --> Language Class Initialized
INFO - 2020-07-04 16:50:23 --> Config Class Initialized
INFO - 2020-07-04 16:50:23 --> Loader Class Initialized
INFO - 2020-07-04 16:50:23 --> Helper loaded: url_helper
INFO - 2020-07-04 16:50:23 --> Helper loaded: main_helper
INFO - 2020-07-04 16:50:23 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:50:23 --> Controller Class Initialized
INFO - 2020-07-04 16:50:23 --> Final output sent to browser
DEBUG - 2020-07-04 16:50:23 --> Total execution time: 0.0080
INFO - 2020-07-04 16:51:01 --> Config Class Initialized
INFO - 2020-07-04 16:51:01 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:51:01 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:51:01 --> Utf8 Class Initialized
INFO - 2020-07-04 16:51:01 --> URI Class Initialized
INFO - 2020-07-04 16:51:01 --> Router Class Initialized
INFO - 2020-07-04 16:51:01 --> Output Class Initialized
INFO - 2020-07-04 16:51:01 --> Security Class Initialized
DEBUG - 2020-07-04 16:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:51:01 --> Input Class Initialized
INFO - 2020-07-04 16:51:01 --> Language Class Initialized
INFO - 2020-07-04 16:51:01 --> Language Class Initialized
INFO - 2020-07-04 16:51:01 --> Config Class Initialized
INFO - 2020-07-04 16:51:01 --> Loader Class Initialized
INFO - 2020-07-04 16:51:01 --> Helper loaded: url_helper
INFO - 2020-07-04 16:51:01 --> Helper loaded: main_helper
INFO - 2020-07-04 16:51:01 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:51:01 --> Controller Class Initialized
DEBUG - 2020-07-04 16:51:01 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:51:01 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:51:01 --> Final output sent to browser
DEBUG - 2020-07-04 16:51:01 --> Total execution time: 0.0054
INFO - 2020-07-04 16:51:03 --> Config Class Initialized
INFO - 2020-07-04 16:51:03 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:51:03 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:51:03 --> Utf8 Class Initialized
INFO - 2020-07-04 16:51:03 --> URI Class Initialized
INFO - 2020-07-04 16:51:03 --> Router Class Initialized
INFO - 2020-07-04 16:51:03 --> Output Class Initialized
INFO - 2020-07-04 16:51:03 --> Security Class Initialized
DEBUG - 2020-07-04 16:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:51:03 --> Input Class Initialized
INFO - 2020-07-04 16:51:03 --> Language Class Initialized
INFO - 2020-07-04 16:51:03 --> Language Class Initialized
INFO - 2020-07-04 16:51:03 --> Config Class Initialized
INFO - 2020-07-04 16:51:03 --> Loader Class Initialized
INFO - 2020-07-04 16:51:03 --> Helper loaded: url_helper
INFO - 2020-07-04 16:51:03 --> Helper loaded: main_helper
INFO - 2020-07-04 16:51:03 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:51:03 --> Controller Class Initialized
INFO - 2020-07-04 16:51:03 --> Final output sent to browser
DEBUG - 2020-07-04 16:51:03 --> Total execution time: 0.0125
INFO - 2020-07-04 16:51:55 --> Config Class Initialized
INFO - 2020-07-04 16:51:55 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:51:55 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:51:55 --> Utf8 Class Initialized
INFO - 2020-07-04 16:51:55 --> URI Class Initialized
INFO - 2020-07-04 16:51:55 --> Router Class Initialized
INFO - 2020-07-04 16:51:55 --> Output Class Initialized
INFO - 2020-07-04 16:51:55 --> Security Class Initialized
DEBUG - 2020-07-04 16:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:51:55 --> Input Class Initialized
INFO - 2020-07-04 16:51:55 --> Language Class Initialized
INFO - 2020-07-04 16:51:55 --> Language Class Initialized
INFO - 2020-07-04 16:51:55 --> Config Class Initialized
INFO - 2020-07-04 16:51:55 --> Loader Class Initialized
INFO - 2020-07-04 16:51:55 --> Helper loaded: url_helper
INFO - 2020-07-04 16:51:55 --> Helper loaded: main_helper
INFO - 2020-07-04 16:51:55 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:51:55 --> Controller Class Initialized
DEBUG - 2020-07-04 16:51:55 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:51:55 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:51:55 --> Final output sent to browser
DEBUG - 2020-07-04 16:51:55 --> Total execution time: 0.0073
INFO - 2020-07-04 16:51:56 --> Config Class Initialized
INFO - 2020-07-04 16:51:56 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:51:56 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:51:56 --> Utf8 Class Initialized
INFO - 2020-07-04 16:51:56 --> URI Class Initialized
INFO - 2020-07-04 16:51:56 --> Router Class Initialized
INFO - 2020-07-04 16:51:56 --> Output Class Initialized
INFO - 2020-07-04 16:51:56 --> Security Class Initialized
DEBUG - 2020-07-04 16:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:51:56 --> Input Class Initialized
INFO - 2020-07-04 16:51:56 --> Language Class Initialized
INFO - 2020-07-04 16:51:56 --> Language Class Initialized
INFO - 2020-07-04 16:51:56 --> Config Class Initialized
INFO - 2020-07-04 16:51:56 --> Loader Class Initialized
INFO - 2020-07-04 16:51:56 --> Helper loaded: url_helper
INFO - 2020-07-04 16:51:56 --> Helper loaded: main_helper
INFO - 2020-07-04 16:51:56 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:51:56 --> Controller Class Initialized
INFO - 2020-07-04 16:51:56 --> Final output sent to browser
DEBUG - 2020-07-04 16:51:56 --> Total execution time: 0.0149
INFO - 2020-07-04 16:52:28 --> Config Class Initialized
INFO - 2020-07-04 16:52:28 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:52:28 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:52:28 --> Utf8 Class Initialized
INFO - 2020-07-04 16:52:28 --> URI Class Initialized
INFO - 2020-07-04 16:52:28 --> Router Class Initialized
INFO - 2020-07-04 16:52:28 --> Output Class Initialized
INFO - 2020-07-04 16:52:28 --> Security Class Initialized
DEBUG - 2020-07-04 16:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:52:28 --> Input Class Initialized
INFO - 2020-07-04 16:52:28 --> Language Class Initialized
INFO - 2020-07-04 16:52:28 --> Language Class Initialized
INFO - 2020-07-04 16:52:28 --> Config Class Initialized
INFO - 2020-07-04 16:52:28 --> Loader Class Initialized
INFO - 2020-07-04 16:52:28 --> Helper loaded: url_helper
INFO - 2020-07-04 16:52:28 --> Helper loaded: main_helper
INFO - 2020-07-04 16:52:28 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:52:28 --> Controller Class Initialized
DEBUG - 2020-07-04 16:52:28 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:52:28 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:52:28 --> Final output sent to browser
DEBUG - 2020-07-04 16:52:28 --> Total execution time: 0.0056
INFO - 2020-07-04 16:52:29 --> Config Class Initialized
INFO - 2020-07-04 16:52:29 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:52:29 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:52:29 --> Utf8 Class Initialized
INFO - 2020-07-04 16:52:29 --> URI Class Initialized
INFO - 2020-07-04 16:52:29 --> Router Class Initialized
INFO - 2020-07-04 16:52:29 --> Output Class Initialized
INFO - 2020-07-04 16:52:29 --> Security Class Initialized
DEBUG - 2020-07-04 16:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:52:29 --> Input Class Initialized
INFO - 2020-07-04 16:52:29 --> Language Class Initialized
INFO - 2020-07-04 16:52:29 --> Language Class Initialized
INFO - 2020-07-04 16:52:29 --> Config Class Initialized
INFO - 2020-07-04 16:52:29 --> Loader Class Initialized
INFO - 2020-07-04 16:52:29 --> Helper loaded: url_helper
INFO - 2020-07-04 16:52:29 --> Helper loaded: main_helper
INFO - 2020-07-04 16:52:29 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:52:29 --> Controller Class Initialized
INFO - 2020-07-04 16:52:29 --> Final output sent to browser
DEBUG - 2020-07-04 16:52:29 --> Total execution time: 0.0062
INFO - 2020-07-04 16:53:18 --> Config Class Initialized
INFO - 2020-07-04 16:53:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:53:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:53:18 --> Utf8 Class Initialized
INFO - 2020-07-04 16:53:18 --> URI Class Initialized
INFO - 2020-07-04 16:53:18 --> Router Class Initialized
INFO - 2020-07-04 16:53:18 --> Output Class Initialized
INFO - 2020-07-04 16:53:18 --> Security Class Initialized
DEBUG - 2020-07-04 16:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:53:18 --> Input Class Initialized
INFO - 2020-07-04 16:53:18 --> Language Class Initialized
INFO - 2020-07-04 16:53:18 --> Language Class Initialized
INFO - 2020-07-04 16:53:18 --> Config Class Initialized
INFO - 2020-07-04 16:53:18 --> Loader Class Initialized
INFO - 2020-07-04 16:53:18 --> Helper loaded: url_helper
INFO - 2020-07-04 16:53:18 --> Helper loaded: main_helper
INFO - 2020-07-04 16:53:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:53:18 --> Controller Class Initialized
DEBUG - 2020-07-04 16:53:18 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:53:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:53:18 --> Final output sent to browser
DEBUG - 2020-07-04 16:53:18 --> Total execution time: 0.0049
INFO - 2020-07-04 16:53:20 --> Config Class Initialized
INFO - 2020-07-04 16:53:20 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:53:20 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:53:20 --> Utf8 Class Initialized
INFO - 2020-07-04 16:53:20 --> URI Class Initialized
INFO - 2020-07-04 16:53:20 --> Router Class Initialized
INFO - 2020-07-04 16:53:20 --> Output Class Initialized
INFO - 2020-07-04 16:53:20 --> Security Class Initialized
DEBUG - 2020-07-04 16:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:53:20 --> Input Class Initialized
INFO - 2020-07-04 16:53:20 --> Language Class Initialized
INFO - 2020-07-04 16:53:20 --> Language Class Initialized
INFO - 2020-07-04 16:53:20 --> Config Class Initialized
INFO - 2020-07-04 16:53:20 --> Loader Class Initialized
INFO - 2020-07-04 16:53:20 --> Helper loaded: url_helper
INFO - 2020-07-04 16:53:20 --> Helper loaded: main_helper
INFO - 2020-07-04 16:53:20 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:53:20 --> Controller Class Initialized
INFO - 2020-07-04 16:53:20 --> Final output sent to browser
DEBUG - 2020-07-04 16:53:20 --> Total execution time: 0.0059
INFO - 2020-07-04 16:54:17 --> Config Class Initialized
INFO - 2020-07-04 16:54:17 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:54:17 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:54:17 --> Utf8 Class Initialized
INFO - 2020-07-04 16:54:17 --> URI Class Initialized
INFO - 2020-07-04 16:54:17 --> Router Class Initialized
INFO - 2020-07-04 16:54:17 --> Output Class Initialized
INFO - 2020-07-04 16:54:17 --> Security Class Initialized
DEBUG - 2020-07-04 16:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:54:17 --> Input Class Initialized
INFO - 2020-07-04 16:54:17 --> Language Class Initialized
INFO - 2020-07-04 16:54:17 --> Language Class Initialized
INFO - 2020-07-04 16:54:17 --> Config Class Initialized
INFO - 2020-07-04 16:54:17 --> Loader Class Initialized
INFO - 2020-07-04 16:54:17 --> Helper loaded: url_helper
INFO - 2020-07-04 16:54:17 --> Helper loaded: main_helper
INFO - 2020-07-04 16:54:17 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:54:17 --> Controller Class Initialized
DEBUG - 2020-07-04 16:54:17 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:54:17 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:54:17 --> Final output sent to browser
DEBUG - 2020-07-04 16:54:17 --> Total execution time: 0.0050
INFO - 2020-07-04 16:54:19 --> Config Class Initialized
INFO - 2020-07-04 16:54:19 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:54:19 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:54:19 --> Utf8 Class Initialized
INFO - 2020-07-04 16:54:19 --> URI Class Initialized
INFO - 2020-07-04 16:54:19 --> Router Class Initialized
INFO - 2020-07-04 16:54:19 --> Output Class Initialized
INFO - 2020-07-04 16:54:19 --> Security Class Initialized
DEBUG - 2020-07-04 16:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:54:19 --> Input Class Initialized
INFO - 2020-07-04 16:54:19 --> Language Class Initialized
INFO - 2020-07-04 16:54:19 --> Language Class Initialized
INFO - 2020-07-04 16:54:19 --> Config Class Initialized
INFO - 2020-07-04 16:54:19 --> Loader Class Initialized
INFO - 2020-07-04 16:54:19 --> Helper loaded: url_helper
INFO - 2020-07-04 16:54:19 --> Helper loaded: main_helper
INFO - 2020-07-04 16:54:19 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:54:19 --> Controller Class Initialized
INFO - 2020-07-04 16:54:19 --> Final output sent to browser
DEBUG - 2020-07-04 16:54:19 --> Total execution time: 0.0101
INFO - 2020-07-04 16:54:35 --> Config Class Initialized
INFO - 2020-07-04 16:54:35 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:54:35 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:54:35 --> Utf8 Class Initialized
INFO - 2020-07-04 16:54:35 --> URI Class Initialized
INFO - 2020-07-04 16:54:35 --> Router Class Initialized
INFO - 2020-07-04 16:54:35 --> Output Class Initialized
INFO - 2020-07-04 16:54:35 --> Security Class Initialized
DEBUG - 2020-07-04 16:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:54:35 --> Input Class Initialized
INFO - 2020-07-04 16:54:35 --> Language Class Initialized
INFO - 2020-07-04 16:54:35 --> Language Class Initialized
INFO - 2020-07-04 16:54:35 --> Config Class Initialized
INFO - 2020-07-04 16:54:35 --> Loader Class Initialized
INFO - 2020-07-04 16:54:35 --> Helper loaded: url_helper
INFO - 2020-07-04 16:54:35 --> Helper loaded: main_helper
INFO - 2020-07-04 16:54:35 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:54:35 --> Controller Class Initialized
DEBUG - 2020-07-04 16:54:35 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:54:35 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:54:35 --> Final output sent to browser
DEBUG - 2020-07-04 16:54:35 --> Total execution time: 0.0071
INFO - 2020-07-04 16:54:37 --> Config Class Initialized
INFO - 2020-07-04 16:54:37 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:54:37 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:54:37 --> Utf8 Class Initialized
INFO - 2020-07-04 16:54:37 --> URI Class Initialized
INFO - 2020-07-04 16:54:37 --> Router Class Initialized
INFO - 2020-07-04 16:54:37 --> Output Class Initialized
INFO - 2020-07-04 16:54:37 --> Security Class Initialized
DEBUG - 2020-07-04 16:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:54:37 --> Input Class Initialized
INFO - 2020-07-04 16:54:37 --> Language Class Initialized
INFO - 2020-07-04 16:54:37 --> Language Class Initialized
INFO - 2020-07-04 16:54:37 --> Config Class Initialized
INFO - 2020-07-04 16:54:37 --> Loader Class Initialized
INFO - 2020-07-04 16:54:37 --> Helper loaded: url_helper
INFO - 2020-07-04 16:54:37 --> Helper loaded: main_helper
INFO - 2020-07-04 16:54:37 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:54:37 --> Controller Class Initialized
INFO - 2020-07-04 16:54:37 --> Final output sent to browser
DEBUG - 2020-07-04 16:54:37 --> Total execution time: 0.0088
INFO - 2020-07-04 16:55:13 --> Config Class Initialized
INFO - 2020-07-04 16:55:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:55:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:55:13 --> Utf8 Class Initialized
INFO - 2020-07-04 16:55:13 --> URI Class Initialized
INFO - 2020-07-04 16:55:13 --> Router Class Initialized
INFO - 2020-07-04 16:55:13 --> Output Class Initialized
INFO - 2020-07-04 16:55:13 --> Security Class Initialized
DEBUG - 2020-07-04 16:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:55:13 --> Input Class Initialized
INFO - 2020-07-04 16:55:13 --> Language Class Initialized
INFO - 2020-07-04 16:55:13 --> Language Class Initialized
INFO - 2020-07-04 16:55:13 --> Config Class Initialized
INFO - 2020-07-04 16:55:13 --> Loader Class Initialized
INFO - 2020-07-04 16:55:13 --> Helper loaded: url_helper
INFO - 2020-07-04 16:55:13 --> Helper loaded: main_helper
INFO - 2020-07-04 16:55:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:55:13 --> Controller Class Initialized
DEBUG - 2020-07-04 16:55:13 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:55:13 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:55:13 --> Final output sent to browser
DEBUG - 2020-07-04 16:55:13 --> Total execution time: 0.0082
INFO - 2020-07-04 16:55:14 --> Config Class Initialized
INFO - 2020-07-04 16:55:14 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:55:14 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:55:14 --> Utf8 Class Initialized
INFO - 2020-07-04 16:55:14 --> URI Class Initialized
INFO - 2020-07-04 16:55:14 --> Router Class Initialized
INFO - 2020-07-04 16:55:14 --> Output Class Initialized
INFO - 2020-07-04 16:55:14 --> Security Class Initialized
DEBUG - 2020-07-04 16:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:55:14 --> Input Class Initialized
INFO - 2020-07-04 16:55:14 --> Language Class Initialized
INFO - 2020-07-04 16:55:14 --> Language Class Initialized
INFO - 2020-07-04 16:55:14 --> Config Class Initialized
INFO - 2020-07-04 16:55:14 --> Loader Class Initialized
INFO - 2020-07-04 16:55:14 --> Helper loaded: url_helper
INFO - 2020-07-04 16:55:14 --> Helper loaded: main_helper
INFO - 2020-07-04 16:55:14 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:55:14 --> Controller Class Initialized
INFO - 2020-07-04 16:55:14 --> Final output sent to browser
DEBUG - 2020-07-04 16:55:14 --> Total execution time: 0.0063
INFO - 2020-07-04 16:56:18 --> Config Class Initialized
INFO - 2020-07-04 16:56:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:56:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:56:18 --> Utf8 Class Initialized
INFO - 2020-07-04 16:56:18 --> URI Class Initialized
INFO - 2020-07-04 16:56:18 --> Router Class Initialized
INFO - 2020-07-04 16:56:18 --> Output Class Initialized
INFO - 2020-07-04 16:56:18 --> Security Class Initialized
DEBUG - 2020-07-04 16:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:56:18 --> Input Class Initialized
INFO - 2020-07-04 16:56:18 --> Language Class Initialized
INFO - 2020-07-04 16:56:18 --> Language Class Initialized
INFO - 2020-07-04 16:56:18 --> Config Class Initialized
INFO - 2020-07-04 16:56:18 --> Loader Class Initialized
INFO - 2020-07-04 16:56:18 --> Helper loaded: url_helper
INFO - 2020-07-04 16:56:18 --> Helper loaded: main_helper
INFO - 2020-07-04 16:56:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:56:18 --> Controller Class Initialized
DEBUG - 2020-07-04 16:56:18 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:56:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:56:18 --> Final output sent to browser
DEBUG - 2020-07-04 16:56:18 --> Total execution time: 0.0038
INFO - 2020-07-04 16:56:20 --> Config Class Initialized
INFO - 2020-07-04 16:56:20 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:56:20 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:56:20 --> Utf8 Class Initialized
INFO - 2020-07-04 16:56:20 --> URI Class Initialized
INFO - 2020-07-04 16:56:20 --> Router Class Initialized
INFO - 2020-07-04 16:56:20 --> Output Class Initialized
INFO - 2020-07-04 16:56:20 --> Security Class Initialized
DEBUG - 2020-07-04 16:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:56:20 --> Input Class Initialized
INFO - 2020-07-04 16:56:20 --> Language Class Initialized
INFO - 2020-07-04 16:56:20 --> Language Class Initialized
INFO - 2020-07-04 16:56:20 --> Config Class Initialized
INFO - 2020-07-04 16:56:20 --> Loader Class Initialized
INFO - 2020-07-04 16:56:20 --> Helper loaded: url_helper
INFO - 2020-07-04 16:56:20 --> Helper loaded: main_helper
INFO - 2020-07-04 16:56:20 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:56:20 --> Controller Class Initialized
INFO - 2020-07-04 16:56:20 --> Final output sent to browser
DEBUG - 2020-07-04 16:56:20 --> Total execution time: 0.0072
INFO - 2020-07-04 16:56:46 --> Config Class Initialized
INFO - 2020-07-04 16:56:46 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:56:46 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:56:46 --> Utf8 Class Initialized
INFO - 2020-07-04 16:56:46 --> URI Class Initialized
INFO - 2020-07-04 16:56:46 --> Router Class Initialized
INFO - 2020-07-04 16:56:46 --> Output Class Initialized
INFO - 2020-07-04 16:56:46 --> Security Class Initialized
DEBUG - 2020-07-04 16:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:56:46 --> Input Class Initialized
INFO - 2020-07-04 16:56:46 --> Language Class Initialized
INFO - 2020-07-04 16:56:46 --> Language Class Initialized
INFO - 2020-07-04 16:56:46 --> Config Class Initialized
INFO - 2020-07-04 16:56:46 --> Loader Class Initialized
INFO - 2020-07-04 16:56:46 --> Helper loaded: url_helper
INFO - 2020-07-04 16:56:46 --> Helper loaded: main_helper
INFO - 2020-07-04 16:56:46 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:56:46 --> Controller Class Initialized
DEBUG - 2020-07-04 16:56:46 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:56:46 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:56:46 --> Final output sent to browser
DEBUG - 2020-07-04 16:56:46 --> Total execution time: 0.0054
INFO - 2020-07-04 16:56:48 --> Config Class Initialized
INFO - 2020-07-04 16:56:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:56:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:56:48 --> Utf8 Class Initialized
INFO - 2020-07-04 16:56:48 --> URI Class Initialized
INFO - 2020-07-04 16:56:48 --> Router Class Initialized
INFO - 2020-07-04 16:56:48 --> Output Class Initialized
INFO - 2020-07-04 16:56:48 --> Security Class Initialized
DEBUG - 2020-07-04 16:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:56:48 --> Input Class Initialized
INFO - 2020-07-04 16:56:48 --> Language Class Initialized
INFO - 2020-07-04 16:56:48 --> Language Class Initialized
INFO - 2020-07-04 16:56:48 --> Config Class Initialized
INFO - 2020-07-04 16:56:48 --> Loader Class Initialized
INFO - 2020-07-04 16:56:48 --> Helper loaded: url_helper
INFO - 2020-07-04 16:56:48 --> Helper loaded: main_helper
INFO - 2020-07-04 16:56:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:56:48 --> Controller Class Initialized
INFO - 2020-07-04 16:56:48 --> Final output sent to browser
DEBUG - 2020-07-04 16:56:48 --> Total execution time: 0.0120
INFO - 2020-07-04 16:58:12 --> Config Class Initialized
INFO - 2020-07-04 16:58:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:58:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:58:12 --> Utf8 Class Initialized
INFO - 2020-07-04 16:58:12 --> URI Class Initialized
INFO - 2020-07-04 16:58:12 --> Router Class Initialized
INFO - 2020-07-04 16:58:12 --> Output Class Initialized
INFO - 2020-07-04 16:58:12 --> Security Class Initialized
DEBUG - 2020-07-04 16:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:58:12 --> Input Class Initialized
INFO - 2020-07-04 16:58:12 --> Language Class Initialized
INFO - 2020-07-04 16:58:12 --> Language Class Initialized
INFO - 2020-07-04 16:58:12 --> Config Class Initialized
INFO - 2020-07-04 16:58:12 --> Loader Class Initialized
INFO - 2020-07-04 16:58:12 --> Helper loaded: url_helper
INFO - 2020-07-04 16:58:12 --> Helper loaded: main_helper
INFO - 2020-07-04 16:58:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:58:12 --> Controller Class Initialized
DEBUG - 2020-07-04 16:58:12 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:58:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:58:12 --> Final output sent to browser
DEBUG - 2020-07-04 16:58:12 --> Total execution time: 0.0059
INFO - 2020-07-04 16:58:14 --> Config Class Initialized
INFO - 2020-07-04 16:58:14 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:58:14 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:58:14 --> Utf8 Class Initialized
INFO - 2020-07-04 16:58:14 --> URI Class Initialized
INFO - 2020-07-04 16:58:14 --> Router Class Initialized
INFO - 2020-07-04 16:58:14 --> Output Class Initialized
INFO - 2020-07-04 16:58:14 --> Security Class Initialized
DEBUG - 2020-07-04 16:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:58:14 --> Input Class Initialized
INFO - 2020-07-04 16:58:14 --> Language Class Initialized
INFO - 2020-07-04 16:58:14 --> Language Class Initialized
INFO - 2020-07-04 16:58:14 --> Config Class Initialized
INFO - 2020-07-04 16:58:14 --> Loader Class Initialized
INFO - 2020-07-04 16:58:14 --> Helper loaded: url_helper
INFO - 2020-07-04 16:58:14 --> Helper loaded: main_helper
INFO - 2020-07-04 16:58:14 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:58:14 --> Controller Class Initialized
INFO - 2020-07-04 16:58:14 --> Final output sent to browser
DEBUG - 2020-07-04 16:58:14 --> Total execution time: 0.0087
INFO - 2020-07-04 16:59:03 --> Config Class Initialized
INFO - 2020-07-04 16:59:03 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:59:03 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:59:03 --> Utf8 Class Initialized
INFO - 2020-07-04 16:59:03 --> URI Class Initialized
INFO - 2020-07-04 16:59:03 --> Router Class Initialized
INFO - 2020-07-04 16:59:03 --> Output Class Initialized
INFO - 2020-07-04 16:59:03 --> Security Class Initialized
DEBUG - 2020-07-04 16:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:59:03 --> Input Class Initialized
INFO - 2020-07-04 16:59:03 --> Language Class Initialized
INFO - 2020-07-04 16:59:03 --> Language Class Initialized
INFO - 2020-07-04 16:59:03 --> Config Class Initialized
INFO - 2020-07-04 16:59:03 --> Loader Class Initialized
INFO - 2020-07-04 16:59:03 --> Helper loaded: url_helper
INFO - 2020-07-04 16:59:03 --> Helper loaded: main_helper
INFO - 2020-07-04 16:59:03 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:59:03 --> Controller Class Initialized
DEBUG - 2020-07-04 16:59:03 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 16:59:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 16:59:03 --> Final output sent to browser
DEBUG - 2020-07-04 16:59:03 --> Total execution time: 0.0111
INFO - 2020-07-04 16:59:05 --> Config Class Initialized
INFO - 2020-07-04 16:59:05 --> Hooks Class Initialized
DEBUG - 2020-07-04 16:59:05 --> UTF-8 Support Enabled
INFO - 2020-07-04 16:59:05 --> Utf8 Class Initialized
INFO - 2020-07-04 16:59:05 --> URI Class Initialized
INFO - 2020-07-04 16:59:05 --> Router Class Initialized
INFO - 2020-07-04 16:59:05 --> Output Class Initialized
INFO - 2020-07-04 16:59:05 --> Security Class Initialized
DEBUG - 2020-07-04 16:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 16:59:05 --> Input Class Initialized
INFO - 2020-07-04 16:59:05 --> Language Class Initialized
INFO - 2020-07-04 16:59:05 --> Language Class Initialized
INFO - 2020-07-04 16:59:05 --> Config Class Initialized
INFO - 2020-07-04 16:59:05 --> Loader Class Initialized
INFO - 2020-07-04 16:59:05 --> Helper loaded: url_helper
INFO - 2020-07-04 16:59:05 --> Helper loaded: main_helper
INFO - 2020-07-04 16:59:05 --> Database Driver Class Initialized
DEBUG - 2020-07-04 16:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 16:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 16:59:05 --> Controller Class Initialized
INFO - 2020-07-04 16:59:05 --> Final output sent to browser
DEBUG - 2020-07-04 16:59:05 --> Total execution time: 0.0145
INFO - 2020-07-04 17:00:20 --> Config Class Initialized
INFO - 2020-07-04 17:00:20 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:00:20 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:00:20 --> Utf8 Class Initialized
INFO - 2020-07-04 17:00:20 --> URI Class Initialized
INFO - 2020-07-04 17:00:20 --> Router Class Initialized
INFO - 2020-07-04 17:00:20 --> Output Class Initialized
INFO - 2020-07-04 17:00:20 --> Security Class Initialized
DEBUG - 2020-07-04 17:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:00:20 --> Input Class Initialized
INFO - 2020-07-04 17:00:20 --> Language Class Initialized
INFO - 2020-07-04 17:00:20 --> Language Class Initialized
INFO - 2020-07-04 17:00:20 --> Config Class Initialized
INFO - 2020-07-04 17:00:20 --> Loader Class Initialized
INFO - 2020-07-04 17:00:20 --> Helper loaded: url_helper
INFO - 2020-07-04 17:00:20 --> Helper loaded: main_helper
INFO - 2020-07-04 17:00:20 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:00:20 --> Controller Class Initialized
DEBUG - 2020-07-04 17:00:20 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:00:20 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:00:20 --> Final output sent to browser
DEBUG - 2020-07-04 17:00:20 --> Total execution time: 0.0068
INFO - 2020-07-04 17:00:22 --> Config Class Initialized
INFO - 2020-07-04 17:00:22 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:00:22 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:00:22 --> Utf8 Class Initialized
INFO - 2020-07-04 17:00:22 --> URI Class Initialized
INFO - 2020-07-04 17:00:22 --> Router Class Initialized
INFO - 2020-07-04 17:00:22 --> Output Class Initialized
INFO - 2020-07-04 17:00:22 --> Security Class Initialized
DEBUG - 2020-07-04 17:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:00:22 --> Input Class Initialized
INFO - 2020-07-04 17:00:22 --> Language Class Initialized
INFO - 2020-07-04 17:00:22 --> Language Class Initialized
INFO - 2020-07-04 17:00:22 --> Config Class Initialized
INFO - 2020-07-04 17:00:22 --> Loader Class Initialized
INFO - 2020-07-04 17:00:22 --> Helper loaded: url_helper
INFO - 2020-07-04 17:00:22 --> Helper loaded: main_helper
INFO - 2020-07-04 17:00:22 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:00:22 --> Controller Class Initialized
INFO - 2020-07-04 17:00:22 --> Final output sent to browser
DEBUG - 2020-07-04 17:00:22 --> Total execution time: 0.0061
INFO - 2020-07-04 17:00:45 --> Config Class Initialized
INFO - 2020-07-04 17:00:45 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:00:45 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:00:45 --> Utf8 Class Initialized
INFO - 2020-07-04 17:00:45 --> URI Class Initialized
INFO - 2020-07-04 17:00:45 --> Router Class Initialized
INFO - 2020-07-04 17:00:45 --> Output Class Initialized
INFO - 2020-07-04 17:00:45 --> Security Class Initialized
DEBUG - 2020-07-04 17:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:00:45 --> Input Class Initialized
INFO - 2020-07-04 17:00:45 --> Language Class Initialized
INFO - 2020-07-04 17:00:45 --> Language Class Initialized
INFO - 2020-07-04 17:00:45 --> Config Class Initialized
INFO - 2020-07-04 17:00:45 --> Loader Class Initialized
INFO - 2020-07-04 17:00:45 --> Helper loaded: url_helper
INFO - 2020-07-04 17:00:45 --> Helper loaded: main_helper
INFO - 2020-07-04 17:00:45 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:00:45 --> Controller Class Initialized
DEBUG - 2020-07-04 17:00:45 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:00:45 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:00:45 --> Final output sent to browser
DEBUG - 2020-07-04 17:00:45 --> Total execution time: 0.0079
INFO - 2020-07-04 17:00:46 --> Config Class Initialized
INFO - 2020-07-04 17:00:46 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:00:46 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:00:46 --> Utf8 Class Initialized
INFO - 2020-07-04 17:00:46 --> URI Class Initialized
INFO - 2020-07-04 17:00:46 --> Router Class Initialized
INFO - 2020-07-04 17:00:46 --> Output Class Initialized
INFO - 2020-07-04 17:00:46 --> Security Class Initialized
DEBUG - 2020-07-04 17:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:00:46 --> Input Class Initialized
INFO - 2020-07-04 17:00:46 --> Language Class Initialized
INFO - 2020-07-04 17:00:46 --> Language Class Initialized
INFO - 2020-07-04 17:00:46 --> Config Class Initialized
INFO - 2020-07-04 17:00:46 --> Loader Class Initialized
INFO - 2020-07-04 17:00:46 --> Helper loaded: url_helper
INFO - 2020-07-04 17:00:46 --> Helper loaded: main_helper
INFO - 2020-07-04 17:00:46 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:00:46 --> Controller Class Initialized
INFO - 2020-07-04 17:00:46 --> Final output sent to browser
DEBUG - 2020-07-04 17:00:46 --> Total execution time: 0.0117
INFO - 2020-07-04 17:00:56 --> Config Class Initialized
INFO - 2020-07-04 17:00:56 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:00:56 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:00:56 --> Utf8 Class Initialized
INFO - 2020-07-04 17:00:56 --> URI Class Initialized
INFO - 2020-07-04 17:00:56 --> Router Class Initialized
INFO - 2020-07-04 17:00:56 --> Output Class Initialized
INFO - 2020-07-04 17:00:56 --> Security Class Initialized
DEBUG - 2020-07-04 17:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:00:56 --> Input Class Initialized
INFO - 2020-07-04 17:00:56 --> Language Class Initialized
INFO - 2020-07-04 17:00:56 --> Language Class Initialized
INFO - 2020-07-04 17:00:56 --> Config Class Initialized
INFO - 2020-07-04 17:00:56 --> Loader Class Initialized
INFO - 2020-07-04 17:00:56 --> Helper loaded: url_helper
INFO - 2020-07-04 17:00:56 --> Helper loaded: main_helper
INFO - 2020-07-04 17:00:56 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:00:56 --> Controller Class Initialized
DEBUG - 2020-07-04 17:00:56 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:00:56 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:00:56 --> Final output sent to browser
DEBUG - 2020-07-04 17:00:56 --> Total execution time: 0.0057
INFO - 2020-07-04 17:00:58 --> Config Class Initialized
INFO - 2020-07-04 17:00:58 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:00:58 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:00:58 --> Utf8 Class Initialized
INFO - 2020-07-04 17:00:58 --> URI Class Initialized
INFO - 2020-07-04 17:00:58 --> Router Class Initialized
INFO - 2020-07-04 17:00:58 --> Output Class Initialized
INFO - 2020-07-04 17:00:58 --> Security Class Initialized
DEBUG - 2020-07-04 17:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:00:58 --> Input Class Initialized
INFO - 2020-07-04 17:00:58 --> Language Class Initialized
INFO - 2020-07-04 17:00:58 --> Language Class Initialized
INFO - 2020-07-04 17:00:58 --> Config Class Initialized
INFO - 2020-07-04 17:00:58 --> Loader Class Initialized
INFO - 2020-07-04 17:00:58 --> Helper loaded: url_helper
INFO - 2020-07-04 17:00:58 --> Helper loaded: main_helper
INFO - 2020-07-04 17:00:58 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:00:58 --> Controller Class Initialized
INFO - 2020-07-04 17:00:58 --> Final output sent to browser
DEBUG - 2020-07-04 17:00:58 --> Total execution time: 0.0087
INFO - 2020-07-04 17:01:52 --> Config Class Initialized
INFO - 2020-07-04 17:01:52 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:01:52 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:01:52 --> Utf8 Class Initialized
INFO - 2020-07-04 17:01:52 --> URI Class Initialized
INFO - 2020-07-04 17:01:52 --> Router Class Initialized
INFO - 2020-07-04 17:01:52 --> Output Class Initialized
INFO - 2020-07-04 17:01:52 --> Security Class Initialized
DEBUG - 2020-07-04 17:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:01:52 --> Input Class Initialized
INFO - 2020-07-04 17:01:52 --> Language Class Initialized
INFO - 2020-07-04 17:01:52 --> Language Class Initialized
INFO - 2020-07-04 17:01:52 --> Config Class Initialized
INFO - 2020-07-04 17:01:52 --> Loader Class Initialized
INFO - 2020-07-04 17:01:52 --> Helper loaded: url_helper
INFO - 2020-07-04 17:01:52 --> Helper loaded: main_helper
INFO - 2020-07-04 17:01:52 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:01:52 --> Controller Class Initialized
DEBUG - 2020-07-04 17:01:52 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:01:52 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:01:52 --> Final output sent to browser
DEBUG - 2020-07-04 17:01:52 --> Total execution time: 0.0041
INFO - 2020-07-04 17:01:54 --> Config Class Initialized
INFO - 2020-07-04 17:01:54 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:01:54 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:01:54 --> Utf8 Class Initialized
INFO - 2020-07-04 17:01:54 --> URI Class Initialized
INFO - 2020-07-04 17:01:54 --> Router Class Initialized
INFO - 2020-07-04 17:01:54 --> Output Class Initialized
INFO - 2020-07-04 17:01:54 --> Security Class Initialized
DEBUG - 2020-07-04 17:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:01:54 --> Input Class Initialized
INFO - 2020-07-04 17:01:54 --> Language Class Initialized
INFO - 2020-07-04 17:01:54 --> Language Class Initialized
INFO - 2020-07-04 17:01:54 --> Config Class Initialized
INFO - 2020-07-04 17:01:54 --> Loader Class Initialized
INFO - 2020-07-04 17:01:54 --> Helper loaded: url_helper
INFO - 2020-07-04 17:01:54 --> Helper loaded: main_helper
INFO - 2020-07-04 17:01:54 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:01:54 --> Controller Class Initialized
INFO - 2020-07-04 17:01:54 --> Final output sent to browser
DEBUG - 2020-07-04 17:01:54 --> Total execution time: 0.0084
INFO - 2020-07-04 17:03:30 --> Config Class Initialized
INFO - 2020-07-04 17:03:30 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:03:30 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:03:30 --> Utf8 Class Initialized
INFO - 2020-07-04 17:03:30 --> URI Class Initialized
INFO - 2020-07-04 17:03:30 --> Router Class Initialized
INFO - 2020-07-04 17:03:30 --> Output Class Initialized
INFO - 2020-07-04 17:03:30 --> Security Class Initialized
DEBUG - 2020-07-04 17:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:03:30 --> Input Class Initialized
INFO - 2020-07-04 17:03:30 --> Language Class Initialized
INFO - 2020-07-04 17:03:30 --> Language Class Initialized
INFO - 2020-07-04 17:03:30 --> Config Class Initialized
INFO - 2020-07-04 17:03:30 --> Loader Class Initialized
INFO - 2020-07-04 17:03:30 --> Helper loaded: url_helper
INFO - 2020-07-04 17:03:30 --> Helper loaded: main_helper
INFO - 2020-07-04 17:03:30 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:03:30 --> Controller Class Initialized
DEBUG - 2020-07-04 17:03:30 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:03:30 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:03:30 --> Final output sent to browser
DEBUG - 2020-07-04 17:03:30 --> Total execution time: 0.0070
INFO - 2020-07-04 17:03:31 --> Config Class Initialized
INFO - 2020-07-04 17:03:31 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:03:31 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:03:31 --> Utf8 Class Initialized
INFO - 2020-07-04 17:03:31 --> URI Class Initialized
INFO - 2020-07-04 17:03:31 --> Router Class Initialized
INFO - 2020-07-04 17:03:31 --> Output Class Initialized
INFO - 2020-07-04 17:03:31 --> Security Class Initialized
DEBUG - 2020-07-04 17:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:03:31 --> Input Class Initialized
INFO - 2020-07-04 17:03:31 --> Language Class Initialized
INFO - 2020-07-04 17:03:31 --> Language Class Initialized
INFO - 2020-07-04 17:03:31 --> Config Class Initialized
INFO - 2020-07-04 17:03:31 --> Loader Class Initialized
INFO - 2020-07-04 17:03:31 --> Helper loaded: url_helper
INFO - 2020-07-04 17:03:31 --> Helper loaded: main_helper
INFO - 2020-07-04 17:03:31 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:03:31 --> Controller Class Initialized
INFO - 2020-07-04 17:03:31 --> Final output sent to browser
DEBUG - 2020-07-04 17:03:31 --> Total execution time: 0.0073
INFO - 2020-07-04 17:03:57 --> Config Class Initialized
INFO - 2020-07-04 17:03:57 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:03:57 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:03:57 --> Utf8 Class Initialized
INFO - 2020-07-04 17:03:57 --> URI Class Initialized
INFO - 2020-07-04 17:03:57 --> Router Class Initialized
INFO - 2020-07-04 17:03:57 --> Output Class Initialized
INFO - 2020-07-04 17:03:57 --> Security Class Initialized
DEBUG - 2020-07-04 17:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:03:57 --> Input Class Initialized
INFO - 2020-07-04 17:03:57 --> Language Class Initialized
INFO - 2020-07-04 17:03:57 --> Language Class Initialized
INFO - 2020-07-04 17:03:57 --> Config Class Initialized
INFO - 2020-07-04 17:03:57 --> Loader Class Initialized
INFO - 2020-07-04 17:03:57 --> Helper loaded: url_helper
INFO - 2020-07-04 17:03:57 --> Helper loaded: main_helper
INFO - 2020-07-04 17:03:57 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:03:57 --> Controller Class Initialized
DEBUG - 2020-07-04 17:03:57 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:03:57 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:03:57 --> Final output sent to browser
DEBUG - 2020-07-04 17:03:57 --> Total execution time: 0.0056
INFO - 2020-07-04 17:03:58 --> Config Class Initialized
INFO - 2020-07-04 17:03:58 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:03:58 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:03:58 --> Utf8 Class Initialized
INFO - 2020-07-04 17:03:58 --> URI Class Initialized
INFO - 2020-07-04 17:03:58 --> Router Class Initialized
INFO - 2020-07-04 17:03:58 --> Output Class Initialized
INFO - 2020-07-04 17:03:58 --> Security Class Initialized
DEBUG - 2020-07-04 17:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:03:58 --> Input Class Initialized
INFO - 2020-07-04 17:03:58 --> Language Class Initialized
INFO - 2020-07-04 17:03:58 --> Language Class Initialized
INFO - 2020-07-04 17:03:58 --> Config Class Initialized
INFO - 2020-07-04 17:03:58 --> Loader Class Initialized
INFO - 2020-07-04 17:03:58 --> Helper loaded: url_helper
INFO - 2020-07-04 17:03:58 --> Helper loaded: main_helper
INFO - 2020-07-04 17:03:58 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:03:58 --> Controller Class Initialized
INFO - 2020-07-04 17:03:58 --> Final output sent to browser
DEBUG - 2020-07-04 17:03:58 --> Total execution time: 0.0102
INFO - 2020-07-04 17:04:11 --> Config Class Initialized
INFO - 2020-07-04 17:04:11 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:04:11 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:04:11 --> Utf8 Class Initialized
INFO - 2020-07-04 17:04:11 --> URI Class Initialized
INFO - 2020-07-04 17:04:11 --> Router Class Initialized
INFO - 2020-07-04 17:04:11 --> Output Class Initialized
INFO - 2020-07-04 17:04:11 --> Security Class Initialized
DEBUG - 2020-07-04 17:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:04:11 --> Input Class Initialized
INFO - 2020-07-04 17:04:11 --> Language Class Initialized
INFO - 2020-07-04 17:04:11 --> Language Class Initialized
INFO - 2020-07-04 17:04:11 --> Config Class Initialized
INFO - 2020-07-04 17:04:11 --> Loader Class Initialized
INFO - 2020-07-04 17:04:11 --> Helper loaded: url_helper
INFO - 2020-07-04 17:04:11 --> Helper loaded: main_helper
INFO - 2020-07-04 17:04:11 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:04:11 --> Controller Class Initialized
DEBUG - 2020-07-04 17:04:11 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:04:11 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:04:11 --> Final output sent to browser
DEBUG - 2020-07-04 17:04:11 --> Total execution time: 0.0035
INFO - 2020-07-04 17:04:13 --> Config Class Initialized
INFO - 2020-07-04 17:04:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:04:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:04:13 --> Utf8 Class Initialized
INFO - 2020-07-04 17:04:13 --> URI Class Initialized
INFO - 2020-07-04 17:04:13 --> Router Class Initialized
INFO - 2020-07-04 17:04:13 --> Output Class Initialized
INFO - 2020-07-04 17:04:13 --> Security Class Initialized
DEBUG - 2020-07-04 17:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:04:13 --> Input Class Initialized
INFO - 2020-07-04 17:04:13 --> Language Class Initialized
INFO - 2020-07-04 17:04:13 --> Language Class Initialized
INFO - 2020-07-04 17:04:13 --> Config Class Initialized
INFO - 2020-07-04 17:04:13 --> Loader Class Initialized
INFO - 2020-07-04 17:04:13 --> Helper loaded: url_helper
INFO - 2020-07-04 17:04:13 --> Helper loaded: main_helper
INFO - 2020-07-04 17:04:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:04:13 --> Controller Class Initialized
INFO - 2020-07-04 17:04:13 --> Final output sent to browser
DEBUG - 2020-07-04 17:04:13 --> Total execution time: 0.0091
INFO - 2020-07-04 17:05:01 --> Config Class Initialized
INFO - 2020-07-04 17:05:01 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:05:01 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:05:01 --> Utf8 Class Initialized
INFO - 2020-07-04 17:05:01 --> URI Class Initialized
INFO - 2020-07-04 17:05:01 --> Router Class Initialized
INFO - 2020-07-04 17:05:01 --> Output Class Initialized
INFO - 2020-07-04 17:05:01 --> Security Class Initialized
DEBUG - 2020-07-04 17:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:05:01 --> Input Class Initialized
INFO - 2020-07-04 17:05:01 --> Language Class Initialized
INFO - 2020-07-04 17:05:01 --> Language Class Initialized
INFO - 2020-07-04 17:05:01 --> Config Class Initialized
INFO - 2020-07-04 17:05:01 --> Loader Class Initialized
INFO - 2020-07-04 17:05:01 --> Helper loaded: url_helper
INFO - 2020-07-04 17:05:01 --> Helper loaded: main_helper
INFO - 2020-07-04 17:05:01 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:05:01 --> Controller Class Initialized
DEBUG - 2020-07-04 17:05:01 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:05:01 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:05:01 --> Final output sent to browser
DEBUG - 2020-07-04 17:05:01 --> Total execution time: 0.0069
INFO - 2020-07-04 17:05:03 --> Config Class Initialized
INFO - 2020-07-04 17:05:03 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:05:03 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:05:03 --> Utf8 Class Initialized
INFO - 2020-07-04 17:05:03 --> URI Class Initialized
INFO - 2020-07-04 17:05:03 --> Router Class Initialized
INFO - 2020-07-04 17:05:03 --> Output Class Initialized
INFO - 2020-07-04 17:05:03 --> Security Class Initialized
DEBUG - 2020-07-04 17:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:05:03 --> Input Class Initialized
INFO - 2020-07-04 17:05:03 --> Language Class Initialized
INFO - 2020-07-04 17:05:03 --> Language Class Initialized
INFO - 2020-07-04 17:05:03 --> Config Class Initialized
INFO - 2020-07-04 17:05:03 --> Loader Class Initialized
INFO - 2020-07-04 17:05:03 --> Helper loaded: url_helper
INFO - 2020-07-04 17:05:03 --> Helper loaded: main_helper
INFO - 2020-07-04 17:05:03 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:05:03 --> Controller Class Initialized
INFO - 2020-07-04 17:05:03 --> Final output sent to browser
DEBUG - 2020-07-04 17:05:03 --> Total execution time: 0.0114
INFO - 2020-07-04 17:05:47 --> Config Class Initialized
INFO - 2020-07-04 17:05:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:05:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:05:47 --> Utf8 Class Initialized
INFO - 2020-07-04 17:05:47 --> URI Class Initialized
INFO - 2020-07-04 17:05:47 --> Router Class Initialized
INFO - 2020-07-04 17:05:47 --> Output Class Initialized
INFO - 2020-07-04 17:05:47 --> Security Class Initialized
DEBUG - 2020-07-04 17:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:05:47 --> Input Class Initialized
INFO - 2020-07-04 17:05:47 --> Language Class Initialized
INFO - 2020-07-04 17:05:47 --> Language Class Initialized
INFO - 2020-07-04 17:05:47 --> Config Class Initialized
INFO - 2020-07-04 17:05:47 --> Loader Class Initialized
INFO - 2020-07-04 17:05:47 --> Helper loaded: url_helper
INFO - 2020-07-04 17:05:47 --> Helper loaded: main_helper
INFO - 2020-07-04 17:05:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:05:47 --> Controller Class Initialized
DEBUG - 2020-07-04 17:05:47 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:05:47 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:05:47 --> Final output sent to browser
DEBUG - 2020-07-04 17:05:47 --> Total execution time: 0.0057
INFO - 2020-07-04 17:05:48 --> Config Class Initialized
INFO - 2020-07-04 17:05:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:05:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:05:48 --> Utf8 Class Initialized
INFO - 2020-07-04 17:05:48 --> URI Class Initialized
INFO - 2020-07-04 17:05:48 --> Router Class Initialized
INFO - 2020-07-04 17:05:48 --> Output Class Initialized
INFO - 2020-07-04 17:05:48 --> Security Class Initialized
DEBUG - 2020-07-04 17:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:05:48 --> Input Class Initialized
INFO - 2020-07-04 17:05:48 --> Language Class Initialized
INFO - 2020-07-04 17:05:48 --> Language Class Initialized
INFO - 2020-07-04 17:05:48 --> Config Class Initialized
INFO - 2020-07-04 17:05:48 --> Loader Class Initialized
INFO - 2020-07-04 17:05:48 --> Helper loaded: url_helper
INFO - 2020-07-04 17:05:48 --> Helper loaded: main_helper
INFO - 2020-07-04 17:05:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:05:48 --> Controller Class Initialized
INFO - 2020-07-04 17:05:48 --> Final output sent to browser
DEBUG - 2020-07-04 17:05:48 --> Total execution time: 0.0057
INFO - 2020-07-04 17:06:29 --> Config Class Initialized
INFO - 2020-07-04 17:06:29 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:06:29 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:06:29 --> Utf8 Class Initialized
INFO - 2020-07-04 17:06:29 --> URI Class Initialized
INFO - 2020-07-04 17:06:29 --> Router Class Initialized
INFO - 2020-07-04 17:06:29 --> Output Class Initialized
INFO - 2020-07-04 17:06:29 --> Security Class Initialized
DEBUG - 2020-07-04 17:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:06:29 --> Input Class Initialized
INFO - 2020-07-04 17:06:29 --> Language Class Initialized
INFO - 2020-07-04 17:06:29 --> Language Class Initialized
INFO - 2020-07-04 17:06:29 --> Config Class Initialized
INFO - 2020-07-04 17:06:29 --> Loader Class Initialized
INFO - 2020-07-04 17:06:29 --> Helper loaded: url_helper
INFO - 2020-07-04 17:06:29 --> Helper loaded: main_helper
INFO - 2020-07-04 17:06:29 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:06:29 --> Controller Class Initialized
DEBUG - 2020-07-04 17:06:29 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:06:29 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:06:29 --> Final output sent to browser
DEBUG - 2020-07-04 17:06:29 --> Total execution time: 0.0052
INFO - 2020-07-04 17:06:30 --> Config Class Initialized
INFO - 2020-07-04 17:06:30 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:06:30 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:06:30 --> Utf8 Class Initialized
INFO - 2020-07-04 17:06:30 --> URI Class Initialized
INFO - 2020-07-04 17:06:30 --> Router Class Initialized
INFO - 2020-07-04 17:06:30 --> Output Class Initialized
INFO - 2020-07-04 17:06:30 --> Security Class Initialized
DEBUG - 2020-07-04 17:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:06:30 --> Input Class Initialized
INFO - 2020-07-04 17:06:30 --> Language Class Initialized
INFO - 2020-07-04 17:06:30 --> Language Class Initialized
INFO - 2020-07-04 17:06:30 --> Config Class Initialized
INFO - 2020-07-04 17:06:30 --> Loader Class Initialized
INFO - 2020-07-04 17:06:30 --> Helper loaded: url_helper
INFO - 2020-07-04 17:06:30 --> Helper loaded: main_helper
INFO - 2020-07-04 17:06:30 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:06:30 --> Controller Class Initialized
INFO - 2020-07-04 17:06:30 --> Final output sent to browser
DEBUG - 2020-07-04 17:06:30 --> Total execution time: 0.0047
INFO - 2020-07-04 17:07:20 --> Config Class Initialized
INFO - 2020-07-04 17:07:20 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:07:20 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:07:20 --> Utf8 Class Initialized
INFO - 2020-07-04 17:07:20 --> URI Class Initialized
INFO - 2020-07-04 17:07:20 --> Router Class Initialized
INFO - 2020-07-04 17:07:20 --> Output Class Initialized
INFO - 2020-07-04 17:07:20 --> Security Class Initialized
DEBUG - 2020-07-04 17:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:07:20 --> Input Class Initialized
INFO - 2020-07-04 17:07:20 --> Language Class Initialized
INFO - 2020-07-04 17:07:20 --> Language Class Initialized
INFO - 2020-07-04 17:07:20 --> Config Class Initialized
INFO - 2020-07-04 17:07:20 --> Loader Class Initialized
INFO - 2020-07-04 17:07:20 --> Helper loaded: url_helper
INFO - 2020-07-04 17:07:20 --> Helper loaded: main_helper
INFO - 2020-07-04 17:07:20 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:07:20 --> Controller Class Initialized
DEBUG - 2020-07-04 17:07:20 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:07:20 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:07:20 --> Final output sent to browser
DEBUG - 2020-07-04 17:07:20 --> Total execution time: 0.0053
INFO - 2020-07-04 17:07:22 --> Config Class Initialized
INFO - 2020-07-04 17:07:22 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:07:22 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:07:22 --> Utf8 Class Initialized
INFO - 2020-07-04 17:07:22 --> URI Class Initialized
INFO - 2020-07-04 17:07:22 --> Router Class Initialized
INFO - 2020-07-04 17:07:22 --> Output Class Initialized
INFO - 2020-07-04 17:07:22 --> Security Class Initialized
DEBUG - 2020-07-04 17:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:07:22 --> Input Class Initialized
INFO - 2020-07-04 17:07:22 --> Language Class Initialized
INFO - 2020-07-04 17:07:22 --> Language Class Initialized
INFO - 2020-07-04 17:07:22 --> Config Class Initialized
INFO - 2020-07-04 17:07:22 --> Loader Class Initialized
INFO - 2020-07-04 17:07:22 --> Helper loaded: url_helper
INFO - 2020-07-04 17:07:22 --> Helper loaded: main_helper
INFO - 2020-07-04 17:07:22 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:07:22 --> Controller Class Initialized
INFO - 2020-07-04 17:07:22 --> Final output sent to browser
DEBUG - 2020-07-04 17:07:22 --> Total execution time: 0.0065
INFO - 2020-07-04 17:09:07 --> Config Class Initialized
INFO - 2020-07-04 17:09:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:09:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:09:07 --> Utf8 Class Initialized
INFO - 2020-07-04 17:09:07 --> URI Class Initialized
INFO - 2020-07-04 17:09:07 --> Router Class Initialized
INFO - 2020-07-04 17:09:07 --> Output Class Initialized
INFO - 2020-07-04 17:09:07 --> Security Class Initialized
DEBUG - 2020-07-04 17:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:09:07 --> Input Class Initialized
INFO - 2020-07-04 17:09:07 --> Language Class Initialized
INFO - 2020-07-04 17:09:07 --> Language Class Initialized
INFO - 2020-07-04 17:09:07 --> Config Class Initialized
INFO - 2020-07-04 17:09:07 --> Loader Class Initialized
INFO - 2020-07-04 17:09:07 --> Helper loaded: url_helper
INFO - 2020-07-04 17:09:07 --> Helper loaded: main_helper
INFO - 2020-07-04 17:09:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:09:07 --> Controller Class Initialized
DEBUG - 2020-07-04 17:09:07 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:09:07 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:09:07 --> Final output sent to browser
DEBUG - 2020-07-04 17:09:07 --> Total execution time: 0.0045
INFO - 2020-07-04 17:09:08 --> Config Class Initialized
INFO - 2020-07-04 17:09:08 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:09:08 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:09:08 --> Utf8 Class Initialized
INFO - 2020-07-04 17:09:08 --> URI Class Initialized
INFO - 2020-07-04 17:09:08 --> Router Class Initialized
INFO - 2020-07-04 17:09:08 --> Output Class Initialized
INFO - 2020-07-04 17:09:08 --> Security Class Initialized
DEBUG - 2020-07-04 17:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:09:08 --> Input Class Initialized
INFO - 2020-07-04 17:09:08 --> Language Class Initialized
INFO - 2020-07-04 17:09:08 --> Language Class Initialized
INFO - 2020-07-04 17:09:08 --> Config Class Initialized
INFO - 2020-07-04 17:09:08 --> Loader Class Initialized
INFO - 2020-07-04 17:09:08 --> Helper loaded: url_helper
INFO - 2020-07-04 17:09:08 --> Helper loaded: main_helper
INFO - 2020-07-04 17:09:08 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:09:08 --> Controller Class Initialized
INFO - 2020-07-04 17:09:08 --> Final output sent to browser
DEBUG - 2020-07-04 17:09:08 --> Total execution time: 0.0098
INFO - 2020-07-04 17:09:35 --> Config Class Initialized
INFO - 2020-07-04 17:09:35 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:09:35 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:09:35 --> Utf8 Class Initialized
INFO - 2020-07-04 17:09:35 --> URI Class Initialized
INFO - 2020-07-04 17:09:35 --> Router Class Initialized
INFO - 2020-07-04 17:09:35 --> Output Class Initialized
INFO - 2020-07-04 17:09:35 --> Security Class Initialized
DEBUG - 2020-07-04 17:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:09:35 --> Input Class Initialized
INFO - 2020-07-04 17:09:35 --> Language Class Initialized
INFO - 2020-07-04 17:09:35 --> Language Class Initialized
INFO - 2020-07-04 17:09:35 --> Config Class Initialized
INFO - 2020-07-04 17:09:35 --> Loader Class Initialized
INFO - 2020-07-04 17:09:35 --> Helper loaded: url_helper
INFO - 2020-07-04 17:09:35 --> Helper loaded: main_helper
INFO - 2020-07-04 17:09:35 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:09:35 --> Controller Class Initialized
DEBUG - 2020-07-04 17:09:35 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:09:35 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:09:35 --> Final output sent to browser
DEBUG - 2020-07-04 17:09:35 --> Total execution time: 0.0041
INFO - 2020-07-04 17:09:37 --> Config Class Initialized
INFO - 2020-07-04 17:09:37 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:09:37 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:09:37 --> Utf8 Class Initialized
INFO - 2020-07-04 17:09:37 --> URI Class Initialized
INFO - 2020-07-04 17:09:37 --> Router Class Initialized
INFO - 2020-07-04 17:09:37 --> Output Class Initialized
INFO - 2020-07-04 17:09:37 --> Security Class Initialized
DEBUG - 2020-07-04 17:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:09:37 --> Input Class Initialized
INFO - 2020-07-04 17:09:37 --> Language Class Initialized
INFO - 2020-07-04 17:09:37 --> Language Class Initialized
INFO - 2020-07-04 17:09:37 --> Config Class Initialized
INFO - 2020-07-04 17:09:37 --> Loader Class Initialized
INFO - 2020-07-04 17:09:37 --> Helper loaded: url_helper
INFO - 2020-07-04 17:09:37 --> Helper loaded: main_helper
INFO - 2020-07-04 17:09:37 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:09:37 --> Controller Class Initialized
INFO - 2020-07-04 17:09:37 --> Final output sent to browser
DEBUG - 2020-07-04 17:09:37 --> Total execution time: 0.0099
INFO - 2020-07-04 17:09:52 --> Config Class Initialized
INFO - 2020-07-04 17:09:52 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:09:52 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:09:52 --> Utf8 Class Initialized
INFO - 2020-07-04 17:09:52 --> URI Class Initialized
INFO - 2020-07-04 17:09:52 --> Router Class Initialized
INFO - 2020-07-04 17:09:52 --> Output Class Initialized
INFO - 2020-07-04 17:09:52 --> Security Class Initialized
DEBUG - 2020-07-04 17:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:09:52 --> Input Class Initialized
INFO - 2020-07-04 17:09:52 --> Language Class Initialized
INFO - 2020-07-04 17:09:52 --> Language Class Initialized
INFO - 2020-07-04 17:09:52 --> Config Class Initialized
INFO - 2020-07-04 17:09:52 --> Loader Class Initialized
INFO - 2020-07-04 17:09:52 --> Helper loaded: url_helper
INFO - 2020-07-04 17:09:52 --> Helper loaded: main_helper
INFO - 2020-07-04 17:09:52 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:09:52 --> Controller Class Initialized
DEBUG - 2020-07-04 17:09:52 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:09:52 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:09:52 --> Final output sent to browser
DEBUG - 2020-07-04 17:09:52 --> Total execution time: 0.0049
INFO - 2020-07-04 17:09:53 --> Config Class Initialized
INFO - 2020-07-04 17:09:53 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:09:53 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:09:53 --> Utf8 Class Initialized
INFO - 2020-07-04 17:09:53 --> URI Class Initialized
INFO - 2020-07-04 17:09:53 --> Router Class Initialized
INFO - 2020-07-04 17:09:53 --> Output Class Initialized
INFO - 2020-07-04 17:09:53 --> Security Class Initialized
DEBUG - 2020-07-04 17:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:09:53 --> Input Class Initialized
INFO - 2020-07-04 17:09:53 --> Language Class Initialized
INFO - 2020-07-04 17:09:53 --> Language Class Initialized
INFO - 2020-07-04 17:09:53 --> Config Class Initialized
INFO - 2020-07-04 17:09:53 --> Loader Class Initialized
INFO - 2020-07-04 17:09:53 --> Helper loaded: url_helper
INFO - 2020-07-04 17:09:53 --> Helper loaded: main_helper
INFO - 2020-07-04 17:09:53 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:09:53 --> Controller Class Initialized
INFO - 2020-07-04 17:09:53 --> Final output sent to browser
DEBUG - 2020-07-04 17:09:53 --> Total execution time: 0.0084
INFO - 2020-07-04 17:11:24 --> Config Class Initialized
INFO - 2020-07-04 17:11:24 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:11:24 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:11:24 --> Utf8 Class Initialized
INFO - 2020-07-04 17:11:24 --> URI Class Initialized
INFO - 2020-07-04 17:11:24 --> Router Class Initialized
INFO - 2020-07-04 17:11:24 --> Output Class Initialized
INFO - 2020-07-04 17:11:24 --> Security Class Initialized
DEBUG - 2020-07-04 17:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:11:24 --> Input Class Initialized
INFO - 2020-07-04 17:11:24 --> Language Class Initialized
INFO - 2020-07-04 17:11:24 --> Language Class Initialized
INFO - 2020-07-04 17:11:24 --> Config Class Initialized
INFO - 2020-07-04 17:11:24 --> Loader Class Initialized
INFO - 2020-07-04 17:11:24 --> Helper loaded: url_helper
INFO - 2020-07-04 17:11:24 --> Helper loaded: main_helper
INFO - 2020-07-04 17:11:24 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:11:24 --> Controller Class Initialized
DEBUG - 2020-07-04 17:11:24 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:11:24 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:11:24 --> Final output sent to browser
DEBUG - 2020-07-04 17:11:24 --> Total execution time: 0.0040
INFO - 2020-07-04 17:11:25 --> Config Class Initialized
INFO - 2020-07-04 17:11:25 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:11:25 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:11:25 --> Utf8 Class Initialized
INFO - 2020-07-04 17:11:25 --> URI Class Initialized
INFO - 2020-07-04 17:11:25 --> Router Class Initialized
INFO - 2020-07-04 17:11:25 --> Output Class Initialized
INFO - 2020-07-04 17:11:25 --> Security Class Initialized
DEBUG - 2020-07-04 17:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:11:25 --> Input Class Initialized
INFO - 2020-07-04 17:11:25 --> Language Class Initialized
INFO - 2020-07-04 17:11:25 --> Language Class Initialized
INFO - 2020-07-04 17:11:25 --> Config Class Initialized
INFO - 2020-07-04 17:11:25 --> Loader Class Initialized
INFO - 2020-07-04 17:11:25 --> Helper loaded: url_helper
INFO - 2020-07-04 17:11:25 --> Helper loaded: main_helper
INFO - 2020-07-04 17:11:25 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:11:25 --> Controller Class Initialized
INFO - 2020-07-04 17:11:25 --> Final output sent to browser
DEBUG - 2020-07-04 17:11:25 --> Total execution time: 0.0061
INFO - 2020-07-04 17:11:44 --> Config Class Initialized
INFO - 2020-07-04 17:11:44 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:11:44 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:11:44 --> Utf8 Class Initialized
INFO - 2020-07-04 17:11:44 --> URI Class Initialized
INFO - 2020-07-04 17:11:44 --> Router Class Initialized
INFO - 2020-07-04 17:11:44 --> Output Class Initialized
INFO - 2020-07-04 17:11:44 --> Security Class Initialized
DEBUG - 2020-07-04 17:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:11:44 --> Input Class Initialized
INFO - 2020-07-04 17:11:44 --> Language Class Initialized
INFO - 2020-07-04 17:11:44 --> Language Class Initialized
INFO - 2020-07-04 17:11:44 --> Config Class Initialized
INFO - 2020-07-04 17:11:44 --> Loader Class Initialized
INFO - 2020-07-04 17:11:44 --> Helper loaded: url_helper
INFO - 2020-07-04 17:11:44 --> Helper loaded: main_helper
INFO - 2020-07-04 17:11:44 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:11:44 --> Controller Class Initialized
DEBUG - 2020-07-04 17:11:44 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:11:44 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:11:44 --> Final output sent to browser
DEBUG - 2020-07-04 17:11:44 --> Total execution time: 0.0064
INFO - 2020-07-04 17:11:46 --> Config Class Initialized
INFO - 2020-07-04 17:11:46 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:11:46 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:11:46 --> Utf8 Class Initialized
INFO - 2020-07-04 17:11:46 --> URI Class Initialized
INFO - 2020-07-04 17:11:46 --> Router Class Initialized
INFO - 2020-07-04 17:11:46 --> Output Class Initialized
INFO - 2020-07-04 17:11:46 --> Security Class Initialized
DEBUG - 2020-07-04 17:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:11:46 --> Input Class Initialized
INFO - 2020-07-04 17:11:46 --> Language Class Initialized
INFO - 2020-07-04 17:11:46 --> Language Class Initialized
INFO - 2020-07-04 17:11:46 --> Config Class Initialized
INFO - 2020-07-04 17:11:46 --> Loader Class Initialized
INFO - 2020-07-04 17:11:46 --> Helper loaded: url_helper
INFO - 2020-07-04 17:11:46 --> Helper loaded: main_helper
INFO - 2020-07-04 17:11:46 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:11:46 --> Controller Class Initialized
INFO - 2020-07-04 17:11:46 --> Final output sent to browser
DEBUG - 2020-07-04 17:11:46 --> Total execution time: 0.0055
INFO - 2020-07-04 17:14:07 --> Config Class Initialized
INFO - 2020-07-04 17:14:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:14:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:14:07 --> Utf8 Class Initialized
INFO - 2020-07-04 17:14:07 --> URI Class Initialized
INFO - 2020-07-04 17:14:07 --> Router Class Initialized
INFO - 2020-07-04 17:14:07 --> Output Class Initialized
INFO - 2020-07-04 17:14:07 --> Security Class Initialized
DEBUG - 2020-07-04 17:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:14:07 --> Input Class Initialized
INFO - 2020-07-04 17:14:07 --> Language Class Initialized
INFO - 2020-07-04 17:14:07 --> Language Class Initialized
INFO - 2020-07-04 17:14:07 --> Config Class Initialized
INFO - 2020-07-04 17:14:07 --> Loader Class Initialized
INFO - 2020-07-04 17:14:07 --> Helper loaded: url_helper
INFO - 2020-07-04 17:14:07 --> Helper loaded: main_helper
INFO - 2020-07-04 17:14:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:14:07 --> Controller Class Initialized
DEBUG - 2020-07-04 17:14:07 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:14:07 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:14:07 --> Final output sent to browser
DEBUG - 2020-07-04 17:14:07 --> Total execution time: 0.0038
INFO - 2020-07-04 17:14:08 --> Config Class Initialized
INFO - 2020-07-04 17:14:08 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:14:08 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:14:08 --> Utf8 Class Initialized
INFO - 2020-07-04 17:14:08 --> URI Class Initialized
INFO - 2020-07-04 17:14:08 --> Router Class Initialized
INFO - 2020-07-04 17:14:08 --> Output Class Initialized
INFO - 2020-07-04 17:14:08 --> Security Class Initialized
DEBUG - 2020-07-04 17:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:14:08 --> Input Class Initialized
INFO - 2020-07-04 17:14:08 --> Language Class Initialized
INFO - 2020-07-04 17:14:08 --> Language Class Initialized
INFO - 2020-07-04 17:14:08 --> Config Class Initialized
INFO - 2020-07-04 17:14:08 --> Loader Class Initialized
INFO - 2020-07-04 17:14:08 --> Helper loaded: url_helper
INFO - 2020-07-04 17:14:08 --> Helper loaded: main_helper
INFO - 2020-07-04 17:14:08 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:14:08 --> Controller Class Initialized
INFO - 2020-07-04 17:14:08 --> Final output sent to browser
DEBUG - 2020-07-04 17:14:08 --> Total execution time: 0.0122
INFO - 2020-07-04 17:17:16 --> Config Class Initialized
INFO - 2020-07-04 17:17:16 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:17:16 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:17:16 --> Utf8 Class Initialized
INFO - 2020-07-04 17:17:16 --> URI Class Initialized
INFO - 2020-07-04 17:17:16 --> Router Class Initialized
INFO - 2020-07-04 17:17:16 --> Output Class Initialized
INFO - 2020-07-04 17:17:16 --> Security Class Initialized
DEBUG - 2020-07-04 17:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:17:16 --> Input Class Initialized
INFO - 2020-07-04 17:17:16 --> Language Class Initialized
INFO - 2020-07-04 17:17:16 --> Language Class Initialized
INFO - 2020-07-04 17:17:16 --> Config Class Initialized
INFO - 2020-07-04 17:17:16 --> Loader Class Initialized
INFO - 2020-07-04 17:17:16 --> Helper loaded: url_helper
INFO - 2020-07-04 17:17:16 --> Helper loaded: main_helper
INFO - 2020-07-04 17:17:16 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:17:16 --> Controller Class Initialized
DEBUG - 2020-07-04 17:17:16 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:17:16 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:17:16 --> Final output sent to browser
DEBUG - 2020-07-04 17:17:16 --> Total execution time: 0.0048
INFO - 2020-07-04 17:17:18 --> Config Class Initialized
INFO - 2020-07-04 17:17:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:17:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:17:18 --> Utf8 Class Initialized
INFO - 2020-07-04 17:17:18 --> URI Class Initialized
INFO - 2020-07-04 17:17:18 --> Router Class Initialized
INFO - 2020-07-04 17:17:18 --> Output Class Initialized
INFO - 2020-07-04 17:17:18 --> Security Class Initialized
DEBUG - 2020-07-04 17:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:17:18 --> Input Class Initialized
INFO - 2020-07-04 17:17:18 --> Language Class Initialized
INFO - 2020-07-04 17:17:18 --> Language Class Initialized
INFO - 2020-07-04 17:17:18 --> Config Class Initialized
INFO - 2020-07-04 17:17:18 --> Loader Class Initialized
INFO - 2020-07-04 17:17:18 --> Helper loaded: url_helper
INFO - 2020-07-04 17:17:18 --> Helper loaded: main_helper
INFO - 2020-07-04 17:17:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:17:18 --> Controller Class Initialized
INFO - 2020-07-04 17:17:18 --> Final output sent to browser
DEBUG - 2020-07-04 17:17:18 --> Total execution time: 0.0117
INFO - 2020-07-04 17:17:37 --> Config Class Initialized
INFO - 2020-07-04 17:17:37 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:17:37 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:17:37 --> Utf8 Class Initialized
INFO - 2020-07-04 17:17:37 --> URI Class Initialized
INFO - 2020-07-04 17:17:37 --> Router Class Initialized
INFO - 2020-07-04 17:17:37 --> Output Class Initialized
INFO - 2020-07-04 17:17:37 --> Security Class Initialized
DEBUG - 2020-07-04 17:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:17:37 --> Input Class Initialized
INFO - 2020-07-04 17:17:37 --> Language Class Initialized
INFO - 2020-07-04 17:17:37 --> Language Class Initialized
INFO - 2020-07-04 17:17:37 --> Config Class Initialized
INFO - 2020-07-04 17:17:37 --> Loader Class Initialized
INFO - 2020-07-04 17:17:37 --> Helper loaded: url_helper
INFO - 2020-07-04 17:17:37 --> Helper loaded: main_helper
INFO - 2020-07-04 17:17:37 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:17:37 --> Controller Class Initialized
DEBUG - 2020-07-04 17:17:37 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:17:37 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:17:37 --> Final output sent to browser
DEBUG - 2020-07-04 17:17:37 --> Total execution time: 0.0059
INFO - 2020-07-04 17:17:48 --> Config Class Initialized
INFO - 2020-07-04 17:17:48 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:17:48 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:17:48 --> Utf8 Class Initialized
INFO - 2020-07-04 17:17:48 --> URI Class Initialized
INFO - 2020-07-04 17:17:48 --> Router Class Initialized
INFO - 2020-07-04 17:17:48 --> Output Class Initialized
INFO - 2020-07-04 17:17:48 --> Security Class Initialized
DEBUG - 2020-07-04 17:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:17:48 --> Input Class Initialized
INFO - 2020-07-04 17:17:48 --> Language Class Initialized
INFO - 2020-07-04 17:17:48 --> Language Class Initialized
INFO - 2020-07-04 17:17:48 --> Config Class Initialized
INFO - 2020-07-04 17:17:48 --> Loader Class Initialized
INFO - 2020-07-04 17:17:48 --> Helper loaded: url_helper
INFO - 2020-07-04 17:17:48 --> Helper loaded: main_helper
INFO - 2020-07-04 17:17:48 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:17:48 --> Controller Class Initialized
DEBUG - 2020-07-04 17:17:48 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:17:48 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:17:48 --> Final output sent to browser
DEBUG - 2020-07-04 17:17:48 --> Total execution time: 0.0053
INFO - 2020-07-04 17:17:49 --> Config Class Initialized
INFO - 2020-07-04 17:17:49 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:17:49 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:17:49 --> Utf8 Class Initialized
INFO - 2020-07-04 17:17:49 --> URI Class Initialized
INFO - 2020-07-04 17:17:49 --> Router Class Initialized
INFO - 2020-07-04 17:17:49 --> Output Class Initialized
INFO - 2020-07-04 17:17:49 --> Security Class Initialized
DEBUG - 2020-07-04 17:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:17:49 --> Input Class Initialized
INFO - 2020-07-04 17:17:49 --> Language Class Initialized
INFO - 2020-07-04 17:17:49 --> Language Class Initialized
INFO - 2020-07-04 17:17:49 --> Config Class Initialized
INFO - 2020-07-04 17:17:49 --> Loader Class Initialized
INFO - 2020-07-04 17:17:49 --> Helper loaded: url_helper
INFO - 2020-07-04 17:17:49 --> Helper loaded: main_helper
INFO - 2020-07-04 17:17:49 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:17:49 --> Controller Class Initialized
INFO - 2020-07-04 17:17:49 --> Final output sent to browser
DEBUG - 2020-07-04 17:17:49 --> Total execution time: 0.0073
INFO - 2020-07-04 17:18:15 --> Config Class Initialized
INFO - 2020-07-04 17:18:15 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:18:15 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:18:15 --> Utf8 Class Initialized
INFO - 2020-07-04 17:18:15 --> URI Class Initialized
INFO - 2020-07-04 17:18:15 --> Router Class Initialized
INFO - 2020-07-04 17:18:15 --> Output Class Initialized
INFO - 2020-07-04 17:18:15 --> Security Class Initialized
DEBUG - 2020-07-04 17:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:18:15 --> Input Class Initialized
INFO - 2020-07-04 17:18:15 --> Language Class Initialized
INFO - 2020-07-04 17:18:15 --> Language Class Initialized
INFO - 2020-07-04 17:18:15 --> Config Class Initialized
INFO - 2020-07-04 17:18:15 --> Loader Class Initialized
INFO - 2020-07-04 17:18:15 --> Helper loaded: url_helper
INFO - 2020-07-04 17:18:15 --> Helper loaded: main_helper
INFO - 2020-07-04 17:18:15 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:18:15 --> Controller Class Initialized
DEBUG - 2020-07-04 17:18:15 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:18:15 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:18:15 --> Final output sent to browser
DEBUG - 2020-07-04 17:18:15 --> Total execution time: 0.0042
INFO - 2020-07-04 17:18:17 --> Config Class Initialized
INFO - 2020-07-04 17:18:17 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:18:17 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:18:17 --> Utf8 Class Initialized
INFO - 2020-07-04 17:18:17 --> URI Class Initialized
INFO - 2020-07-04 17:18:17 --> Router Class Initialized
INFO - 2020-07-04 17:18:17 --> Output Class Initialized
INFO - 2020-07-04 17:18:17 --> Security Class Initialized
DEBUG - 2020-07-04 17:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:18:17 --> Input Class Initialized
INFO - 2020-07-04 17:18:17 --> Language Class Initialized
INFO - 2020-07-04 17:18:17 --> Language Class Initialized
INFO - 2020-07-04 17:18:17 --> Config Class Initialized
INFO - 2020-07-04 17:18:17 --> Loader Class Initialized
INFO - 2020-07-04 17:18:17 --> Helper loaded: url_helper
INFO - 2020-07-04 17:18:17 --> Helper loaded: main_helper
INFO - 2020-07-04 17:18:17 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:18:17 --> Controller Class Initialized
INFO - 2020-07-04 17:18:17 --> Final output sent to browser
DEBUG - 2020-07-04 17:18:17 --> Total execution time: 0.0084
INFO - 2020-07-04 17:22:20 --> Config Class Initialized
INFO - 2020-07-04 17:22:20 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:22:20 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:22:20 --> Utf8 Class Initialized
INFO - 2020-07-04 17:22:20 --> URI Class Initialized
INFO - 2020-07-04 17:22:20 --> Router Class Initialized
INFO - 2020-07-04 17:22:20 --> Output Class Initialized
INFO - 2020-07-04 17:22:20 --> Security Class Initialized
DEBUG - 2020-07-04 17:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:22:20 --> Input Class Initialized
INFO - 2020-07-04 17:22:20 --> Language Class Initialized
INFO - 2020-07-04 17:22:20 --> Language Class Initialized
INFO - 2020-07-04 17:22:20 --> Config Class Initialized
INFO - 2020-07-04 17:22:20 --> Loader Class Initialized
INFO - 2020-07-04 17:22:20 --> Helper loaded: url_helper
INFO - 2020-07-04 17:22:20 --> Helper loaded: main_helper
INFO - 2020-07-04 17:22:20 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:22:20 --> Controller Class Initialized
DEBUG - 2020-07-04 17:22:20 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:22:20 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:22:20 --> Final output sent to browser
DEBUG - 2020-07-04 17:22:20 --> Total execution time: 0.0090
INFO - 2020-07-04 17:22:22 --> Config Class Initialized
INFO - 2020-07-04 17:22:22 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:22:22 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:22:22 --> Utf8 Class Initialized
INFO - 2020-07-04 17:22:22 --> URI Class Initialized
INFO - 2020-07-04 17:22:22 --> Router Class Initialized
INFO - 2020-07-04 17:22:22 --> Output Class Initialized
INFO - 2020-07-04 17:22:22 --> Security Class Initialized
DEBUG - 2020-07-04 17:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:22:22 --> Input Class Initialized
INFO - 2020-07-04 17:22:22 --> Language Class Initialized
INFO - 2020-07-04 17:22:22 --> Language Class Initialized
INFO - 2020-07-04 17:22:22 --> Config Class Initialized
INFO - 2020-07-04 17:22:22 --> Loader Class Initialized
INFO - 2020-07-04 17:22:22 --> Helper loaded: url_helper
INFO - 2020-07-04 17:22:22 --> Helper loaded: main_helper
INFO - 2020-07-04 17:22:22 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:22:22 --> Controller Class Initialized
INFO - 2020-07-04 17:22:22 --> Final output sent to browser
DEBUG - 2020-07-04 17:22:22 --> Total execution time: 0.0067
INFO - 2020-07-04 17:22:25 --> Config Class Initialized
INFO - 2020-07-04 17:22:25 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:22:25 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:22:25 --> Utf8 Class Initialized
INFO - 2020-07-04 17:22:25 --> URI Class Initialized
INFO - 2020-07-04 17:22:25 --> Router Class Initialized
INFO - 2020-07-04 17:22:25 --> Output Class Initialized
INFO - 2020-07-04 17:22:25 --> Security Class Initialized
DEBUG - 2020-07-04 17:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:22:25 --> Input Class Initialized
INFO - 2020-07-04 17:22:25 --> Language Class Initialized
ERROR - 2020-07-04 17:22:25 --> 404 Page Not Found: /index
INFO - 2020-07-04 17:23:10 --> Config Class Initialized
INFO - 2020-07-04 17:23:10 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:23:10 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:23:10 --> Utf8 Class Initialized
INFO - 2020-07-04 17:23:10 --> URI Class Initialized
INFO - 2020-07-04 17:23:10 --> Router Class Initialized
INFO - 2020-07-04 17:23:10 --> Output Class Initialized
INFO - 2020-07-04 17:23:10 --> Security Class Initialized
DEBUG - 2020-07-04 17:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:23:10 --> Input Class Initialized
INFO - 2020-07-04 17:23:10 --> Language Class Initialized
INFO - 2020-07-04 17:23:10 --> Language Class Initialized
INFO - 2020-07-04 17:23:10 --> Config Class Initialized
INFO - 2020-07-04 17:23:10 --> Loader Class Initialized
INFO - 2020-07-04 17:23:10 --> Helper loaded: url_helper
INFO - 2020-07-04 17:23:10 --> Helper loaded: main_helper
INFO - 2020-07-04 17:23:10 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:23:10 --> Controller Class Initialized
DEBUG - 2020-07-04 17:23:10 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:23:10 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:23:10 --> Final output sent to browser
DEBUG - 2020-07-04 17:23:10 --> Total execution time: 0.0049
INFO - 2020-07-04 17:23:11 --> Config Class Initialized
INFO - 2020-07-04 17:23:11 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:23:11 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:23:11 --> Utf8 Class Initialized
INFO - 2020-07-04 17:23:11 --> URI Class Initialized
INFO - 2020-07-04 17:23:11 --> Router Class Initialized
INFO - 2020-07-04 17:23:11 --> Output Class Initialized
INFO - 2020-07-04 17:23:11 --> Security Class Initialized
DEBUG - 2020-07-04 17:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:23:11 --> Input Class Initialized
INFO - 2020-07-04 17:23:11 --> Language Class Initialized
INFO - 2020-07-04 17:23:11 --> Language Class Initialized
INFO - 2020-07-04 17:23:11 --> Config Class Initialized
INFO - 2020-07-04 17:23:11 --> Loader Class Initialized
INFO - 2020-07-04 17:23:11 --> Helper loaded: url_helper
INFO - 2020-07-04 17:23:11 --> Helper loaded: main_helper
INFO - 2020-07-04 17:23:11 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:23:11 --> Controller Class Initialized
INFO - 2020-07-04 17:23:11 --> Final output sent to browser
DEBUG - 2020-07-04 17:23:11 --> Total execution time: 0.0061
INFO - 2020-07-04 17:23:14 --> Config Class Initialized
INFO - 2020-07-04 17:23:14 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:23:14 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:23:14 --> Utf8 Class Initialized
INFO - 2020-07-04 17:23:14 --> URI Class Initialized
INFO - 2020-07-04 17:23:14 --> Router Class Initialized
INFO - 2020-07-04 17:23:14 --> Output Class Initialized
INFO - 2020-07-04 17:23:14 --> Security Class Initialized
DEBUG - 2020-07-04 17:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:23:14 --> Input Class Initialized
INFO - 2020-07-04 17:23:14 --> Language Class Initialized
INFO - 2020-07-04 17:23:14 --> Language Class Initialized
INFO - 2020-07-04 17:23:14 --> Config Class Initialized
INFO - 2020-07-04 17:23:14 --> Loader Class Initialized
INFO - 2020-07-04 17:23:14 --> Helper loaded: url_helper
INFO - 2020-07-04 17:23:14 --> Helper loaded: main_helper
INFO - 2020-07-04 17:23:14 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:23:14 --> Controller Class Initialized
INFO - 2020-07-04 17:23:14 --> Final output sent to browser
DEBUG - 2020-07-04 17:23:14 --> Total execution time: 0.0167
INFO - 2020-07-04 17:23:21 --> Config Class Initialized
INFO - 2020-07-04 17:23:21 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:23:21 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:23:21 --> Utf8 Class Initialized
INFO - 2020-07-04 17:23:21 --> URI Class Initialized
INFO - 2020-07-04 17:23:21 --> Router Class Initialized
INFO - 2020-07-04 17:23:21 --> Output Class Initialized
INFO - 2020-07-04 17:23:21 --> Security Class Initialized
DEBUG - 2020-07-04 17:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:23:21 --> Input Class Initialized
INFO - 2020-07-04 17:23:21 --> Language Class Initialized
INFO - 2020-07-04 17:23:21 --> Language Class Initialized
INFO - 2020-07-04 17:23:21 --> Config Class Initialized
INFO - 2020-07-04 17:23:21 --> Loader Class Initialized
INFO - 2020-07-04 17:23:21 --> Helper loaded: url_helper
INFO - 2020-07-04 17:23:21 --> Helper loaded: main_helper
INFO - 2020-07-04 17:23:21 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:23:21 --> Controller Class Initialized
INFO - 2020-07-04 17:23:21 --> Final output sent to browser
DEBUG - 2020-07-04 17:23:21 --> Total execution time: 0.0085
INFO - 2020-07-04 17:23:56 --> Config Class Initialized
INFO - 2020-07-04 17:23:56 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:23:56 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:23:56 --> Utf8 Class Initialized
INFO - 2020-07-04 17:23:56 --> URI Class Initialized
INFO - 2020-07-04 17:23:56 --> Router Class Initialized
INFO - 2020-07-04 17:23:56 --> Output Class Initialized
INFO - 2020-07-04 17:23:56 --> Security Class Initialized
DEBUG - 2020-07-04 17:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:23:56 --> Input Class Initialized
INFO - 2020-07-04 17:23:56 --> Language Class Initialized
INFO - 2020-07-04 17:23:56 --> Language Class Initialized
INFO - 2020-07-04 17:23:56 --> Config Class Initialized
INFO - 2020-07-04 17:23:56 --> Loader Class Initialized
INFO - 2020-07-04 17:23:56 --> Helper loaded: url_helper
INFO - 2020-07-04 17:23:56 --> Helper loaded: main_helper
INFO - 2020-07-04 17:23:56 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:23:56 --> Controller Class Initialized
INFO - 2020-07-04 17:23:56 --> Final output sent to browser
DEBUG - 2020-07-04 17:23:56 --> Total execution time: 0.0043
INFO - 2020-07-04 17:23:58 --> Config Class Initialized
INFO - 2020-07-04 17:23:58 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:23:58 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:23:58 --> Utf8 Class Initialized
INFO - 2020-07-04 17:23:58 --> URI Class Initialized
INFO - 2020-07-04 17:23:58 --> Router Class Initialized
INFO - 2020-07-04 17:23:58 --> Output Class Initialized
INFO - 2020-07-04 17:23:58 --> Security Class Initialized
DEBUG - 2020-07-04 17:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:23:58 --> Input Class Initialized
INFO - 2020-07-04 17:23:58 --> Language Class Initialized
INFO - 2020-07-04 17:23:58 --> Language Class Initialized
INFO - 2020-07-04 17:23:58 --> Config Class Initialized
INFO - 2020-07-04 17:23:58 --> Loader Class Initialized
INFO - 2020-07-04 17:23:58 --> Helper loaded: url_helper
INFO - 2020-07-04 17:23:58 --> Helper loaded: main_helper
INFO - 2020-07-04 17:23:58 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:23:58 --> Controller Class Initialized
INFO - 2020-07-04 17:23:58 --> Final output sent to browser
DEBUG - 2020-07-04 17:23:58 --> Total execution time: 0.0051
INFO - 2020-07-04 17:24:27 --> Config Class Initialized
INFO - 2020-07-04 17:24:27 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:24:27 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:24:27 --> Utf8 Class Initialized
INFO - 2020-07-04 17:24:27 --> URI Class Initialized
INFO - 2020-07-04 17:24:27 --> Router Class Initialized
INFO - 2020-07-04 17:24:27 --> Output Class Initialized
INFO - 2020-07-04 17:24:27 --> Security Class Initialized
DEBUG - 2020-07-04 17:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:24:27 --> Input Class Initialized
INFO - 2020-07-04 17:24:27 --> Language Class Initialized
INFO - 2020-07-04 17:24:27 --> Language Class Initialized
INFO - 2020-07-04 17:24:27 --> Config Class Initialized
INFO - 2020-07-04 17:24:27 --> Loader Class Initialized
INFO - 2020-07-04 17:24:27 --> Helper loaded: url_helper
INFO - 2020-07-04 17:24:27 --> Helper loaded: main_helper
INFO - 2020-07-04 17:24:27 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:24:27 --> Controller Class Initialized
DEBUG - 2020-07-04 17:24:27 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:24:27 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:24:27 --> Final output sent to browser
DEBUG - 2020-07-04 17:24:27 --> Total execution time: 0.0044
INFO - 2020-07-04 17:24:28 --> Config Class Initialized
INFO - 2020-07-04 17:24:28 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:24:28 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:24:28 --> Utf8 Class Initialized
INFO - 2020-07-04 17:24:28 --> URI Class Initialized
INFO - 2020-07-04 17:24:28 --> Router Class Initialized
INFO - 2020-07-04 17:24:28 --> Output Class Initialized
INFO - 2020-07-04 17:24:28 --> Security Class Initialized
DEBUG - 2020-07-04 17:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:24:28 --> Input Class Initialized
INFO - 2020-07-04 17:24:28 --> Language Class Initialized
INFO - 2020-07-04 17:24:28 --> Language Class Initialized
INFO - 2020-07-04 17:24:28 --> Config Class Initialized
INFO - 2020-07-04 17:24:28 --> Loader Class Initialized
INFO - 2020-07-04 17:24:28 --> Helper loaded: url_helper
INFO - 2020-07-04 17:24:28 --> Helper loaded: main_helper
INFO - 2020-07-04 17:24:28 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:24:28 --> Controller Class Initialized
INFO - 2020-07-04 17:24:28 --> Final output sent to browser
DEBUG - 2020-07-04 17:24:28 --> Total execution time: 0.0057
INFO - 2020-07-04 17:24:35 --> Config Class Initialized
INFO - 2020-07-04 17:24:35 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:24:35 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:24:35 --> Utf8 Class Initialized
INFO - 2020-07-04 17:24:35 --> URI Class Initialized
INFO - 2020-07-04 17:24:35 --> Router Class Initialized
INFO - 2020-07-04 17:24:35 --> Output Class Initialized
INFO - 2020-07-04 17:24:35 --> Security Class Initialized
DEBUG - 2020-07-04 17:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:24:35 --> Input Class Initialized
INFO - 2020-07-04 17:24:35 --> Language Class Initialized
INFO - 2020-07-04 17:24:35 --> Language Class Initialized
INFO - 2020-07-04 17:24:35 --> Config Class Initialized
INFO - 2020-07-04 17:24:35 --> Loader Class Initialized
INFO - 2020-07-04 17:24:35 --> Helper loaded: url_helper
INFO - 2020-07-04 17:24:35 --> Helper loaded: main_helper
INFO - 2020-07-04 17:24:35 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:24:35 --> Controller Class Initialized
DEBUG - 2020-07-04 17:24:35 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:24:35 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:24:35 --> Final output sent to browser
DEBUG - 2020-07-04 17:24:35 --> Total execution time: 0.0036
INFO - 2020-07-04 17:24:36 --> Config Class Initialized
INFO - 2020-07-04 17:24:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:24:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:24:36 --> Utf8 Class Initialized
INFO - 2020-07-04 17:24:36 --> URI Class Initialized
INFO - 2020-07-04 17:24:36 --> Router Class Initialized
INFO - 2020-07-04 17:24:36 --> Output Class Initialized
INFO - 2020-07-04 17:24:36 --> Security Class Initialized
DEBUG - 2020-07-04 17:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:24:36 --> Input Class Initialized
INFO - 2020-07-04 17:24:36 --> Language Class Initialized
INFO - 2020-07-04 17:24:36 --> Language Class Initialized
INFO - 2020-07-04 17:24:36 --> Config Class Initialized
INFO - 2020-07-04 17:24:36 --> Loader Class Initialized
INFO - 2020-07-04 17:24:36 --> Helper loaded: url_helper
INFO - 2020-07-04 17:24:36 --> Helper loaded: main_helper
INFO - 2020-07-04 17:24:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:24:36 --> Controller Class Initialized
INFO - 2020-07-04 17:24:36 --> Final output sent to browser
DEBUG - 2020-07-04 17:24:36 --> Total execution time: 0.0051
INFO - 2020-07-04 17:24:39 --> Config Class Initialized
INFO - 2020-07-04 17:24:39 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:24:39 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:24:39 --> Utf8 Class Initialized
INFO - 2020-07-04 17:24:39 --> URI Class Initialized
INFO - 2020-07-04 17:24:39 --> Router Class Initialized
INFO - 2020-07-04 17:24:39 --> Output Class Initialized
INFO - 2020-07-04 17:24:39 --> Security Class Initialized
DEBUG - 2020-07-04 17:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:24:39 --> Input Class Initialized
INFO - 2020-07-04 17:24:39 --> Language Class Initialized
INFO - 2020-07-04 17:24:39 --> Language Class Initialized
INFO - 2020-07-04 17:24:39 --> Config Class Initialized
INFO - 2020-07-04 17:24:39 --> Loader Class Initialized
INFO - 2020-07-04 17:24:39 --> Helper loaded: url_helper
INFO - 2020-07-04 17:24:39 --> Helper loaded: main_helper
INFO - 2020-07-04 17:24:39 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:24:39 --> Controller Class Initialized
INFO - 2020-07-04 17:24:39 --> Final output sent to browser
DEBUG - 2020-07-04 17:24:39 --> Total execution time: 0.0042
INFO - 2020-07-04 17:24:41 --> Config Class Initialized
INFO - 2020-07-04 17:24:41 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:24:41 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:24:41 --> Utf8 Class Initialized
INFO - 2020-07-04 17:24:41 --> URI Class Initialized
INFO - 2020-07-04 17:24:41 --> Router Class Initialized
INFO - 2020-07-04 17:24:41 --> Output Class Initialized
INFO - 2020-07-04 17:24:41 --> Security Class Initialized
DEBUG - 2020-07-04 17:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:24:41 --> Input Class Initialized
INFO - 2020-07-04 17:24:41 --> Language Class Initialized
INFO - 2020-07-04 17:24:41 --> Language Class Initialized
INFO - 2020-07-04 17:24:41 --> Config Class Initialized
INFO - 2020-07-04 17:24:41 --> Loader Class Initialized
INFO - 2020-07-04 17:24:41 --> Helper loaded: url_helper
INFO - 2020-07-04 17:24:41 --> Helper loaded: main_helper
INFO - 2020-07-04 17:24:41 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:24:41 --> Controller Class Initialized
INFO - 2020-07-04 17:24:41 --> Final output sent to browser
DEBUG - 2020-07-04 17:24:41 --> Total execution time: 0.0071
INFO - 2020-07-04 17:24:43 --> Config Class Initialized
INFO - 2020-07-04 17:24:43 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:24:43 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:24:43 --> Utf8 Class Initialized
INFO - 2020-07-04 17:24:43 --> URI Class Initialized
INFO - 2020-07-04 17:24:43 --> Router Class Initialized
INFO - 2020-07-04 17:24:43 --> Output Class Initialized
INFO - 2020-07-04 17:24:43 --> Security Class Initialized
DEBUG - 2020-07-04 17:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:24:43 --> Input Class Initialized
INFO - 2020-07-04 17:24:43 --> Language Class Initialized
INFO - 2020-07-04 17:24:43 --> Language Class Initialized
INFO - 2020-07-04 17:24:43 --> Config Class Initialized
INFO - 2020-07-04 17:24:43 --> Loader Class Initialized
INFO - 2020-07-04 17:24:43 --> Helper loaded: url_helper
INFO - 2020-07-04 17:24:43 --> Helper loaded: main_helper
INFO - 2020-07-04 17:24:43 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:24:43 --> Controller Class Initialized
INFO - 2020-07-04 17:24:43 --> Final output sent to browser
DEBUG - 2020-07-04 17:24:43 --> Total execution time: 0.0042
INFO - 2020-07-04 17:25:26 --> Config Class Initialized
INFO - 2020-07-04 17:25:26 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:25:26 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:25:26 --> Utf8 Class Initialized
INFO - 2020-07-04 17:25:26 --> URI Class Initialized
INFO - 2020-07-04 17:25:26 --> Router Class Initialized
INFO - 2020-07-04 17:25:26 --> Output Class Initialized
INFO - 2020-07-04 17:25:26 --> Security Class Initialized
DEBUG - 2020-07-04 17:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:25:26 --> Input Class Initialized
INFO - 2020-07-04 17:25:26 --> Language Class Initialized
INFO - 2020-07-04 17:25:26 --> Language Class Initialized
INFO - 2020-07-04 17:25:26 --> Config Class Initialized
INFO - 2020-07-04 17:25:26 --> Loader Class Initialized
INFO - 2020-07-04 17:25:26 --> Helper loaded: url_helper
INFO - 2020-07-04 17:25:26 --> Helper loaded: main_helper
INFO - 2020-07-04 17:25:26 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:25:26 --> Controller Class Initialized
DEBUG - 2020-07-04 17:25:26 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:25:26 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:25:26 --> Final output sent to browser
DEBUG - 2020-07-04 17:25:26 --> Total execution time: 0.0035
INFO - 2020-07-04 17:25:27 --> Config Class Initialized
INFO - 2020-07-04 17:25:27 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:25:27 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:25:27 --> Utf8 Class Initialized
INFO - 2020-07-04 17:25:27 --> URI Class Initialized
INFO - 2020-07-04 17:25:27 --> Router Class Initialized
INFO - 2020-07-04 17:25:27 --> Output Class Initialized
INFO - 2020-07-04 17:25:27 --> Security Class Initialized
DEBUG - 2020-07-04 17:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:25:27 --> Input Class Initialized
INFO - 2020-07-04 17:25:27 --> Language Class Initialized
INFO - 2020-07-04 17:25:27 --> Language Class Initialized
INFO - 2020-07-04 17:25:27 --> Config Class Initialized
INFO - 2020-07-04 17:25:27 --> Loader Class Initialized
INFO - 2020-07-04 17:25:27 --> Helper loaded: url_helper
INFO - 2020-07-04 17:25:27 --> Helper loaded: main_helper
INFO - 2020-07-04 17:25:27 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:25:27 --> Controller Class Initialized
INFO - 2020-07-04 17:25:27 --> Final output sent to browser
DEBUG - 2020-07-04 17:25:27 --> Total execution time: 0.0037
INFO - 2020-07-04 17:26:04 --> Config Class Initialized
INFO - 2020-07-04 17:26:04 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:26:04 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:26:04 --> Utf8 Class Initialized
INFO - 2020-07-04 17:26:04 --> URI Class Initialized
INFO - 2020-07-04 17:26:04 --> Router Class Initialized
INFO - 2020-07-04 17:26:04 --> Output Class Initialized
INFO - 2020-07-04 17:26:04 --> Security Class Initialized
DEBUG - 2020-07-04 17:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:26:04 --> Input Class Initialized
INFO - 2020-07-04 17:26:04 --> Language Class Initialized
INFO - 2020-07-04 17:26:04 --> Language Class Initialized
INFO - 2020-07-04 17:26:04 --> Config Class Initialized
INFO - 2020-07-04 17:26:04 --> Loader Class Initialized
INFO - 2020-07-04 17:26:04 --> Helper loaded: url_helper
INFO - 2020-07-04 17:26:04 --> Helper loaded: main_helper
INFO - 2020-07-04 17:26:04 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:26:04 --> Controller Class Initialized
DEBUG - 2020-07-04 17:26:04 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:26:04 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:26:04 --> Final output sent to browser
DEBUG - 2020-07-04 17:26:04 --> Total execution time: 0.0044
INFO - 2020-07-04 17:26:04 --> Config Class Initialized
INFO - 2020-07-04 17:26:04 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:26:04 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:26:04 --> Utf8 Class Initialized
INFO - 2020-07-04 17:26:04 --> URI Class Initialized
INFO - 2020-07-04 17:26:04 --> Router Class Initialized
INFO - 2020-07-04 17:26:04 --> Output Class Initialized
INFO - 2020-07-04 17:26:04 --> Security Class Initialized
DEBUG - 2020-07-04 17:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:26:04 --> Input Class Initialized
INFO - 2020-07-04 17:26:04 --> Language Class Initialized
INFO - 2020-07-04 17:26:04 --> Language Class Initialized
INFO - 2020-07-04 17:26:04 --> Config Class Initialized
INFO - 2020-07-04 17:26:04 --> Loader Class Initialized
INFO - 2020-07-04 17:26:04 --> Helper loaded: url_helper
INFO - 2020-07-04 17:26:04 --> Helper loaded: main_helper
INFO - 2020-07-04 17:26:04 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:26:04 --> Controller Class Initialized
INFO - 2020-07-04 17:26:04 --> Final output sent to browser
DEBUG - 2020-07-04 17:26:04 --> Total execution time: 0.0045
INFO - 2020-07-04 17:26:18 --> Config Class Initialized
INFO - 2020-07-04 17:26:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:26:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:26:18 --> Utf8 Class Initialized
INFO - 2020-07-04 17:26:18 --> URI Class Initialized
INFO - 2020-07-04 17:26:18 --> Router Class Initialized
INFO - 2020-07-04 17:26:18 --> Output Class Initialized
INFO - 2020-07-04 17:26:18 --> Security Class Initialized
DEBUG - 2020-07-04 17:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:26:18 --> Input Class Initialized
INFO - 2020-07-04 17:26:18 --> Language Class Initialized
INFO - 2020-07-04 17:26:18 --> Language Class Initialized
INFO - 2020-07-04 17:26:18 --> Config Class Initialized
INFO - 2020-07-04 17:26:18 --> Loader Class Initialized
INFO - 2020-07-04 17:26:18 --> Helper loaded: url_helper
INFO - 2020-07-04 17:26:18 --> Helper loaded: main_helper
INFO - 2020-07-04 17:26:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:26:18 --> Controller Class Initialized
DEBUG - 2020-07-04 17:26:18 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:26:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:26:18 --> Final output sent to browser
DEBUG - 2020-07-04 17:26:18 --> Total execution time: 0.0041
INFO - 2020-07-04 17:26:19 --> Config Class Initialized
INFO - 2020-07-04 17:26:19 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:26:19 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:26:19 --> Utf8 Class Initialized
INFO - 2020-07-04 17:26:19 --> URI Class Initialized
INFO - 2020-07-04 17:26:19 --> Router Class Initialized
INFO - 2020-07-04 17:26:19 --> Output Class Initialized
INFO - 2020-07-04 17:26:19 --> Security Class Initialized
DEBUG - 2020-07-04 17:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:26:19 --> Input Class Initialized
INFO - 2020-07-04 17:26:19 --> Language Class Initialized
INFO - 2020-07-04 17:26:19 --> Language Class Initialized
INFO - 2020-07-04 17:26:19 --> Config Class Initialized
INFO - 2020-07-04 17:26:19 --> Loader Class Initialized
INFO - 2020-07-04 17:26:19 --> Helper loaded: url_helper
INFO - 2020-07-04 17:26:19 --> Helper loaded: main_helper
INFO - 2020-07-04 17:26:19 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:26:19 --> Controller Class Initialized
INFO - 2020-07-04 17:26:19 --> Final output sent to browser
DEBUG - 2020-07-04 17:26:19 --> Total execution time: 0.0038
INFO - 2020-07-04 17:27:34 --> Config Class Initialized
INFO - 2020-07-04 17:27:34 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:27:34 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:27:34 --> Utf8 Class Initialized
INFO - 2020-07-04 17:27:34 --> URI Class Initialized
INFO - 2020-07-04 17:27:34 --> Router Class Initialized
INFO - 2020-07-04 17:27:34 --> Output Class Initialized
INFO - 2020-07-04 17:27:34 --> Security Class Initialized
DEBUG - 2020-07-04 17:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:27:34 --> Input Class Initialized
INFO - 2020-07-04 17:27:34 --> Language Class Initialized
INFO - 2020-07-04 17:27:34 --> Language Class Initialized
INFO - 2020-07-04 17:27:34 --> Config Class Initialized
INFO - 2020-07-04 17:27:34 --> Loader Class Initialized
INFO - 2020-07-04 17:27:34 --> Helper loaded: url_helper
INFO - 2020-07-04 17:27:34 --> Helper loaded: main_helper
INFO - 2020-07-04 17:27:34 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:27:34 --> Controller Class Initialized
DEBUG - 2020-07-04 17:27:34 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:27:34 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:27:34 --> Final output sent to browser
DEBUG - 2020-07-04 17:27:34 --> Total execution time: 0.0065
INFO - 2020-07-04 17:27:35 --> Config Class Initialized
INFO - 2020-07-04 17:27:35 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:27:35 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:27:35 --> Utf8 Class Initialized
INFO - 2020-07-04 17:27:35 --> URI Class Initialized
INFO - 2020-07-04 17:27:35 --> Router Class Initialized
INFO - 2020-07-04 17:27:35 --> Output Class Initialized
INFO - 2020-07-04 17:27:35 --> Security Class Initialized
DEBUG - 2020-07-04 17:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:27:35 --> Input Class Initialized
INFO - 2020-07-04 17:27:35 --> Language Class Initialized
INFO - 2020-07-04 17:27:35 --> Language Class Initialized
INFO - 2020-07-04 17:27:35 --> Config Class Initialized
INFO - 2020-07-04 17:27:35 --> Loader Class Initialized
INFO - 2020-07-04 17:27:35 --> Helper loaded: url_helper
INFO - 2020-07-04 17:27:35 --> Helper loaded: main_helper
INFO - 2020-07-04 17:27:35 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:27:35 --> Controller Class Initialized
INFO - 2020-07-04 17:27:35 --> Final output sent to browser
DEBUG - 2020-07-04 17:27:35 --> Total execution time: 0.0041
INFO - 2020-07-04 17:28:18 --> Config Class Initialized
INFO - 2020-07-04 17:28:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:28:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:28:18 --> Utf8 Class Initialized
INFO - 2020-07-04 17:28:18 --> URI Class Initialized
INFO - 2020-07-04 17:28:18 --> Router Class Initialized
INFO - 2020-07-04 17:28:18 --> Output Class Initialized
INFO - 2020-07-04 17:28:18 --> Security Class Initialized
DEBUG - 2020-07-04 17:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:28:18 --> Input Class Initialized
INFO - 2020-07-04 17:28:18 --> Language Class Initialized
INFO - 2020-07-04 17:28:18 --> Language Class Initialized
INFO - 2020-07-04 17:28:18 --> Config Class Initialized
INFO - 2020-07-04 17:28:18 --> Loader Class Initialized
INFO - 2020-07-04 17:28:18 --> Helper loaded: url_helper
INFO - 2020-07-04 17:28:18 --> Helper loaded: main_helper
INFO - 2020-07-04 17:28:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:28:18 --> Controller Class Initialized
INFO - 2020-07-04 17:28:18 --> Final output sent to browser
DEBUG - 2020-07-04 17:28:18 --> Total execution time: 0.0044
INFO - 2020-07-04 17:28:20 --> Config Class Initialized
INFO - 2020-07-04 17:28:20 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:28:20 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:28:20 --> Utf8 Class Initialized
INFO - 2020-07-04 17:28:20 --> URI Class Initialized
INFO - 2020-07-04 17:28:20 --> Router Class Initialized
INFO - 2020-07-04 17:28:20 --> Output Class Initialized
INFO - 2020-07-04 17:28:20 --> Security Class Initialized
DEBUG - 2020-07-04 17:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:28:20 --> Input Class Initialized
INFO - 2020-07-04 17:28:20 --> Language Class Initialized
INFO - 2020-07-04 17:28:20 --> Language Class Initialized
INFO - 2020-07-04 17:28:20 --> Config Class Initialized
INFO - 2020-07-04 17:28:20 --> Loader Class Initialized
INFO - 2020-07-04 17:28:20 --> Helper loaded: url_helper
INFO - 2020-07-04 17:28:20 --> Helper loaded: main_helper
INFO - 2020-07-04 17:28:20 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:28:20 --> Controller Class Initialized
INFO - 2020-07-04 17:28:20 --> Final output sent to browser
DEBUG - 2020-07-04 17:28:20 --> Total execution time: 0.0056
INFO - 2020-07-04 17:31:06 --> Config Class Initialized
INFO - 2020-07-04 17:31:06 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:31:06 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:31:06 --> Utf8 Class Initialized
INFO - 2020-07-04 17:31:06 --> URI Class Initialized
INFO - 2020-07-04 17:31:06 --> Router Class Initialized
INFO - 2020-07-04 17:31:06 --> Output Class Initialized
INFO - 2020-07-04 17:31:06 --> Security Class Initialized
DEBUG - 2020-07-04 17:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:31:06 --> Input Class Initialized
INFO - 2020-07-04 17:31:06 --> Language Class Initialized
INFO - 2020-07-04 17:31:06 --> Language Class Initialized
INFO - 2020-07-04 17:31:06 --> Config Class Initialized
INFO - 2020-07-04 17:31:06 --> Loader Class Initialized
INFO - 2020-07-04 17:31:06 --> Helper loaded: url_helper
INFO - 2020-07-04 17:31:06 --> Helper loaded: main_helper
INFO - 2020-07-04 17:31:06 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:31:06 --> Controller Class Initialized
DEBUG - 2020-07-04 17:31:06 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:31:06 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:31:06 --> Final output sent to browser
DEBUG - 2020-07-04 17:31:06 --> Total execution time: 0.0045
INFO - 2020-07-04 17:31:07 --> Config Class Initialized
INFO - 2020-07-04 17:31:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:31:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:31:07 --> Utf8 Class Initialized
INFO - 2020-07-04 17:31:07 --> URI Class Initialized
INFO - 2020-07-04 17:31:07 --> Router Class Initialized
INFO - 2020-07-04 17:31:07 --> Output Class Initialized
INFO - 2020-07-04 17:31:07 --> Security Class Initialized
DEBUG - 2020-07-04 17:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:31:07 --> Input Class Initialized
INFO - 2020-07-04 17:31:07 --> Language Class Initialized
INFO - 2020-07-04 17:31:07 --> Language Class Initialized
INFO - 2020-07-04 17:31:07 --> Config Class Initialized
INFO - 2020-07-04 17:31:07 --> Loader Class Initialized
INFO - 2020-07-04 17:31:07 --> Helper loaded: url_helper
INFO - 2020-07-04 17:31:07 --> Helper loaded: main_helper
INFO - 2020-07-04 17:31:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:31:07 --> Controller Class Initialized
INFO - 2020-07-04 17:31:07 --> Final output sent to browser
DEBUG - 2020-07-04 17:31:07 --> Total execution time: 0.0041
INFO - 2020-07-04 17:32:43 --> Config Class Initialized
INFO - 2020-07-04 17:32:43 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:32:43 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:32:43 --> Utf8 Class Initialized
INFO - 2020-07-04 17:32:43 --> URI Class Initialized
INFO - 2020-07-04 17:32:43 --> Router Class Initialized
INFO - 2020-07-04 17:32:43 --> Output Class Initialized
INFO - 2020-07-04 17:32:43 --> Security Class Initialized
DEBUG - 2020-07-04 17:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:32:43 --> Input Class Initialized
INFO - 2020-07-04 17:32:43 --> Language Class Initialized
INFO - 2020-07-04 17:32:43 --> Language Class Initialized
INFO - 2020-07-04 17:32:43 --> Config Class Initialized
INFO - 2020-07-04 17:32:43 --> Loader Class Initialized
INFO - 2020-07-04 17:32:43 --> Helper loaded: url_helper
INFO - 2020-07-04 17:32:43 --> Helper loaded: main_helper
INFO - 2020-07-04 17:32:43 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:32:43 --> Controller Class Initialized
INFO - 2020-07-04 17:32:43 --> Config Class Initialized
INFO - 2020-07-04 17:32:43 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:32:43 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:32:43 --> Utf8 Class Initialized
INFO - 2020-07-04 17:32:43 --> URI Class Initialized
INFO - 2020-07-04 17:32:43 --> Router Class Initialized
INFO - 2020-07-04 17:32:43 --> Output Class Initialized
INFO - 2020-07-04 17:32:43 --> Security Class Initialized
DEBUG - 2020-07-04 17:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:32:43 --> Input Class Initialized
INFO - 2020-07-04 17:32:43 --> Language Class Initialized
INFO - 2020-07-04 17:32:43 --> Language Class Initialized
INFO - 2020-07-04 17:32:43 --> Config Class Initialized
INFO - 2020-07-04 17:32:43 --> Loader Class Initialized
INFO - 2020-07-04 17:32:43 --> Helper loaded: url_helper
INFO - 2020-07-04 17:32:43 --> Helper loaded: main_helper
INFO - 2020-07-04 17:32:43 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:32:43 --> Controller Class Initialized
DEBUG - 2020-07-04 17:32:43 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:32:43 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:32:43 --> Final output sent to browser
DEBUG - 2020-07-04 17:32:43 --> Total execution time: 0.0030
INFO - 2020-07-04 17:32:44 --> Config Class Initialized
INFO - 2020-07-04 17:32:44 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:32:44 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:32:44 --> Utf8 Class Initialized
INFO - 2020-07-04 17:32:44 --> URI Class Initialized
INFO - 2020-07-04 17:32:44 --> Router Class Initialized
INFO - 2020-07-04 17:32:44 --> Output Class Initialized
INFO - 2020-07-04 17:32:44 --> Security Class Initialized
DEBUG - 2020-07-04 17:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:32:44 --> Input Class Initialized
INFO - 2020-07-04 17:32:44 --> Language Class Initialized
INFO - 2020-07-04 17:32:44 --> Language Class Initialized
INFO - 2020-07-04 17:32:44 --> Config Class Initialized
INFO - 2020-07-04 17:32:44 --> Loader Class Initialized
INFO - 2020-07-04 17:32:44 --> Helper loaded: url_helper
INFO - 2020-07-04 17:32:44 --> Helper loaded: main_helper
INFO - 2020-07-04 17:32:44 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:32:44 --> Controller Class Initialized
INFO - 2020-07-04 17:32:44 --> Final output sent to browser
DEBUG - 2020-07-04 17:32:44 --> Total execution time: 0.0092
INFO - 2020-07-04 17:33:25 --> Config Class Initialized
INFO - 2020-07-04 17:33:25 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:33:25 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:33:25 --> Utf8 Class Initialized
INFO - 2020-07-04 17:33:25 --> URI Class Initialized
INFO - 2020-07-04 17:33:25 --> Router Class Initialized
INFO - 2020-07-04 17:33:25 --> Output Class Initialized
INFO - 2020-07-04 17:33:25 --> Security Class Initialized
DEBUG - 2020-07-04 17:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:33:25 --> Input Class Initialized
INFO - 2020-07-04 17:33:25 --> Language Class Initialized
INFO - 2020-07-04 17:33:25 --> Language Class Initialized
INFO - 2020-07-04 17:33:25 --> Config Class Initialized
INFO - 2020-07-04 17:33:25 --> Loader Class Initialized
INFO - 2020-07-04 17:33:25 --> Helper loaded: url_helper
INFO - 2020-07-04 17:33:25 --> Helper loaded: main_helper
INFO - 2020-07-04 17:33:25 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:33:25 --> Controller Class Initialized
DEBUG - 2020-07-04 17:33:25 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:33:25 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:33:25 --> Final output sent to browser
DEBUG - 2020-07-04 17:33:25 --> Total execution time: 0.0041
INFO - 2020-07-04 17:34:50 --> Config Class Initialized
INFO - 2020-07-04 17:34:50 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:34:50 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:34:50 --> Utf8 Class Initialized
INFO - 2020-07-04 17:34:50 --> URI Class Initialized
INFO - 2020-07-04 17:34:50 --> Router Class Initialized
INFO - 2020-07-04 17:34:50 --> Output Class Initialized
INFO - 2020-07-04 17:34:50 --> Security Class Initialized
DEBUG - 2020-07-04 17:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:34:50 --> Input Class Initialized
INFO - 2020-07-04 17:34:50 --> Language Class Initialized
INFO - 2020-07-04 17:34:50 --> Language Class Initialized
INFO - 2020-07-04 17:34:50 --> Config Class Initialized
INFO - 2020-07-04 17:34:50 --> Loader Class Initialized
INFO - 2020-07-04 17:34:50 --> Helper loaded: url_helper
INFO - 2020-07-04 17:34:50 --> Helper loaded: main_helper
INFO - 2020-07-04 17:34:50 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:34:50 --> Controller Class Initialized
DEBUG - 2020-07-04 17:34:50 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:34:50 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:34:50 --> Final output sent to browser
DEBUG - 2020-07-04 17:34:50 --> Total execution time: 0.0056
INFO - 2020-07-04 17:34:51 --> Config Class Initialized
INFO - 2020-07-04 17:34:51 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:34:51 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:34:51 --> Utf8 Class Initialized
INFO - 2020-07-04 17:34:51 --> URI Class Initialized
INFO - 2020-07-04 17:34:51 --> Router Class Initialized
INFO - 2020-07-04 17:34:51 --> Output Class Initialized
INFO - 2020-07-04 17:34:51 --> Security Class Initialized
DEBUG - 2020-07-04 17:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:34:51 --> Input Class Initialized
INFO - 2020-07-04 17:34:51 --> Language Class Initialized
INFO - 2020-07-04 17:34:51 --> Language Class Initialized
INFO - 2020-07-04 17:34:51 --> Config Class Initialized
INFO - 2020-07-04 17:34:51 --> Loader Class Initialized
INFO - 2020-07-04 17:34:51 --> Helper loaded: url_helper
INFO - 2020-07-04 17:34:51 --> Helper loaded: main_helper
INFO - 2020-07-04 17:34:51 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:34:51 --> Controller Class Initialized
INFO - 2020-07-04 17:34:51 --> Final output sent to browser
DEBUG - 2020-07-04 17:34:51 --> Total execution time: 0.0056
INFO - 2020-07-04 17:35:13 --> Config Class Initialized
INFO - 2020-07-04 17:35:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:35:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:35:13 --> Utf8 Class Initialized
INFO - 2020-07-04 17:35:13 --> URI Class Initialized
INFO - 2020-07-04 17:35:13 --> Router Class Initialized
INFO - 2020-07-04 17:35:13 --> Output Class Initialized
INFO - 2020-07-04 17:35:13 --> Security Class Initialized
DEBUG - 2020-07-04 17:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:35:13 --> Input Class Initialized
INFO - 2020-07-04 17:35:13 --> Language Class Initialized
INFO - 2020-07-04 17:35:13 --> Language Class Initialized
INFO - 2020-07-04 17:35:13 --> Config Class Initialized
INFO - 2020-07-04 17:35:13 --> Loader Class Initialized
INFO - 2020-07-04 17:35:13 --> Helper loaded: url_helper
INFO - 2020-07-04 17:35:13 --> Helper loaded: main_helper
INFO - 2020-07-04 17:35:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:35:13 --> Controller Class Initialized
INFO - 2020-07-04 17:35:13 --> Config Class Initialized
INFO - 2020-07-04 17:35:13 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:35:13 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:35:13 --> Utf8 Class Initialized
INFO - 2020-07-04 17:35:13 --> URI Class Initialized
INFO - 2020-07-04 17:35:13 --> Router Class Initialized
INFO - 2020-07-04 17:35:13 --> Output Class Initialized
INFO - 2020-07-04 17:35:13 --> Security Class Initialized
DEBUG - 2020-07-04 17:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:35:13 --> Input Class Initialized
INFO - 2020-07-04 17:35:13 --> Language Class Initialized
INFO - 2020-07-04 17:35:13 --> Language Class Initialized
INFO - 2020-07-04 17:35:13 --> Config Class Initialized
INFO - 2020-07-04 17:35:13 --> Loader Class Initialized
INFO - 2020-07-04 17:35:13 --> Helper loaded: url_helper
INFO - 2020-07-04 17:35:13 --> Helper loaded: main_helper
INFO - 2020-07-04 17:35:13 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:35:13 --> Controller Class Initialized
DEBUG - 2020-07-04 17:35:13 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:35:13 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:35:13 --> Final output sent to browser
DEBUG - 2020-07-04 17:35:13 --> Total execution time: 0.0032
INFO - 2020-07-04 17:35:14 --> Config Class Initialized
INFO - 2020-07-04 17:35:14 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:35:14 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:35:14 --> Utf8 Class Initialized
INFO - 2020-07-04 17:35:14 --> URI Class Initialized
INFO - 2020-07-04 17:35:14 --> Router Class Initialized
INFO - 2020-07-04 17:35:14 --> Output Class Initialized
INFO - 2020-07-04 17:35:14 --> Security Class Initialized
DEBUG - 2020-07-04 17:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:35:14 --> Input Class Initialized
INFO - 2020-07-04 17:35:14 --> Language Class Initialized
INFO - 2020-07-04 17:35:14 --> Language Class Initialized
INFO - 2020-07-04 17:35:14 --> Config Class Initialized
INFO - 2020-07-04 17:35:14 --> Loader Class Initialized
INFO - 2020-07-04 17:35:14 --> Helper loaded: url_helper
INFO - 2020-07-04 17:35:14 --> Helper loaded: main_helper
INFO - 2020-07-04 17:35:14 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:35:14 --> Controller Class Initialized
INFO - 2020-07-04 17:35:14 --> Final output sent to browser
DEBUG - 2020-07-04 17:35:14 --> Total execution time: 0.0068
INFO - 2020-07-04 17:37:44 --> Config Class Initialized
INFO - 2020-07-04 17:37:44 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:37:44 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:37:44 --> Utf8 Class Initialized
INFO - 2020-07-04 17:37:44 --> URI Class Initialized
INFO - 2020-07-04 17:37:44 --> Router Class Initialized
INFO - 2020-07-04 17:37:44 --> Output Class Initialized
INFO - 2020-07-04 17:37:44 --> Security Class Initialized
DEBUG - 2020-07-04 17:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:37:44 --> Input Class Initialized
INFO - 2020-07-04 17:37:44 --> Language Class Initialized
INFO - 2020-07-04 17:37:44 --> Language Class Initialized
INFO - 2020-07-04 17:37:44 --> Config Class Initialized
INFO - 2020-07-04 17:37:44 --> Loader Class Initialized
INFO - 2020-07-04 17:37:44 --> Helper loaded: url_helper
INFO - 2020-07-04 17:37:44 --> Helper loaded: main_helper
INFO - 2020-07-04 17:37:44 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:37:44 --> Controller Class Initialized
DEBUG - 2020-07-04 17:37:44 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:37:44 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:37:44 --> Final output sent to browser
DEBUG - 2020-07-04 17:37:44 --> Total execution time: 0.0076
INFO - 2020-07-04 17:37:45 --> Config Class Initialized
INFO - 2020-07-04 17:37:45 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:37:45 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:37:45 --> Utf8 Class Initialized
INFO - 2020-07-04 17:37:45 --> URI Class Initialized
INFO - 2020-07-04 17:37:45 --> Router Class Initialized
INFO - 2020-07-04 17:37:45 --> Output Class Initialized
INFO - 2020-07-04 17:37:45 --> Security Class Initialized
DEBUG - 2020-07-04 17:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:37:45 --> Input Class Initialized
INFO - 2020-07-04 17:37:45 --> Language Class Initialized
INFO - 2020-07-04 17:37:45 --> Language Class Initialized
INFO - 2020-07-04 17:37:45 --> Config Class Initialized
INFO - 2020-07-04 17:37:45 --> Loader Class Initialized
INFO - 2020-07-04 17:37:45 --> Helper loaded: url_helper
INFO - 2020-07-04 17:37:45 --> Helper loaded: main_helper
INFO - 2020-07-04 17:37:45 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:37:45 --> Controller Class Initialized
INFO - 2020-07-04 17:37:45 --> Final output sent to browser
DEBUG - 2020-07-04 17:37:45 --> Total execution time: 0.0054
INFO - 2020-07-04 17:37:56 --> Config Class Initialized
INFO - 2020-07-04 17:37:56 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:37:56 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:37:56 --> Utf8 Class Initialized
INFO - 2020-07-04 17:37:56 --> URI Class Initialized
INFO - 2020-07-04 17:37:56 --> Router Class Initialized
INFO - 2020-07-04 17:37:56 --> Output Class Initialized
INFO - 2020-07-04 17:37:56 --> Security Class Initialized
DEBUG - 2020-07-04 17:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:37:56 --> Input Class Initialized
INFO - 2020-07-04 17:37:56 --> Language Class Initialized
INFO - 2020-07-04 17:37:56 --> Language Class Initialized
INFO - 2020-07-04 17:37:56 --> Config Class Initialized
INFO - 2020-07-04 17:37:56 --> Loader Class Initialized
INFO - 2020-07-04 17:37:56 --> Helper loaded: url_helper
INFO - 2020-07-04 17:37:56 --> Helper loaded: main_helper
INFO - 2020-07-04 17:37:56 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:37:56 --> Controller Class Initialized
DEBUG - 2020-07-04 17:37:56 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:37:56 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:37:56 --> Final output sent to browser
DEBUG - 2020-07-04 17:37:56 --> Total execution time: 0.0035
INFO - 2020-07-04 17:37:57 --> Config Class Initialized
INFO - 2020-07-04 17:37:57 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:37:57 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:37:57 --> Utf8 Class Initialized
INFO - 2020-07-04 17:37:57 --> URI Class Initialized
INFO - 2020-07-04 17:37:57 --> Router Class Initialized
INFO - 2020-07-04 17:37:57 --> Output Class Initialized
INFO - 2020-07-04 17:37:57 --> Security Class Initialized
DEBUG - 2020-07-04 17:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:37:57 --> Input Class Initialized
INFO - 2020-07-04 17:37:57 --> Language Class Initialized
INFO - 2020-07-04 17:37:57 --> Language Class Initialized
INFO - 2020-07-04 17:37:57 --> Config Class Initialized
INFO - 2020-07-04 17:37:57 --> Loader Class Initialized
INFO - 2020-07-04 17:37:57 --> Helper loaded: url_helper
INFO - 2020-07-04 17:37:57 --> Helper loaded: main_helper
INFO - 2020-07-04 17:37:57 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:37:57 --> Controller Class Initialized
INFO - 2020-07-04 17:37:57 --> Final output sent to browser
DEBUG - 2020-07-04 17:37:57 --> Total execution time: 0.0041
INFO - 2020-07-04 17:38:30 --> Config Class Initialized
INFO - 2020-07-04 17:38:30 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:38:30 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:38:30 --> Utf8 Class Initialized
INFO - 2020-07-04 17:38:30 --> URI Class Initialized
INFO - 2020-07-04 17:38:30 --> Router Class Initialized
INFO - 2020-07-04 17:38:30 --> Output Class Initialized
INFO - 2020-07-04 17:38:30 --> Security Class Initialized
DEBUG - 2020-07-04 17:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:38:30 --> Input Class Initialized
INFO - 2020-07-04 17:38:30 --> Language Class Initialized
INFO - 2020-07-04 17:38:30 --> Language Class Initialized
INFO - 2020-07-04 17:38:30 --> Config Class Initialized
INFO - 2020-07-04 17:38:30 --> Loader Class Initialized
INFO - 2020-07-04 17:38:30 --> Helper loaded: url_helper
INFO - 2020-07-04 17:38:30 --> Helper loaded: main_helper
INFO - 2020-07-04 17:38:30 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:38:30 --> Controller Class Initialized
DEBUG - 2020-07-04 17:38:30 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-04 17:38:30 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:38:30 --> Final output sent to browser
DEBUG - 2020-07-04 17:38:30 --> Total execution time: 0.0039
INFO - 2020-07-04 17:38:31 --> Config Class Initialized
INFO - 2020-07-04 17:38:31 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:38:31 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:38:31 --> Utf8 Class Initialized
INFO - 2020-07-04 17:38:31 --> URI Class Initialized
INFO - 2020-07-04 17:38:31 --> Router Class Initialized
INFO - 2020-07-04 17:38:31 --> Output Class Initialized
INFO - 2020-07-04 17:38:31 --> Security Class Initialized
DEBUG - 2020-07-04 17:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:38:31 --> Input Class Initialized
INFO - 2020-07-04 17:38:31 --> Language Class Initialized
INFO - 2020-07-04 17:38:31 --> Language Class Initialized
INFO - 2020-07-04 17:38:31 --> Config Class Initialized
INFO - 2020-07-04 17:38:31 --> Loader Class Initialized
INFO - 2020-07-04 17:38:31 --> Helper loaded: url_helper
INFO - 2020-07-04 17:38:31 --> Helper loaded: main_helper
INFO - 2020-07-04 17:38:31 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:38:31 --> Controller Class Initialized
INFO - 2020-07-04 17:38:31 --> Final output sent to browser
DEBUG - 2020-07-04 17:38:31 --> Total execution time: 0.0058
INFO - 2020-07-04 17:39:32 --> Config Class Initialized
INFO - 2020-07-04 17:39:32 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:39:32 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:39:32 --> Utf8 Class Initialized
INFO - 2020-07-04 17:39:32 --> URI Class Initialized
DEBUG - 2020-07-04 17:39:32 --> No URI present. Default controller set.
INFO - 2020-07-04 17:39:32 --> Router Class Initialized
INFO - 2020-07-04 17:39:32 --> Output Class Initialized
INFO - 2020-07-04 17:39:32 --> Security Class Initialized
DEBUG - 2020-07-04 17:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:39:32 --> Input Class Initialized
INFO - 2020-07-04 17:39:32 --> Language Class Initialized
INFO - 2020-07-04 17:39:32 --> Language Class Initialized
INFO - 2020-07-04 17:39:32 --> Config Class Initialized
INFO - 2020-07-04 17:39:32 --> Loader Class Initialized
INFO - 2020-07-04 17:39:32 --> Helper loaded: url_helper
INFO - 2020-07-04 17:39:32 --> Helper loaded: main_helper
INFO - 2020-07-04 17:39:32 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:39:32 --> Controller Class Initialized
DEBUG - 2020-07-04 17:39:32 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 17:39:32 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:39:32 --> Final output sent to browser
DEBUG - 2020-07-04 17:39:32 --> Total execution time: 0.0100
INFO - 2020-07-04 17:40:25 --> Config Class Initialized
INFO - 2020-07-04 17:40:25 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:40:25 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:40:25 --> Utf8 Class Initialized
INFO - 2020-07-04 17:40:25 --> URI Class Initialized
INFO - 2020-07-04 17:40:25 --> Router Class Initialized
INFO - 2020-07-04 17:40:25 --> Output Class Initialized
INFO - 2020-07-04 17:40:25 --> Security Class Initialized
DEBUG - 2020-07-04 17:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:40:25 --> Input Class Initialized
INFO - 2020-07-04 17:40:25 --> Language Class Initialized
INFO - 2020-07-04 17:40:25 --> Language Class Initialized
INFO - 2020-07-04 17:40:25 --> Config Class Initialized
INFO - 2020-07-04 17:40:25 --> Loader Class Initialized
INFO - 2020-07-04 17:40:25 --> Helper loaded: url_helper
INFO - 2020-07-04 17:40:25 --> Helper loaded: main_helper
INFO - 2020-07-04 17:40:25 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:40:25 --> Controller Class Initialized
INFO - 2020-07-04 17:40:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 17:40:25 --> Pagination Class Initialized
ERROR - 2020-07-04 17:40:25 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 17:40:25 --> Helper loaded: file_helper
DEBUG - 2020-07-04 17:40:25 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 17:40:26 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 17:40:26 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:40:26 --> Final output sent to browser
DEBUG - 2020-07-04 17:40:26 --> Total execution time: 1.2656
INFO - 2020-07-04 17:40:36 --> Config Class Initialized
INFO - 2020-07-04 17:40:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:40:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:40:36 --> Utf8 Class Initialized
INFO - 2020-07-04 17:40:36 --> URI Class Initialized
INFO - 2020-07-04 17:40:36 --> Router Class Initialized
INFO - 2020-07-04 17:40:36 --> Output Class Initialized
INFO - 2020-07-04 17:40:36 --> Security Class Initialized
DEBUG - 2020-07-04 17:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:40:36 --> Input Class Initialized
INFO - 2020-07-04 17:40:36 --> Language Class Initialized
INFO - 2020-07-04 17:40:36 --> Language Class Initialized
INFO - 2020-07-04 17:40:36 --> Config Class Initialized
INFO - 2020-07-04 17:40:36 --> Loader Class Initialized
INFO - 2020-07-04 17:40:36 --> Helper loaded: url_helper
INFO - 2020-07-04 17:40:36 --> Helper loaded: main_helper
INFO - 2020-07-04 17:40:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:40:36 --> Controller Class Initialized
INFO - 2020-07-04 17:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 17:40:36 --> Pagination Class Initialized
ERROR - 2020-07-04 17:40:36 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 17:40:36 --> Helper loaded: file_helper
DEBUG - 2020-07-04 17:40:36 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 17:40:37 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 17:40:37 --> Final output sent to browser
DEBUG - 2020-07-04 17:40:37 --> Total execution time: 1.1727
INFO - 2020-07-04 17:40:43 --> Config Class Initialized
INFO - 2020-07-04 17:40:43 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:40:43 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:40:43 --> Utf8 Class Initialized
INFO - 2020-07-04 17:40:43 --> URI Class Initialized
INFO - 2020-07-04 17:40:43 --> Router Class Initialized
INFO - 2020-07-04 17:40:43 --> Output Class Initialized
INFO - 2020-07-04 17:40:43 --> Security Class Initialized
DEBUG - 2020-07-04 17:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:40:43 --> Input Class Initialized
INFO - 2020-07-04 17:40:43 --> Language Class Initialized
INFO - 2020-07-04 17:40:43 --> Language Class Initialized
INFO - 2020-07-04 17:40:43 --> Config Class Initialized
INFO - 2020-07-04 17:40:43 --> Loader Class Initialized
INFO - 2020-07-04 17:40:43 --> Helper loaded: url_helper
INFO - 2020-07-04 17:40:43 --> Helper loaded: main_helper
INFO - 2020-07-04 17:40:43 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:40:43 --> Controller Class Initialized
INFO - 2020-07-04 17:40:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 17:40:43 --> Pagination Class Initialized
ERROR - 2020-07-04 17:40:43 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 17:40:43 --> Helper loaded: file_helper
DEBUG - 2020-07-04 17:40:43 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 17:40:44 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 17:40:44 --> Final output sent to browser
DEBUG - 2020-07-04 17:40:44 --> Total execution time: 1.3879
INFO - 2020-07-04 17:44:54 --> Config Class Initialized
INFO - 2020-07-04 17:44:54 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:44:54 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:44:54 --> Utf8 Class Initialized
INFO - 2020-07-04 17:44:54 --> URI Class Initialized
INFO - 2020-07-04 17:44:54 --> Router Class Initialized
INFO - 2020-07-04 17:44:54 --> Output Class Initialized
INFO - 2020-07-04 17:44:54 --> Security Class Initialized
DEBUG - 2020-07-04 17:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:44:54 --> Input Class Initialized
INFO - 2020-07-04 17:44:54 --> Language Class Initialized
INFO - 2020-07-04 17:44:54 --> Language Class Initialized
INFO - 2020-07-04 17:44:54 --> Config Class Initialized
INFO - 2020-07-04 17:44:54 --> Loader Class Initialized
INFO - 2020-07-04 17:44:54 --> Helper loaded: url_helper
INFO - 2020-07-04 17:44:54 --> Helper loaded: main_helper
INFO - 2020-07-04 17:44:54 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:44:54 --> Controller Class Initialized
INFO - 2020-07-04 17:44:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 17:44:54 --> Pagination Class Initialized
ERROR - 2020-07-04 17:44:54 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 17:44:54 --> Helper loaded: file_helper
DEBUG - 2020-07-04 17:44:54 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 17:44:54 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 17:44:54 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:44:54 --> Final output sent to browser
DEBUG - 2020-07-04 17:44:54 --> Total execution time: 0.0067
INFO - 2020-07-04 17:46:15 --> Config Class Initialized
INFO - 2020-07-04 17:46:15 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:46:15 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:46:15 --> Utf8 Class Initialized
INFO - 2020-07-04 17:46:15 --> URI Class Initialized
INFO - 2020-07-04 17:46:15 --> Router Class Initialized
INFO - 2020-07-04 17:46:15 --> Output Class Initialized
INFO - 2020-07-04 17:46:15 --> Security Class Initialized
DEBUG - 2020-07-04 17:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:46:15 --> Input Class Initialized
INFO - 2020-07-04 17:46:15 --> Language Class Initialized
INFO - 2020-07-04 17:46:15 --> Language Class Initialized
INFO - 2020-07-04 17:46:15 --> Config Class Initialized
INFO - 2020-07-04 17:46:15 --> Loader Class Initialized
INFO - 2020-07-04 17:46:15 --> Helper loaded: url_helper
INFO - 2020-07-04 17:46:15 --> Helper loaded: main_helper
INFO - 2020-07-04 17:46:15 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:46:15 --> Controller Class Initialized
INFO - 2020-07-04 17:46:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 17:46:15 --> Pagination Class Initialized
ERROR - 2020-07-04 17:46:15 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 17:46:15 --> Helper loaded: file_helper
DEBUG - 2020-07-04 17:46:15 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 17:46:16 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 17:46:16 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:46:16 --> Final output sent to browser
DEBUG - 2020-07-04 17:46:16 --> Total execution time: 1.3200
INFO - 2020-07-04 17:46:42 --> Config Class Initialized
INFO - 2020-07-04 17:46:42 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:46:42 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:46:42 --> Utf8 Class Initialized
INFO - 2020-07-04 17:46:42 --> URI Class Initialized
INFO - 2020-07-04 17:46:42 --> Router Class Initialized
INFO - 2020-07-04 17:46:42 --> Output Class Initialized
INFO - 2020-07-04 17:46:42 --> Security Class Initialized
DEBUG - 2020-07-04 17:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:46:42 --> Input Class Initialized
INFO - 2020-07-04 17:46:42 --> Language Class Initialized
INFO - 2020-07-04 17:46:42 --> Language Class Initialized
INFO - 2020-07-04 17:46:42 --> Config Class Initialized
INFO - 2020-07-04 17:46:42 --> Loader Class Initialized
INFO - 2020-07-04 17:46:42 --> Helper loaded: url_helper
INFO - 2020-07-04 17:46:42 --> Helper loaded: main_helper
INFO - 2020-07-04 17:46:42 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:46:42 --> Controller Class Initialized
INFO - 2020-07-04 17:46:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 17:46:42 --> Pagination Class Initialized
ERROR - 2020-07-04 17:46:42 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 17:46:42 --> Helper loaded: file_helper
DEBUG - 2020-07-04 17:46:42 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 17:46:42 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 17:46:42 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:46:42 --> Final output sent to browser
DEBUG - 2020-07-04 17:46:42 --> Total execution time: 0.0044
INFO - 2020-07-04 17:46:55 --> Config Class Initialized
INFO - 2020-07-04 17:46:55 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:46:55 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:46:55 --> Utf8 Class Initialized
INFO - 2020-07-04 17:46:55 --> URI Class Initialized
INFO - 2020-07-04 17:46:55 --> Router Class Initialized
INFO - 2020-07-04 17:46:55 --> Output Class Initialized
INFO - 2020-07-04 17:46:55 --> Security Class Initialized
DEBUG - 2020-07-04 17:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:46:55 --> Input Class Initialized
INFO - 2020-07-04 17:46:55 --> Language Class Initialized
INFO - 2020-07-04 17:46:55 --> Language Class Initialized
INFO - 2020-07-04 17:46:55 --> Config Class Initialized
INFO - 2020-07-04 17:46:55 --> Loader Class Initialized
INFO - 2020-07-04 17:46:55 --> Helper loaded: url_helper
INFO - 2020-07-04 17:46:55 --> Helper loaded: main_helper
INFO - 2020-07-04 17:46:55 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:46:55 --> Controller Class Initialized
INFO - 2020-07-04 17:46:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 17:46:55 --> Pagination Class Initialized
ERROR - 2020-07-04 17:46:55 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 17:46:55 --> Helper loaded: file_helper
DEBUG - 2020-07-04 17:46:55 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 17:46:55 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 17:46:55 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:46:55 --> Final output sent to browser
DEBUG - 2020-07-04 17:46:55 --> Total execution time: 0.0051
INFO - 2020-07-04 17:48:17 --> Config Class Initialized
INFO - 2020-07-04 17:48:17 --> Hooks Class Initialized
DEBUG - 2020-07-04 17:48:17 --> UTF-8 Support Enabled
INFO - 2020-07-04 17:48:17 --> Utf8 Class Initialized
INFO - 2020-07-04 17:48:17 --> URI Class Initialized
INFO - 2020-07-04 17:48:17 --> Router Class Initialized
INFO - 2020-07-04 17:48:17 --> Output Class Initialized
INFO - 2020-07-04 17:48:17 --> Security Class Initialized
DEBUG - 2020-07-04 17:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 17:48:17 --> Input Class Initialized
INFO - 2020-07-04 17:48:17 --> Language Class Initialized
INFO - 2020-07-04 17:48:17 --> Language Class Initialized
INFO - 2020-07-04 17:48:17 --> Config Class Initialized
INFO - 2020-07-04 17:48:17 --> Loader Class Initialized
INFO - 2020-07-04 17:48:17 --> Helper loaded: url_helper
INFO - 2020-07-04 17:48:17 --> Helper loaded: main_helper
INFO - 2020-07-04 17:48:17 --> Database Driver Class Initialized
DEBUG - 2020-07-04 17:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 17:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 17:48:17 --> Controller Class Initialized
INFO - 2020-07-04 17:48:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 17:48:17 --> Pagination Class Initialized
ERROR - 2020-07-04 17:48:17 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 17:48:17 --> Helper loaded: file_helper
DEBUG - 2020-07-04 17:48:17 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 17:48:17 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 17:48:17 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 17:48:17 --> Final output sent to browser
DEBUG - 2020-07-04 17:48:17 --> Total execution time: 0.0055
INFO - 2020-07-04 19:59:23 --> Config Class Initialized
INFO - 2020-07-04 19:59:23 --> Hooks Class Initialized
DEBUG - 2020-07-04 19:59:23 --> UTF-8 Support Enabled
INFO - 2020-07-04 19:59:23 --> Utf8 Class Initialized
INFO - 2020-07-04 19:59:23 --> URI Class Initialized
INFO - 2020-07-04 19:59:23 --> Router Class Initialized
INFO - 2020-07-04 19:59:23 --> Output Class Initialized
INFO - 2020-07-04 19:59:23 --> Security Class Initialized
DEBUG - 2020-07-04 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 19:59:23 --> Input Class Initialized
INFO - 2020-07-04 19:59:23 --> Language Class Initialized
INFO - 2020-07-04 19:59:23 --> Language Class Initialized
INFO - 2020-07-04 19:59:23 --> Config Class Initialized
INFO - 2020-07-04 19:59:23 --> Loader Class Initialized
INFO - 2020-07-04 19:59:23 --> Helper loaded: url_helper
INFO - 2020-07-04 19:59:23 --> Helper loaded: main_helper
INFO - 2020-07-04 19:59:23 --> Database Driver Class Initialized
DEBUG - 2020-07-04 19:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 19:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 19:59:23 --> Controller Class Initialized
INFO - 2020-07-04 19:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 19:59:23 --> Pagination Class Initialized
ERROR - 2020-07-04 19:59:23 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 19:59:23 --> Helper loaded: file_helper
DEBUG - 2020-07-04 19:59:23 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 19:59:24 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 19:59:24 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 19:59:24 --> Final output sent to browser
DEBUG - 2020-07-04 19:59:24 --> Total execution time: 1.3566
INFO - 2020-07-04 19:59:47 --> Config Class Initialized
INFO - 2020-07-04 19:59:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 19:59:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 19:59:47 --> Utf8 Class Initialized
INFO - 2020-07-04 19:59:47 --> URI Class Initialized
INFO - 2020-07-04 19:59:47 --> Router Class Initialized
INFO - 2020-07-04 19:59:47 --> Output Class Initialized
INFO - 2020-07-04 19:59:47 --> Security Class Initialized
DEBUG - 2020-07-04 19:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 19:59:47 --> Input Class Initialized
INFO - 2020-07-04 19:59:47 --> Language Class Initialized
INFO - 2020-07-04 19:59:47 --> Language Class Initialized
INFO - 2020-07-04 19:59:47 --> Config Class Initialized
INFO - 2020-07-04 19:59:47 --> Loader Class Initialized
INFO - 2020-07-04 19:59:47 --> Helper loaded: url_helper
INFO - 2020-07-04 19:59:47 --> Helper loaded: main_helper
INFO - 2020-07-04 19:59:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 19:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 19:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 19:59:47 --> Controller Class Initialized
INFO - 2020-07-04 19:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 19:59:47 --> Pagination Class Initialized
ERROR - 2020-07-04 19:59:47 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 19:59:47 --> Helper loaded: file_helper
DEBUG - 2020-07-04 19:59:47 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 19:59:48 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 19:59:48 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 19:59:48 --> Final output sent to browser
DEBUG - 2020-07-04 19:59:48 --> Total execution time: 0.0067
INFO - 2020-07-04 20:01:26 --> Config Class Initialized
INFO - 2020-07-04 20:01:26 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:01:26 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:01:26 --> Utf8 Class Initialized
INFO - 2020-07-04 20:01:26 --> URI Class Initialized
INFO - 2020-07-04 20:01:26 --> Router Class Initialized
INFO - 2020-07-04 20:01:26 --> Output Class Initialized
INFO - 2020-07-04 20:01:26 --> Security Class Initialized
DEBUG - 2020-07-04 20:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:01:26 --> Input Class Initialized
INFO - 2020-07-04 20:01:26 --> Language Class Initialized
INFO - 2020-07-04 20:01:26 --> Language Class Initialized
INFO - 2020-07-04 20:01:26 --> Config Class Initialized
INFO - 2020-07-04 20:01:26 --> Loader Class Initialized
INFO - 2020-07-04 20:01:26 --> Helper loaded: url_helper
INFO - 2020-07-04 20:01:26 --> Helper loaded: main_helper
INFO - 2020-07-04 20:01:26 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:01:26 --> Controller Class Initialized
INFO - 2020-07-04 20:01:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:01:26 --> Pagination Class Initialized
ERROR - 2020-07-04 20:01:26 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:01:26 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:01:26 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:01:26 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:01:26 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:01:26 --> Final output sent to browser
DEBUG - 2020-07-04 20:01:26 --> Total execution time: 0.0063
INFO - 2020-07-04 20:02:09 --> Config Class Initialized
INFO - 2020-07-04 20:02:09 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:02:09 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:02:09 --> Utf8 Class Initialized
INFO - 2020-07-04 20:02:09 --> URI Class Initialized
INFO - 2020-07-04 20:02:09 --> Router Class Initialized
INFO - 2020-07-04 20:02:09 --> Output Class Initialized
INFO - 2020-07-04 20:02:09 --> Security Class Initialized
DEBUG - 2020-07-04 20:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:02:09 --> Input Class Initialized
INFO - 2020-07-04 20:02:09 --> Language Class Initialized
INFO - 2020-07-04 20:02:09 --> Language Class Initialized
INFO - 2020-07-04 20:02:09 --> Config Class Initialized
INFO - 2020-07-04 20:02:09 --> Loader Class Initialized
INFO - 2020-07-04 20:02:09 --> Helper loaded: url_helper
INFO - 2020-07-04 20:02:09 --> Helper loaded: main_helper
INFO - 2020-07-04 20:02:09 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:02:09 --> Controller Class Initialized
INFO - 2020-07-04 20:02:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:02:09 --> Pagination Class Initialized
ERROR - 2020-07-04 20:02:09 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:02:09 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:02:09 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:02:09 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:02:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:02:09 --> Final output sent to browser
DEBUG - 2020-07-04 20:02:09 --> Total execution time: 0.0065
INFO - 2020-07-04 20:02:46 --> Config Class Initialized
INFO - 2020-07-04 20:02:46 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:02:46 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:02:46 --> Utf8 Class Initialized
INFO - 2020-07-04 20:02:46 --> URI Class Initialized
INFO - 2020-07-04 20:02:46 --> Router Class Initialized
INFO - 2020-07-04 20:02:46 --> Output Class Initialized
INFO - 2020-07-04 20:02:46 --> Security Class Initialized
DEBUG - 2020-07-04 20:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:02:46 --> Input Class Initialized
INFO - 2020-07-04 20:02:46 --> Language Class Initialized
INFO - 2020-07-04 20:02:46 --> Language Class Initialized
INFO - 2020-07-04 20:02:46 --> Config Class Initialized
INFO - 2020-07-04 20:02:46 --> Loader Class Initialized
INFO - 2020-07-04 20:02:46 --> Helper loaded: url_helper
INFO - 2020-07-04 20:02:46 --> Helper loaded: main_helper
INFO - 2020-07-04 20:02:46 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:02:46 --> Controller Class Initialized
INFO - 2020-07-04 20:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:02:46 --> Pagination Class Initialized
ERROR - 2020-07-04 20:02:46 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:02:46 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:02:46 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:02:46 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:02:46 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:02:46 --> Final output sent to browser
DEBUG - 2020-07-04 20:02:46 --> Total execution time: 0.0057
INFO - 2020-07-04 20:02:59 --> Config Class Initialized
INFO - 2020-07-04 20:02:59 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:02:59 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:02:59 --> Utf8 Class Initialized
INFO - 2020-07-04 20:02:59 --> URI Class Initialized
INFO - 2020-07-04 20:02:59 --> Router Class Initialized
INFO - 2020-07-04 20:02:59 --> Output Class Initialized
INFO - 2020-07-04 20:02:59 --> Security Class Initialized
DEBUG - 2020-07-04 20:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:02:59 --> Input Class Initialized
INFO - 2020-07-04 20:02:59 --> Language Class Initialized
INFO - 2020-07-04 20:02:59 --> Language Class Initialized
INFO - 2020-07-04 20:02:59 --> Config Class Initialized
INFO - 2020-07-04 20:02:59 --> Loader Class Initialized
INFO - 2020-07-04 20:02:59 --> Helper loaded: url_helper
INFO - 2020-07-04 20:02:59 --> Helper loaded: main_helper
INFO - 2020-07-04 20:02:59 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:02:59 --> Controller Class Initialized
INFO - 2020-07-04 20:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:02:59 --> Pagination Class Initialized
ERROR - 2020-07-04 20:02:59 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:02:59 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:02:59 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:02:59 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:02:59 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:02:59 --> Final output sent to browser
DEBUG - 2020-07-04 20:02:59 --> Total execution time: 0.0051
INFO - 2020-07-04 20:04:01 --> Config Class Initialized
INFO - 2020-07-04 20:04:01 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:04:01 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:04:01 --> Utf8 Class Initialized
INFO - 2020-07-04 20:04:01 --> URI Class Initialized
INFO - 2020-07-04 20:04:01 --> Router Class Initialized
INFO - 2020-07-04 20:04:01 --> Output Class Initialized
INFO - 2020-07-04 20:04:01 --> Security Class Initialized
DEBUG - 2020-07-04 20:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:04:01 --> Input Class Initialized
INFO - 2020-07-04 20:04:01 --> Language Class Initialized
INFO - 2020-07-04 20:04:01 --> Language Class Initialized
INFO - 2020-07-04 20:04:01 --> Config Class Initialized
INFO - 2020-07-04 20:04:01 --> Loader Class Initialized
INFO - 2020-07-04 20:04:01 --> Helper loaded: url_helper
INFO - 2020-07-04 20:04:01 --> Helper loaded: main_helper
INFO - 2020-07-04 20:04:01 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:04:01 --> Controller Class Initialized
INFO - 2020-07-04 20:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:04:01 --> Pagination Class Initialized
ERROR - 2020-07-04 20:04:01 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:04:01 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:04:01 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:04:01 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:04:01 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:04:01 --> Final output sent to browser
DEBUG - 2020-07-04 20:04:01 --> Total execution time: 0.0068
INFO - 2020-07-04 20:05:40 --> Config Class Initialized
INFO - 2020-07-04 20:05:40 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:05:40 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:05:40 --> Utf8 Class Initialized
INFO - 2020-07-04 20:05:40 --> URI Class Initialized
INFO - 2020-07-04 20:05:40 --> Router Class Initialized
INFO - 2020-07-04 20:05:40 --> Output Class Initialized
INFO - 2020-07-04 20:05:40 --> Security Class Initialized
DEBUG - 2020-07-04 20:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:05:40 --> Input Class Initialized
INFO - 2020-07-04 20:05:40 --> Language Class Initialized
INFO - 2020-07-04 20:05:40 --> Language Class Initialized
INFO - 2020-07-04 20:05:40 --> Config Class Initialized
INFO - 2020-07-04 20:05:40 --> Loader Class Initialized
INFO - 2020-07-04 20:05:40 --> Helper loaded: url_helper
INFO - 2020-07-04 20:05:40 --> Helper loaded: main_helper
INFO - 2020-07-04 20:05:40 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:05:40 --> Controller Class Initialized
INFO - 2020-07-04 20:05:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:05:40 --> Pagination Class Initialized
ERROR - 2020-07-04 20:05:40 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:05:40 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:05:40 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:05:41 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:05:41 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:05:41 --> Final output sent to browser
DEBUG - 2020-07-04 20:05:41 --> Total execution time: 1.3906
INFO - 2020-07-04 20:07:29 --> Config Class Initialized
INFO - 2020-07-04 20:07:29 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:07:29 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:07:29 --> Utf8 Class Initialized
INFO - 2020-07-04 20:07:29 --> URI Class Initialized
INFO - 2020-07-04 20:07:29 --> Router Class Initialized
INFO - 2020-07-04 20:07:29 --> Output Class Initialized
INFO - 2020-07-04 20:07:29 --> Security Class Initialized
DEBUG - 2020-07-04 20:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:07:29 --> Input Class Initialized
INFO - 2020-07-04 20:07:29 --> Language Class Initialized
INFO - 2020-07-04 20:07:29 --> Language Class Initialized
INFO - 2020-07-04 20:07:29 --> Config Class Initialized
INFO - 2020-07-04 20:07:29 --> Loader Class Initialized
INFO - 2020-07-04 20:07:29 --> Helper loaded: url_helper
INFO - 2020-07-04 20:07:29 --> Helper loaded: main_helper
INFO - 2020-07-04 20:07:29 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:07:29 --> Controller Class Initialized
INFO - 2020-07-04 20:07:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:07:29 --> Pagination Class Initialized
ERROR - 2020-07-04 20:07:29 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:07:29 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:07:29 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:07:29 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:07:29 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:07:29 --> Final output sent to browser
DEBUG - 2020-07-04 20:07:29 --> Total execution time: 0.0056
INFO - 2020-07-04 20:07:51 --> Config Class Initialized
INFO - 2020-07-04 20:07:51 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:07:51 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:07:51 --> Utf8 Class Initialized
INFO - 2020-07-04 20:07:51 --> URI Class Initialized
INFO - 2020-07-04 20:07:51 --> Router Class Initialized
INFO - 2020-07-04 20:07:51 --> Output Class Initialized
INFO - 2020-07-04 20:07:51 --> Security Class Initialized
DEBUG - 2020-07-04 20:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:07:51 --> Input Class Initialized
INFO - 2020-07-04 20:07:51 --> Language Class Initialized
INFO - 2020-07-04 20:07:51 --> Language Class Initialized
INFO - 2020-07-04 20:07:51 --> Config Class Initialized
INFO - 2020-07-04 20:07:51 --> Loader Class Initialized
INFO - 2020-07-04 20:07:51 --> Helper loaded: url_helper
INFO - 2020-07-04 20:07:51 --> Helper loaded: main_helper
INFO - 2020-07-04 20:07:51 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:07:51 --> Controller Class Initialized
INFO - 2020-07-04 20:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:07:51 --> Pagination Class Initialized
ERROR - 2020-07-04 20:07:51 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:07:51 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:07:51 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:07:51 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:07:51 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:07:51 --> Final output sent to browser
DEBUG - 2020-07-04 20:07:51 --> Total execution time: 0.0072
INFO - 2020-07-04 20:09:02 --> Config Class Initialized
INFO - 2020-07-04 20:09:02 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:09:02 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:09:02 --> Utf8 Class Initialized
INFO - 2020-07-04 20:09:02 --> URI Class Initialized
INFO - 2020-07-04 20:09:02 --> Router Class Initialized
INFO - 2020-07-04 20:09:02 --> Output Class Initialized
INFO - 2020-07-04 20:09:02 --> Security Class Initialized
DEBUG - 2020-07-04 20:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:09:02 --> Input Class Initialized
INFO - 2020-07-04 20:09:02 --> Language Class Initialized
INFO - 2020-07-04 20:09:02 --> Language Class Initialized
INFO - 2020-07-04 20:09:02 --> Config Class Initialized
INFO - 2020-07-04 20:09:02 --> Loader Class Initialized
INFO - 2020-07-04 20:09:02 --> Helper loaded: url_helper
INFO - 2020-07-04 20:09:02 --> Helper loaded: main_helper
INFO - 2020-07-04 20:09:02 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:09:02 --> Controller Class Initialized
INFO - 2020-07-04 20:09:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:09:02 --> Pagination Class Initialized
ERROR - 2020-07-04 20:09:02 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:09:02 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:09:02 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:09:02 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:09:02 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:09:02 --> Final output sent to browser
DEBUG - 2020-07-04 20:09:02 --> Total execution time: 0.0056
INFO - 2020-07-04 20:09:41 --> Config Class Initialized
INFO - 2020-07-04 20:09:41 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:09:41 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:09:41 --> Utf8 Class Initialized
INFO - 2020-07-04 20:09:41 --> URI Class Initialized
INFO - 2020-07-04 20:09:41 --> Router Class Initialized
INFO - 2020-07-04 20:09:41 --> Output Class Initialized
INFO - 2020-07-04 20:09:41 --> Security Class Initialized
DEBUG - 2020-07-04 20:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:09:41 --> Input Class Initialized
INFO - 2020-07-04 20:09:41 --> Language Class Initialized
INFO - 2020-07-04 20:09:41 --> Language Class Initialized
INFO - 2020-07-04 20:09:41 --> Config Class Initialized
INFO - 2020-07-04 20:09:41 --> Loader Class Initialized
INFO - 2020-07-04 20:09:41 --> Helper loaded: url_helper
INFO - 2020-07-04 20:09:41 --> Helper loaded: main_helper
INFO - 2020-07-04 20:09:41 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:09:41 --> Controller Class Initialized
INFO - 2020-07-04 20:09:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:09:41 --> Pagination Class Initialized
ERROR - 2020-07-04 20:09:41 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:09:41 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:09:41 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:09:41 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:09:41 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:09:41 --> Final output sent to browser
DEBUG - 2020-07-04 20:09:41 --> Total execution time: 0.0044
INFO - 2020-07-04 20:10:14 --> Config Class Initialized
INFO - 2020-07-04 20:10:14 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:10:14 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:10:14 --> Utf8 Class Initialized
INFO - 2020-07-04 20:10:14 --> URI Class Initialized
INFO - 2020-07-04 20:10:14 --> Router Class Initialized
INFO - 2020-07-04 20:10:14 --> Output Class Initialized
INFO - 2020-07-04 20:10:14 --> Security Class Initialized
DEBUG - 2020-07-04 20:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:10:14 --> Input Class Initialized
INFO - 2020-07-04 20:10:14 --> Language Class Initialized
INFO - 2020-07-04 20:10:14 --> Language Class Initialized
INFO - 2020-07-04 20:10:14 --> Config Class Initialized
INFO - 2020-07-04 20:10:14 --> Loader Class Initialized
INFO - 2020-07-04 20:10:14 --> Helper loaded: url_helper
INFO - 2020-07-04 20:10:14 --> Helper loaded: main_helper
INFO - 2020-07-04 20:10:14 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:10:14 --> Controller Class Initialized
INFO - 2020-07-04 20:10:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:10:14 --> Pagination Class Initialized
ERROR - 2020-07-04 20:10:14 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:10:14 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:10:14 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:10:16 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 20:10:16 --> Final output sent to browser
DEBUG - 2020-07-04 20:10:16 --> Total execution time: 1.2471
INFO - 2020-07-04 20:18:42 --> Config Class Initialized
INFO - 2020-07-04 20:18:42 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:18:42 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:18:42 --> Utf8 Class Initialized
INFO - 2020-07-04 20:18:42 --> URI Class Initialized
INFO - 2020-07-04 20:18:42 --> Router Class Initialized
INFO - 2020-07-04 20:18:42 --> Output Class Initialized
INFO - 2020-07-04 20:18:42 --> Security Class Initialized
DEBUG - 2020-07-04 20:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:18:42 --> Input Class Initialized
INFO - 2020-07-04 20:18:42 --> Language Class Initialized
INFO - 2020-07-04 20:18:42 --> Language Class Initialized
INFO - 2020-07-04 20:18:42 --> Config Class Initialized
INFO - 2020-07-04 20:18:42 --> Loader Class Initialized
INFO - 2020-07-04 20:18:42 --> Helper loaded: url_helper
INFO - 2020-07-04 20:18:42 --> Helper loaded: main_helper
INFO - 2020-07-04 20:18:42 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:18:42 --> Controller Class Initialized
INFO - 2020-07-04 20:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:18:42 --> Pagination Class Initialized
ERROR - 2020-07-04 20:18:42 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:18:42 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:18:42 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:18:44 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:18:44 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:18:44 --> Final output sent to browser
DEBUG - 2020-07-04 20:18:44 --> Total execution time: 1.3744
INFO - 2020-07-04 20:21:05 --> Config Class Initialized
INFO - 2020-07-04 20:21:05 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:21:05 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:21:05 --> Utf8 Class Initialized
INFO - 2020-07-04 20:21:05 --> URI Class Initialized
INFO - 2020-07-04 20:21:05 --> Router Class Initialized
INFO - 2020-07-04 20:21:05 --> Output Class Initialized
INFO - 2020-07-04 20:21:05 --> Security Class Initialized
DEBUG - 2020-07-04 20:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:21:05 --> Input Class Initialized
INFO - 2020-07-04 20:21:05 --> Language Class Initialized
ERROR - 2020-07-04 20:21:05 --> 404 Page Not Found: /index
INFO - 2020-07-04 20:21:11 --> Config Class Initialized
INFO - 2020-07-04 20:21:11 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:21:11 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:21:11 --> Utf8 Class Initialized
INFO - 2020-07-04 20:21:11 --> URI Class Initialized
INFO - 2020-07-04 20:21:11 --> Router Class Initialized
INFO - 2020-07-04 20:21:11 --> Output Class Initialized
INFO - 2020-07-04 20:21:11 --> Security Class Initialized
DEBUG - 2020-07-04 20:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:21:11 --> Input Class Initialized
INFO - 2020-07-04 20:21:11 --> Language Class Initialized
INFO - 2020-07-04 20:21:11 --> Language Class Initialized
INFO - 2020-07-04 20:21:11 --> Config Class Initialized
INFO - 2020-07-04 20:21:11 --> Loader Class Initialized
INFO - 2020-07-04 20:21:11 --> Helper loaded: url_helper
INFO - 2020-07-04 20:21:11 --> Helper loaded: main_helper
INFO - 2020-07-04 20:21:11 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:21:11 --> Controller Class Initialized
INFO - 2020-07-04 20:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:21:11 --> Pagination Class Initialized
ERROR - 2020-07-04 20:21:11 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:21:11 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:21:11 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:21:11 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:21:11 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:21:11 --> Final output sent to browser
DEBUG - 2020-07-04 20:21:11 --> Total execution time: 0.0039
INFO - 2020-07-04 20:22:05 --> Config Class Initialized
INFO - 2020-07-04 20:22:05 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:22:05 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:22:05 --> Utf8 Class Initialized
INFO - 2020-07-04 20:22:05 --> URI Class Initialized
INFO - 2020-07-04 20:22:05 --> Router Class Initialized
INFO - 2020-07-04 20:22:05 --> Output Class Initialized
INFO - 2020-07-04 20:22:05 --> Security Class Initialized
DEBUG - 2020-07-04 20:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:22:05 --> Input Class Initialized
INFO - 2020-07-04 20:22:05 --> Language Class Initialized
INFO - 2020-07-04 20:22:05 --> Language Class Initialized
INFO - 2020-07-04 20:22:05 --> Config Class Initialized
INFO - 2020-07-04 20:22:05 --> Loader Class Initialized
INFO - 2020-07-04 20:22:05 --> Helper loaded: url_helper
INFO - 2020-07-04 20:22:05 --> Helper loaded: main_helper
INFO - 2020-07-04 20:22:05 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:22:05 --> Controller Class Initialized
INFO - 2020-07-04 20:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:22:05 --> Pagination Class Initialized
ERROR - 2020-07-04 20:22:05 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:22:05 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:22:05 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:22:07 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 20:22:07 --> Final output sent to browser
DEBUG - 2020-07-04 20:22:07 --> Total execution time: 1.1418
INFO - 2020-07-04 20:24:51 --> Config Class Initialized
INFO - 2020-07-04 20:24:51 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:24:51 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:24:51 --> Utf8 Class Initialized
INFO - 2020-07-04 20:24:51 --> URI Class Initialized
INFO - 2020-07-04 20:24:51 --> Router Class Initialized
INFO - 2020-07-04 20:24:51 --> Output Class Initialized
INFO - 2020-07-04 20:24:51 --> Security Class Initialized
DEBUG - 2020-07-04 20:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:24:51 --> Input Class Initialized
INFO - 2020-07-04 20:24:51 --> Language Class Initialized
INFO - 2020-07-04 20:24:51 --> Language Class Initialized
INFO - 2020-07-04 20:24:51 --> Config Class Initialized
INFO - 2020-07-04 20:24:51 --> Loader Class Initialized
INFO - 2020-07-04 20:24:51 --> Helper loaded: url_helper
INFO - 2020-07-04 20:24:51 --> Helper loaded: main_helper
INFO - 2020-07-04 20:24:51 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:24:51 --> Controller Class Initialized
INFO - 2020-07-04 20:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:24:51 --> Pagination Class Initialized
ERROR - 2020-07-04 20:24:51 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:24:51 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:24:51 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:24:52 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:24:52 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:24:52 --> Final output sent to browser
DEBUG - 2020-07-04 20:24:52 --> Total execution time: 1.2169
INFO - 2020-07-04 20:26:32 --> Config Class Initialized
INFO - 2020-07-04 20:26:32 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:26:32 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:26:32 --> Utf8 Class Initialized
INFO - 2020-07-04 20:26:32 --> URI Class Initialized
INFO - 2020-07-04 20:26:32 --> Router Class Initialized
INFO - 2020-07-04 20:26:32 --> Output Class Initialized
INFO - 2020-07-04 20:26:32 --> Security Class Initialized
DEBUG - 2020-07-04 20:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:26:32 --> Input Class Initialized
INFO - 2020-07-04 20:26:32 --> Language Class Initialized
INFO - 2020-07-04 20:26:32 --> Language Class Initialized
INFO - 2020-07-04 20:26:32 --> Config Class Initialized
INFO - 2020-07-04 20:26:32 --> Loader Class Initialized
INFO - 2020-07-04 20:26:32 --> Helper loaded: url_helper
INFO - 2020-07-04 20:26:32 --> Helper loaded: main_helper
INFO - 2020-07-04 20:26:32 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:26:32 --> Controller Class Initialized
INFO - 2020-07-04 20:26:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:26:32 --> Pagination Class Initialized
ERROR - 2020-07-04 20:26:32 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:26:32 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:26:32 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:26:32 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:26:32 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:26:32 --> Final output sent to browser
DEBUG - 2020-07-04 20:26:32 --> Total execution time: 0.0061
INFO - 2020-07-04 20:27:53 --> Config Class Initialized
INFO - 2020-07-04 20:27:53 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:27:53 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:27:53 --> Utf8 Class Initialized
INFO - 2020-07-04 20:27:53 --> URI Class Initialized
INFO - 2020-07-04 20:27:53 --> Router Class Initialized
INFO - 2020-07-04 20:27:53 --> Output Class Initialized
INFO - 2020-07-04 20:27:53 --> Security Class Initialized
DEBUG - 2020-07-04 20:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:27:53 --> Input Class Initialized
INFO - 2020-07-04 20:27:53 --> Language Class Initialized
INFO - 2020-07-04 20:27:53 --> Language Class Initialized
INFO - 2020-07-04 20:27:53 --> Config Class Initialized
INFO - 2020-07-04 20:27:53 --> Loader Class Initialized
INFO - 2020-07-04 20:27:53 --> Helper loaded: url_helper
INFO - 2020-07-04 20:27:53 --> Helper loaded: main_helper
INFO - 2020-07-04 20:27:53 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:27:53 --> Controller Class Initialized
INFO - 2020-07-04 20:27:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:27:53 --> Pagination Class Initialized
ERROR - 2020-07-04 20:27:53 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:27:53 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:27:53 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:27:53 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:27:53 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:27:53 --> Final output sent to browser
DEBUG - 2020-07-04 20:27:53 --> Total execution time: 0.0059
INFO - 2020-07-04 20:30:55 --> Config Class Initialized
INFO - 2020-07-04 20:30:55 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:30:55 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:30:55 --> Utf8 Class Initialized
INFO - 2020-07-04 20:30:55 --> URI Class Initialized
INFO - 2020-07-04 20:30:55 --> Router Class Initialized
INFO - 2020-07-04 20:30:55 --> Output Class Initialized
INFO - 2020-07-04 20:30:55 --> Security Class Initialized
DEBUG - 2020-07-04 20:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:30:55 --> Input Class Initialized
INFO - 2020-07-04 20:30:55 --> Language Class Initialized
INFO - 2020-07-04 20:30:55 --> Language Class Initialized
INFO - 2020-07-04 20:30:55 --> Config Class Initialized
INFO - 2020-07-04 20:30:55 --> Loader Class Initialized
INFO - 2020-07-04 20:30:55 --> Helper loaded: url_helper
INFO - 2020-07-04 20:30:55 --> Helper loaded: main_helper
INFO - 2020-07-04 20:30:55 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:30:55 --> Controller Class Initialized
INFO - 2020-07-04 20:30:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:30:55 --> Pagination Class Initialized
ERROR - 2020-07-04 20:30:55 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:30:55 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:30:55 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:30:57 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:30:57 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:30:57 --> Final output sent to browser
DEBUG - 2020-07-04 20:30:57 --> Total execution time: 1.4790
INFO - 2020-07-04 20:35:10 --> Config Class Initialized
INFO - 2020-07-04 20:35:10 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:35:10 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:35:10 --> Utf8 Class Initialized
INFO - 2020-07-04 20:35:10 --> URI Class Initialized
INFO - 2020-07-04 20:35:10 --> Router Class Initialized
INFO - 2020-07-04 20:35:10 --> Output Class Initialized
INFO - 2020-07-04 20:35:10 --> Security Class Initialized
DEBUG - 2020-07-04 20:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:35:10 --> Input Class Initialized
INFO - 2020-07-04 20:35:10 --> Language Class Initialized
INFO - 2020-07-04 20:35:10 --> Language Class Initialized
INFO - 2020-07-04 20:35:10 --> Config Class Initialized
INFO - 2020-07-04 20:35:10 --> Loader Class Initialized
INFO - 2020-07-04 20:35:10 --> Helper loaded: url_helper
INFO - 2020-07-04 20:35:10 --> Helper loaded: main_helper
INFO - 2020-07-04 20:35:10 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:35:10 --> Controller Class Initialized
INFO - 2020-07-04 20:35:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:35:10 --> Pagination Class Initialized
ERROR - 2020-07-04 20:35:10 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:35:10 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:35:10 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:35:10 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:35:10 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:35:10 --> Final output sent to browser
DEBUG - 2020-07-04 20:35:10 --> Total execution time: 0.0083
INFO - 2020-07-04 20:44:35 --> Config Class Initialized
INFO - 2020-07-04 20:44:35 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:44:35 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:44:35 --> Utf8 Class Initialized
INFO - 2020-07-04 20:44:35 --> URI Class Initialized
DEBUG - 2020-07-04 20:44:35 --> No URI present. Default controller set.
INFO - 2020-07-04 20:44:35 --> Router Class Initialized
INFO - 2020-07-04 20:44:35 --> Output Class Initialized
INFO - 2020-07-04 20:44:35 --> Security Class Initialized
DEBUG - 2020-07-04 20:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:44:35 --> Input Class Initialized
INFO - 2020-07-04 20:44:35 --> Language Class Initialized
INFO - 2020-07-04 20:44:35 --> Language Class Initialized
INFO - 2020-07-04 20:44:35 --> Config Class Initialized
INFO - 2020-07-04 20:44:35 --> Loader Class Initialized
INFO - 2020-07-04 20:44:35 --> Helper loaded: url_helper
INFO - 2020-07-04 20:44:35 --> Helper loaded: main_helper
INFO - 2020-07-04 20:44:35 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:44:35 --> Controller Class Initialized
DEBUG - 2020-07-04 20:44:35 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 20:44:35 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:44:35 --> Final output sent to browser
DEBUG - 2020-07-04 20:44:35 --> Total execution time: 0.0089
INFO - 2020-07-04 20:45:02 --> Config Class Initialized
INFO - 2020-07-04 20:45:02 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:45:02 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:45:02 --> Utf8 Class Initialized
INFO - 2020-07-04 20:45:02 --> URI Class Initialized
INFO - 2020-07-04 20:45:02 --> Router Class Initialized
INFO - 2020-07-04 20:45:02 --> Output Class Initialized
INFO - 2020-07-04 20:45:02 --> Security Class Initialized
DEBUG - 2020-07-04 20:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:45:02 --> Input Class Initialized
INFO - 2020-07-04 20:45:02 --> Language Class Initialized
INFO - 2020-07-04 20:45:02 --> Language Class Initialized
INFO - 2020-07-04 20:45:02 --> Config Class Initialized
INFO - 2020-07-04 20:45:02 --> Loader Class Initialized
INFO - 2020-07-04 20:45:02 --> Helper loaded: url_helper
INFO - 2020-07-04 20:45:02 --> Helper loaded: main_helper
INFO - 2020-07-04 20:45:02 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:45:02 --> Controller Class Initialized
INFO - 2020-07-04 20:45:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:45:02 --> Pagination Class Initialized
ERROR - 2020-07-04 20:45:02 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:45:02 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:45:02 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:45:03 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:45:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:45:03 --> Final output sent to browser
DEBUG - 2020-07-04 20:45:03 --> Total execution time: 1.6924
INFO - 2020-07-04 20:55:00 --> Config Class Initialized
INFO - 2020-07-04 20:55:00 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:55:00 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:55:00 --> Utf8 Class Initialized
INFO - 2020-07-04 20:55:00 --> URI Class Initialized
INFO - 2020-07-04 20:55:00 --> Router Class Initialized
INFO - 2020-07-04 20:55:00 --> Output Class Initialized
INFO - 2020-07-04 20:55:00 --> Security Class Initialized
DEBUG - 2020-07-04 20:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:55:00 --> Input Class Initialized
INFO - 2020-07-04 20:55:00 --> Language Class Initialized
INFO - 2020-07-04 20:55:00 --> Language Class Initialized
INFO - 2020-07-04 20:55:00 --> Config Class Initialized
INFO - 2020-07-04 20:55:00 --> Loader Class Initialized
INFO - 2020-07-04 20:55:00 --> Helper loaded: url_helper
INFO - 2020-07-04 20:55:00 --> Helper loaded: main_helper
INFO - 2020-07-04 20:55:00 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:55:00 --> Controller Class Initialized
INFO - 2020-07-04 20:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:55:00 --> Pagination Class Initialized
ERROR - 2020-07-04 20:55:00 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:55:00 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:55:00 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:55:02 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:55:02 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:55:02 --> Final output sent to browser
DEBUG - 2020-07-04 20:55:02 --> Total execution time: 1.6624
INFO - 2020-07-04 20:55:20 --> Config Class Initialized
INFO - 2020-07-04 20:55:20 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:55:20 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:55:20 --> Utf8 Class Initialized
INFO - 2020-07-04 20:55:20 --> URI Class Initialized
INFO - 2020-07-04 20:55:20 --> Router Class Initialized
INFO - 2020-07-04 20:55:20 --> Output Class Initialized
INFO - 2020-07-04 20:55:20 --> Security Class Initialized
DEBUG - 2020-07-04 20:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:55:20 --> Input Class Initialized
INFO - 2020-07-04 20:55:20 --> Language Class Initialized
INFO - 2020-07-04 20:55:20 --> Language Class Initialized
INFO - 2020-07-04 20:55:20 --> Config Class Initialized
INFO - 2020-07-04 20:55:20 --> Loader Class Initialized
INFO - 2020-07-04 20:55:20 --> Helper loaded: url_helper
INFO - 2020-07-04 20:55:20 --> Helper loaded: main_helper
INFO - 2020-07-04 20:55:20 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:55:20 --> Controller Class Initialized
INFO - 2020-07-04 20:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:55:20 --> Pagination Class Initialized
ERROR - 2020-07-04 20:55:20 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:55:20 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:55:20 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:55:20 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:55:20 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:55:20 --> Final output sent to browser
DEBUG - 2020-07-04 20:55:20 --> Total execution time: 0.0041
INFO - 2020-07-04 20:55:44 --> Config Class Initialized
INFO - 2020-07-04 20:55:44 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:55:44 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:55:44 --> Utf8 Class Initialized
INFO - 2020-07-04 20:55:44 --> URI Class Initialized
INFO - 2020-07-04 20:55:44 --> Router Class Initialized
INFO - 2020-07-04 20:55:44 --> Output Class Initialized
INFO - 2020-07-04 20:55:44 --> Security Class Initialized
DEBUG - 2020-07-04 20:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:55:44 --> Input Class Initialized
INFO - 2020-07-04 20:55:44 --> Language Class Initialized
INFO - 2020-07-04 20:55:44 --> Language Class Initialized
INFO - 2020-07-04 20:55:44 --> Config Class Initialized
INFO - 2020-07-04 20:55:44 --> Loader Class Initialized
INFO - 2020-07-04 20:55:44 --> Helper loaded: url_helper
INFO - 2020-07-04 20:55:44 --> Helper loaded: main_helper
INFO - 2020-07-04 20:55:44 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:55:44 --> Controller Class Initialized
INFO - 2020-07-04 20:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:55:44 --> Pagination Class Initialized
ERROR - 2020-07-04 20:55:44 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:55:44 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:55:44 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:55:44 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:55:44 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:55:44 --> Final output sent to browser
DEBUG - 2020-07-04 20:55:44 --> Total execution time: 0.0066
INFO - 2020-07-04 20:56:24 --> Config Class Initialized
INFO - 2020-07-04 20:56:24 --> Hooks Class Initialized
DEBUG - 2020-07-04 20:56:24 --> UTF-8 Support Enabled
INFO - 2020-07-04 20:56:24 --> Utf8 Class Initialized
INFO - 2020-07-04 20:56:24 --> URI Class Initialized
INFO - 2020-07-04 20:56:24 --> Router Class Initialized
INFO - 2020-07-04 20:56:24 --> Output Class Initialized
INFO - 2020-07-04 20:56:24 --> Security Class Initialized
DEBUG - 2020-07-04 20:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 20:56:24 --> Input Class Initialized
INFO - 2020-07-04 20:56:24 --> Language Class Initialized
INFO - 2020-07-04 20:56:24 --> Language Class Initialized
INFO - 2020-07-04 20:56:24 --> Config Class Initialized
INFO - 2020-07-04 20:56:24 --> Loader Class Initialized
INFO - 2020-07-04 20:56:24 --> Helper loaded: url_helper
INFO - 2020-07-04 20:56:24 --> Helper loaded: main_helper
INFO - 2020-07-04 20:56:24 --> Database Driver Class Initialized
DEBUG - 2020-07-04 20:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 20:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 20:56:24 --> Controller Class Initialized
INFO - 2020-07-04 20:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 20:56:24 --> Pagination Class Initialized
ERROR - 2020-07-04 20:56:24 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 20:56:24 --> Helper loaded: file_helper
DEBUG - 2020-07-04 20:56:24 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 20:56:24 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 20:56:24 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 20:56:24 --> Final output sent to browser
DEBUG - 2020-07-04 20:56:24 --> Total execution time: 0.0073
INFO - 2020-07-04 21:01:40 --> Config Class Initialized
INFO - 2020-07-04 21:01:40 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:01:40 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:01:40 --> Utf8 Class Initialized
INFO - 2020-07-04 21:01:40 --> URI Class Initialized
INFO - 2020-07-04 21:01:40 --> Router Class Initialized
INFO - 2020-07-04 21:01:40 --> Output Class Initialized
INFO - 2020-07-04 21:01:40 --> Security Class Initialized
DEBUG - 2020-07-04 21:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:01:40 --> Input Class Initialized
INFO - 2020-07-04 21:01:40 --> Language Class Initialized
INFO - 2020-07-04 21:01:40 --> Language Class Initialized
INFO - 2020-07-04 21:01:40 --> Config Class Initialized
INFO - 2020-07-04 21:01:40 --> Loader Class Initialized
INFO - 2020-07-04 21:01:40 --> Helper loaded: url_helper
INFO - 2020-07-04 21:01:40 --> Helper loaded: main_helper
INFO - 2020-07-04 21:01:40 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:01:40 --> Controller Class Initialized
INFO - 2020-07-04 21:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:01:40 --> Pagination Class Initialized
ERROR - 2020-07-04 21:01:40 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:01:40 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:01:40 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:01:41 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:01:41 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:01:41 --> Final output sent to browser
DEBUG - 2020-07-04 21:01:41 --> Total execution time: 1.3585
INFO - 2020-07-04 21:05:20 --> Config Class Initialized
INFO - 2020-07-04 21:05:20 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:05:20 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:05:20 --> Utf8 Class Initialized
INFO - 2020-07-04 21:05:20 --> URI Class Initialized
INFO - 2020-07-04 21:05:20 --> Router Class Initialized
INFO - 2020-07-04 21:05:20 --> Output Class Initialized
INFO - 2020-07-04 21:05:20 --> Security Class Initialized
DEBUG - 2020-07-04 21:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:05:20 --> Input Class Initialized
INFO - 2020-07-04 21:05:20 --> Language Class Initialized
INFO - 2020-07-04 21:05:20 --> Language Class Initialized
INFO - 2020-07-04 21:05:20 --> Config Class Initialized
INFO - 2020-07-04 21:05:20 --> Loader Class Initialized
INFO - 2020-07-04 21:05:20 --> Helper loaded: url_helper
INFO - 2020-07-04 21:05:20 --> Helper loaded: main_helper
INFO - 2020-07-04 21:05:20 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:05:20 --> Controller Class Initialized
INFO - 2020-07-04 21:05:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:05:20 --> Pagination Class Initialized
ERROR - 2020-07-04 21:05:20 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:05:20 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:05:20 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:05:20 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:05:20 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:05:20 --> Final output sent to browser
DEBUG - 2020-07-04 21:05:20 --> Total execution time: 0.0054
INFO - 2020-07-04 21:06:54 --> Config Class Initialized
INFO - 2020-07-04 21:06:54 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:06:54 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:06:54 --> Utf8 Class Initialized
INFO - 2020-07-04 21:06:54 --> URI Class Initialized
INFO - 2020-07-04 21:06:54 --> Router Class Initialized
INFO - 2020-07-04 21:06:54 --> Output Class Initialized
INFO - 2020-07-04 21:06:54 --> Security Class Initialized
DEBUG - 2020-07-04 21:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:06:54 --> Input Class Initialized
INFO - 2020-07-04 21:06:54 --> Language Class Initialized
INFO - 2020-07-04 21:06:54 --> Language Class Initialized
INFO - 2020-07-04 21:06:54 --> Config Class Initialized
INFO - 2020-07-04 21:06:54 --> Loader Class Initialized
INFO - 2020-07-04 21:06:54 --> Helper loaded: url_helper
INFO - 2020-07-04 21:06:54 --> Helper loaded: main_helper
INFO - 2020-07-04 21:06:54 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:06:54 --> Controller Class Initialized
INFO - 2020-07-04 21:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:06:54 --> Pagination Class Initialized
ERROR - 2020-07-04 21:06:54 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:06:54 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:06:54 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:06:55 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:06:55 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:06:55 --> Final output sent to browser
DEBUG - 2020-07-04 21:06:55 --> Total execution time: 1.4058
INFO - 2020-07-04 21:07:03 --> Config Class Initialized
INFO - 2020-07-04 21:07:03 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:07:03 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:07:03 --> Utf8 Class Initialized
INFO - 2020-07-04 21:07:03 --> URI Class Initialized
INFO - 2020-07-04 21:07:03 --> Router Class Initialized
INFO - 2020-07-04 21:07:03 --> Output Class Initialized
INFO - 2020-07-04 21:07:03 --> Security Class Initialized
DEBUG - 2020-07-04 21:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:07:03 --> Input Class Initialized
INFO - 2020-07-04 21:07:03 --> Language Class Initialized
INFO - 2020-07-04 21:07:03 --> Language Class Initialized
INFO - 2020-07-04 21:07:03 --> Config Class Initialized
INFO - 2020-07-04 21:07:03 --> Loader Class Initialized
INFO - 2020-07-04 21:07:03 --> Helper loaded: url_helper
INFO - 2020-07-04 21:07:03 --> Helper loaded: main_helper
INFO - 2020-07-04 21:07:03 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:07:03 --> Controller Class Initialized
INFO - 2020-07-04 21:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:07:03 --> Pagination Class Initialized
ERROR - 2020-07-04 21:07:03 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:07:03 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:07:03 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:07:03 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:07:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:07:03 --> Final output sent to browser
DEBUG - 2020-07-04 21:07:03 --> Total execution time: 0.0041
INFO - 2020-07-04 21:07:12 --> Config Class Initialized
INFO - 2020-07-04 21:07:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:07:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:07:12 --> Utf8 Class Initialized
INFO - 2020-07-04 21:07:12 --> URI Class Initialized
INFO - 2020-07-04 21:07:12 --> Router Class Initialized
INFO - 2020-07-04 21:07:12 --> Output Class Initialized
INFO - 2020-07-04 21:07:12 --> Security Class Initialized
DEBUG - 2020-07-04 21:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:07:12 --> Input Class Initialized
INFO - 2020-07-04 21:07:12 --> Language Class Initialized
INFO - 2020-07-04 21:07:12 --> Language Class Initialized
INFO - 2020-07-04 21:07:12 --> Config Class Initialized
INFO - 2020-07-04 21:07:12 --> Loader Class Initialized
INFO - 2020-07-04 21:07:12 --> Helper loaded: url_helper
INFO - 2020-07-04 21:07:12 --> Helper loaded: main_helper
INFO - 2020-07-04 21:07:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:07:12 --> Controller Class Initialized
INFO - 2020-07-04 21:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:07:12 --> Pagination Class Initialized
ERROR - 2020-07-04 21:07:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:07:12 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:07:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:07:12 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:07:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:07:12 --> Final output sent to browser
DEBUG - 2020-07-04 21:07:12 --> Total execution time: 0.0061
INFO - 2020-07-04 21:08:35 --> Config Class Initialized
INFO - 2020-07-04 21:08:35 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:08:35 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:08:35 --> Utf8 Class Initialized
INFO - 2020-07-04 21:08:35 --> URI Class Initialized
INFO - 2020-07-04 21:08:35 --> Router Class Initialized
INFO - 2020-07-04 21:08:35 --> Output Class Initialized
INFO - 2020-07-04 21:08:35 --> Security Class Initialized
DEBUG - 2020-07-04 21:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:08:35 --> Input Class Initialized
INFO - 2020-07-04 21:08:35 --> Language Class Initialized
INFO - 2020-07-04 21:08:35 --> Language Class Initialized
INFO - 2020-07-04 21:08:35 --> Config Class Initialized
INFO - 2020-07-04 21:08:35 --> Loader Class Initialized
INFO - 2020-07-04 21:08:35 --> Helper loaded: url_helper
INFO - 2020-07-04 21:08:35 --> Helper loaded: main_helper
INFO - 2020-07-04 21:08:35 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:08:35 --> Controller Class Initialized
INFO - 2020-07-04 21:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:08:35 --> Pagination Class Initialized
ERROR - 2020-07-04 21:08:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:08:35 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:08:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:08:35 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:08:35 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:08:35 --> Final output sent to browser
DEBUG - 2020-07-04 21:08:35 --> Total execution time: 0.0055
INFO - 2020-07-04 21:08:36 --> Config Class Initialized
INFO - 2020-07-04 21:08:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:08:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:08:36 --> Utf8 Class Initialized
INFO - 2020-07-04 21:08:36 --> URI Class Initialized
INFO - 2020-07-04 21:08:36 --> Router Class Initialized
INFO - 2020-07-04 21:08:36 --> Output Class Initialized
INFO - 2020-07-04 21:08:36 --> Security Class Initialized
DEBUG - 2020-07-04 21:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:08:36 --> Input Class Initialized
INFO - 2020-07-04 21:08:36 --> Language Class Initialized
INFO - 2020-07-04 21:08:36 --> Language Class Initialized
INFO - 2020-07-04 21:08:36 --> Config Class Initialized
INFO - 2020-07-04 21:08:36 --> Loader Class Initialized
INFO - 2020-07-04 21:08:36 --> Helper loaded: url_helper
INFO - 2020-07-04 21:08:36 --> Helper loaded: main_helper
INFO - 2020-07-04 21:08:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:08:36 --> Controller Class Initialized
INFO - 2020-07-04 21:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:08:36 --> Pagination Class Initialized
ERROR - 2020-07-04 21:08:36 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:08:36 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:08:36 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:08:36 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:08:36 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:08:36 --> Final output sent to browser
DEBUG - 2020-07-04 21:08:36 --> Total execution time: 0.0039
INFO - 2020-07-04 21:08:38 --> Config Class Initialized
INFO - 2020-07-04 21:08:38 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:08:38 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:08:38 --> Utf8 Class Initialized
INFO - 2020-07-04 21:08:38 --> URI Class Initialized
INFO - 2020-07-04 21:08:38 --> Router Class Initialized
INFO - 2020-07-04 21:08:38 --> Output Class Initialized
INFO - 2020-07-04 21:08:38 --> Security Class Initialized
DEBUG - 2020-07-04 21:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:08:38 --> Input Class Initialized
INFO - 2020-07-04 21:08:38 --> Language Class Initialized
INFO - 2020-07-04 21:08:38 --> Language Class Initialized
INFO - 2020-07-04 21:08:38 --> Config Class Initialized
INFO - 2020-07-04 21:08:38 --> Loader Class Initialized
INFO - 2020-07-04 21:08:38 --> Helper loaded: url_helper
INFO - 2020-07-04 21:08:38 --> Helper loaded: main_helper
INFO - 2020-07-04 21:08:38 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:08:38 --> Controller Class Initialized
INFO - 2020-07-04 21:08:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:08:38 --> Pagination Class Initialized
ERROR - 2020-07-04 21:08:38 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:08:38 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:08:38 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:08:38 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:08:38 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:08:38 --> Final output sent to browser
DEBUG - 2020-07-04 21:08:38 --> Total execution time: 0.0054
INFO - 2020-07-04 21:08:42 --> Config Class Initialized
INFO - 2020-07-04 21:08:42 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:08:42 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:08:42 --> Utf8 Class Initialized
INFO - 2020-07-04 21:08:42 --> URI Class Initialized
INFO - 2020-07-04 21:08:42 --> Router Class Initialized
INFO - 2020-07-04 21:08:42 --> Output Class Initialized
INFO - 2020-07-04 21:08:42 --> Security Class Initialized
DEBUG - 2020-07-04 21:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:08:42 --> Input Class Initialized
INFO - 2020-07-04 21:08:42 --> Language Class Initialized
INFO - 2020-07-04 21:08:42 --> Language Class Initialized
INFO - 2020-07-04 21:08:42 --> Config Class Initialized
INFO - 2020-07-04 21:08:42 --> Loader Class Initialized
INFO - 2020-07-04 21:08:42 --> Helper loaded: url_helper
INFO - 2020-07-04 21:08:42 --> Helper loaded: main_helper
INFO - 2020-07-04 21:08:42 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:08:42 --> Controller Class Initialized
INFO - 2020-07-04 21:08:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:08:42 --> Pagination Class Initialized
ERROR - 2020-07-04 21:08:42 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:08:42 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:08:42 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:08:42 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:08:42 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:08:42 --> Final output sent to browser
DEBUG - 2020-07-04 21:08:42 --> Total execution time: 0.0044
INFO - 2020-07-04 21:08:53 --> Config Class Initialized
INFO - 2020-07-04 21:08:53 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:08:53 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:08:53 --> Utf8 Class Initialized
INFO - 2020-07-04 21:08:53 --> URI Class Initialized
INFO - 2020-07-04 21:08:53 --> Router Class Initialized
INFO - 2020-07-04 21:08:53 --> Output Class Initialized
INFO - 2020-07-04 21:08:53 --> Security Class Initialized
DEBUG - 2020-07-04 21:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:08:53 --> Input Class Initialized
INFO - 2020-07-04 21:08:53 --> Language Class Initialized
INFO - 2020-07-04 21:08:53 --> Language Class Initialized
INFO - 2020-07-04 21:08:53 --> Config Class Initialized
INFO - 2020-07-04 21:08:53 --> Loader Class Initialized
INFO - 2020-07-04 21:08:53 --> Helper loaded: url_helper
INFO - 2020-07-04 21:08:53 --> Helper loaded: main_helper
INFO - 2020-07-04 21:08:53 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:08:53 --> Controller Class Initialized
INFO - 2020-07-04 21:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:08:53 --> Pagination Class Initialized
ERROR - 2020-07-04 21:08:53 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:08:53 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:08:53 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:08:54 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:08:54 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:08:54 --> Final output sent to browser
DEBUG - 2020-07-04 21:08:54 --> Total execution time: 1.3537
INFO - 2020-07-04 21:09:09 --> Config Class Initialized
INFO - 2020-07-04 21:09:09 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:09:09 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:09:09 --> Utf8 Class Initialized
INFO - 2020-07-04 21:09:09 --> URI Class Initialized
INFO - 2020-07-04 21:09:09 --> Router Class Initialized
INFO - 2020-07-04 21:09:09 --> Output Class Initialized
INFO - 2020-07-04 21:09:09 --> Security Class Initialized
DEBUG - 2020-07-04 21:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:09:09 --> Input Class Initialized
INFO - 2020-07-04 21:09:09 --> Language Class Initialized
INFO - 2020-07-04 21:09:09 --> Language Class Initialized
INFO - 2020-07-04 21:09:09 --> Config Class Initialized
INFO - 2020-07-04 21:09:09 --> Loader Class Initialized
INFO - 2020-07-04 21:09:09 --> Helper loaded: url_helper
INFO - 2020-07-04 21:09:09 --> Helper loaded: main_helper
INFO - 2020-07-04 21:09:09 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:09:09 --> Controller Class Initialized
INFO - 2020-07-04 21:09:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:09:09 --> Pagination Class Initialized
ERROR - 2020-07-04 21:09:09 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:09:09 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:09:09 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:09:10 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:09:10 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:09:10 --> Final output sent to browser
DEBUG - 2020-07-04 21:09:10 --> Total execution time: 1.2809
INFO - 2020-07-04 21:30:17 --> Config Class Initialized
INFO - 2020-07-04 21:30:17 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:30:17 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:30:17 --> Utf8 Class Initialized
INFO - 2020-07-04 21:30:17 --> URI Class Initialized
INFO - 2020-07-04 21:30:17 --> Router Class Initialized
INFO - 2020-07-04 21:30:17 --> Output Class Initialized
INFO - 2020-07-04 21:30:17 --> Security Class Initialized
DEBUG - 2020-07-04 21:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:30:17 --> Input Class Initialized
INFO - 2020-07-04 21:30:17 --> Language Class Initialized
INFO - 2020-07-04 21:30:17 --> Language Class Initialized
INFO - 2020-07-04 21:30:17 --> Config Class Initialized
INFO - 2020-07-04 21:30:17 --> Loader Class Initialized
INFO - 2020-07-04 21:30:17 --> Helper loaded: url_helper
INFO - 2020-07-04 21:30:17 --> Helper loaded: main_helper
INFO - 2020-07-04 21:30:17 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:30:17 --> Controller Class Initialized
INFO - 2020-07-04 21:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:30:17 --> Pagination Class Initialized
ERROR - 2020-07-04 21:30:17 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:30:17 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:30:17 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
ERROR - 2020-07-04 21:30:18 --> Severity: Notice --> Only variables should be passed by reference /var/www/journal/application/modules/landing/controllers/Search.php 106
DEBUG - 2020-07-04 21:30:18 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:30:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:30:18 --> Config Class Initialized
INFO - 2020-07-04 21:30:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:30:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:30:18 --> Utf8 Class Initialized
INFO - 2020-07-04 21:30:18 --> URI Class Initialized
INFO - 2020-07-04 21:30:18 --> Router Class Initialized
INFO - 2020-07-04 21:30:18 --> Output Class Initialized
INFO - 2020-07-04 21:30:18 --> Security Class Initialized
DEBUG - 2020-07-04 21:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:30:18 --> Input Class Initialized
INFO - 2020-07-04 21:30:18 --> Language Class Initialized
INFO - 2020-07-04 21:30:18 --> Language Class Initialized
INFO - 2020-07-04 21:30:18 --> Config Class Initialized
INFO - 2020-07-04 21:30:18 --> Loader Class Initialized
INFO - 2020-07-04 21:30:18 --> Helper loaded: url_helper
INFO - 2020-07-04 21:30:18 --> Helper loaded: main_helper
INFO - 2020-07-04 21:30:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:30:18 --> Controller Class Initialized
INFO - 2020-07-04 21:30:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:30:18 --> Pagination Class Initialized
ERROR - 2020-07-04 21:30:18 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:30:18 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:30:18 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
ERROR - 2020-07-04 21:30:18 --> Severity: Notice --> Only variables should be passed by reference /var/www/journal/application/modules/landing/controllers/Search.php 106
DEBUG - 2020-07-04 21:30:18 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:30:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:30:18 --> Final output sent to browser
DEBUG - 2020-07-04 21:30:18 --> Total execution time: 0.0046
INFO - 2020-07-04 21:30:56 --> Config Class Initialized
INFO - 2020-07-04 21:30:56 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:30:56 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:30:56 --> Utf8 Class Initialized
INFO - 2020-07-04 21:30:56 --> URI Class Initialized
INFO - 2020-07-04 21:30:56 --> Router Class Initialized
INFO - 2020-07-04 21:30:56 --> Output Class Initialized
INFO - 2020-07-04 21:30:56 --> Security Class Initialized
DEBUG - 2020-07-04 21:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:30:56 --> Input Class Initialized
INFO - 2020-07-04 21:30:56 --> Language Class Initialized
INFO - 2020-07-04 21:30:56 --> Language Class Initialized
INFO - 2020-07-04 21:30:56 --> Config Class Initialized
INFO - 2020-07-04 21:30:56 --> Loader Class Initialized
INFO - 2020-07-04 21:30:56 --> Helper loaded: url_helper
INFO - 2020-07-04 21:30:56 --> Helper loaded: main_helper
INFO - 2020-07-04 21:30:56 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:30:56 --> Controller Class Initialized
INFO - 2020-07-04 21:30:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:30:56 --> Pagination Class Initialized
ERROR - 2020-07-04 21:30:56 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:30:56 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:30:56 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
ERROR - 2020-07-04 21:30:57 --> Severity: Notice --> Only variables should be passed by reference /var/www/journal/application/modules/landing/controllers/Search.php 106
DEBUG - 2020-07-04 21:30:57 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:30:57 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:30:57 --> Final output sent to browser
DEBUG - 2020-07-04 21:30:57 --> Total execution time: 1.2953
INFO - 2020-07-04 21:33:42 --> Config Class Initialized
INFO - 2020-07-04 21:33:42 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:33:42 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:33:42 --> Utf8 Class Initialized
INFO - 2020-07-04 21:33:42 --> URI Class Initialized
INFO - 2020-07-04 21:33:42 --> Router Class Initialized
INFO - 2020-07-04 21:33:42 --> Output Class Initialized
INFO - 2020-07-04 21:33:42 --> Security Class Initialized
DEBUG - 2020-07-04 21:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:33:42 --> Input Class Initialized
INFO - 2020-07-04 21:33:42 --> Language Class Initialized
ERROR - 2020-07-04 21:33:42 --> Severity: error --> Exception: syntax error, unexpected '}' /var/www/journal/application/modules/landing/controllers/Search.php 109
INFO - 2020-07-04 21:33:47 --> Config Class Initialized
INFO - 2020-07-04 21:33:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:33:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:33:47 --> Utf8 Class Initialized
INFO - 2020-07-04 21:33:47 --> URI Class Initialized
INFO - 2020-07-04 21:33:47 --> Router Class Initialized
INFO - 2020-07-04 21:33:47 --> Output Class Initialized
INFO - 2020-07-04 21:33:47 --> Security Class Initialized
DEBUG - 2020-07-04 21:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:33:47 --> Input Class Initialized
INFO - 2020-07-04 21:33:47 --> Language Class Initialized
INFO - 2020-07-04 21:33:47 --> Language Class Initialized
INFO - 2020-07-04 21:33:47 --> Config Class Initialized
INFO - 2020-07-04 21:33:47 --> Loader Class Initialized
INFO - 2020-07-04 21:33:47 --> Helper loaded: url_helper
INFO - 2020-07-04 21:33:47 --> Helper loaded: main_helper
INFO - 2020-07-04 21:33:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:33:47 --> Controller Class Initialized
INFO - 2020-07-04 21:33:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:33:47 --> Pagination Class Initialized
ERROR - 2020-07-04 21:33:47 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:33:47 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:33:47 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:33:47 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:33:47 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:33:47 --> Final output sent to browser
DEBUG - 2020-07-04 21:33:47 --> Total execution time: 0.0046
INFO - 2020-07-04 21:34:31 --> Config Class Initialized
INFO - 2020-07-04 21:34:31 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:34:31 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:34:31 --> Utf8 Class Initialized
INFO - 2020-07-04 21:34:31 --> URI Class Initialized
INFO - 2020-07-04 21:34:31 --> Router Class Initialized
INFO - 2020-07-04 21:34:31 --> Output Class Initialized
INFO - 2020-07-04 21:34:31 --> Security Class Initialized
DEBUG - 2020-07-04 21:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:34:31 --> Input Class Initialized
INFO - 2020-07-04 21:34:31 --> Language Class Initialized
INFO - 2020-07-04 21:34:31 --> Language Class Initialized
INFO - 2020-07-04 21:34:31 --> Config Class Initialized
INFO - 2020-07-04 21:34:31 --> Loader Class Initialized
INFO - 2020-07-04 21:34:31 --> Helper loaded: url_helper
INFO - 2020-07-04 21:34:31 --> Helper loaded: main_helper
INFO - 2020-07-04 21:34:31 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:34:31 --> Controller Class Initialized
INFO - 2020-07-04 21:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:34:31 --> Pagination Class Initialized
ERROR - 2020-07-04 21:34:31 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:34:31 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:34:31 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:34:31 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:34:31 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:34:31 --> Final output sent to browser
DEBUG - 2020-07-04 21:34:31 --> Total execution time: 0.0055
INFO - 2020-07-04 21:35:04 --> Config Class Initialized
INFO - 2020-07-04 21:35:04 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:35:04 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:35:04 --> Utf8 Class Initialized
INFO - 2020-07-04 21:35:04 --> URI Class Initialized
INFO - 2020-07-04 21:35:04 --> Router Class Initialized
INFO - 2020-07-04 21:35:04 --> Output Class Initialized
INFO - 2020-07-04 21:35:04 --> Security Class Initialized
DEBUG - 2020-07-04 21:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:35:04 --> Input Class Initialized
INFO - 2020-07-04 21:35:04 --> Language Class Initialized
ERROR - 2020-07-04 21:35:04 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) /var/www/journal/application/modules/landing/controllers/Search.php 17
INFO - 2020-07-04 21:35:43 --> Config Class Initialized
INFO - 2020-07-04 21:35:43 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:35:43 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:35:43 --> Utf8 Class Initialized
INFO - 2020-07-04 21:35:43 --> URI Class Initialized
INFO - 2020-07-04 21:35:43 --> Router Class Initialized
INFO - 2020-07-04 21:35:43 --> Output Class Initialized
INFO - 2020-07-04 21:35:43 --> Security Class Initialized
DEBUG - 2020-07-04 21:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:35:43 --> Input Class Initialized
INFO - 2020-07-04 21:35:43 --> Language Class Initialized
INFO - 2020-07-04 21:35:43 --> Language Class Initialized
INFO - 2020-07-04 21:35:43 --> Config Class Initialized
INFO - 2020-07-04 21:35:43 --> Loader Class Initialized
INFO - 2020-07-04 21:35:43 --> Helper loaded: url_helper
INFO - 2020-07-04 21:35:43 --> Helper loaded: main_helper
INFO - 2020-07-04 21:35:43 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:35:43 --> Controller Class Initialized
INFO - 2020-07-04 21:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:35:43 --> Pagination Class Initialized
ERROR - 2020-07-04 21:35:43 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:35:43 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:35:43 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
INFO - 2020-07-04 21:36:08 --> Config Class Initialized
INFO - 2020-07-04 21:36:08 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:36:08 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:36:08 --> Utf8 Class Initialized
INFO - 2020-07-04 21:36:08 --> URI Class Initialized
INFO - 2020-07-04 21:36:08 --> Router Class Initialized
INFO - 2020-07-04 21:36:08 --> Output Class Initialized
INFO - 2020-07-04 21:36:08 --> Security Class Initialized
DEBUG - 2020-07-04 21:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:36:08 --> Input Class Initialized
INFO - 2020-07-04 21:36:08 --> Language Class Initialized
INFO - 2020-07-04 21:36:08 --> Language Class Initialized
INFO - 2020-07-04 21:36:08 --> Config Class Initialized
INFO - 2020-07-04 21:36:08 --> Loader Class Initialized
INFO - 2020-07-04 21:36:08 --> Helper loaded: url_helper
INFO - 2020-07-04 21:36:08 --> Helper loaded: main_helper
INFO - 2020-07-04 21:36:08 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:36:08 --> Controller Class Initialized
INFO - 2020-07-04 21:36:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:36:08 --> Pagination Class Initialized
ERROR - 2020-07-04 21:36:08 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:36:08 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:36:08 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:36:09 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:36:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:36:09 --> Final output sent to browser
DEBUG - 2020-07-04 21:36:09 --> Total execution time: 1.3823
INFO - 2020-07-04 21:36:40 --> Config Class Initialized
INFO - 2020-07-04 21:36:40 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:36:40 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:36:40 --> Utf8 Class Initialized
INFO - 2020-07-04 21:36:40 --> URI Class Initialized
INFO - 2020-07-04 21:36:40 --> Router Class Initialized
INFO - 2020-07-04 21:36:40 --> Output Class Initialized
INFO - 2020-07-04 21:36:40 --> Security Class Initialized
DEBUG - 2020-07-04 21:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:36:40 --> Input Class Initialized
INFO - 2020-07-04 21:36:40 --> Language Class Initialized
INFO - 2020-07-04 21:36:40 --> Language Class Initialized
INFO - 2020-07-04 21:36:40 --> Config Class Initialized
INFO - 2020-07-04 21:36:40 --> Loader Class Initialized
INFO - 2020-07-04 21:36:40 --> Helper loaded: url_helper
INFO - 2020-07-04 21:36:40 --> Helper loaded: main_helper
INFO - 2020-07-04 21:36:40 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:36:40 --> Controller Class Initialized
INFO - 2020-07-04 21:36:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:36:40 --> Pagination Class Initialized
ERROR - 2020-07-04 21:36:40 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:36:40 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:36:40 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
INFO - 2020-07-04 21:37:36 --> Config Class Initialized
INFO - 2020-07-04 21:37:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:37:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:37:36 --> Utf8 Class Initialized
INFO - 2020-07-04 21:37:36 --> URI Class Initialized
INFO - 2020-07-04 21:37:36 --> Router Class Initialized
INFO - 2020-07-04 21:37:36 --> Output Class Initialized
INFO - 2020-07-04 21:37:36 --> Security Class Initialized
DEBUG - 2020-07-04 21:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:37:36 --> Input Class Initialized
INFO - 2020-07-04 21:37:36 --> Language Class Initialized
INFO - 2020-07-04 21:37:36 --> Language Class Initialized
INFO - 2020-07-04 21:37:36 --> Config Class Initialized
INFO - 2020-07-04 21:37:36 --> Loader Class Initialized
INFO - 2020-07-04 21:37:36 --> Helper loaded: url_helper
INFO - 2020-07-04 21:37:36 --> Helper loaded: main_helper
INFO - 2020-07-04 21:37:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:37:36 --> Controller Class Initialized
INFO - 2020-07-04 21:37:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:37:36 --> Pagination Class Initialized
ERROR - 2020-07-04 21:37:36 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:37:36 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:37:36 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:37:36 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:37:36 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:37:36 --> Final output sent to browser
DEBUG - 2020-07-04 21:37:36 --> Total execution time: 0.0050
INFO - 2020-07-04 21:37:43 --> Config Class Initialized
INFO - 2020-07-04 21:37:43 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:37:43 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:37:43 --> Utf8 Class Initialized
INFO - 2020-07-04 21:37:43 --> URI Class Initialized
INFO - 2020-07-04 21:37:43 --> Router Class Initialized
INFO - 2020-07-04 21:37:43 --> Output Class Initialized
INFO - 2020-07-04 21:37:43 --> Security Class Initialized
DEBUG - 2020-07-04 21:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:37:43 --> Input Class Initialized
INFO - 2020-07-04 21:37:43 --> Language Class Initialized
INFO - 2020-07-04 21:37:43 --> Language Class Initialized
INFO - 2020-07-04 21:37:43 --> Config Class Initialized
INFO - 2020-07-04 21:37:43 --> Loader Class Initialized
INFO - 2020-07-04 21:37:43 --> Helper loaded: url_helper
INFO - 2020-07-04 21:37:43 --> Helper loaded: main_helper
INFO - 2020-07-04 21:37:43 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:37:43 --> Controller Class Initialized
INFO - 2020-07-04 21:37:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:37:43 --> Pagination Class Initialized
ERROR - 2020-07-04 21:37:43 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:37:43 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:37:43 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:37:43 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:37:43 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:37:43 --> Final output sent to browser
DEBUG - 2020-07-04 21:37:43 --> Total execution time: 0.0040
INFO - 2020-07-04 21:38:30 --> Config Class Initialized
INFO - 2020-07-04 21:38:30 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:38:30 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:38:30 --> Utf8 Class Initialized
INFO - 2020-07-04 21:38:30 --> URI Class Initialized
INFO - 2020-07-04 21:38:30 --> Router Class Initialized
INFO - 2020-07-04 21:38:30 --> Output Class Initialized
INFO - 2020-07-04 21:38:30 --> Security Class Initialized
DEBUG - 2020-07-04 21:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:38:30 --> Input Class Initialized
INFO - 2020-07-04 21:38:30 --> Language Class Initialized
INFO - 2020-07-04 21:38:30 --> Language Class Initialized
INFO - 2020-07-04 21:38:30 --> Config Class Initialized
INFO - 2020-07-04 21:38:30 --> Loader Class Initialized
INFO - 2020-07-04 21:38:30 --> Helper loaded: url_helper
INFO - 2020-07-04 21:38:30 --> Helper loaded: main_helper
INFO - 2020-07-04 21:38:30 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:38:30 --> Controller Class Initialized
INFO - 2020-07-04 21:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:38:30 --> Pagination Class Initialized
ERROR - 2020-07-04 21:38:30 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:38:30 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:38:30 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
INFO - 2020-07-04 21:39:22 --> Config Class Initialized
INFO - 2020-07-04 21:39:22 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:39:22 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:39:22 --> Utf8 Class Initialized
INFO - 2020-07-04 21:39:22 --> URI Class Initialized
INFO - 2020-07-04 21:39:22 --> Router Class Initialized
INFO - 2020-07-04 21:39:22 --> Output Class Initialized
INFO - 2020-07-04 21:39:22 --> Security Class Initialized
DEBUG - 2020-07-04 21:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:39:22 --> Input Class Initialized
INFO - 2020-07-04 21:39:22 --> Language Class Initialized
INFO - 2020-07-04 21:39:22 --> Language Class Initialized
INFO - 2020-07-04 21:39:22 --> Config Class Initialized
INFO - 2020-07-04 21:39:22 --> Loader Class Initialized
INFO - 2020-07-04 21:39:22 --> Helper loaded: url_helper
INFO - 2020-07-04 21:39:22 --> Helper loaded: main_helper
INFO - 2020-07-04 21:39:22 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:39:22 --> Controller Class Initialized
INFO - 2020-07-04 21:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:39:22 --> Pagination Class Initialized
ERROR - 2020-07-04 21:39:22 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:39:22 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:39:22 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
INFO - 2020-07-04 21:40:20 --> Config Class Initialized
INFO - 2020-07-04 21:40:20 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:40:20 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:40:20 --> Utf8 Class Initialized
INFO - 2020-07-04 21:40:20 --> URI Class Initialized
INFO - 2020-07-04 21:40:20 --> Router Class Initialized
INFO - 2020-07-04 21:40:20 --> Output Class Initialized
INFO - 2020-07-04 21:40:20 --> Security Class Initialized
DEBUG - 2020-07-04 21:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:40:20 --> Input Class Initialized
INFO - 2020-07-04 21:40:20 --> Language Class Initialized
INFO - 2020-07-04 21:40:20 --> Language Class Initialized
INFO - 2020-07-04 21:40:20 --> Config Class Initialized
INFO - 2020-07-04 21:40:20 --> Loader Class Initialized
INFO - 2020-07-04 21:40:20 --> Helper loaded: url_helper
INFO - 2020-07-04 21:40:20 --> Helper loaded: main_helper
INFO - 2020-07-04 21:40:20 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:40:20 --> Controller Class Initialized
INFO - 2020-07-04 21:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:40:20 --> Pagination Class Initialized
ERROR - 2020-07-04 21:40:20 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:40:20 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:40:20 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
ERROR - 2020-07-04 21:40:20 --> Severity: Notice --> Array to string conversion /var/www/journal/application/modules/landing/controllers/Search.php 112
DEBUG - 2020-07-04 21:40:20 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:40:20 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:40:20 --> Final output sent to browser
DEBUG - 2020-07-04 21:40:20 --> Total execution time: 0.0062
INFO - 2020-07-04 21:40:49 --> Config Class Initialized
INFO - 2020-07-04 21:40:49 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:40:49 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:40:49 --> Utf8 Class Initialized
INFO - 2020-07-04 21:40:49 --> URI Class Initialized
INFO - 2020-07-04 21:40:49 --> Router Class Initialized
INFO - 2020-07-04 21:40:49 --> Output Class Initialized
INFO - 2020-07-04 21:40:49 --> Security Class Initialized
DEBUG - 2020-07-04 21:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:40:49 --> Input Class Initialized
INFO - 2020-07-04 21:40:49 --> Language Class Initialized
INFO - 2020-07-04 21:40:49 --> Language Class Initialized
INFO - 2020-07-04 21:40:49 --> Config Class Initialized
INFO - 2020-07-04 21:40:49 --> Loader Class Initialized
INFO - 2020-07-04 21:40:49 --> Helper loaded: url_helper
INFO - 2020-07-04 21:40:49 --> Helper loaded: main_helper
INFO - 2020-07-04 21:40:49 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:40:49 --> Controller Class Initialized
INFO - 2020-07-04 21:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:40:49 --> Pagination Class Initialized
ERROR - 2020-07-04 21:40:49 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:40:49 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:40:49 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:40:49 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:40:49 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:40:49 --> Final output sent to browser
DEBUG - 2020-07-04 21:40:49 --> Total execution time: 0.0046
INFO - 2020-07-04 21:40:57 --> Config Class Initialized
INFO - 2020-07-04 21:40:57 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:40:57 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:40:57 --> Utf8 Class Initialized
INFO - 2020-07-04 21:40:57 --> URI Class Initialized
INFO - 2020-07-04 21:40:57 --> Router Class Initialized
INFO - 2020-07-04 21:40:57 --> Output Class Initialized
INFO - 2020-07-04 21:40:57 --> Security Class Initialized
DEBUG - 2020-07-04 21:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:40:57 --> Input Class Initialized
INFO - 2020-07-04 21:40:57 --> Language Class Initialized
INFO - 2020-07-04 21:40:57 --> Language Class Initialized
INFO - 2020-07-04 21:40:57 --> Config Class Initialized
INFO - 2020-07-04 21:40:57 --> Loader Class Initialized
INFO - 2020-07-04 21:40:57 --> Helper loaded: url_helper
INFO - 2020-07-04 21:40:57 --> Helper loaded: main_helper
INFO - 2020-07-04 21:40:57 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:40:57 --> Controller Class Initialized
INFO - 2020-07-04 21:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:40:57 --> Pagination Class Initialized
ERROR - 2020-07-04 21:40:57 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:40:57 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:40:57 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
ERROR - 2020-07-04 21:40:57 --> Severity: error --> Exception: Argument 1 passed to Search::_used_host() must be of the type string, null given, called in /var/www/journal/application/modules/landing/controllers/Search.php on line 25 /var/www/journal/application/modules/landing/controllers/Search.php 43
INFO - 2020-07-04 21:42:10 --> Config Class Initialized
INFO - 2020-07-04 21:42:10 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:42:10 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:42:10 --> Utf8 Class Initialized
INFO - 2020-07-04 21:42:10 --> URI Class Initialized
INFO - 2020-07-04 21:42:10 --> Router Class Initialized
INFO - 2020-07-04 21:42:10 --> Output Class Initialized
INFO - 2020-07-04 21:42:10 --> Security Class Initialized
DEBUG - 2020-07-04 21:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:42:10 --> Input Class Initialized
INFO - 2020-07-04 21:42:10 --> Language Class Initialized
INFO - 2020-07-04 21:42:10 --> Language Class Initialized
INFO - 2020-07-04 21:42:10 --> Config Class Initialized
INFO - 2020-07-04 21:42:10 --> Loader Class Initialized
INFO - 2020-07-04 21:42:10 --> Helper loaded: url_helper
INFO - 2020-07-04 21:42:10 --> Helper loaded: main_helper
INFO - 2020-07-04 21:42:10 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:42:10 --> Controller Class Initialized
INFO - 2020-07-04 21:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:42:10 --> Pagination Class Initialized
ERROR - 2020-07-04 21:42:10 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:42:10 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:42:10 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:42:11 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:42:11 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:42:11 --> Final output sent to browser
DEBUG - 2020-07-04 21:42:11 --> Total execution time: 1.2238
INFO - 2020-07-04 21:42:18 --> Config Class Initialized
INFO - 2020-07-04 21:42:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:42:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:42:18 --> Utf8 Class Initialized
INFO - 2020-07-04 21:42:18 --> URI Class Initialized
INFO - 2020-07-04 21:42:18 --> Router Class Initialized
INFO - 2020-07-04 21:42:18 --> Output Class Initialized
INFO - 2020-07-04 21:42:18 --> Security Class Initialized
DEBUG - 2020-07-04 21:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:42:18 --> Input Class Initialized
INFO - 2020-07-04 21:42:18 --> Language Class Initialized
INFO - 2020-07-04 21:42:18 --> Language Class Initialized
INFO - 2020-07-04 21:42:18 --> Config Class Initialized
INFO - 2020-07-04 21:42:18 --> Loader Class Initialized
INFO - 2020-07-04 21:42:18 --> Helper loaded: url_helper
INFO - 2020-07-04 21:42:18 --> Helper loaded: main_helper
INFO - 2020-07-04 21:42:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:42:18 --> Controller Class Initialized
INFO - 2020-07-04 21:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:42:18 --> Pagination Class Initialized
ERROR - 2020-07-04 21:42:18 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:42:18 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:42:18 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:42:18 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:42:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:42:18 --> Final output sent to browser
DEBUG - 2020-07-04 21:42:18 --> Total execution time: 0.0047
INFO - 2020-07-04 21:42:41 --> Config Class Initialized
INFO - 2020-07-04 21:42:41 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:42:41 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:42:41 --> Utf8 Class Initialized
INFO - 2020-07-04 21:42:41 --> URI Class Initialized
INFO - 2020-07-04 21:42:41 --> Router Class Initialized
INFO - 2020-07-04 21:42:41 --> Output Class Initialized
INFO - 2020-07-04 21:42:41 --> Security Class Initialized
DEBUG - 2020-07-04 21:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:42:41 --> Input Class Initialized
INFO - 2020-07-04 21:42:41 --> Language Class Initialized
INFO - 2020-07-04 21:42:41 --> Language Class Initialized
INFO - 2020-07-04 21:42:41 --> Config Class Initialized
INFO - 2020-07-04 21:42:41 --> Loader Class Initialized
INFO - 2020-07-04 21:42:41 --> Helper loaded: url_helper
INFO - 2020-07-04 21:42:41 --> Helper loaded: main_helper
INFO - 2020-07-04 21:42:41 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:42:41 --> Controller Class Initialized
INFO - 2020-07-04 21:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:42:41 --> Pagination Class Initialized
ERROR - 2020-07-04 21:42:41 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:42:41 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:42:41 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:42:41 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:42:41 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:42:41 --> Final output sent to browser
DEBUG - 2020-07-04 21:42:41 --> Total execution time: 0.0062
INFO - 2020-07-04 21:44:25 --> Config Class Initialized
INFO - 2020-07-04 21:44:25 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:44:25 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:44:25 --> Utf8 Class Initialized
INFO - 2020-07-04 21:44:25 --> URI Class Initialized
INFO - 2020-07-04 21:44:25 --> Router Class Initialized
INFO - 2020-07-04 21:44:25 --> Output Class Initialized
INFO - 2020-07-04 21:44:25 --> Security Class Initialized
DEBUG - 2020-07-04 21:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:44:25 --> Input Class Initialized
INFO - 2020-07-04 21:44:25 --> Language Class Initialized
INFO - 2020-07-04 21:44:25 --> Language Class Initialized
INFO - 2020-07-04 21:44:25 --> Config Class Initialized
INFO - 2020-07-04 21:44:25 --> Loader Class Initialized
INFO - 2020-07-04 21:44:25 --> Helper loaded: url_helper
INFO - 2020-07-04 21:44:25 --> Helper loaded: main_helper
INFO - 2020-07-04 21:44:25 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:44:25 --> Controller Class Initialized
INFO - 2020-07-04 21:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:44:25 --> Pagination Class Initialized
ERROR - 2020-07-04 21:44:25 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:44:25 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:44:25 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:44:25 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:44:25 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:44:25 --> Final output sent to browser
DEBUG - 2020-07-04 21:44:25 --> Total execution time: 0.0046
INFO - 2020-07-04 21:44:31 --> Config Class Initialized
INFO - 2020-07-04 21:44:31 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:44:31 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:44:31 --> Utf8 Class Initialized
INFO - 2020-07-04 21:44:31 --> URI Class Initialized
INFO - 2020-07-04 21:44:31 --> Router Class Initialized
INFO - 2020-07-04 21:44:31 --> Output Class Initialized
INFO - 2020-07-04 21:44:31 --> Security Class Initialized
DEBUG - 2020-07-04 21:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:44:31 --> Input Class Initialized
INFO - 2020-07-04 21:44:31 --> Language Class Initialized
INFO - 2020-07-04 21:44:31 --> Language Class Initialized
INFO - 2020-07-04 21:44:31 --> Config Class Initialized
INFO - 2020-07-04 21:44:31 --> Loader Class Initialized
INFO - 2020-07-04 21:44:31 --> Helper loaded: url_helper
INFO - 2020-07-04 21:44:31 --> Helper loaded: main_helper
INFO - 2020-07-04 21:44:31 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:44:31 --> Controller Class Initialized
INFO - 2020-07-04 21:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:44:31 --> Pagination Class Initialized
ERROR - 2020-07-04 21:44:31 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:44:31 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:44:31 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:44:31 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:44:31 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:44:31 --> Final output sent to browser
DEBUG - 2020-07-04 21:44:31 --> Total execution time: 0.0037
INFO - 2020-07-04 21:44:36 --> Config Class Initialized
INFO - 2020-07-04 21:44:36 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:44:36 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:44:36 --> Utf8 Class Initialized
INFO - 2020-07-04 21:44:36 --> URI Class Initialized
INFO - 2020-07-04 21:44:36 --> Router Class Initialized
INFO - 2020-07-04 21:44:36 --> Output Class Initialized
INFO - 2020-07-04 21:44:36 --> Security Class Initialized
DEBUG - 2020-07-04 21:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:44:36 --> Input Class Initialized
INFO - 2020-07-04 21:44:36 --> Language Class Initialized
INFO - 2020-07-04 21:44:36 --> Language Class Initialized
INFO - 2020-07-04 21:44:36 --> Config Class Initialized
INFO - 2020-07-04 21:44:36 --> Loader Class Initialized
INFO - 2020-07-04 21:44:36 --> Helper loaded: url_helper
INFO - 2020-07-04 21:44:36 --> Helper loaded: main_helper
INFO - 2020-07-04 21:44:36 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:44:36 --> Controller Class Initialized
INFO - 2020-07-04 21:44:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:44:36 --> Pagination Class Initialized
ERROR - 2020-07-04 21:44:36 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:44:36 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:44:36 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:44:37 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:44:37 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:44:37 --> Final output sent to browser
DEBUG - 2020-07-04 21:44:37 --> Total execution time: 1.3257
INFO - 2020-07-04 21:45:08 --> Config Class Initialized
INFO - 2020-07-04 21:45:08 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:45:08 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:45:08 --> Utf8 Class Initialized
INFO - 2020-07-04 21:45:08 --> URI Class Initialized
INFO - 2020-07-04 21:45:08 --> Router Class Initialized
INFO - 2020-07-04 21:45:08 --> Output Class Initialized
INFO - 2020-07-04 21:45:08 --> Security Class Initialized
DEBUG - 2020-07-04 21:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:45:08 --> Input Class Initialized
INFO - 2020-07-04 21:45:08 --> Language Class Initialized
INFO - 2020-07-04 21:45:08 --> Language Class Initialized
INFO - 2020-07-04 21:45:08 --> Config Class Initialized
INFO - 2020-07-04 21:45:08 --> Loader Class Initialized
INFO - 2020-07-04 21:45:08 --> Helper loaded: url_helper
INFO - 2020-07-04 21:45:08 --> Helper loaded: main_helper
INFO - 2020-07-04 21:45:08 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:45:08 --> Controller Class Initialized
INFO - 2020-07-04 21:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:45:08 --> Pagination Class Initialized
ERROR - 2020-07-04 21:45:08 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:45:08 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:45:08 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:45:08 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:45:08 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:45:08 --> Final output sent to browser
DEBUG - 2020-07-04 21:45:08 --> Total execution time: 0.0071
INFO - 2020-07-04 21:45:18 --> Config Class Initialized
INFO - 2020-07-04 21:45:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:45:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:45:18 --> Utf8 Class Initialized
INFO - 2020-07-04 21:45:18 --> URI Class Initialized
INFO - 2020-07-04 21:45:18 --> Router Class Initialized
INFO - 2020-07-04 21:45:18 --> Output Class Initialized
INFO - 2020-07-04 21:45:18 --> Security Class Initialized
DEBUG - 2020-07-04 21:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:45:18 --> Input Class Initialized
INFO - 2020-07-04 21:45:18 --> Language Class Initialized
INFO - 2020-07-04 21:45:18 --> Language Class Initialized
INFO - 2020-07-04 21:45:18 --> Config Class Initialized
INFO - 2020-07-04 21:45:18 --> Loader Class Initialized
INFO - 2020-07-04 21:45:18 --> Helper loaded: url_helper
INFO - 2020-07-04 21:45:18 --> Helper loaded: main_helper
INFO - 2020-07-04 21:45:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:45:18 --> Controller Class Initialized
INFO - 2020-07-04 21:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:45:18 --> Pagination Class Initialized
ERROR - 2020-07-04 21:45:18 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:45:18 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:45:18 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:45:18 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:45:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:45:18 --> Final output sent to browser
DEBUG - 2020-07-04 21:45:18 --> Total execution time: 0.0042
INFO - 2020-07-04 21:46:16 --> Config Class Initialized
INFO - 2020-07-04 21:46:16 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:46:16 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:46:16 --> Utf8 Class Initialized
INFO - 2020-07-04 21:46:16 --> URI Class Initialized
INFO - 2020-07-04 21:46:16 --> Router Class Initialized
INFO - 2020-07-04 21:46:16 --> Output Class Initialized
INFO - 2020-07-04 21:46:16 --> Security Class Initialized
DEBUG - 2020-07-04 21:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:46:16 --> Input Class Initialized
INFO - 2020-07-04 21:46:16 --> Language Class Initialized
INFO - 2020-07-04 21:46:16 --> Language Class Initialized
INFO - 2020-07-04 21:46:16 --> Config Class Initialized
INFO - 2020-07-04 21:46:16 --> Loader Class Initialized
INFO - 2020-07-04 21:46:16 --> Helper loaded: url_helper
INFO - 2020-07-04 21:46:16 --> Helper loaded: main_helper
INFO - 2020-07-04 21:46:16 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:46:16 --> Controller Class Initialized
INFO - 2020-07-04 21:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:46:16 --> Pagination Class Initialized
ERROR - 2020-07-04 21:46:16 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:46:16 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:46:16 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:46:16 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:46:16 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:46:16 --> Final output sent to browser
DEBUG - 2020-07-04 21:46:16 --> Total execution time: 0.0050
INFO - 2020-07-04 21:46:20 --> Config Class Initialized
INFO - 2020-07-04 21:46:20 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:46:20 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:46:20 --> Utf8 Class Initialized
INFO - 2020-07-04 21:46:20 --> URI Class Initialized
INFO - 2020-07-04 21:46:20 --> Router Class Initialized
INFO - 2020-07-04 21:46:20 --> Output Class Initialized
INFO - 2020-07-04 21:46:20 --> Security Class Initialized
DEBUG - 2020-07-04 21:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:46:20 --> Input Class Initialized
INFO - 2020-07-04 21:46:20 --> Language Class Initialized
INFO - 2020-07-04 21:46:20 --> Language Class Initialized
INFO - 2020-07-04 21:46:20 --> Config Class Initialized
INFO - 2020-07-04 21:46:20 --> Loader Class Initialized
INFO - 2020-07-04 21:46:20 --> Helper loaded: url_helper
INFO - 2020-07-04 21:46:20 --> Helper loaded: main_helper
INFO - 2020-07-04 21:46:20 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:46:20 --> Controller Class Initialized
INFO - 2020-07-04 21:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:46:20 --> Pagination Class Initialized
ERROR - 2020-07-04 21:46:20 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:46:20 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:46:20 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:46:20 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:46:20 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:46:20 --> Final output sent to browser
DEBUG - 2020-07-04 21:46:20 --> Total execution time: 0.0041
INFO - 2020-07-04 21:46:25 --> Config Class Initialized
INFO - 2020-07-04 21:46:25 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:46:25 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:46:25 --> Utf8 Class Initialized
INFO - 2020-07-04 21:46:25 --> URI Class Initialized
INFO - 2020-07-04 21:46:25 --> Router Class Initialized
INFO - 2020-07-04 21:46:25 --> Output Class Initialized
INFO - 2020-07-04 21:46:25 --> Security Class Initialized
DEBUG - 2020-07-04 21:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:46:25 --> Input Class Initialized
INFO - 2020-07-04 21:46:25 --> Language Class Initialized
INFO - 2020-07-04 21:46:25 --> Language Class Initialized
INFO - 2020-07-04 21:46:25 --> Config Class Initialized
INFO - 2020-07-04 21:46:25 --> Loader Class Initialized
INFO - 2020-07-04 21:46:25 --> Helper loaded: url_helper
INFO - 2020-07-04 21:46:25 --> Helper loaded: main_helper
INFO - 2020-07-04 21:46:25 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:46:25 --> Controller Class Initialized
INFO - 2020-07-04 21:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:46:25 --> Pagination Class Initialized
ERROR - 2020-07-04 21:46:25 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:46:25 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:46:25 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:46:25 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:46:25 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:46:25 --> Final output sent to browser
DEBUG - 2020-07-04 21:46:25 --> Total execution time: 0.0043
INFO - 2020-07-04 21:49:54 --> Config Class Initialized
INFO - 2020-07-04 21:49:54 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:49:54 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:49:54 --> Utf8 Class Initialized
INFO - 2020-07-04 21:49:54 --> URI Class Initialized
INFO - 2020-07-04 21:49:54 --> Router Class Initialized
INFO - 2020-07-04 21:49:54 --> Output Class Initialized
INFO - 2020-07-04 21:49:54 --> Security Class Initialized
DEBUG - 2020-07-04 21:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:49:54 --> Input Class Initialized
INFO - 2020-07-04 21:49:54 --> Language Class Initialized
INFO - 2020-07-04 21:49:54 --> Language Class Initialized
INFO - 2020-07-04 21:49:54 --> Config Class Initialized
INFO - 2020-07-04 21:49:54 --> Loader Class Initialized
INFO - 2020-07-04 21:49:54 --> Helper loaded: url_helper
INFO - 2020-07-04 21:49:54 --> Helper loaded: main_helper
INFO - 2020-07-04 21:49:54 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:49:54 --> Controller Class Initialized
INFO - 2020-07-04 21:49:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:49:54 --> Pagination Class Initialized
ERROR - 2020-07-04 21:49:54 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:49:54 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:49:54 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:49:56 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:49:56 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:49:56 --> Final output sent to browser
DEBUG - 2020-07-04 21:49:56 --> Total execution time: 1.4028
INFO - 2020-07-04 21:57:41 --> Config Class Initialized
INFO - 2020-07-04 21:57:41 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:57:41 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:57:41 --> Utf8 Class Initialized
INFO - 2020-07-04 21:57:41 --> URI Class Initialized
INFO - 2020-07-04 21:57:41 --> Router Class Initialized
INFO - 2020-07-04 21:57:41 --> Output Class Initialized
INFO - 2020-07-04 21:57:41 --> Security Class Initialized
DEBUG - 2020-07-04 21:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:57:41 --> Input Class Initialized
INFO - 2020-07-04 21:57:41 --> Language Class Initialized
INFO - 2020-07-04 21:57:41 --> Language Class Initialized
INFO - 2020-07-04 21:57:41 --> Config Class Initialized
INFO - 2020-07-04 21:57:41 --> Loader Class Initialized
INFO - 2020-07-04 21:57:41 --> Helper loaded: url_helper
INFO - 2020-07-04 21:57:41 --> Helper loaded: main_helper
INFO - 2020-07-04 21:57:41 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:57:41 --> Controller Class Initialized
INFO - 2020-07-04 21:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:57:41 --> Pagination Class Initialized
ERROR - 2020-07-04 21:57:41 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:57:41 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:57:41 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:57:42 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:57:42 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:57:42 --> Final output sent to browser
DEBUG - 2020-07-04 21:57:42 --> Total execution time: 1.4225
INFO - 2020-07-04 21:57:49 --> Config Class Initialized
INFO - 2020-07-04 21:57:49 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:57:49 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:57:49 --> Utf8 Class Initialized
INFO - 2020-07-04 21:58:06 --> Config Class Initialized
INFO - 2020-07-04 21:58:06 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:58:06 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:58:06 --> Utf8 Class Initialized
INFO - 2020-07-04 21:58:18 --> Config Class Initialized
INFO - 2020-07-04 21:58:18 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:58:18 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:58:18 --> Utf8 Class Initialized
INFO - 2020-07-04 21:58:18 --> URI Class Initialized
INFO - 2020-07-04 21:58:18 --> Router Class Initialized
INFO - 2020-07-04 21:58:18 --> Output Class Initialized
INFO - 2020-07-04 21:58:18 --> Security Class Initialized
DEBUG - 2020-07-04 21:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:58:18 --> Input Class Initialized
INFO - 2020-07-04 21:58:18 --> Language Class Initialized
INFO - 2020-07-04 21:58:18 --> Language Class Initialized
INFO - 2020-07-04 21:58:18 --> Config Class Initialized
INFO - 2020-07-04 21:58:18 --> Loader Class Initialized
INFO - 2020-07-04 21:58:18 --> Helper loaded: url_helper
INFO - 2020-07-04 21:58:18 --> Helper loaded: main_helper
INFO - 2020-07-04 21:58:18 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:58:18 --> Controller Class Initialized
INFO - 2020-07-04 21:58:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:58:18 --> Pagination Class Initialized
ERROR - 2020-07-04 21:58:18 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:58:18 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:58:18 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:58:18 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:58:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:58:18 --> Final output sent to browser
DEBUG - 2020-07-04 21:58:18 --> Total execution time: 0.0056
INFO - 2020-07-04 21:58:24 --> Config Class Initialized
INFO - 2020-07-04 21:58:24 --> Hooks Class Initialized
DEBUG - 2020-07-04 21:58:24 --> UTF-8 Support Enabled
INFO - 2020-07-04 21:58:24 --> Utf8 Class Initialized
INFO - 2020-07-04 21:58:24 --> URI Class Initialized
INFO - 2020-07-04 21:58:24 --> Router Class Initialized
INFO - 2020-07-04 21:58:24 --> Output Class Initialized
INFO - 2020-07-04 21:58:24 --> Security Class Initialized
DEBUG - 2020-07-04 21:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 21:58:24 --> Input Class Initialized
INFO - 2020-07-04 21:58:24 --> Language Class Initialized
INFO - 2020-07-04 21:58:24 --> Language Class Initialized
INFO - 2020-07-04 21:58:24 --> Config Class Initialized
INFO - 2020-07-04 21:58:24 --> Loader Class Initialized
INFO - 2020-07-04 21:58:24 --> Helper loaded: url_helper
INFO - 2020-07-04 21:58:24 --> Helper loaded: main_helper
INFO - 2020-07-04 21:58:24 --> Database Driver Class Initialized
DEBUG - 2020-07-04 21:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 21:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 21:58:24 --> Controller Class Initialized
INFO - 2020-07-04 21:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 21:58:24 --> Pagination Class Initialized
ERROR - 2020-07-04 21:58:24 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 21:58:24 --> Helper loaded: file_helper
DEBUG - 2020-07-04 21:58:24 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 21:58:24 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 21:58:24 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 21:58:24 --> Final output sent to browser
DEBUG - 2020-07-04 21:58:24 --> Total execution time: 0.0055
INFO - 2020-07-04 23:12:24 --> Config Class Initialized
INFO - 2020-07-04 23:12:24 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:12:24 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:12:24 --> Utf8 Class Initialized
INFO - 2020-07-04 23:12:24 --> URI Class Initialized
INFO - 2020-07-04 23:12:24 --> Router Class Initialized
INFO - 2020-07-04 23:12:24 --> Output Class Initialized
INFO - 2020-07-04 23:12:24 --> Security Class Initialized
DEBUG - 2020-07-04 23:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:12:24 --> Input Class Initialized
INFO - 2020-07-04 23:12:24 --> Language Class Initialized
INFO - 2020-07-04 23:12:24 --> Language Class Initialized
INFO - 2020-07-04 23:12:24 --> Config Class Initialized
INFO - 2020-07-04 23:12:24 --> Loader Class Initialized
INFO - 2020-07-04 23:12:24 --> Helper loaded: url_helper
INFO - 2020-07-04 23:12:24 --> Helper loaded: main_helper
INFO - 2020-07-04 23:12:24 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:12:24 --> Controller Class Initialized
INFO - 2020-07-04 23:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:12:24 --> Pagination Class Initialized
ERROR - 2020-07-04 23:12:24 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:12:24 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:12:24 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:12:26 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:12:26 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:12:26 --> Final output sent to browser
DEBUG - 2020-07-04 23:12:26 --> Total execution time: 1.4039
INFO - 2020-07-04 23:12:32 --> Config Class Initialized
INFO - 2020-07-04 23:12:32 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:12:32 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:12:32 --> Utf8 Class Initialized
INFO - 2020-07-04 23:12:32 --> URI Class Initialized
INFO - 2020-07-04 23:12:32 --> Router Class Initialized
INFO - 2020-07-04 23:12:32 --> Output Class Initialized
INFO - 2020-07-04 23:12:32 --> Security Class Initialized
DEBUG - 2020-07-04 23:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:12:32 --> Input Class Initialized
INFO - 2020-07-04 23:12:32 --> Language Class Initialized
INFO - 2020-07-04 23:12:32 --> Language Class Initialized
INFO - 2020-07-04 23:12:32 --> Config Class Initialized
INFO - 2020-07-04 23:12:32 --> Loader Class Initialized
INFO - 2020-07-04 23:12:32 --> Helper loaded: url_helper
INFO - 2020-07-04 23:12:32 --> Helper loaded: main_helper
INFO - 2020-07-04 23:12:32 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:12:32 --> Controller Class Initialized
INFO - 2020-07-04 23:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:12:32 --> Pagination Class Initialized
ERROR - 2020-07-04 23:12:32 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:12:32 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:12:32 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:12:32 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:12:32 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:12:32 --> Final output sent to browser
DEBUG - 2020-07-04 23:12:32 --> Total execution time: 0.0084
INFO - 2020-07-04 23:12:41 --> Config Class Initialized
INFO - 2020-07-04 23:12:41 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:12:41 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:12:41 --> Utf8 Class Initialized
INFO - 2020-07-04 23:12:41 --> URI Class Initialized
INFO - 2020-07-04 23:12:41 --> Router Class Initialized
INFO - 2020-07-04 23:12:41 --> Output Class Initialized
INFO - 2020-07-04 23:12:41 --> Security Class Initialized
DEBUG - 2020-07-04 23:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:12:41 --> Input Class Initialized
INFO - 2020-07-04 23:12:41 --> Language Class Initialized
INFO - 2020-07-04 23:12:41 --> Language Class Initialized
INFO - 2020-07-04 23:12:41 --> Config Class Initialized
INFO - 2020-07-04 23:12:41 --> Loader Class Initialized
INFO - 2020-07-04 23:12:41 --> Helper loaded: url_helper
INFO - 2020-07-04 23:12:41 --> Helper loaded: main_helper
INFO - 2020-07-04 23:12:41 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:12:41 --> Controller Class Initialized
INFO - 2020-07-04 23:12:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:12:41 --> Pagination Class Initialized
ERROR - 2020-07-04 23:12:41 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:12:41 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:12:41 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:12:41 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:12:41 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:12:41 --> Final output sent to browser
DEBUG - 2020-07-04 23:12:41 --> Total execution time: 0.0036
INFO - 2020-07-04 23:12:47 --> Config Class Initialized
INFO - 2020-07-04 23:12:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:12:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:12:47 --> Utf8 Class Initialized
INFO - 2020-07-04 23:12:47 --> URI Class Initialized
INFO - 2020-07-04 23:12:47 --> Router Class Initialized
INFO - 2020-07-04 23:12:47 --> Output Class Initialized
INFO - 2020-07-04 23:12:47 --> Security Class Initialized
DEBUG - 2020-07-04 23:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:12:47 --> Input Class Initialized
INFO - 2020-07-04 23:12:47 --> Language Class Initialized
INFO - 2020-07-04 23:12:47 --> Language Class Initialized
INFO - 2020-07-04 23:12:47 --> Config Class Initialized
INFO - 2020-07-04 23:12:47 --> Loader Class Initialized
INFO - 2020-07-04 23:12:47 --> Helper loaded: url_helper
INFO - 2020-07-04 23:12:47 --> Helper loaded: main_helper
INFO - 2020-07-04 23:12:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:12:47 --> Controller Class Initialized
INFO - 2020-07-04 23:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:12:47 --> Pagination Class Initialized
ERROR - 2020-07-04 23:12:47 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:12:47 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:12:47 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:12:47 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:12:47 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:12:47 --> Final output sent to browser
DEBUG - 2020-07-04 23:12:47 --> Total execution time: 0.0049
INFO - 2020-07-04 23:12:51 --> Config Class Initialized
INFO - 2020-07-04 23:12:51 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:12:51 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:12:51 --> Utf8 Class Initialized
INFO - 2020-07-04 23:12:51 --> URI Class Initialized
INFO - 2020-07-04 23:12:51 --> Router Class Initialized
INFO - 2020-07-04 23:12:51 --> Output Class Initialized
INFO - 2020-07-04 23:12:51 --> Security Class Initialized
DEBUG - 2020-07-04 23:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:12:51 --> Input Class Initialized
INFO - 2020-07-04 23:12:51 --> Language Class Initialized
INFO - 2020-07-04 23:12:51 --> Language Class Initialized
INFO - 2020-07-04 23:12:51 --> Config Class Initialized
INFO - 2020-07-04 23:12:51 --> Loader Class Initialized
INFO - 2020-07-04 23:12:51 --> Helper loaded: url_helper
INFO - 2020-07-04 23:12:51 --> Helper loaded: main_helper
INFO - 2020-07-04 23:12:51 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:12:51 --> Controller Class Initialized
INFO - 2020-07-04 23:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:12:51 --> Pagination Class Initialized
ERROR - 2020-07-04 23:12:51 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:12:51 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:12:51 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:12:51 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:12:51 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:12:51 --> Final output sent to browser
DEBUG - 2020-07-04 23:12:51 --> Total execution time: 0.0041
INFO - 2020-07-04 23:13:23 --> Config Class Initialized
INFO - 2020-07-04 23:13:23 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:13:23 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:13:23 --> Utf8 Class Initialized
INFO - 2020-07-04 23:13:23 --> URI Class Initialized
INFO - 2020-07-04 23:13:23 --> Router Class Initialized
INFO - 2020-07-04 23:13:23 --> Output Class Initialized
INFO - 2020-07-04 23:13:23 --> Security Class Initialized
DEBUG - 2020-07-04 23:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:13:23 --> Input Class Initialized
INFO - 2020-07-04 23:13:23 --> Language Class Initialized
INFO - 2020-07-04 23:13:23 --> Language Class Initialized
INFO - 2020-07-04 23:13:23 --> Config Class Initialized
INFO - 2020-07-04 23:13:23 --> Loader Class Initialized
INFO - 2020-07-04 23:13:23 --> Helper loaded: url_helper
INFO - 2020-07-04 23:13:23 --> Helper loaded: main_helper
INFO - 2020-07-04 23:13:23 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:13:23 --> Controller Class Initialized
INFO - 2020-07-04 23:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:13:23 --> Pagination Class Initialized
ERROR - 2020-07-04 23:13:23 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:13:23 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:13:23 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:13:23 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:13:23 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:13:23 --> Final output sent to browser
DEBUG - 2020-07-04 23:13:23 --> Total execution time: 0.0057
INFO - 2020-07-04 23:13:39 --> Config Class Initialized
INFO - 2020-07-04 23:13:39 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:13:39 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:13:39 --> Utf8 Class Initialized
INFO - 2020-07-04 23:13:39 --> URI Class Initialized
INFO - 2020-07-04 23:13:39 --> Router Class Initialized
INFO - 2020-07-04 23:13:39 --> Output Class Initialized
INFO - 2020-07-04 23:13:39 --> Security Class Initialized
DEBUG - 2020-07-04 23:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:13:39 --> Input Class Initialized
INFO - 2020-07-04 23:13:39 --> Language Class Initialized
INFO - 2020-07-04 23:13:39 --> Language Class Initialized
INFO - 2020-07-04 23:13:39 --> Config Class Initialized
INFO - 2020-07-04 23:13:39 --> Loader Class Initialized
INFO - 2020-07-04 23:13:39 --> Helper loaded: url_helper
INFO - 2020-07-04 23:13:39 --> Helper loaded: main_helper
INFO - 2020-07-04 23:13:39 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:13:39 --> Controller Class Initialized
INFO - 2020-07-04 23:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:13:39 --> Pagination Class Initialized
ERROR - 2020-07-04 23:13:39 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:13:39 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:13:39 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:13:39 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:13:39 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:13:39 --> Final output sent to browser
DEBUG - 2020-07-04 23:13:39 --> Total execution time: 0.0084
INFO - 2020-07-04 23:13:44 --> Config Class Initialized
INFO - 2020-07-04 23:13:44 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:13:44 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:13:44 --> Utf8 Class Initialized
INFO - 2020-07-04 23:13:44 --> URI Class Initialized
INFO - 2020-07-04 23:13:44 --> Router Class Initialized
INFO - 2020-07-04 23:13:44 --> Output Class Initialized
INFO - 2020-07-04 23:13:44 --> Security Class Initialized
DEBUG - 2020-07-04 23:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:13:44 --> Input Class Initialized
INFO - 2020-07-04 23:13:44 --> Language Class Initialized
INFO - 2020-07-04 23:13:44 --> Language Class Initialized
INFO - 2020-07-04 23:13:44 --> Config Class Initialized
INFO - 2020-07-04 23:13:44 --> Loader Class Initialized
INFO - 2020-07-04 23:13:44 --> Helper loaded: url_helper
INFO - 2020-07-04 23:13:44 --> Helper loaded: main_helper
INFO - 2020-07-04 23:13:44 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:13:44 --> Controller Class Initialized
INFO - 2020-07-04 23:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:13:44 --> Pagination Class Initialized
ERROR - 2020-07-04 23:13:44 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:13:44 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:13:44 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:13:44 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:13:44 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:13:44 --> Final output sent to browser
DEBUG - 2020-07-04 23:13:44 --> Total execution time: 0.0049
INFO - 2020-07-04 23:14:01 --> Config Class Initialized
INFO - 2020-07-04 23:14:01 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:14:01 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:14:01 --> Utf8 Class Initialized
INFO - 2020-07-04 23:14:01 --> URI Class Initialized
INFO - 2020-07-04 23:14:01 --> Router Class Initialized
INFO - 2020-07-04 23:14:01 --> Output Class Initialized
INFO - 2020-07-04 23:14:01 --> Security Class Initialized
DEBUG - 2020-07-04 23:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:14:01 --> Input Class Initialized
INFO - 2020-07-04 23:14:01 --> Language Class Initialized
INFO - 2020-07-04 23:14:01 --> Language Class Initialized
INFO - 2020-07-04 23:14:01 --> Config Class Initialized
INFO - 2020-07-04 23:14:01 --> Loader Class Initialized
INFO - 2020-07-04 23:14:01 --> Helper loaded: url_helper
INFO - 2020-07-04 23:14:01 --> Helper loaded: main_helper
INFO - 2020-07-04 23:14:01 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:14:01 --> Controller Class Initialized
INFO - 2020-07-04 23:14:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:14:01 --> Pagination Class Initialized
ERROR - 2020-07-04 23:14:01 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:14:01 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:14:01 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:14:01 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:14:01 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:14:01 --> Final output sent to browser
DEBUG - 2020-07-04 23:14:01 --> Total execution time: 0.0058
INFO - 2020-07-04 23:14:07 --> Config Class Initialized
INFO - 2020-07-04 23:14:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:14:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:14:07 --> Utf8 Class Initialized
INFO - 2020-07-04 23:14:07 --> URI Class Initialized
INFO - 2020-07-04 23:14:07 --> Router Class Initialized
INFO - 2020-07-04 23:14:07 --> Output Class Initialized
INFO - 2020-07-04 23:14:07 --> Security Class Initialized
DEBUG - 2020-07-04 23:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:14:07 --> Input Class Initialized
INFO - 2020-07-04 23:14:07 --> Language Class Initialized
INFO - 2020-07-04 23:14:07 --> Language Class Initialized
INFO - 2020-07-04 23:14:07 --> Config Class Initialized
INFO - 2020-07-04 23:14:07 --> Loader Class Initialized
INFO - 2020-07-04 23:14:07 --> Helper loaded: url_helper
INFO - 2020-07-04 23:14:07 --> Helper loaded: main_helper
INFO - 2020-07-04 23:14:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:14:07 --> Controller Class Initialized
INFO - 2020-07-04 23:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:14:07 --> Pagination Class Initialized
ERROR - 2020-07-04 23:14:07 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:14:07 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:14:07 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:14:07 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:14:07 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:14:07 --> Final output sent to browser
DEBUG - 2020-07-04 23:14:07 --> Total execution time: 0.0046
INFO - 2020-07-04 23:14:12 --> Config Class Initialized
INFO - 2020-07-04 23:14:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:14:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:14:12 --> Utf8 Class Initialized
INFO - 2020-07-04 23:14:12 --> URI Class Initialized
INFO - 2020-07-04 23:14:12 --> Router Class Initialized
INFO - 2020-07-04 23:14:12 --> Output Class Initialized
INFO - 2020-07-04 23:14:12 --> Security Class Initialized
DEBUG - 2020-07-04 23:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:14:12 --> Input Class Initialized
INFO - 2020-07-04 23:14:12 --> Language Class Initialized
INFO - 2020-07-04 23:14:12 --> Language Class Initialized
INFO - 2020-07-04 23:14:12 --> Config Class Initialized
INFO - 2020-07-04 23:14:12 --> Loader Class Initialized
INFO - 2020-07-04 23:14:12 --> Helper loaded: url_helper
INFO - 2020-07-04 23:14:12 --> Helper loaded: main_helper
INFO - 2020-07-04 23:14:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:14:12 --> Controller Class Initialized
INFO - 2020-07-04 23:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:14:12 --> Pagination Class Initialized
ERROR - 2020-07-04 23:14:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:14:12 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:14:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:14:12 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:14:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:14:12 --> Final output sent to browser
DEBUG - 2020-07-04 23:14:12 --> Total execution time: 0.0039
INFO - 2020-07-04 23:15:28 --> Config Class Initialized
INFO - 2020-07-04 23:15:28 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:15:28 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:15:28 --> Utf8 Class Initialized
INFO - 2020-07-04 23:15:28 --> URI Class Initialized
INFO - 2020-07-04 23:15:28 --> Router Class Initialized
INFO - 2020-07-04 23:15:28 --> Output Class Initialized
INFO - 2020-07-04 23:15:28 --> Security Class Initialized
DEBUG - 2020-07-04 23:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:15:28 --> Input Class Initialized
INFO - 2020-07-04 23:15:28 --> Language Class Initialized
INFO - 2020-07-04 23:15:28 --> Language Class Initialized
INFO - 2020-07-04 23:15:28 --> Config Class Initialized
INFO - 2020-07-04 23:15:28 --> Loader Class Initialized
INFO - 2020-07-04 23:15:28 --> Helper loaded: url_helper
INFO - 2020-07-04 23:15:28 --> Helper loaded: main_helper
INFO - 2020-07-04 23:15:28 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:15:28 --> Controller Class Initialized
INFO - 2020-07-04 23:15:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:15:28 --> Pagination Class Initialized
ERROR - 2020-07-04 23:15:28 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:15:28 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:15:28 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:15:29 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:15:29 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:15:29 --> Final output sent to browser
DEBUG - 2020-07-04 23:15:29 --> Total execution time: 0.0085
INFO - 2020-07-04 23:16:02 --> Config Class Initialized
INFO - 2020-07-04 23:16:02 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:16:02 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:16:02 --> Utf8 Class Initialized
INFO - 2020-07-04 23:16:02 --> URI Class Initialized
INFO - 2020-07-04 23:16:02 --> Router Class Initialized
INFO - 2020-07-04 23:16:02 --> Output Class Initialized
INFO - 2020-07-04 23:16:02 --> Security Class Initialized
DEBUG - 2020-07-04 23:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:16:02 --> Input Class Initialized
INFO - 2020-07-04 23:16:02 --> Language Class Initialized
INFO - 2020-07-04 23:16:02 --> Language Class Initialized
INFO - 2020-07-04 23:16:02 --> Config Class Initialized
INFO - 2020-07-04 23:16:02 --> Loader Class Initialized
INFO - 2020-07-04 23:16:02 --> Helper loaded: url_helper
INFO - 2020-07-04 23:16:02 --> Helper loaded: main_helper
INFO - 2020-07-04 23:16:02 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:16:02 --> Controller Class Initialized
INFO - 2020-07-04 23:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:16:02 --> Pagination Class Initialized
ERROR - 2020-07-04 23:16:02 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:16:02 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:16:02 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:16:02 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:16:02 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:16:02 --> Final output sent to browser
DEBUG - 2020-07-04 23:16:02 --> Total execution time: 0.0079
INFO - 2020-07-04 23:17:01 --> Config Class Initialized
INFO - 2020-07-04 23:17:01 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:17:01 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:17:01 --> Utf8 Class Initialized
INFO - 2020-07-04 23:17:01 --> URI Class Initialized
INFO - 2020-07-04 23:17:01 --> Router Class Initialized
INFO - 2020-07-04 23:17:01 --> Output Class Initialized
INFO - 2020-07-04 23:17:01 --> Security Class Initialized
DEBUG - 2020-07-04 23:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:17:01 --> Input Class Initialized
INFO - 2020-07-04 23:17:01 --> Language Class Initialized
INFO - 2020-07-04 23:17:01 --> Language Class Initialized
INFO - 2020-07-04 23:17:01 --> Config Class Initialized
INFO - 2020-07-04 23:17:01 --> Loader Class Initialized
INFO - 2020-07-04 23:17:01 --> Helper loaded: url_helper
INFO - 2020-07-04 23:17:01 --> Helper loaded: main_helper
INFO - 2020-07-04 23:17:01 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:17:01 --> Controller Class Initialized
INFO - 2020-07-04 23:17:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:17:01 --> Pagination Class Initialized
ERROR - 2020-07-04 23:17:01 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:17:01 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:17:01 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
INFO - 2020-07-04 23:17:33 --> Config Class Initialized
INFO - 2020-07-04 23:17:33 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:17:33 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:17:33 --> Utf8 Class Initialized
INFO - 2020-07-04 23:17:33 --> URI Class Initialized
INFO - 2020-07-04 23:17:33 --> Router Class Initialized
INFO - 2020-07-04 23:17:33 --> Output Class Initialized
INFO - 2020-07-04 23:17:33 --> Security Class Initialized
DEBUG - 2020-07-04 23:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:17:33 --> Input Class Initialized
INFO - 2020-07-04 23:17:33 --> Language Class Initialized
INFO - 2020-07-04 23:17:33 --> Language Class Initialized
INFO - 2020-07-04 23:17:33 --> Config Class Initialized
INFO - 2020-07-04 23:17:33 --> Loader Class Initialized
INFO - 2020-07-04 23:17:33 --> Helper loaded: url_helper
INFO - 2020-07-04 23:17:33 --> Helper loaded: main_helper
INFO - 2020-07-04 23:17:33 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:17:33 --> Controller Class Initialized
INFO - 2020-07-04 23:17:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:17:33 --> Pagination Class Initialized
ERROR - 2020-07-04 23:17:33 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:17:33 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:17:33 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:17:35 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:17:35 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:17:35 --> Final output sent to browser
DEBUG - 2020-07-04 23:17:35 --> Total execution time: 1.3484
INFO - 2020-07-04 23:17:51 --> Config Class Initialized
INFO - 2020-07-04 23:17:51 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:17:51 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:17:51 --> Utf8 Class Initialized
INFO - 2020-07-04 23:17:51 --> URI Class Initialized
INFO - 2020-07-04 23:17:51 --> Router Class Initialized
INFO - 2020-07-04 23:17:51 --> Output Class Initialized
INFO - 2020-07-04 23:17:51 --> Security Class Initialized
DEBUG - 2020-07-04 23:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:17:51 --> Input Class Initialized
INFO - 2020-07-04 23:17:51 --> Language Class Initialized
INFO - 2020-07-04 23:17:51 --> Language Class Initialized
INFO - 2020-07-04 23:17:51 --> Config Class Initialized
INFO - 2020-07-04 23:17:51 --> Loader Class Initialized
INFO - 2020-07-04 23:17:51 --> Helper loaded: url_helper
INFO - 2020-07-04 23:17:51 --> Helper loaded: main_helper
INFO - 2020-07-04 23:17:51 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:17:51 --> Controller Class Initialized
INFO - 2020-07-04 23:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:17:51 --> Pagination Class Initialized
ERROR - 2020-07-04 23:17:51 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:17:51 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:17:51 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:17:51 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:17:51 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:17:51 --> Final output sent to browser
DEBUG - 2020-07-04 23:17:51 --> Total execution time: 0.0044
INFO - 2020-07-04 23:20:43 --> Config Class Initialized
INFO - 2020-07-04 23:20:43 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:20:43 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:20:43 --> Utf8 Class Initialized
INFO - 2020-07-04 23:20:43 --> URI Class Initialized
INFO - 2020-07-04 23:20:43 --> Router Class Initialized
INFO - 2020-07-04 23:20:43 --> Output Class Initialized
INFO - 2020-07-04 23:20:43 --> Security Class Initialized
DEBUG - 2020-07-04 23:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:20:43 --> Input Class Initialized
INFO - 2020-07-04 23:20:43 --> Language Class Initialized
INFO - 2020-07-04 23:20:43 --> Language Class Initialized
INFO - 2020-07-04 23:20:43 --> Config Class Initialized
INFO - 2020-07-04 23:20:43 --> Loader Class Initialized
INFO - 2020-07-04 23:20:43 --> Helper loaded: url_helper
INFO - 2020-07-04 23:20:43 --> Helper loaded: main_helper
INFO - 2020-07-04 23:20:43 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:20:43 --> Controller Class Initialized
INFO - 2020-07-04 23:20:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:20:43 --> Pagination Class Initialized
ERROR - 2020-07-04 23:20:43 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:20:43 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:20:43 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:20:43 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:20:43 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:20:43 --> Final output sent to browser
DEBUG - 2020-07-04 23:20:43 --> Total execution time: 0.0050
INFO - 2020-07-04 23:20:45 --> Config Class Initialized
INFO - 2020-07-04 23:20:45 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:20:45 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:20:45 --> Utf8 Class Initialized
INFO - 2020-07-04 23:20:45 --> URI Class Initialized
INFO - 2020-07-04 23:20:45 --> Router Class Initialized
INFO - 2020-07-04 23:20:45 --> Output Class Initialized
INFO - 2020-07-04 23:20:45 --> Security Class Initialized
DEBUG - 2020-07-04 23:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:20:45 --> Input Class Initialized
INFO - 2020-07-04 23:20:45 --> Language Class Initialized
INFO - 2020-07-04 23:20:45 --> Language Class Initialized
INFO - 2020-07-04 23:20:45 --> Config Class Initialized
INFO - 2020-07-04 23:20:45 --> Loader Class Initialized
INFO - 2020-07-04 23:20:45 --> Helper loaded: url_helper
INFO - 2020-07-04 23:20:45 --> Helper loaded: main_helper
INFO - 2020-07-04 23:20:45 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:20:45 --> Controller Class Initialized
INFO - 2020-07-04 23:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:20:45 --> Pagination Class Initialized
ERROR - 2020-07-04 23:20:45 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:20:45 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:20:45 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:20:45 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:20:45 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:20:45 --> Final output sent to browser
DEBUG - 2020-07-04 23:20:45 --> Total execution time: 0.0042
INFO - 2020-07-04 23:20:58 --> Config Class Initialized
INFO - 2020-07-04 23:20:58 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:20:58 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:20:58 --> Utf8 Class Initialized
INFO - 2020-07-04 23:20:58 --> URI Class Initialized
INFO - 2020-07-04 23:20:58 --> Router Class Initialized
INFO - 2020-07-04 23:20:58 --> Output Class Initialized
INFO - 2020-07-04 23:20:58 --> Security Class Initialized
DEBUG - 2020-07-04 23:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:20:58 --> Input Class Initialized
INFO - 2020-07-04 23:20:58 --> Language Class Initialized
INFO - 2020-07-04 23:20:58 --> Language Class Initialized
INFO - 2020-07-04 23:20:58 --> Config Class Initialized
INFO - 2020-07-04 23:20:58 --> Loader Class Initialized
INFO - 2020-07-04 23:20:58 --> Helper loaded: url_helper
INFO - 2020-07-04 23:20:58 --> Helper loaded: main_helper
INFO - 2020-07-04 23:20:58 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:20:58 --> Controller Class Initialized
INFO - 2020-07-04 23:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:20:58 --> Pagination Class Initialized
ERROR - 2020-07-04 23:20:58 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:20:58 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:20:58 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:20:58 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:20:58 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:20:58 --> Final output sent to browser
DEBUG - 2020-07-04 23:20:58 --> Total execution time: 0.0040
INFO - 2020-07-04 23:22:22 --> Config Class Initialized
INFO - 2020-07-04 23:22:22 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:22:22 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:22:22 --> Utf8 Class Initialized
INFO - 2020-07-04 23:22:22 --> URI Class Initialized
INFO - 2020-07-04 23:22:22 --> Router Class Initialized
INFO - 2020-07-04 23:22:22 --> Output Class Initialized
INFO - 2020-07-04 23:22:22 --> Security Class Initialized
DEBUG - 2020-07-04 23:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:22:22 --> Input Class Initialized
INFO - 2020-07-04 23:22:22 --> Language Class Initialized
INFO - 2020-07-04 23:22:22 --> Language Class Initialized
INFO - 2020-07-04 23:22:22 --> Config Class Initialized
INFO - 2020-07-04 23:22:22 --> Loader Class Initialized
INFO - 2020-07-04 23:22:22 --> Helper loaded: url_helper
INFO - 2020-07-04 23:22:22 --> Helper loaded: main_helper
INFO - 2020-07-04 23:22:22 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:22:22 --> Controller Class Initialized
INFO - 2020-07-04 23:22:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:22:22 --> Pagination Class Initialized
ERROR - 2020-07-04 23:22:22 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:22:22 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:22:22 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:22:22 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:22:22 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:22:22 --> Final output sent to browser
DEBUG - 2020-07-04 23:22:22 --> Total execution time: 0.0070
INFO - 2020-07-04 23:22:35 --> Config Class Initialized
INFO - 2020-07-04 23:22:35 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:22:35 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:22:35 --> Utf8 Class Initialized
INFO - 2020-07-04 23:22:35 --> URI Class Initialized
INFO - 2020-07-04 23:22:35 --> Router Class Initialized
INFO - 2020-07-04 23:22:35 --> Output Class Initialized
INFO - 2020-07-04 23:22:35 --> Security Class Initialized
DEBUG - 2020-07-04 23:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:22:35 --> Input Class Initialized
INFO - 2020-07-04 23:22:35 --> Language Class Initialized
INFO - 2020-07-04 23:22:35 --> Language Class Initialized
INFO - 2020-07-04 23:22:35 --> Config Class Initialized
INFO - 2020-07-04 23:22:35 --> Loader Class Initialized
INFO - 2020-07-04 23:22:35 --> Helper loaded: url_helper
INFO - 2020-07-04 23:22:35 --> Helper loaded: main_helper
INFO - 2020-07-04 23:22:35 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:22:35 --> Controller Class Initialized
INFO - 2020-07-04 23:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:22:35 --> Pagination Class Initialized
ERROR - 2020-07-04 23:22:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:22:35 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:22:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:22:35 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:22:35 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:22:35 --> Final output sent to browser
DEBUG - 2020-07-04 23:22:35 --> Total execution time: 0.0056
INFO - 2020-07-04 23:22:43 --> Config Class Initialized
INFO - 2020-07-04 23:22:43 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:22:43 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:22:43 --> Utf8 Class Initialized
INFO - 2020-07-04 23:22:43 --> URI Class Initialized
INFO - 2020-07-04 23:22:43 --> Router Class Initialized
INFO - 2020-07-04 23:22:43 --> Output Class Initialized
INFO - 2020-07-04 23:22:43 --> Security Class Initialized
DEBUG - 2020-07-04 23:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:22:43 --> Input Class Initialized
INFO - 2020-07-04 23:22:43 --> Language Class Initialized
INFO - 2020-07-04 23:22:43 --> Language Class Initialized
INFO - 2020-07-04 23:22:43 --> Config Class Initialized
INFO - 2020-07-04 23:22:43 --> Loader Class Initialized
INFO - 2020-07-04 23:22:43 --> Helper loaded: url_helper
INFO - 2020-07-04 23:22:43 --> Helper loaded: main_helper
INFO - 2020-07-04 23:22:43 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:22:43 --> Controller Class Initialized
INFO - 2020-07-04 23:22:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:22:43 --> Pagination Class Initialized
ERROR - 2020-07-04 23:22:43 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:22:43 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:22:43 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:22:44 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:22:44 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:22:44 --> Final output sent to browser
DEBUG - 2020-07-04 23:22:44 --> Total execution time: 1.3701
INFO - 2020-07-04 23:22:52 --> Config Class Initialized
INFO - 2020-07-04 23:22:52 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:22:52 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:22:52 --> Utf8 Class Initialized
INFO - 2020-07-04 23:22:52 --> URI Class Initialized
INFO - 2020-07-04 23:22:52 --> Router Class Initialized
INFO - 2020-07-04 23:22:52 --> Output Class Initialized
INFO - 2020-07-04 23:22:52 --> Security Class Initialized
DEBUG - 2020-07-04 23:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:22:52 --> Input Class Initialized
INFO - 2020-07-04 23:22:52 --> Language Class Initialized
INFO - 2020-07-04 23:22:52 --> Language Class Initialized
INFO - 2020-07-04 23:22:52 --> Config Class Initialized
INFO - 2020-07-04 23:22:52 --> Loader Class Initialized
INFO - 2020-07-04 23:22:52 --> Helper loaded: url_helper
INFO - 2020-07-04 23:22:52 --> Helper loaded: main_helper
INFO - 2020-07-04 23:22:52 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:22:52 --> Controller Class Initialized
INFO - 2020-07-04 23:22:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:22:52 --> Pagination Class Initialized
ERROR - 2020-07-04 23:22:52 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:22:52 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:22:52 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:22:52 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:22:52 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:22:52 --> Final output sent to browser
DEBUG - 2020-07-04 23:22:52 --> Total execution time: 0.0045
INFO - 2020-07-04 23:23:06 --> Config Class Initialized
INFO - 2020-07-04 23:23:06 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:23:06 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:23:06 --> Utf8 Class Initialized
INFO - 2020-07-04 23:23:06 --> URI Class Initialized
INFO - 2020-07-04 23:23:06 --> Router Class Initialized
INFO - 2020-07-04 23:23:06 --> Output Class Initialized
INFO - 2020-07-04 23:23:06 --> Security Class Initialized
DEBUG - 2020-07-04 23:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:23:06 --> Input Class Initialized
INFO - 2020-07-04 23:23:06 --> Language Class Initialized
INFO - 2020-07-04 23:23:06 --> Language Class Initialized
INFO - 2020-07-04 23:23:06 --> Config Class Initialized
INFO - 2020-07-04 23:23:06 --> Loader Class Initialized
INFO - 2020-07-04 23:23:06 --> Helper loaded: url_helper
INFO - 2020-07-04 23:23:06 --> Helper loaded: main_helper
INFO - 2020-07-04 23:23:06 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:23:06 --> Controller Class Initialized
INFO - 2020-07-04 23:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:23:06 --> Pagination Class Initialized
ERROR - 2020-07-04 23:23:06 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:23:06 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:23:06 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:23:06 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:23:06 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:23:06 --> Final output sent to browser
DEBUG - 2020-07-04 23:23:06 --> Total execution time: 0.0044
INFO - 2020-07-04 23:23:10 --> Config Class Initialized
INFO - 2020-07-04 23:23:10 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:23:10 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:23:10 --> Utf8 Class Initialized
INFO - 2020-07-04 23:23:10 --> URI Class Initialized
INFO - 2020-07-04 23:23:10 --> Router Class Initialized
INFO - 2020-07-04 23:23:10 --> Output Class Initialized
INFO - 2020-07-04 23:23:10 --> Security Class Initialized
DEBUG - 2020-07-04 23:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:23:10 --> Input Class Initialized
INFO - 2020-07-04 23:23:10 --> Language Class Initialized
INFO - 2020-07-04 23:23:10 --> Language Class Initialized
INFO - 2020-07-04 23:23:10 --> Config Class Initialized
INFO - 2020-07-04 23:23:10 --> Loader Class Initialized
INFO - 2020-07-04 23:23:10 --> Helper loaded: url_helper
INFO - 2020-07-04 23:23:10 --> Helper loaded: main_helper
INFO - 2020-07-04 23:23:10 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:23:10 --> Controller Class Initialized
INFO - 2020-07-04 23:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:23:10 --> Pagination Class Initialized
ERROR - 2020-07-04 23:23:10 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:23:10 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:23:10 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:23:10 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:23:10 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:23:10 --> Final output sent to browser
DEBUG - 2020-07-04 23:23:10 --> Total execution time: 0.0049
INFO - 2020-07-04 23:23:15 --> Config Class Initialized
INFO - 2020-07-04 23:23:15 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:23:15 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:23:15 --> Utf8 Class Initialized
INFO - 2020-07-04 23:23:15 --> URI Class Initialized
INFO - 2020-07-04 23:23:15 --> Router Class Initialized
INFO - 2020-07-04 23:23:15 --> Output Class Initialized
INFO - 2020-07-04 23:23:15 --> Security Class Initialized
DEBUG - 2020-07-04 23:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:23:15 --> Input Class Initialized
INFO - 2020-07-04 23:23:15 --> Language Class Initialized
INFO - 2020-07-04 23:23:15 --> Language Class Initialized
INFO - 2020-07-04 23:23:15 --> Config Class Initialized
INFO - 2020-07-04 23:23:15 --> Loader Class Initialized
INFO - 2020-07-04 23:23:15 --> Helper loaded: url_helper
INFO - 2020-07-04 23:23:15 --> Helper loaded: main_helper
INFO - 2020-07-04 23:23:15 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:23:15 --> Controller Class Initialized
INFO - 2020-07-04 23:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:23:15 --> Pagination Class Initialized
ERROR - 2020-07-04 23:23:15 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:23:15 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:23:15 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:23:15 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:23:15 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:23:15 --> Final output sent to browser
DEBUG - 2020-07-04 23:23:15 --> Total execution time: 0.0041
INFO - 2020-07-04 23:24:21 --> Config Class Initialized
INFO - 2020-07-04 23:24:21 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:24:21 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:24:21 --> Utf8 Class Initialized
INFO - 2020-07-04 23:24:21 --> URI Class Initialized
INFO - 2020-07-04 23:24:21 --> Router Class Initialized
INFO - 2020-07-04 23:24:21 --> Output Class Initialized
INFO - 2020-07-04 23:24:21 --> Security Class Initialized
DEBUG - 2020-07-04 23:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:24:21 --> Input Class Initialized
INFO - 2020-07-04 23:24:21 --> Language Class Initialized
INFO - 2020-07-04 23:24:21 --> Language Class Initialized
INFO - 2020-07-04 23:24:21 --> Config Class Initialized
INFO - 2020-07-04 23:24:21 --> Loader Class Initialized
INFO - 2020-07-04 23:24:21 --> Helper loaded: url_helper
INFO - 2020-07-04 23:24:21 --> Helper loaded: main_helper
INFO - 2020-07-04 23:24:21 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:24:21 --> Controller Class Initialized
INFO - 2020-07-04 23:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:24:21 --> Pagination Class Initialized
ERROR - 2020-07-04 23:24:21 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:24:21 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:24:21 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:24:23 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:24:23 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:24:23 --> Final output sent to browser
DEBUG - 2020-07-04 23:24:23 --> Total execution time: 1.3471
INFO - 2020-07-04 23:25:15 --> Config Class Initialized
INFO - 2020-07-04 23:25:15 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:25:15 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:25:15 --> Utf8 Class Initialized
INFO - 2020-07-04 23:25:15 --> URI Class Initialized
DEBUG - 2020-07-04 23:25:15 --> No URI present. Default controller set.
INFO - 2020-07-04 23:25:15 --> Router Class Initialized
INFO - 2020-07-04 23:25:15 --> Output Class Initialized
INFO - 2020-07-04 23:25:15 --> Security Class Initialized
DEBUG - 2020-07-04 23:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:25:15 --> Input Class Initialized
INFO - 2020-07-04 23:25:15 --> Language Class Initialized
INFO - 2020-07-04 23:25:15 --> Language Class Initialized
INFO - 2020-07-04 23:25:15 --> Config Class Initialized
INFO - 2020-07-04 23:25:15 --> Loader Class Initialized
INFO - 2020-07-04 23:25:15 --> Helper loaded: url_helper
INFO - 2020-07-04 23:25:15 --> Helper loaded: main_helper
INFO - 2020-07-04 23:25:15 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:25:15 --> Controller Class Initialized
DEBUG - 2020-07-04 23:25:15 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-04 23:25:15 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:25:15 --> Final output sent to browser
DEBUG - 2020-07-04 23:25:15 --> Total execution time: 0.0038
INFO - 2020-07-04 23:26:19 --> Config Class Initialized
INFO - 2020-07-04 23:26:19 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:26:19 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:26:19 --> Utf8 Class Initialized
INFO - 2020-07-04 23:26:19 --> URI Class Initialized
INFO - 2020-07-04 23:26:19 --> Router Class Initialized
INFO - 2020-07-04 23:26:19 --> Output Class Initialized
INFO - 2020-07-04 23:26:19 --> Security Class Initialized
DEBUG - 2020-07-04 23:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:26:19 --> Input Class Initialized
INFO - 2020-07-04 23:26:19 --> Language Class Initialized
INFO - 2020-07-04 23:26:19 --> Language Class Initialized
INFO - 2020-07-04 23:26:19 --> Config Class Initialized
INFO - 2020-07-04 23:26:19 --> Loader Class Initialized
INFO - 2020-07-04 23:26:19 --> Helper loaded: url_helper
INFO - 2020-07-04 23:26:19 --> Helper loaded: main_helper
INFO - 2020-07-04 23:26:19 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:26:19 --> Controller Class Initialized
INFO - 2020-07-04 23:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:26:19 --> Pagination Class Initialized
ERROR - 2020-07-04 23:26:19 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:26:19 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:26:19 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:26:21 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:26:21 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:26:21 --> Final output sent to browser
DEBUG - 2020-07-04 23:26:21 --> Total execution time: 1.6430
INFO - 2020-07-04 23:26:54 --> Config Class Initialized
INFO - 2020-07-04 23:26:54 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:26:54 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:26:54 --> Utf8 Class Initialized
INFO - 2020-07-04 23:26:54 --> URI Class Initialized
INFO - 2020-07-04 23:26:54 --> Router Class Initialized
INFO - 2020-07-04 23:26:54 --> Output Class Initialized
INFO - 2020-07-04 23:26:54 --> Security Class Initialized
DEBUG - 2020-07-04 23:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:26:54 --> Input Class Initialized
INFO - 2020-07-04 23:26:54 --> Language Class Initialized
INFO - 2020-07-04 23:26:54 --> Language Class Initialized
INFO - 2020-07-04 23:26:54 --> Config Class Initialized
INFO - 2020-07-04 23:26:54 --> Loader Class Initialized
INFO - 2020-07-04 23:26:54 --> Helper loaded: url_helper
INFO - 2020-07-04 23:26:54 --> Helper loaded: main_helper
INFO - 2020-07-04 23:26:54 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:26:54 --> Controller Class Initialized
INFO - 2020-07-04 23:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:26:54 --> Pagination Class Initialized
ERROR - 2020-07-04 23:26:54 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:26:54 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:26:54 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:26:55 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 23:26:55 --> Final output sent to browser
DEBUG - 2020-07-04 23:26:55 --> Total execution time: 1.3616
INFO - 2020-07-04 23:34:28 --> Config Class Initialized
INFO - 2020-07-04 23:34:28 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:34:28 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:34:28 --> Utf8 Class Initialized
INFO - 2020-07-04 23:34:28 --> URI Class Initialized
INFO - 2020-07-04 23:34:28 --> Router Class Initialized
INFO - 2020-07-04 23:34:28 --> Output Class Initialized
INFO - 2020-07-04 23:34:28 --> Security Class Initialized
DEBUG - 2020-07-04 23:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:34:28 --> Input Class Initialized
INFO - 2020-07-04 23:34:28 --> Language Class Initialized
INFO - 2020-07-04 23:34:28 --> Language Class Initialized
INFO - 2020-07-04 23:34:28 --> Config Class Initialized
INFO - 2020-07-04 23:34:28 --> Loader Class Initialized
INFO - 2020-07-04 23:34:28 --> Helper loaded: url_helper
INFO - 2020-07-04 23:34:28 --> Helper loaded: main_helper
INFO - 2020-07-04 23:34:28 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:34:28 --> Controller Class Initialized
INFO - 2020-07-04 23:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:34:28 --> Pagination Class Initialized
ERROR - 2020-07-04 23:34:28 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:34:28 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:34:28 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:34:29 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:34:29 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:34:29 --> Final output sent to browser
DEBUG - 2020-07-04 23:34:29 --> Total execution time: 1.4050
INFO - 2020-07-04 23:34:46 --> Config Class Initialized
INFO - 2020-07-04 23:34:46 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:34:46 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:34:46 --> Utf8 Class Initialized
INFO - 2020-07-04 23:34:46 --> URI Class Initialized
INFO - 2020-07-04 23:34:46 --> Router Class Initialized
INFO - 2020-07-04 23:34:46 --> Output Class Initialized
INFO - 2020-07-04 23:34:46 --> Security Class Initialized
DEBUG - 2020-07-04 23:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:34:46 --> Input Class Initialized
INFO - 2020-07-04 23:34:46 --> Language Class Initialized
INFO - 2020-07-04 23:34:46 --> Language Class Initialized
INFO - 2020-07-04 23:34:46 --> Config Class Initialized
INFO - 2020-07-04 23:34:46 --> Loader Class Initialized
INFO - 2020-07-04 23:34:46 --> Helper loaded: url_helper
INFO - 2020-07-04 23:34:46 --> Helper loaded: main_helper
INFO - 2020-07-04 23:34:46 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:34:46 --> Controller Class Initialized
INFO - 2020-07-04 23:34:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:34:46 --> Pagination Class Initialized
ERROR - 2020-07-04 23:34:46 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:34:46 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:34:46 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:34:48 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:34:48 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:34:48 --> Final output sent to browser
DEBUG - 2020-07-04 23:34:48 --> Total execution time: 1.3725
INFO - 2020-07-04 23:35:00 --> Config Class Initialized
INFO - 2020-07-04 23:35:00 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:35:00 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:35:00 --> Utf8 Class Initialized
INFO - 2020-07-04 23:35:00 --> URI Class Initialized
INFO - 2020-07-04 23:35:00 --> Router Class Initialized
INFO - 2020-07-04 23:35:00 --> Output Class Initialized
INFO - 2020-07-04 23:35:00 --> Security Class Initialized
DEBUG - 2020-07-04 23:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:35:00 --> Input Class Initialized
INFO - 2020-07-04 23:35:00 --> Language Class Initialized
INFO - 2020-07-04 23:35:00 --> Language Class Initialized
INFO - 2020-07-04 23:35:00 --> Config Class Initialized
INFO - 2020-07-04 23:35:00 --> Loader Class Initialized
INFO - 2020-07-04 23:35:00 --> Helper loaded: url_helper
INFO - 2020-07-04 23:35:00 --> Helper loaded: main_helper
INFO - 2020-07-04 23:35:00 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:35:00 --> Controller Class Initialized
INFO - 2020-07-04 23:35:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:35:00 --> Pagination Class Initialized
ERROR - 2020-07-04 23:35:00 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:35:00 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:35:00 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:35:02 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:35:02 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:35:02 --> Final output sent to browser
DEBUG - 2020-07-04 23:35:02 --> Total execution time: 1.4526
INFO - 2020-07-04 23:35:12 --> Config Class Initialized
INFO - 2020-07-04 23:35:12 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:35:12 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:35:12 --> Utf8 Class Initialized
INFO - 2020-07-04 23:35:12 --> URI Class Initialized
INFO - 2020-07-04 23:35:12 --> Router Class Initialized
INFO - 2020-07-04 23:35:12 --> Output Class Initialized
INFO - 2020-07-04 23:35:12 --> Security Class Initialized
DEBUG - 2020-07-04 23:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:35:12 --> Input Class Initialized
INFO - 2020-07-04 23:35:12 --> Language Class Initialized
INFO - 2020-07-04 23:35:12 --> Language Class Initialized
INFO - 2020-07-04 23:35:12 --> Config Class Initialized
INFO - 2020-07-04 23:35:12 --> Loader Class Initialized
INFO - 2020-07-04 23:35:12 --> Helper loaded: url_helper
INFO - 2020-07-04 23:35:12 --> Helper loaded: main_helper
INFO - 2020-07-04 23:35:12 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:35:12 --> Controller Class Initialized
INFO - 2020-07-04 23:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:35:12 --> Pagination Class Initialized
ERROR - 2020-07-04 23:35:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:35:12 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:35:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:35:14 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:35:14 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:35:14 --> Final output sent to browser
DEBUG - 2020-07-04 23:35:14 --> Total execution time: 1.3190
INFO - 2020-07-04 23:35:21 --> Config Class Initialized
INFO - 2020-07-04 23:35:21 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:35:21 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:35:21 --> Utf8 Class Initialized
INFO - 2020-07-04 23:35:21 --> URI Class Initialized
INFO - 2020-07-04 23:35:21 --> Router Class Initialized
INFO - 2020-07-04 23:35:21 --> Output Class Initialized
INFO - 2020-07-04 23:35:21 --> Security Class Initialized
DEBUG - 2020-07-04 23:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:35:21 --> Input Class Initialized
INFO - 2020-07-04 23:35:21 --> Language Class Initialized
INFO - 2020-07-04 23:35:21 --> Language Class Initialized
INFO - 2020-07-04 23:35:21 --> Config Class Initialized
INFO - 2020-07-04 23:35:21 --> Loader Class Initialized
INFO - 2020-07-04 23:35:21 --> Helper loaded: url_helper
INFO - 2020-07-04 23:35:21 --> Helper loaded: main_helper
INFO - 2020-07-04 23:35:21 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:35:21 --> Controller Class Initialized
INFO - 2020-07-04 23:35:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:35:21 --> Pagination Class Initialized
ERROR - 2020-07-04 23:35:21 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:35:21 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:35:21 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:35:21 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:35:21 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:35:21 --> Final output sent to browser
DEBUG - 2020-07-04 23:35:21 --> Total execution time: 0.0052
INFO - 2020-07-04 23:35:30 --> Config Class Initialized
INFO - 2020-07-04 23:35:30 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:35:30 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:35:30 --> Utf8 Class Initialized
INFO - 2020-07-04 23:35:30 --> URI Class Initialized
INFO - 2020-07-04 23:35:30 --> Router Class Initialized
INFO - 2020-07-04 23:35:30 --> Output Class Initialized
INFO - 2020-07-04 23:35:30 --> Security Class Initialized
DEBUG - 2020-07-04 23:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:35:30 --> Input Class Initialized
INFO - 2020-07-04 23:35:30 --> Language Class Initialized
INFO - 2020-07-04 23:35:30 --> Language Class Initialized
INFO - 2020-07-04 23:35:30 --> Config Class Initialized
INFO - 2020-07-04 23:35:30 --> Loader Class Initialized
INFO - 2020-07-04 23:35:30 --> Helper loaded: url_helper
INFO - 2020-07-04 23:35:30 --> Helper loaded: main_helper
INFO - 2020-07-04 23:35:30 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:35:30 --> Controller Class Initialized
INFO - 2020-07-04 23:35:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:35:30 --> Pagination Class Initialized
ERROR - 2020-07-04 23:35:30 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:35:30 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:35:30 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:35:30 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:35:30 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:35:30 --> Final output sent to browser
DEBUG - 2020-07-04 23:35:30 --> Total execution time: 0.0053
INFO - 2020-07-04 23:35:37 --> Config Class Initialized
INFO - 2020-07-04 23:35:37 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:35:37 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:35:37 --> Utf8 Class Initialized
INFO - 2020-07-04 23:35:37 --> URI Class Initialized
INFO - 2020-07-04 23:35:37 --> Router Class Initialized
INFO - 2020-07-04 23:35:37 --> Output Class Initialized
INFO - 2020-07-04 23:35:37 --> Security Class Initialized
DEBUG - 2020-07-04 23:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:35:37 --> Input Class Initialized
INFO - 2020-07-04 23:35:37 --> Language Class Initialized
INFO - 2020-07-04 23:35:37 --> Language Class Initialized
INFO - 2020-07-04 23:35:37 --> Config Class Initialized
INFO - 2020-07-04 23:35:37 --> Loader Class Initialized
INFO - 2020-07-04 23:35:37 --> Helper loaded: url_helper
INFO - 2020-07-04 23:35:37 --> Helper loaded: main_helper
INFO - 2020-07-04 23:35:37 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:35:37 --> Controller Class Initialized
INFO - 2020-07-04 23:35:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:35:37 --> Pagination Class Initialized
ERROR - 2020-07-04 23:35:37 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:35:37 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:35:37 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:35:38 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:35:38 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:35:38 --> Final output sent to browser
DEBUG - 2020-07-04 23:35:38 --> Total execution time: 1.8548
INFO - 2020-07-04 23:35:52 --> Config Class Initialized
INFO - 2020-07-04 23:35:52 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:35:52 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:35:52 --> Utf8 Class Initialized
INFO - 2020-07-04 23:35:52 --> URI Class Initialized
INFO - 2020-07-04 23:35:52 --> Router Class Initialized
INFO - 2020-07-04 23:35:52 --> Output Class Initialized
INFO - 2020-07-04 23:35:52 --> Security Class Initialized
DEBUG - 2020-07-04 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:35:52 --> Input Class Initialized
INFO - 2020-07-04 23:35:52 --> Language Class Initialized
INFO - 2020-07-04 23:35:52 --> Language Class Initialized
INFO - 2020-07-04 23:35:52 --> Config Class Initialized
INFO - 2020-07-04 23:35:52 --> Loader Class Initialized
INFO - 2020-07-04 23:35:52 --> Helper loaded: url_helper
INFO - 2020-07-04 23:35:52 --> Helper loaded: main_helper
INFO - 2020-07-04 23:35:52 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:35:52 --> Controller Class Initialized
INFO - 2020-07-04 23:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:35:52 --> Pagination Class Initialized
ERROR - 2020-07-04 23:35:52 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:35:52 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:35:52 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:35:54 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:35:54 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:35:54 --> Final output sent to browser
DEBUG - 2020-07-04 23:35:54 --> Total execution time: 1.8569
INFO - 2020-07-04 23:36:05 --> Config Class Initialized
INFO - 2020-07-04 23:36:05 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:36:05 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:36:05 --> Utf8 Class Initialized
INFO - 2020-07-04 23:36:05 --> URI Class Initialized
INFO - 2020-07-04 23:36:05 --> Router Class Initialized
INFO - 2020-07-04 23:36:05 --> Output Class Initialized
INFO - 2020-07-04 23:36:05 --> Security Class Initialized
DEBUG - 2020-07-04 23:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:36:05 --> Input Class Initialized
INFO - 2020-07-04 23:36:05 --> Language Class Initialized
INFO - 2020-07-04 23:36:05 --> Language Class Initialized
INFO - 2020-07-04 23:36:05 --> Config Class Initialized
INFO - 2020-07-04 23:36:05 --> Loader Class Initialized
INFO - 2020-07-04 23:36:05 --> Helper loaded: url_helper
INFO - 2020-07-04 23:36:05 --> Helper loaded: main_helper
INFO - 2020-07-04 23:36:05 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:36:05 --> Controller Class Initialized
INFO - 2020-07-04 23:36:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:36:05 --> Pagination Class Initialized
ERROR - 2020-07-04 23:36:05 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:36:05 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:36:05 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:36:07 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 23:36:07 --> Final output sent to browser
DEBUG - 2020-07-04 23:36:07 --> Total execution time: 1.4793
INFO - 2020-07-04 23:39:06 --> Config Class Initialized
INFO - 2020-07-04 23:39:06 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:39:06 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:39:06 --> Utf8 Class Initialized
INFO - 2020-07-04 23:39:06 --> URI Class Initialized
INFO - 2020-07-04 23:39:06 --> Router Class Initialized
INFO - 2020-07-04 23:39:06 --> Output Class Initialized
INFO - 2020-07-04 23:39:06 --> Security Class Initialized
DEBUG - 2020-07-04 23:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:39:06 --> Input Class Initialized
INFO - 2020-07-04 23:39:06 --> Language Class Initialized
INFO - 2020-07-04 23:39:06 --> Language Class Initialized
INFO - 2020-07-04 23:39:06 --> Config Class Initialized
INFO - 2020-07-04 23:39:06 --> Loader Class Initialized
INFO - 2020-07-04 23:39:06 --> Helper loaded: url_helper
INFO - 2020-07-04 23:39:06 --> Helper loaded: main_helper
INFO - 2020-07-04 23:39:06 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:39:06 --> Controller Class Initialized
INFO - 2020-07-04 23:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:39:06 --> Pagination Class Initialized
ERROR - 2020-07-04 23:39:06 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:39:06 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:39:06 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:39:08 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 23:39:08 --> Final output sent to browser
DEBUG - 2020-07-04 23:39:08 --> Total execution time: 1.2424
INFO - 2020-07-04 23:39:15 --> Config Class Initialized
INFO - 2020-07-04 23:39:15 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:39:15 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:39:15 --> Utf8 Class Initialized
INFO - 2020-07-04 23:39:15 --> URI Class Initialized
INFO - 2020-07-04 23:39:15 --> Router Class Initialized
INFO - 2020-07-04 23:39:15 --> Output Class Initialized
INFO - 2020-07-04 23:39:15 --> Security Class Initialized
DEBUG - 2020-07-04 23:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:39:15 --> Input Class Initialized
INFO - 2020-07-04 23:39:15 --> Language Class Initialized
INFO - 2020-07-04 23:39:15 --> Language Class Initialized
INFO - 2020-07-04 23:39:15 --> Config Class Initialized
INFO - 2020-07-04 23:39:15 --> Loader Class Initialized
INFO - 2020-07-04 23:39:15 --> Helper loaded: url_helper
INFO - 2020-07-04 23:39:15 --> Helper loaded: main_helper
INFO - 2020-07-04 23:39:15 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:39:15 --> Controller Class Initialized
INFO - 2020-07-04 23:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:39:15 --> Pagination Class Initialized
ERROR - 2020-07-04 23:39:15 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:39:15 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:39:15 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:39:16 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 23:39:16 --> Final output sent to browser
DEBUG - 2020-07-04 23:39:16 --> Total execution time: 1.5664
INFO - 2020-07-04 23:44:47 --> Config Class Initialized
INFO - 2020-07-04 23:44:47 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:44:47 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:44:47 --> Utf8 Class Initialized
INFO - 2020-07-04 23:44:47 --> URI Class Initialized
INFO - 2020-07-04 23:44:47 --> Router Class Initialized
INFO - 2020-07-04 23:44:47 --> Output Class Initialized
INFO - 2020-07-04 23:44:47 --> Security Class Initialized
DEBUG - 2020-07-04 23:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:44:47 --> Input Class Initialized
INFO - 2020-07-04 23:44:47 --> Language Class Initialized
INFO - 2020-07-04 23:44:47 --> Language Class Initialized
INFO - 2020-07-04 23:44:47 --> Config Class Initialized
INFO - 2020-07-04 23:44:47 --> Loader Class Initialized
INFO - 2020-07-04 23:44:47 --> Helper loaded: url_helper
INFO - 2020-07-04 23:44:47 --> Helper loaded: main_helper
INFO - 2020-07-04 23:44:47 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:44:47 --> Controller Class Initialized
INFO - 2020-07-04 23:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:44:47 --> Pagination Class Initialized
ERROR - 2020-07-04 23:44:47 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:44:47 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:44:47 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:44:49 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 23:44:49 --> Final output sent to browser
DEBUG - 2020-07-04 23:44:49 --> Total execution time: 1.5471
INFO - 2020-07-04 23:45:32 --> Config Class Initialized
INFO - 2020-07-04 23:45:32 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:45:32 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:45:32 --> Utf8 Class Initialized
INFO - 2020-07-04 23:45:32 --> URI Class Initialized
INFO - 2020-07-04 23:45:32 --> Router Class Initialized
INFO - 2020-07-04 23:45:32 --> Output Class Initialized
INFO - 2020-07-04 23:45:32 --> Security Class Initialized
DEBUG - 2020-07-04 23:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:45:32 --> Input Class Initialized
INFO - 2020-07-04 23:45:32 --> Language Class Initialized
INFO - 2020-07-04 23:45:32 --> Language Class Initialized
INFO - 2020-07-04 23:45:32 --> Config Class Initialized
INFO - 2020-07-04 23:45:32 --> Loader Class Initialized
INFO - 2020-07-04 23:45:32 --> Helper loaded: url_helper
INFO - 2020-07-04 23:45:32 --> Helper loaded: main_helper
INFO - 2020-07-04 23:45:32 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:45:32 --> Controller Class Initialized
INFO - 2020-07-04 23:45:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:45:32 --> Pagination Class Initialized
ERROR - 2020-07-04 23:45:32 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:45:32 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:45:32 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:45:33 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 23:45:33 --> Final output sent to browser
DEBUG - 2020-07-04 23:45:33 --> Total execution time: 1.2413
INFO - 2020-07-04 23:46:07 --> Config Class Initialized
INFO - 2020-07-04 23:46:07 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:46:07 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:46:07 --> Utf8 Class Initialized
INFO - 2020-07-04 23:46:07 --> URI Class Initialized
INFO - 2020-07-04 23:46:07 --> Router Class Initialized
INFO - 2020-07-04 23:46:07 --> Output Class Initialized
INFO - 2020-07-04 23:46:07 --> Security Class Initialized
DEBUG - 2020-07-04 23:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:46:07 --> Input Class Initialized
INFO - 2020-07-04 23:46:07 --> Language Class Initialized
INFO - 2020-07-04 23:46:07 --> Language Class Initialized
INFO - 2020-07-04 23:46:07 --> Config Class Initialized
INFO - 2020-07-04 23:46:07 --> Loader Class Initialized
INFO - 2020-07-04 23:46:07 --> Helper loaded: url_helper
INFO - 2020-07-04 23:46:07 --> Helper loaded: main_helper
INFO - 2020-07-04 23:46:07 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:46:07 --> Controller Class Initialized
INFO - 2020-07-04 23:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:46:07 --> Pagination Class Initialized
ERROR - 2020-07-04 23:46:07 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:46:07 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:46:07 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:46:09 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:46:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:46:09 --> Final output sent to browser
DEBUG - 2020-07-04 23:46:09 --> Total execution time: 1.2556
INFO - 2020-07-04 23:46:16 --> Config Class Initialized
INFO - 2020-07-04 23:46:16 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:46:16 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:46:16 --> Utf8 Class Initialized
INFO - 2020-07-04 23:46:16 --> URI Class Initialized
INFO - 2020-07-04 23:46:16 --> Router Class Initialized
INFO - 2020-07-04 23:46:16 --> Output Class Initialized
INFO - 2020-07-04 23:46:16 --> Security Class Initialized
DEBUG - 2020-07-04 23:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:46:16 --> Input Class Initialized
INFO - 2020-07-04 23:46:16 --> Language Class Initialized
INFO - 2020-07-04 23:46:16 --> Language Class Initialized
INFO - 2020-07-04 23:46:16 --> Config Class Initialized
INFO - 2020-07-04 23:46:16 --> Loader Class Initialized
INFO - 2020-07-04 23:46:16 --> Helper loaded: url_helper
INFO - 2020-07-04 23:46:16 --> Helper loaded: main_helper
INFO - 2020-07-04 23:46:16 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:46:16 --> Controller Class Initialized
INFO - 2020-07-04 23:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:46:16 --> Pagination Class Initialized
ERROR - 2020-07-04 23:46:16 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:46:16 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:46:16 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:46:17 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-04 23:46:17 --> Final output sent to browser
DEBUG - 2020-07-04 23:46:17 --> Total execution time: 1.1350
INFO - 2020-07-04 23:46:27 --> Config Class Initialized
INFO - 2020-07-04 23:46:27 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:46:27 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:46:27 --> Utf8 Class Initialized
INFO - 2020-07-04 23:46:27 --> URI Class Initialized
INFO - 2020-07-04 23:46:27 --> Router Class Initialized
INFO - 2020-07-04 23:46:27 --> Output Class Initialized
INFO - 2020-07-04 23:46:27 --> Security Class Initialized
DEBUG - 2020-07-04 23:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:46:27 --> Input Class Initialized
INFO - 2020-07-04 23:46:27 --> Language Class Initialized
INFO - 2020-07-04 23:46:27 --> Language Class Initialized
INFO - 2020-07-04 23:46:27 --> Config Class Initialized
INFO - 2020-07-04 23:46:27 --> Loader Class Initialized
INFO - 2020-07-04 23:46:27 --> Helper loaded: url_helper
INFO - 2020-07-04 23:46:27 --> Helper loaded: main_helper
INFO - 2020-07-04 23:46:27 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:46:27 --> Controller Class Initialized
INFO - 2020-07-04 23:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:46:27 --> Pagination Class Initialized
ERROR - 2020-07-04 23:46:27 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:46:27 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:46:27 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:46:28 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:46:28 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:46:28 --> Final output sent to browser
DEBUG - 2020-07-04 23:46:28 --> Total execution time: 1.2879
INFO - 2020-07-04 23:55:15 --> Config Class Initialized
INFO - 2020-07-04 23:55:15 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:55:15 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:55:15 --> Utf8 Class Initialized
INFO - 2020-07-04 23:55:15 --> URI Class Initialized
INFO - 2020-07-04 23:55:15 --> Router Class Initialized
INFO - 2020-07-04 23:55:15 --> Output Class Initialized
INFO - 2020-07-04 23:55:15 --> Security Class Initialized
DEBUG - 2020-07-04 23:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:55:15 --> Input Class Initialized
INFO - 2020-07-04 23:55:15 --> Language Class Initialized
INFO - 2020-07-04 23:55:15 --> Language Class Initialized
INFO - 2020-07-04 23:55:15 --> Config Class Initialized
INFO - 2020-07-04 23:55:15 --> Loader Class Initialized
INFO - 2020-07-04 23:55:15 --> Helper loaded: url_helper
INFO - 2020-07-04 23:55:15 --> Helper loaded: main_helper
INFO - 2020-07-04 23:55:15 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:55:15 --> Controller Class Initialized
INFO - 2020-07-04 23:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:55:15 --> Pagination Class Initialized
ERROR - 2020-07-04 23:55:15 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:55:15 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:55:15 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:55:17 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:55:17 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:55:17 --> Final output sent to browser
DEBUG - 2020-07-04 23:55:17 --> Total execution time: 1.4269
INFO - 2020-07-04 23:55:28 --> Config Class Initialized
INFO - 2020-07-04 23:55:28 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:55:28 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:55:28 --> Utf8 Class Initialized
INFO - 2020-07-04 23:55:28 --> URI Class Initialized
INFO - 2020-07-04 23:55:28 --> Router Class Initialized
INFO - 2020-07-04 23:55:28 --> Output Class Initialized
INFO - 2020-07-04 23:55:28 --> Security Class Initialized
DEBUG - 2020-07-04 23:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:55:28 --> Input Class Initialized
INFO - 2020-07-04 23:55:28 --> Language Class Initialized
INFO - 2020-07-04 23:55:28 --> Language Class Initialized
INFO - 2020-07-04 23:55:28 --> Config Class Initialized
INFO - 2020-07-04 23:55:28 --> Loader Class Initialized
INFO - 2020-07-04 23:55:28 --> Helper loaded: url_helper
INFO - 2020-07-04 23:55:28 --> Helper loaded: main_helper
INFO - 2020-07-04 23:55:28 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:55:28 --> Controller Class Initialized
INFO - 2020-07-04 23:55:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:55:28 --> Pagination Class Initialized
ERROR - 2020-07-04 23:55:28 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:55:28 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:55:28 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:55:28 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:55:28 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:55:28 --> Final output sent to browser
DEBUG - 2020-07-04 23:55:28 --> Total execution time: 0.0046
INFO - 2020-07-04 23:55:33 --> Config Class Initialized
INFO - 2020-07-04 23:55:33 --> Hooks Class Initialized
DEBUG - 2020-07-04 23:55:33 --> UTF-8 Support Enabled
INFO - 2020-07-04 23:55:33 --> Utf8 Class Initialized
INFO - 2020-07-04 23:55:33 --> URI Class Initialized
INFO - 2020-07-04 23:55:33 --> Router Class Initialized
INFO - 2020-07-04 23:55:33 --> Output Class Initialized
INFO - 2020-07-04 23:55:33 --> Security Class Initialized
DEBUG - 2020-07-04 23:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-04 23:55:33 --> Input Class Initialized
INFO - 2020-07-04 23:55:33 --> Language Class Initialized
INFO - 2020-07-04 23:55:33 --> Language Class Initialized
INFO - 2020-07-04 23:55:33 --> Config Class Initialized
INFO - 2020-07-04 23:55:33 --> Loader Class Initialized
INFO - 2020-07-04 23:55:33 --> Helper loaded: url_helper
INFO - 2020-07-04 23:55:33 --> Helper loaded: main_helper
INFO - 2020-07-04 23:55:33 --> Database Driver Class Initialized
DEBUG - 2020-07-04 23:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-04 23:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-04 23:55:33 --> Controller Class Initialized
INFO - 2020-07-04 23:55:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-04 23:55:33 --> Pagination Class Initialized
ERROR - 2020-07-04 23:55:33 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-04 23:55:33 --> Helper loaded: file_helper
DEBUG - 2020-07-04 23:55:33 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-04 23:55:33 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-04 23:55:33 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-04 23:55:33 --> Final output sent to browser
DEBUG - 2020-07-04 23:55:33 --> Total execution time: 0.0041
