<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-07-08 16:51:12 --> Config Class Initialized
INFO - 2020-07-08 16:51:12 --> Hooks Class Initialized
DEBUG - 2020-07-08 16:51:12 --> UTF-8 Support Enabled
INFO - 2020-07-08 16:51:12 --> Utf8 Class Initialized
INFO - 2020-07-08 16:51:12 --> URI Class Initialized
DEBUG - 2020-07-08 16:51:12 --> No URI present. Default controller set.
INFO - 2020-07-08 16:51:12 --> Router Class Initialized
INFO - 2020-07-08 16:51:12 --> Output Class Initialized
INFO - 2020-07-08 16:51:12 --> Security Class Initialized
DEBUG - 2020-07-08 16:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 16:51:12 --> Input Class Initialized
INFO - 2020-07-08 16:51:12 --> Language Class Initialized
INFO - 2020-07-08 16:51:12 --> Language Class Initialized
INFO - 2020-07-08 16:51:12 --> Config Class Initialized
INFO - 2020-07-08 16:51:12 --> Loader Class Initialized
INFO - 2020-07-08 16:51:12 --> Helper loaded: url_helper
INFO - 2020-07-08 16:51:12 --> Helper loaded: main_helper
INFO - 2020-07-08 16:51:12 --> Database Driver Class Initialized
DEBUG - 2020-07-08 16:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 16:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 16:51:12 --> Controller Class Initialized
DEBUG - 2020-07-08 16:51:12 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-08 16:51:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-08 16:51:12 --> Final output sent to browser
DEBUG - 2020-07-08 16:51:12 --> Total execution time: 0.0791
INFO - 2020-07-08 16:52:09 --> Config Class Initialized
INFO - 2020-07-08 16:52:09 --> Hooks Class Initialized
DEBUG - 2020-07-08 16:52:09 --> UTF-8 Support Enabled
INFO - 2020-07-08 16:52:09 --> Utf8 Class Initialized
INFO - 2020-07-08 16:52:09 --> URI Class Initialized
DEBUG - 2020-07-08 16:52:09 --> No URI present. Default controller set.
INFO - 2020-07-08 16:52:09 --> Router Class Initialized
INFO - 2020-07-08 16:52:09 --> Output Class Initialized
INFO - 2020-07-08 16:52:09 --> Security Class Initialized
DEBUG - 2020-07-08 16:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 16:52:09 --> Input Class Initialized
INFO - 2020-07-08 16:52:09 --> Language Class Initialized
INFO - 2020-07-08 16:52:09 --> Language Class Initialized
INFO - 2020-07-08 16:52:09 --> Config Class Initialized
INFO - 2020-07-08 16:52:09 --> Loader Class Initialized
INFO - 2020-07-08 16:52:09 --> Helper loaded: url_helper
INFO - 2020-07-08 16:52:09 --> Helper loaded: main_helper
INFO - 2020-07-08 16:52:09 --> Database Driver Class Initialized
DEBUG - 2020-07-08 16:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 16:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 16:52:09 --> Controller Class Initialized
DEBUG - 2020-07-08 16:52:09 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-08 16:52:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-08 16:52:09 --> Final output sent to browser
DEBUG - 2020-07-08 16:52:09 --> Total execution time: 0.0073
INFO - 2020-07-08 16:52:44 --> Config Class Initialized
INFO - 2020-07-08 16:52:44 --> Hooks Class Initialized
DEBUG - 2020-07-08 16:52:44 --> UTF-8 Support Enabled
INFO - 2020-07-08 16:52:44 --> Utf8 Class Initialized
INFO - 2020-07-08 16:52:44 --> URI Class Initialized
DEBUG - 2020-07-08 16:52:44 --> No URI present. Default controller set.
INFO - 2020-07-08 16:52:44 --> Router Class Initialized
INFO - 2020-07-08 16:52:44 --> Output Class Initialized
INFO - 2020-07-08 16:52:44 --> Security Class Initialized
DEBUG - 2020-07-08 16:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 16:52:44 --> Input Class Initialized
INFO - 2020-07-08 16:52:44 --> Language Class Initialized
INFO - 2020-07-08 16:52:44 --> Language Class Initialized
INFO - 2020-07-08 16:52:44 --> Config Class Initialized
INFO - 2020-07-08 16:52:44 --> Loader Class Initialized
INFO - 2020-07-08 16:52:44 --> Helper loaded: url_helper
INFO - 2020-07-08 16:52:44 --> Helper loaded: main_helper
INFO - 2020-07-08 16:52:44 --> Database Driver Class Initialized
DEBUG - 2020-07-08 16:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 16:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 16:52:44 --> Controller Class Initialized
DEBUG - 2020-07-08 16:52:44 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-08 16:52:44 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-08 16:52:44 --> Final output sent to browser
DEBUG - 2020-07-08 16:52:44 --> Total execution time: 0.0049
INFO - 2020-07-08 16:53:18 --> Config Class Initialized
INFO - 2020-07-08 16:53:18 --> Hooks Class Initialized
DEBUG - 2020-07-08 16:53:18 --> UTF-8 Support Enabled
INFO - 2020-07-08 16:53:18 --> Utf8 Class Initialized
INFO - 2020-07-08 16:53:18 --> URI Class Initialized
DEBUG - 2020-07-08 16:53:18 --> No URI present. Default controller set.
INFO - 2020-07-08 16:53:18 --> Router Class Initialized
INFO - 2020-07-08 16:53:18 --> Output Class Initialized
INFO - 2020-07-08 16:53:18 --> Security Class Initialized
DEBUG - 2020-07-08 16:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 16:53:18 --> Input Class Initialized
INFO - 2020-07-08 16:53:18 --> Language Class Initialized
INFO - 2020-07-08 16:53:18 --> Language Class Initialized
INFO - 2020-07-08 16:53:18 --> Config Class Initialized
INFO - 2020-07-08 16:53:18 --> Loader Class Initialized
INFO - 2020-07-08 16:53:18 --> Helper loaded: url_helper
INFO - 2020-07-08 16:53:18 --> Helper loaded: main_helper
INFO - 2020-07-08 16:53:18 --> Database Driver Class Initialized
DEBUG - 2020-07-08 16:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 16:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 16:53:18 --> Controller Class Initialized
DEBUG - 2020-07-08 16:53:18 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-08 16:53:18 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-08 16:53:18 --> Final output sent to browser
DEBUG - 2020-07-08 16:53:18 --> Total execution time: 0.0097
INFO - 2020-07-08 16:54:04 --> Config Class Initialized
INFO - 2020-07-08 16:54:04 --> Hooks Class Initialized
DEBUG - 2020-07-08 16:54:04 --> UTF-8 Support Enabled
INFO - 2020-07-08 16:54:04 --> Utf8 Class Initialized
INFO - 2020-07-08 16:54:04 --> URI Class Initialized
INFO - 2020-07-08 16:54:04 --> Router Class Initialized
INFO - 2020-07-08 16:54:04 --> Output Class Initialized
INFO - 2020-07-08 16:54:04 --> Security Class Initialized
DEBUG - 2020-07-08 16:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 16:54:04 --> Input Class Initialized
INFO - 2020-07-08 16:54:04 --> Language Class Initialized
INFO - 2020-07-08 16:54:04 --> Language Class Initialized
INFO - 2020-07-08 16:54:04 --> Config Class Initialized
INFO - 2020-07-08 16:54:04 --> Loader Class Initialized
INFO - 2020-07-08 16:54:04 --> Helper loaded: url_helper
INFO - 2020-07-08 16:54:04 --> Helper loaded: main_helper
INFO - 2020-07-08 16:54:04 --> Database Driver Class Initialized
DEBUG - 2020-07-08 16:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 16:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 16:54:04 --> Controller Class Initialized
INFO - 2020-07-08 16:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-08 16:54:04 --> Pagination Class Initialized
ERROR - 2020-07-08 16:54:04 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-08 16:54:04 --> Helper loaded: file_helper
DEBUG - 2020-07-08 16:54:04 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-08 16:54:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-08 16:54:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-08 16:54:04 --> Encryption Class Initialized
INFO - 2020-07-08 16:54:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-08 16:54:06 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-08 16:54:06 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-08 16:54:06 --> Final output sent to browser
DEBUG - 2020-07-08 16:54:06 --> Total execution time: 1.8795
INFO - 2020-07-08 16:56:40 --> Config Class Initialized
INFO - 2020-07-08 16:56:40 --> Hooks Class Initialized
DEBUG - 2020-07-08 16:56:40 --> UTF-8 Support Enabled
INFO - 2020-07-08 16:56:40 --> Utf8 Class Initialized
INFO - 2020-07-08 16:56:40 --> URI Class Initialized
DEBUG - 2020-07-08 16:56:40 --> No URI present. Default controller set.
INFO - 2020-07-08 16:56:40 --> Router Class Initialized
INFO - 2020-07-08 16:56:40 --> Output Class Initialized
INFO - 2020-07-08 16:56:40 --> Security Class Initialized
DEBUG - 2020-07-08 16:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 16:56:40 --> Input Class Initialized
INFO - 2020-07-08 16:56:40 --> Language Class Initialized
INFO - 2020-07-08 16:56:40 --> Language Class Initialized
INFO - 2020-07-08 16:56:40 --> Config Class Initialized
INFO - 2020-07-08 16:56:40 --> Loader Class Initialized
INFO - 2020-07-08 16:56:40 --> Helper loaded: url_helper
INFO - 2020-07-08 16:56:40 --> Helper loaded: main_helper
INFO - 2020-07-08 16:56:40 --> Database Driver Class Initialized
DEBUG - 2020-07-08 16:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 16:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 16:56:40 --> Controller Class Initialized
DEBUG - 2020-07-08 16:56:40 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-08 16:56:40 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-08 16:56:40 --> Final output sent to browser
DEBUG - 2020-07-08 16:56:40 --> Total execution time: 0.0038
INFO - 2020-07-08 16:57:18 --> Config Class Initialized
INFO - 2020-07-08 16:57:18 --> Hooks Class Initialized
DEBUG - 2020-07-08 16:57:18 --> UTF-8 Support Enabled
INFO - 2020-07-08 16:57:18 --> Utf8 Class Initialized
INFO - 2020-07-08 16:57:18 --> URI Class Initialized
INFO - 2020-07-08 16:57:18 --> Router Class Initialized
INFO - 2020-07-08 16:57:18 --> Output Class Initialized
INFO - 2020-07-08 16:57:18 --> Security Class Initialized
DEBUG - 2020-07-08 16:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 16:57:18 --> Input Class Initialized
INFO - 2020-07-08 16:57:18 --> Language Class Initialized
INFO - 2020-07-08 16:57:18 --> Language Class Initialized
INFO - 2020-07-08 16:57:18 --> Config Class Initialized
INFO - 2020-07-08 16:57:18 --> Loader Class Initialized
INFO - 2020-07-08 16:57:18 --> Helper loaded: url_helper
INFO - 2020-07-08 16:57:18 --> Helper loaded: main_helper
INFO - 2020-07-08 16:57:18 --> Database Driver Class Initialized
DEBUG - 2020-07-08 16:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 16:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 16:57:18 --> Controller Class Initialized
INFO - 2020-07-08 16:57:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-08 16:57:18 --> Pagination Class Initialized
ERROR - 2020-07-08 16:57:18 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-08 16:57:18 --> Helper loaded: file_helper
DEBUG - 2020-07-08 16:57:18 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-08 16:57:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-08 16:57:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-08 16:57:18 --> Encryption Class Initialized
INFO - 2020-07-08 16:57:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-08 16:57:20 --> Config Class Initialized
INFO - 2020-07-08 16:57:20 --> Hooks Class Initialized
DEBUG - 2020-07-08 16:57:20 --> UTF-8 Support Enabled
INFO - 2020-07-08 16:57:20 --> Utf8 Class Initialized
INFO - 2020-07-08 16:57:20 --> URI Class Initialized
INFO - 2020-07-08 16:57:20 --> Router Class Initialized
INFO - 2020-07-08 16:57:20 --> Output Class Initialized
INFO - 2020-07-08 16:57:20 --> Security Class Initialized
DEBUG - 2020-07-08 16:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 16:57:20 --> Input Class Initialized
INFO - 2020-07-08 16:57:20 --> Language Class Initialized
INFO - 2020-07-08 16:57:20 --> Language Class Initialized
INFO - 2020-07-08 16:57:20 --> Config Class Initialized
INFO - 2020-07-08 16:57:20 --> Loader Class Initialized
INFO - 2020-07-08 16:57:20 --> Helper loaded: url_helper
INFO - 2020-07-08 16:57:20 --> Helper loaded: main_helper
INFO - 2020-07-08 16:57:20 --> Database Driver Class Initialized
DEBUG - 2020-07-08 16:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 16:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 16:57:20 --> Controller Class Initialized
DEBUG - 2020-07-08 16:57:20 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-08 16:57:20 --> Final output sent to browser
DEBUG - 2020-07-08 16:57:20 --> Total execution time: 0.0064
INFO - 2020-07-08 16:57:30 --> Config Class Initialized
INFO - 2020-07-08 16:57:30 --> Hooks Class Initialized
DEBUG - 2020-07-08 16:57:30 --> UTF-8 Support Enabled
INFO - 2020-07-08 16:57:30 --> Utf8 Class Initialized
INFO - 2020-07-08 16:57:30 --> URI Class Initialized
INFO - 2020-07-08 16:57:30 --> Router Class Initialized
INFO - 2020-07-08 16:57:30 --> Output Class Initialized
INFO - 2020-07-08 16:57:30 --> Security Class Initialized
DEBUG - 2020-07-08 16:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 16:57:30 --> Input Class Initialized
INFO - 2020-07-08 16:57:30 --> Language Class Initialized
INFO - 2020-07-08 16:57:30 --> Language Class Initialized
INFO - 2020-07-08 16:57:30 --> Config Class Initialized
INFO - 2020-07-08 16:57:30 --> Loader Class Initialized
INFO - 2020-07-08 16:57:30 --> Helper loaded: url_helper
INFO - 2020-07-08 16:57:30 --> Helper loaded: main_helper
INFO - 2020-07-08 16:57:30 --> Database Driver Class Initialized
DEBUG - 2020-07-08 16:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 16:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 16:57:30 --> Controller Class Initialized
INFO - 2020-07-08 16:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-08 16:57:30 --> Pagination Class Initialized
ERROR - 2020-07-08 16:57:30 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-08 16:57:30 --> Helper loaded: file_helper
DEBUG - 2020-07-08 16:57:30 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-08 16:57:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-08 16:57:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-08 16:57:30 --> Encryption Class Initialized
INFO - 2020-07-08 16:57:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-08 16:57:30 --> Severity: error --> Exception: Call to undefined method Search::_get_works_pmc() /var/www/journal/application/modules/landing/controllers/Search.php 71
INFO - 2020-07-08 17:08:58 --> Config Class Initialized
INFO - 2020-07-08 17:08:58 --> Hooks Class Initialized
DEBUG - 2020-07-08 17:08:58 --> UTF-8 Support Enabled
INFO - 2020-07-08 17:08:58 --> Utf8 Class Initialized
INFO - 2020-07-08 17:08:58 --> URI Class Initialized
INFO - 2020-07-08 17:08:58 --> Router Class Initialized
INFO - 2020-07-08 17:08:58 --> Output Class Initialized
INFO - 2020-07-08 17:08:58 --> Security Class Initialized
DEBUG - 2020-07-08 17:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 17:08:58 --> Input Class Initialized
INFO - 2020-07-08 17:08:58 --> Language Class Initialized
INFO - 2020-07-08 17:08:58 --> Language Class Initialized
INFO - 2020-07-08 17:08:58 --> Config Class Initialized
INFO - 2020-07-08 17:08:58 --> Loader Class Initialized
INFO - 2020-07-08 17:08:58 --> Helper loaded: url_helper
INFO - 2020-07-08 17:08:58 --> Helper loaded: main_helper
INFO - 2020-07-08 17:08:58 --> Database Driver Class Initialized
DEBUG - 2020-07-08 17:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 17:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 17:08:58 --> Controller Class Initialized
INFO - 2020-07-08 17:08:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-08 17:08:58 --> Pagination Class Initialized
ERROR - 2020-07-08 17:08:58 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-08 17:08:58 --> Helper loaded: file_helper
DEBUG - 2020-07-08 17:08:58 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-08 17:08:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-08 17:08:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-08 17:08:58 --> Encryption Class Initialized
INFO - 2020-07-08 17:08:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
ERROR - 2020-07-08 17:08:58 --> Severity: error --> Exception: Call to undefined method Search::_get_works_pmc() /var/www/journal/application/modules/landing/controllers/Search.php 71
INFO - 2020-07-08 17:09:05 --> Config Class Initialized
INFO - 2020-07-08 17:09:05 --> Hooks Class Initialized
DEBUG - 2020-07-08 17:09:05 --> UTF-8 Support Enabled
INFO - 2020-07-08 17:09:05 --> Utf8 Class Initialized
INFO - 2020-07-08 17:09:05 --> URI Class Initialized
INFO - 2020-07-08 17:09:05 --> Router Class Initialized
INFO - 2020-07-08 17:09:05 --> Output Class Initialized
INFO - 2020-07-08 17:09:05 --> Security Class Initialized
DEBUG - 2020-07-08 17:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 17:09:05 --> Input Class Initialized
INFO - 2020-07-08 17:09:05 --> Language Class Initialized
INFO - 2020-07-08 17:09:05 --> Language Class Initialized
INFO - 2020-07-08 17:09:05 --> Config Class Initialized
INFO - 2020-07-08 17:09:05 --> Loader Class Initialized
INFO - 2020-07-08 17:09:05 --> Helper loaded: url_helper
INFO - 2020-07-08 17:09:05 --> Helper loaded: main_helper
INFO - 2020-07-08 17:09:05 --> Database Driver Class Initialized
DEBUG - 2020-07-08 17:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 17:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 17:09:05 --> Controller Class Initialized
INFO - 2020-07-08 17:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-08 17:09:05 --> Pagination Class Initialized
ERROR - 2020-07-08 17:09:05 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-08 17:09:05 --> Helper loaded: file_helper
DEBUG - 2020-07-08 17:09:05 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-08 17:09:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-08 17:09:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-08 17:09:05 --> Encryption Class Initialized
INFO - 2020-07-08 17:09:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-08 17:09:06 --> Config Class Initialized
INFO - 2020-07-08 17:09:06 --> Hooks Class Initialized
DEBUG - 2020-07-08 17:09:06 --> UTF-8 Support Enabled
INFO - 2020-07-08 17:09:06 --> Utf8 Class Initialized
INFO - 2020-07-08 17:09:06 --> URI Class Initialized
INFO - 2020-07-08 17:09:06 --> Router Class Initialized
INFO - 2020-07-08 17:09:06 --> Output Class Initialized
INFO - 2020-07-08 17:09:06 --> Security Class Initialized
DEBUG - 2020-07-08 17:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 17:09:06 --> Input Class Initialized
INFO - 2020-07-08 17:09:06 --> Language Class Initialized
INFO - 2020-07-08 17:09:06 --> Language Class Initialized
INFO - 2020-07-08 17:09:06 --> Config Class Initialized
INFO - 2020-07-08 17:09:06 --> Loader Class Initialized
INFO - 2020-07-08 17:09:06 --> Helper loaded: url_helper
INFO - 2020-07-08 17:09:06 --> Helper loaded: main_helper
INFO - 2020-07-08 17:09:06 --> Database Driver Class Initialized
DEBUG - 2020-07-08 17:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 17:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 17:09:06 --> Controller Class Initialized
DEBUG - 2020-07-08 17:09:06 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-08 17:09:06 --> Final output sent to browser
DEBUG - 2020-07-08 17:09:06 --> Total execution time: 0.0044
INFO - 2020-07-08 17:16:55 --> Config Class Initialized
INFO - 2020-07-08 17:16:55 --> Hooks Class Initialized
DEBUG - 2020-07-08 17:16:55 --> UTF-8 Support Enabled
INFO - 2020-07-08 17:16:55 --> Utf8 Class Initialized
INFO - 2020-07-08 17:16:55 --> URI Class Initialized
INFO - 2020-07-08 17:16:55 --> Router Class Initialized
INFO - 2020-07-08 17:16:55 --> Output Class Initialized
INFO - 2020-07-08 17:16:55 --> Security Class Initialized
DEBUG - 2020-07-08 17:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 17:16:55 --> Input Class Initialized
INFO - 2020-07-08 17:16:55 --> Language Class Initialized
INFO - 2020-07-08 17:16:55 --> Language Class Initialized
INFO - 2020-07-08 17:16:55 --> Config Class Initialized
INFO - 2020-07-08 17:16:55 --> Loader Class Initialized
INFO - 2020-07-08 17:16:55 --> Helper loaded: url_helper
INFO - 2020-07-08 17:16:55 --> Helper loaded: main_helper
INFO - 2020-07-08 17:16:55 --> Database Driver Class Initialized
DEBUG - 2020-07-08 17:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 17:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 17:16:55 --> Controller Class Initialized
INFO - 2020-07-08 17:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-08 17:16:55 --> Pagination Class Initialized
ERROR - 2020-07-08 17:16:55 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-08 17:16:55 --> Helper loaded: file_helper
DEBUG - 2020-07-08 17:16:55 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-08 17:16:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-08 17:16:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-08 17:16:55 --> Encryption Class Initialized
INFO - 2020-07-08 17:16:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-08 17:16:56 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-08 17:16:56 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-08 17:16:56 --> Final output sent to browser
DEBUG - 2020-07-08 17:16:56 --> Total execution time: 1.2498
INFO - 2020-07-08 17:17:08 --> Config Class Initialized
INFO - 2020-07-08 17:17:08 --> Hooks Class Initialized
DEBUG - 2020-07-08 17:17:08 --> UTF-8 Support Enabled
INFO - 2020-07-08 17:17:08 --> Utf8 Class Initialized
INFO - 2020-07-08 17:17:08 --> URI Class Initialized
INFO - 2020-07-08 17:17:08 --> Router Class Initialized
INFO - 2020-07-08 17:17:08 --> Output Class Initialized
INFO - 2020-07-08 17:17:08 --> Security Class Initialized
DEBUG - 2020-07-08 17:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 17:17:08 --> Input Class Initialized
INFO - 2020-07-08 17:17:08 --> Language Class Initialized
INFO - 2020-07-08 17:17:08 --> Language Class Initialized
INFO - 2020-07-08 17:17:08 --> Config Class Initialized
INFO - 2020-07-08 17:17:08 --> Loader Class Initialized
INFO - 2020-07-08 17:17:08 --> Helper loaded: url_helper
INFO - 2020-07-08 17:17:08 --> Helper loaded: main_helper
INFO - 2020-07-08 17:17:08 --> Database Driver Class Initialized
DEBUG - 2020-07-08 17:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 17:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 17:17:08 --> Controller Class Initialized
INFO - 2020-07-08 17:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-08 17:17:08 --> Pagination Class Initialized
ERROR - 2020-07-08 17:17:08 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-08 17:17:08 --> Helper loaded: file_helper
DEBUG - 2020-07-08 17:17:08 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-08 17:17:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-08 17:17:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-08 17:17:08 --> Encryption Class Initialized
INFO - 2020-07-08 17:17:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-08 17:17:09 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-08 17:17:09 --> Final output sent to browser
DEBUG - 2020-07-08 17:17:09 --> Total execution time: 1.3363
INFO - 2020-07-08 17:17:19 --> Config Class Initialized
INFO - 2020-07-08 17:17:19 --> Hooks Class Initialized
DEBUG - 2020-07-08 17:17:19 --> UTF-8 Support Enabled
INFO - 2020-07-08 17:17:19 --> Utf8 Class Initialized
INFO - 2020-07-08 17:17:19 --> URI Class Initialized
INFO - 2020-07-08 17:17:19 --> Router Class Initialized
INFO - 2020-07-08 17:17:19 --> Output Class Initialized
INFO - 2020-07-08 17:17:19 --> Security Class Initialized
DEBUG - 2020-07-08 17:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 17:17:19 --> Input Class Initialized
INFO - 2020-07-08 17:17:19 --> Language Class Initialized
INFO - 2020-07-08 17:17:19 --> Language Class Initialized
INFO - 2020-07-08 17:17:19 --> Config Class Initialized
INFO - 2020-07-08 17:17:19 --> Loader Class Initialized
INFO - 2020-07-08 17:17:19 --> Helper loaded: url_helper
INFO - 2020-07-08 17:17:19 --> Helper loaded: main_helper
INFO - 2020-07-08 17:17:19 --> Database Driver Class Initialized
DEBUG - 2020-07-08 17:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 17:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 17:17:19 --> Controller Class Initialized
DEBUG - 2020-07-08 17:17:19 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-08 17:17:19 --> Final output sent to browser
DEBUG - 2020-07-08 17:17:19 --> Total execution time: 0.0039
INFO - 2020-07-08 17:17:21 --> Config Class Initialized
INFO - 2020-07-08 17:17:21 --> Hooks Class Initialized
DEBUG - 2020-07-08 17:17:21 --> UTF-8 Support Enabled
INFO - 2020-07-08 17:17:21 --> Utf8 Class Initialized
INFO - 2020-07-08 17:17:21 --> URI Class Initialized
INFO - 2020-07-08 17:17:21 --> Router Class Initialized
INFO - 2020-07-08 17:17:21 --> Output Class Initialized
INFO - 2020-07-08 17:17:21 --> Security Class Initialized
DEBUG - 2020-07-08 17:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 17:17:21 --> Input Class Initialized
INFO - 2020-07-08 17:17:21 --> Language Class Initialized
INFO - 2020-07-08 17:17:21 --> Language Class Initialized
INFO - 2020-07-08 17:17:21 --> Config Class Initialized
INFO - 2020-07-08 17:17:21 --> Loader Class Initialized
INFO - 2020-07-08 17:17:21 --> Helper loaded: url_helper
INFO - 2020-07-08 17:17:21 --> Helper loaded: main_helper
INFO - 2020-07-08 17:17:21 --> Database Driver Class Initialized
DEBUG - 2020-07-08 17:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 17:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 17:17:21 --> Controller Class Initialized
INFO - 2020-07-08 17:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-08 17:17:21 --> Pagination Class Initialized
ERROR - 2020-07-08 17:17:21 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-08 17:17:21 --> Helper loaded: file_helper
DEBUG - 2020-07-08 17:17:21 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-08 17:17:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-08 17:17:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-08 17:17:21 --> Encryption Class Initialized
INFO - 2020-07-08 17:17:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-08 17:17:21 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-08 17:17:21 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-08 17:17:21 --> Final output sent to browser
DEBUG - 2020-07-08 17:17:21 --> Total execution time: 0.0043
INFO - 2020-07-08 17:17:26 --> Config Class Initialized
INFO - 2020-07-08 17:17:26 --> Hooks Class Initialized
DEBUG - 2020-07-08 17:17:26 --> UTF-8 Support Enabled
INFO - 2020-07-08 17:17:26 --> Utf8 Class Initialized
INFO - 2020-07-08 17:17:26 --> URI Class Initialized
INFO - 2020-07-08 17:17:26 --> Router Class Initialized
INFO - 2020-07-08 17:17:26 --> Output Class Initialized
INFO - 2020-07-08 17:17:26 --> Security Class Initialized
DEBUG - 2020-07-08 17:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 17:17:26 --> Input Class Initialized
INFO - 2020-07-08 17:17:26 --> Language Class Initialized
INFO - 2020-07-08 17:17:26 --> Language Class Initialized
INFO - 2020-07-08 17:17:26 --> Config Class Initialized
INFO - 2020-07-08 17:17:26 --> Loader Class Initialized
INFO - 2020-07-08 17:17:26 --> Helper loaded: url_helper
INFO - 2020-07-08 17:17:26 --> Helper loaded: main_helper
INFO - 2020-07-08 17:17:26 --> Database Driver Class Initialized
DEBUG - 2020-07-08 17:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 17:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 17:17:26 --> Controller Class Initialized
INFO - 2020-07-08 17:17:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-08 17:17:26 --> Pagination Class Initialized
ERROR - 2020-07-08 17:17:26 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-08 17:17:26 --> Helper loaded: file_helper
DEBUG - 2020-07-08 17:17:26 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-08 17:17:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-07-08 17:17:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-07-08 17:17:26 --> Encryption Class Initialized
INFO - 2020-07-08 17:17:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
DEBUG - 2020-07-08 17:17:27 --> File loaded: /var/www/journal/application/modules/landing/views/xml_export_v.php
INFO - 2020-07-08 17:17:27 --> Final output sent to browser
DEBUG - 2020-07-08 17:17:27 --> Total execution time: 1.1867
INFO - 2020-07-08 22:56:06 --> Config Class Initialized
INFO - 2020-07-08 22:56:06 --> Hooks Class Initialized
DEBUG - 2020-07-08 22:56:06 --> UTF-8 Support Enabled
INFO - 2020-07-08 22:56:06 --> Utf8 Class Initialized
INFO - 2020-07-08 22:56:06 --> URI Class Initialized
INFO - 2020-07-08 22:56:06 --> Router Class Initialized
INFO - 2020-07-08 22:56:06 --> Output Class Initialized
INFO - 2020-07-08 22:56:06 --> Security Class Initialized
DEBUG - 2020-07-08 22:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 22:56:06 --> Input Class Initialized
INFO - 2020-07-08 22:56:06 --> Language Class Initialized
INFO - 2020-07-08 22:56:06 --> Language Class Initialized
INFO - 2020-07-08 22:56:06 --> Config Class Initialized
INFO - 2020-07-08 22:56:06 --> Loader Class Initialized
INFO - 2020-07-08 22:56:06 --> Helper loaded: url_helper
INFO - 2020-07-08 22:56:06 --> Helper loaded: main_helper
INFO - 2020-07-08 22:56:06 --> Database Driver Class Initialized
DEBUG - 2020-07-08 22:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 22:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 22:56:06 --> Controller Class Initialized
ERROR - 2020-07-08 22:56:06 --> Severity: error --> Exception: syntax error, unexpected 'return' (T_RETURN) /var/www/journal/application/modules/auth/models/Auth_model.php 17
INFO - 2020-07-08 22:56:23 --> Config Class Initialized
INFO - 2020-07-08 22:56:23 --> Hooks Class Initialized
DEBUG - 2020-07-08 22:56:23 --> UTF-8 Support Enabled
INFO - 2020-07-08 22:56:23 --> Utf8 Class Initialized
INFO - 2020-07-08 22:56:23 --> URI Class Initialized
INFO - 2020-07-08 22:56:23 --> Router Class Initialized
INFO - 2020-07-08 22:56:23 --> Output Class Initialized
INFO - 2020-07-08 22:56:23 --> Security Class Initialized
DEBUG - 2020-07-08 22:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 22:56:23 --> Input Class Initialized
INFO - 2020-07-08 22:56:23 --> Language Class Initialized
INFO - 2020-07-08 22:56:23 --> Language Class Initialized
INFO - 2020-07-08 22:56:23 --> Config Class Initialized
INFO - 2020-07-08 22:56:23 --> Loader Class Initialized
INFO - 2020-07-08 22:56:23 --> Helper loaded: url_helper
INFO - 2020-07-08 22:56:23 --> Helper loaded: main_helper
INFO - 2020-07-08 22:56:23 --> Database Driver Class Initialized
DEBUG - 2020-07-08 22:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 22:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 22:56:23 --> Controller Class Initialized
DEBUG - 2020-07-08 22:56:23 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-08 22:56:23 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
DEBUG - 2020-07-08 22:56:23 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-08 22:56:23 --> Final output sent to browser
DEBUG - 2020-07-08 22:56:23 --> Total execution time: 0.0038
INFO - 2020-07-08 22:56:43 --> Config Class Initialized
INFO - 2020-07-08 22:56:43 --> Hooks Class Initialized
DEBUG - 2020-07-08 22:56:43 --> UTF-8 Support Enabled
INFO - 2020-07-08 22:56:43 --> Utf8 Class Initialized
INFO - 2020-07-08 22:56:43 --> URI Class Initialized
INFO - 2020-07-08 22:56:43 --> Router Class Initialized
INFO - 2020-07-08 22:56:43 --> Output Class Initialized
INFO - 2020-07-08 22:56:43 --> Security Class Initialized
DEBUG - 2020-07-08 22:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 22:56:43 --> Input Class Initialized
INFO - 2020-07-08 22:56:43 --> Language Class Initialized
INFO - 2020-07-08 22:56:43 --> Language Class Initialized
INFO - 2020-07-08 22:56:43 --> Config Class Initialized
INFO - 2020-07-08 22:56:43 --> Loader Class Initialized
INFO - 2020-07-08 22:56:43 --> Helper loaded: url_helper
INFO - 2020-07-08 22:56:43 --> Helper loaded: main_helper
INFO - 2020-07-08 22:56:43 --> Database Driver Class Initialized
DEBUG - 2020-07-08 22:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 22:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 22:56:43 --> Controller Class Initialized
DEBUG - 2020-07-08 22:56:43 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
ERROR - 2020-07-08 22:56:43 --> Severity: Notice --> Undefined variable: data /var/www/journal/application/modules/auth/controllers/Auth.php 17
DEBUG - 2020-07-08 22:56:43 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-08 22:56:43 --> Final output sent to browser
DEBUG - 2020-07-08 22:56:43 --> Total execution time: 0.0057
INFO - 2020-07-08 22:56:50 --> Config Class Initialized
INFO - 2020-07-08 22:56:50 --> Hooks Class Initialized
DEBUG - 2020-07-08 22:56:50 --> UTF-8 Support Enabled
INFO - 2020-07-08 22:56:50 --> Utf8 Class Initialized
INFO - 2020-07-08 22:56:50 --> URI Class Initialized
INFO - 2020-07-08 22:56:50 --> Router Class Initialized
INFO - 2020-07-08 22:56:50 --> Output Class Initialized
INFO - 2020-07-08 22:56:50 --> Security Class Initialized
DEBUG - 2020-07-08 22:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 22:56:50 --> Input Class Initialized
INFO - 2020-07-08 22:56:50 --> Language Class Initialized
INFO - 2020-07-08 22:56:50 --> Language Class Initialized
INFO - 2020-07-08 22:56:50 --> Config Class Initialized
INFO - 2020-07-08 22:56:50 --> Loader Class Initialized
INFO - 2020-07-08 22:56:50 --> Helper loaded: url_helper
INFO - 2020-07-08 22:56:50 --> Helper loaded: main_helper
INFO - 2020-07-08 22:56:50 --> Database Driver Class Initialized
DEBUG - 2020-07-08 22:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 22:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 22:56:50 --> Controller Class Initialized
DEBUG - 2020-07-08 22:56:50 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-08 22:56:50 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-08 22:56:50 --> Final output sent to browser
DEBUG - 2020-07-08 22:56:50 --> Total execution time: 0.0037
INFO - 2020-07-08 22:57:27 --> Config Class Initialized
INFO - 2020-07-08 22:57:27 --> Hooks Class Initialized
DEBUG - 2020-07-08 22:57:27 --> UTF-8 Support Enabled
INFO - 2020-07-08 22:57:27 --> Utf8 Class Initialized
INFO - 2020-07-08 22:57:27 --> URI Class Initialized
INFO - 2020-07-08 22:57:27 --> Router Class Initialized
INFO - 2020-07-08 22:57:27 --> Output Class Initialized
INFO - 2020-07-08 22:57:27 --> Security Class Initialized
DEBUG - 2020-07-08 22:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 22:57:27 --> Input Class Initialized
INFO - 2020-07-08 22:57:27 --> Language Class Initialized
INFO - 2020-07-08 22:57:27 --> Language Class Initialized
INFO - 2020-07-08 22:57:27 --> Config Class Initialized
INFO - 2020-07-08 22:57:27 --> Loader Class Initialized
INFO - 2020-07-08 22:57:27 --> Helper loaded: url_helper
INFO - 2020-07-08 22:57:27 --> Helper loaded: main_helper
INFO - 2020-07-08 22:57:27 --> Database Driver Class Initialized
DEBUG - 2020-07-08 22:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 22:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 22:57:27 --> Controller Class Initialized
DEBUG - 2020-07-08 22:57:27 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-08 22:57:27 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-08 22:57:27 --> Final output sent to browser
DEBUG - 2020-07-08 22:57:27 --> Total execution time: 0.0038
INFO - 2020-07-08 22:57:58 --> Config Class Initialized
INFO - 2020-07-08 22:57:58 --> Hooks Class Initialized
DEBUG - 2020-07-08 22:57:58 --> UTF-8 Support Enabled
INFO - 2020-07-08 22:57:58 --> Utf8 Class Initialized
INFO - 2020-07-08 22:57:58 --> URI Class Initialized
INFO - 2020-07-08 22:57:58 --> Router Class Initialized
INFO - 2020-07-08 22:57:58 --> Output Class Initialized
INFO - 2020-07-08 22:57:58 --> Security Class Initialized
DEBUG - 2020-07-08 22:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 22:57:58 --> Input Class Initialized
INFO - 2020-07-08 22:57:58 --> Language Class Initialized
INFO - 2020-07-08 22:57:58 --> Language Class Initialized
INFO - 2020-07-08 22:57:58 --> Config Class Initialized
INFO - 2020-07-08 22:57:58 --> Loader Class Initialized
INFO - 2020-07-08 22:57:58 --> Helper loaded: url_helper
INFO - 2020-07-08 22:57:58 --> Helper loaded: main_helper
INFO - 2020-07-08 22:57:58 --> Database Driver Class Initialized
DEBUG - 2020-07-08 22:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 22:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 22:57:58 --> Controller Class Initialized
DEBUG - 2020-07-08 22:57:58 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-08 22:57:58 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-08 22:57:58 --> Final output sent to browser
DEBUG - 2020-07-08 22:57:58 --> Total execution time: 0.0032
INFO - 2020-07-08 22:58:20 --> Config Class Initialized
INFO - 2020-07-08 22:58:20 --> Hooks Class Initialized
DEBUG - 2020-07-08 22:58:20 --> UTF-8 Support Enabled
INFO - 2020-07-08 22:58:20 --> Utf8 Class Initialized
INFO - 2020-07-08 22:58:20 --> URI Class Initialized
INFO - 2020-07-08 22:58:20 --> Router Class Initialized
INFO - 2020-07-08 22:58:20 --> Output Class Initialized
INFO - 2020-07-08 22:58:20 --> Security Class Initialized
DEBUG - 2020-07-08 22:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 22:58:20 --> Input Class Initialized
INFO - 2020-07-08 22:58:20 --> Language Class Initialized
INFO - 2020-07-08 22:58:20 --> Language Class Initialized
INFO - 2020-07-08 22:58:20 --> Config Class Initialized
INFO - 2020-07-08 22:58:20 --> Loader Class Initialized
INFO - 2020-07-08 22:58:20 --> Helper loaded: url_helper
INFO - 2020-07-08 22:58:20 --> Helper loaded: main_helper
INFO - 2020-07-08 22:58:20 --> Database Driver Class Initialized
DEBUG - 2020-07-08 22:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 22:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 22:58:20 --> Controller Class Initialized
DEBUG - 2020-07-08 22:58:20 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-08 22:58:20 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-08 22:58:20 --> Final output sent to browser
DEBUG - 2020-07-08 22:58:20 --> Total execution time: 0.0034
INFO - 2020-07-08 22:59:20 --> Config Class Initialized
INFO - 2020-07-08 22:59:20 --> Hooks Class Initialized
DEBUG - 2020-07-08 22:59:20 --> UTF-8 Support Enabled
INFO - 2020-07-08 22:59:20 --> Utf8 Class Initialized
INFO - 2020-07-08 22:59:20 --> URI Class Initialized
INFO - 2020-07-08 22:59:20 --> Router Class Initialized
INFO - 2020-07-08 22:59:20 --> Output Class Initialized
INFO - 2020-07-08 22:59:20 --> Security Class Initialized
DEBUG - 2020-07-08 22:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 22:59:20 --> Input Class Initialized
INFO - 2020-07-08 22:59:20 --> Language Class Initialized
INFO - 2020-07-08 22:59:20 --> Language Class Initialized
INFO - 2020-07-08 22:59:20 --> Config Class Initialized
INFO - 2020-07-08 22:59:20 --> Loader Class Initialized
INFO - 2020-07-08 22:59:20 --> Helper loaded: url_helper
INFO - 2020-07-08 22:59:20 --> Helper loaded: main_helper
INFO - 2020-07-08 22:59:20 --> Database Driver Class Initialized
DEBUG - 2020-07-08 22:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 22:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 22:59:20 --> Controller Class Initialized
DEBUG - 2020-07-08 22:59:20 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-08 22:59:20 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-08 22:59:20 --> Final output sent to browser
DEBUG - 2020-07-08 22:59:20 --> Total execution time: 0.0035
INFO - 2020-07-08 22:59:30 --> Config Class Initialized
INFO - 2020-07-08 22:59:30 --> Hooks Class Initialized
DEBUG - 2020-07-08 22:59:30 --> UTF-8 Support Enabled
INFO - 2020-07-08 22:59:30 --> Utf8 Class Initialized
INFO - 2020-07-08 22:59:30 --> URI Class Initialized
INFO - 2020-07-08 22:59:30 --> Router Class Initialized
INFO - 2020-07-08 22:59:30 --> Output Class Initialized
INFO - 2020-07-08 22:59:30 --> Security Class Initialized
DEBUG - 2020-07-08 22:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 22:59:30 --> Input Class Initialized
INFO - 2020-07-08 22:59:30 --> Language Class Initialized
INFO - 2020-07-08 22:59:30 --> Language Class Initialized
INFO - 2020-07-08 22:59:30 --> Config Class Initialized
INFO - 2020-07-08 22:59:30 --> Loader Class Initialized
INFO - 2020-07-08 22:59:30 --> Helper loaded: url_helper
INFO - 2020-07-08 22:59:30 --> Helper loaded: main_helper
INFO - 2020-07-08 22:59:30 --> Database Driver Class Initialized
DEBUG - 2020-07-08 22:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 22:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 22:59:30 --> Controller Class Initialized
DEBUG - 2020-07-08 22:59:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-08 22:59:30 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-08 22:59:30 --> Final output sent to browser
DEBUG - 2020-07-08 22:59:30 --> Total execution time: 0.0033
INFO - 2020-07-08 22:59:42 --> Config Class Initialized
INFO - 2020-07-08 22:59:42 --> Hooks Class Initialized
DEBUG - 2020-07-08 22:59:42 --> UTF-8 Support Enabled
INFO - 2020-07-08 22:59:42 --> Utf8 Class Initialized
INFO - 2020-07-08 22:59:42 --> URI Class Initialized
INFO - 2020-07-08 22:59:42 --> Router Class Initialized
INFO - 2020-07-08 22:59:42 --> Output Class Initialized
INFO - 2020-07-08 22:59:42 --> Security Class Initialized
DEBUG - 2020-07-08 22:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 22:59:42 --> Input Class Initialized
INFO - 2020-07-08 22:59:42 --> Language Class Initialized
INFO - 2020-07-08 22:59:42 --> Language Class Initialized
INFO - 2020-07-08 22:59:42 --> Config Class Initialized
INFO - 2020-07-08 22:59:42 --> Loader Class Initialized
INFO - 2020-07-08 22:59:42 --> Helper loaded: url_helper
INFO - 2020-07-08 22:59:42 --> Helper loaded: main_helper
INFO - 2020-07-08 22:59:42 --> Database Driver Class Initialized
DEBUG - 2020-07-08 22:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 22:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 22:59:42 --> Controller Class Initialized
DEBUG - 2020-07-08 22:59:42 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-08 22:59:42 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-08 22:59:42 --> Final output sent to browser
DEBUG - 2020-07-08 22:59:42 --> Total execution time: 0.0031
INFO - 2020-07-08 23:02:30 --> Config Class Initialized
INFO - 2020-07-08 23:02:30 --> Hooks Class Initialized
DEBUG - 2020-07-08 23:02:30 --> UTF-8 Support Enabled
INFO - 2020-07-08 23:02:30 --> Utf8 Class Initialized
INFO - 2020-07-08 23:02:30 --> URI Class Initialized
INFO - 2020-07-08 23:02:30 --> Router Class Initialized
INFO - 2020-07-08 23:02:30 --> Output Class Initialized
INFO - 2020-07-08 23:02:30 --> Security Class Initialized
DEBUG - 2020-07-08 23:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 23:02:30 --> Input Class Initialized
INFO - 2020-07-08 23:02:30 --> Language Class Initialized
INFO - 2020-07-08 23:02:30 --> Language Class Initialized
INFO - 2020-07-08 23:02:30 --> Config Class Initialized
INFO - 2020-07-08 23:02:30 --> Loader Class Initialized
INFO - 2020-07-08 23:02:30 --> Helper loaded: url_helper
INFO - 2020-07-08 23:02:30 --> Helper loaded: main_helper
INFO - 2020-07-08 23:02:30 --> Database Driver Class Initialized
DEBUG - 2020-07-08 23:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 23:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 23:02:30 --> Controller Class Initialized
DEBUG - 2020-07-08 23:02:30 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-08 23:02:30 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-08 23:02:30 --> Final output sent to browser
DEBUG - 2020-07-08 23:02:30 --> Total execution time: 0.0039
INFO - 2020-07-08 23:02:58 --> Config Class Initialized
INFO - 2020-07-08 23:02:58 --> Hooks Class Initialized
DEBUG - 2020-07-08 23:02:58 --> UTF-8 Support Enabled
INFO - 2020-07-08 23:02:58 --> Utf8 Class Initialized
INFO - 2020-07-08 23:02:58 --> URI Class Initialized
INFO - 2020-07-08 23:02:58 --> Router Class Initialized
INFO - 2020-07-08 23:02:58 --> Output Class Initialized
INFO - 2020-07-08 23:02:58 --> Security Class Initialized
DEBUG - 2020-07-08 23:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 23:02:58 --> Input Class Initialized
INFO - 2020-07-08 23:02:58 --> Language Class Initialized
INFO - 2020-07-08 23:02:58 --> Language Class Initialized
INFO - 2020-07-08 23:02:58 --> Config Class Initialized
INFO - 2020-07-08 23:02:58 --> Loader Class Initialized
INFO - 2020-07-08 23:02:58 --> Helper loaded: url_helper
INFO - 2020-07-08 23:02:58 --> Helper loaded: main_helper
INFO - 2020-07-08 23:02:58 --> Database Driver Class Initialized
DEBUG - 2020-07-08 23:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 23:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 23:02:58 --> Controller Class Initialized
DEBUG - 2020-07-08 23:02:58 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-08 23:02:58 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-08 23:02:58 --> Final output sent to browser
DEBUG - 2020-07-08 23:02:58 --> Total execution time: 0.0047
INFO - 2020-07-08 23:03:14 --> Config Class Initialized
INFO - 2020-07-08 23:03:14 --> Hooks Class Initialized
DEBUG - 2020-07-08 23:03:14 --> UTF-8 Support Enabled
INFO - 2020-07-08 23:03:14 --> Utf8 Class Initialized
INFO - 2020-07-08 23:03:14 --> URI Class Initialized
INFO - 2020-07-08 23:03:14 --> Router Class Initialized
INFO - 2020-07-08 23:03:14 --> Output Class Initialized
INFO - 2020-07-08 23:03:14 --> Security Class Initialized
DEBUG - 2020-07-08 23:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-08 23:03:14 --> Input Class Initialized
INFO - 2020-07-08 23:03:14 --> Language Class Initialized
INFO - 2020-07-08 23:03:14 --> Language Class Initialized
INFO - 2020-07-08 23:03:14 --> Config Class Initialized
INFO - 2020-07-08 23:03:14 --> Loader Class Initialized
INFO - 2020-07-08 23:03:14 --> Helper loaded: url_helper
INFO - 2020-07-08 23:03:14 --> Helper loaded: main_helper
INFO - 2020-07-08 23:03:14 --> Database Driver Class Initialized
DEBUG - 2020-07-08 23:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-08 23:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-08 23:03:14 --> Controller Class Initialized
DEBUG - 2020-07-08 23:03:14 --> File loaded: /var/www/journal/application/modules/auth/models/Auth_model.php
DEBUG - 2020-07-08 23:03:14 --> File loaded: /var/www/journal/application/modules/auth/views/auth_v.php
INFO - 2020-07-08 23:03:14 --> Final output sent to browser
DEBUG - 2020-07-08 23:03:14 --> Total execution time: 0.0033
