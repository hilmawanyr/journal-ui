<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-07-05 00:00:25 --> Config Class Initialized
INFO - 2020-07-05 00:00:25 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:00:25 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:00:25 --> Utf8 Class Initialized
INFO - 2020-07-05 00:00:25 --> URI Class Initialized
INFO - 2020-07-05 00:00:25 --> Router Class Initialized
INFO - 2020-07-05 00:00:25 --> Output Class Initialized
INFO - 2020-07-05 00:00:25 --> Security Class Initialized
DEBUG - 2020-07-05 00:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:00:25 --> Input Class Initialized
INFO - 2020-07-05 00:00:25 --> Language Class Initialized
INFO - 2020-07-05 00:00:25 --> Language Class Initialized
INFO - 2020-07-05 00:00:25 --> Config Class Initialized
INFO - 2020-07-05 00:00:25 --> Loader Class Initialized
INFO - 2020-07-05 00:00:25 --> Helper loaded: url_helper
INFO - 2020-07-05 00:00:25 --> Helper loaded: main_helper
INFO - 2020-07-05 00:00:25 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:00:25 --> Controller Class Initialized
INFO - 2020-07-05 00:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:00:25 --> Pagination Class Initialized
ERROR - 2020-07-05 00:00:25 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:00:25 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:00:25 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:00:26 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:00:26 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:00:26 --> Final output sent to browser
DEBUG - 2020-07-05 00:00:26 --> Total execution time: 1.3622
INFO - 2020-07-05 00:00:32 --> Config Class Initialized
INFO - 2020-07-05 00:00:32 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:00:32 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:00:32 --> Utf8 Class Initialized
INFO - 2020-07-05 00:00:32 --> URI Class Initialized
INFO - 2020-07-05 00:00:32 --> Router Class Initialized
INFO - 2020-07-05 00:00:32 --> Output Class Initialized
INFO - 2020-07-05 00:00:32 --> Security Class Initialized
DEBUG - 2020-07-05 00:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:00:32 --> Input Class Initialized
INFO - 2020-07-05 00:00:32 --> Language Class Initialized
INFO - 2020-07-05 00:00:32 --> Language Class Initialized
INFO - 2020-07-05 00:00:32 --> Config Class Initialized
INFO - 2020-07-05 00:00:32 --> Loader Class Initialized
INFO - 2020-07-05 00:00:32 --> Helper loaded: url_helper
INFO - 2020-07-05 00:00:32 --> Helper loaded: main_helper
INFO - 2020-07-05 00:00:32 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:00:32 --> Controller Class Initialized
INFO - 2020-07-05 00:00:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:00:32 --> Pagination Class Initialized
ERROR - 2020-07-05 00:00:32 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:00:32 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:00:32 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:00:33 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:00:33 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:00:33 --> Final output sent to browser
DEBUG - 2020-07-05 00:00:33 --> Total execution time: 1.3050
INFO - 2020-07-05 00:00:38 --> Config Class Initialized
INFO - 2020-07-05 00:00:38 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:00:38 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:00:38 --> Utf8 Class Initialized
INFO - 2020-07-05 00:00:38 --> URI Class Initialized
INFO - 2020-07-05 00:00:38 --> Router Class Initialized
INFO - 2020-07-05 00:00:38 --> Output Class Initialized
INFO - 2020-07-05 00:00:38 --> Security Class Initialized
DEBUG - 2020-07-05 00:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:00:38 --> Input Class Initialized
INFO - 2020-07-05 00:00:38 --> Language Class Initialized
INFO - 2020-07-05 00:00:38 --> Language Class Initialized
INFO - 2020-07-05 00:00:38 --> Config Class Initialized
INFO - 2020-07-05 00:00:38 --> Loader Class Initialized
INFO - 2020-07-05 00:00:38 --> Helper loaded: url_helper
INFO - 2020-07-05 00:00:38 --> Helper loaded: main_helper
INFO - 2020-07-05 00:00:38 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:00:38 --> Controller Class Initialized
INFO - 2020-07-05 00:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:00:38 --> Pagination Class Initialized
ERROR - 2020-07-05 00:00:38 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:00:38 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:00:38 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:00:39 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:00:39 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:00:39 --> Final output sent to browser
DEBUG - 2020-07-05 00:00:39 --> Total execution time: 1.3032
INFO - 2020-07-05 00:00:44 --> Config Class Initialized
INFO - 2020-07-05 00:00:44 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:00:44 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:00:44 --> Utf8 Class Initialized
INFO - 2020-07-05 00:00:44 --> URI Class Initialized
INFO - 2020-07-05 00:00:44 --> Router Class Initialized
INFO - 2020-07-05 00:00:44 --> Output Class Initialized
INFO - 2020-07-05 00:00:44 --> Security Class Initialized
DEBUG - 2020-07-05 00:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:00:44 --> Input Class Initialized
INFO - 2020-07-05 00:00:44 --> Language Class Initialized
INFO - 2020-07-05 00:00:44 --> Language Class Initialized
INFO - 2020-07-05 00:00:44 --> Config Class Initialized
INFO - 2020-07-05 00:00:44 --> Loader Class Initialized
INFO - 2020-07-05 00:00:44 --> Helper loaded: url_helper
INFO - 2020-07-05 00:00:44 --> Helper loaded: main_helper
INFO - 2020-07-05 00:00:44 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:00:44 --> Controller Class Initialized
INFO - 2020-07-05 00:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:00:44 --> Pagination Class Initialized
ERROR - 2020-07-05 00:00:44 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:00:44 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:00:44 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:00:44 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:00:44 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:00:44 --> Final output sent to browser
DEBUG - 2020-07-05 00:00:44 --> Total execution time: 0.0040
INFO - 2020-07-05 00:00:48 --> Config Class Initialized
INFO - 2020-07-05 00:00:48 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:00:48 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:00:48 --> Utf8 Class Initialized
INFO - 2020-07-05 00:00:48 --> URI Class Initialized
INFO - 2020-07-05 00:00:48 --> Router Class Initialized
INFO - 2020-07-05 00:00:48 --> Output Class Initialized
INFO - 2020-07-05 00:00:48 --> Security Class Initialized
DEBUG - 2020-07-05 00:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:00:48 --> Input Class Initialized
INFO - 2020-07-05 00:00:48 --> Language Class Initialized
INFO - 2020-07-05 00:00:48 --> Language Class Initialized
INFO - 2020-07-05 00:00:48 --> Config Class Initialized
INFO - 2020-07-05 00:00:48 --> Loader Class Initialized
INFO - 2020-07-05 00:00:48 --> Helper loaded: url_helper
INFO - 2020-07-05 00:00:48 --> Helper loaded: main_helper
INFO - 2020-07-05 00:00:48 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:00:48 --> Controller Class Initialized
INFO - 2020-07-05 00:00:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:00:48 --> Pagination Class Initialized
ERROR - 2020-07-05 00:00:48 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:00:48 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:00:48 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:00:50 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:00:50 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:00:50 --> Final output sent to browser
DEBUG - 2020-07-05 00:00:50 --> Total execution time: 1.2536
INFO - 2020-07-05 00:01:10 --> Config Class Initialized
INFO - 2020-07-05 00:01:10 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:01:10 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:01:10 --> Utf8 Class Initialized
INFO - 2020-07-05 00:01:10 --> URI Class Initialized
INFO - 2020-07-05 00:01:10 --> Router Class Initialized
INFO - 2020-07-05 00:01:10 --> Output Class Initialized
INFO - 2020-07-05 00:01:10 --> Security Class Initialized
DEBUG - 2020-07-05 00:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:01:10 --> Input Class Initialized
INFO - 2020-07-05 00:01:10 --> Language Class Initialized
INFO - 2020-07-05 00:01:10 --> Language Class Initialized
INFO - 2020-07-05 00:01:10 --> Config Class Initialized
INFO - 2020-07-05 00:01:10 --> Loader Class Initialized
INFO - 2020-07-05 00:01:10 --> Helper loaded: url_helper
INFO - 2020-07-05 00:01:10 --> Helper loaded: main_helper
INFO - 2020-07-05 00:01:10 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:01:10 --> Controller Class Initialized
INFO - 2020-07-05 00:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:01:10 --> Pagination Class Initialized
ERROR - 2020-07-05 00:01:10 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:01:10 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:01:10 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:01:10 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:01:10 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:01:10 --> Final output sent to browser
DEBUG - 2020-07-05 00:01:10 --> Total execution time: 0.0039
INFO - 2020-07-05 00:02:03 --> Config Class Initialized
INFO - 2020-07-05 00:02:03 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:02:03 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:02:03 --> Utf8 Class Initialized
INFO - 2020-07-05 00:02:03 --> URI Class Initialized
INFO - 2020-07-05 00:02:03 --> Router Class Initialized
INFO - 2020-07-05 00:02:03 --> Output Class Initialized
INFO - 2020-07-05 00:02:03 --> Security Class Initialized
DEBUG - 2020-07-05 00:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:02:03 --> Input Class Initialized
INFO - 2020-07-05 00:02:03 --> Language Class Initialized
INFO - 2020-07-05 00:02:03 --> Language Class Initialized
INFO - 2020-07-05 00:02:03 --> Config Class Initialized
INFO - 2020-07-05 00:02:03 --> Loader Class Initialized
INFO - 2020-07-05 00:02:03 --> Helper loaded: url_helper
INFO - 2020-07-05 00:02:03 --> Helper loaded: main_helper
INFO - 2020-07-05 00:02:03 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:02:03 --> Controller Class Initialized
INFO - 2020-07-05 00:02:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:02:03 --> Pagination Class Initialized
ERROR - 2020-07-05 00:02:03 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:02:03 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:02:03 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:02:03 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:02:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:02:03 --> Final output sent to browser
DEBUG - 2020-07-05 00:02:03 --> Total execution time: 0.0112
INFO - 2020-07-05 00:02:08 --> Config Class Initialized
INFO - 2020-07-05 00:02:08 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:02:08 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:02:08 --> Utf8 Class Initialized
INFO - 2020-07-05 00:02:08 --> URI Class Initialized
INFO - 2020-07-05 00:02:08 --> Router Class Initialized
INFO - 2020-07-05 00:02:08 --> Output Class Initialized
INFO - 2020-07-05 00:02:08 --> Security Class Initialized
DEBUG - 2020-07-05 00:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:02:08 --> Input Class Initialized
INFO - 2020-07-05 00:02:08 --> Language Class Initialized
INFO - 2020-07-05 00:02:08 --> Language Class Initialized
INFO - 2020-07-05 00:02:08 --> Config Class Initialized
INFO - 2020-07-05 00:02:08 --> Loader Class Initialized
INFO - 2020-07-05 00:02:08 --> Helper loaded: url_helper
INFO - 2020-07-05 00:02:08 --> Helper loaded: main_helper
INFO - 2020-07-05 00:02:08 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:02:08 --> Controller Class Initialized
INFO - 2020-07-05 00:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:02:08 --> Pagination Class Initialized
ERROR - 2020-07-05 00:02:08 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:02:08 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:02:08 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:02:08 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:02:08 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:02:08 --> Final output sent to browser
DEBUG - 2020-07-05 00:02:08 --> Total execution time: 0.0043
INFO - 2020-07-05 00:02:23 --> Config Class Initialized
INFO - 2020-07-05 00:02:23 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:02:23 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:02:23 --> Utf8 Class Initialized
INFO - 2020-07-05 00:02:23 --> URI Class Initialized
INFO - 2020-07-05 00:02:23 --> Router Class Initialized
INFO - 2020-07-05 00:02:23 --> Output Class Initialized
INFO - 2020-07-05 00:02:23 --> Security Class Initialized
DEBUG - 2020-07-05 00:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:02:23 --> Input Class Initialized
INFO - 2020-07-05 00:02:23 --> Language Class Initialized
INFO - 2020-07-05 00:02:23 --> Language Class Initialized
INFO - 2020-07-05 00:02:23 --> Config Class Initialized
INFO - 2020-07-05 00:02:23 --> Loader Class Initialized
INFO - 2020-07-05 00:02:23 --> Helper loaded: url_helper
INFO - 2020-07-05 00:02:23 --> Helper loaded: main_helper
INFO - 2020-07-05 00:02:23 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:02:23 --> Controller Class Initialized
INFO - 2020-07-05 00:02:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:02:23 --> Pagination Class Initialized
ERROR - 2020-07-05 00:02:23 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:02:23 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:02:23 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:02:23 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:02:23 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:02:23 --> Final output sent to browser
DEBUG - 2020-07-05 00:02:23 --> Total execution time: 0.0045
INFO - 2020-07-05 00:02:31 --> Config Class Initialized
INFO - 2020-07-05 00:02:31 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:02:31 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:02:31 --> Utf8 Class Initialized
INFO - 2020-07-05 00:02:31 --> URI Class Initialized
INFO - 2020-07-05 00:02:31 --> Router Class Initialized
INFO - 2020-07-05 00:02:31 --> Output Class Initialized
INFO - 2020-07-05 00:02:31 --> Security Class Initialized
DEBUG - 2020-07-05 00:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:02:31 --> Input Class Initialized
INFO - 2020-07-05 00:02:31 --> Language Class Initialized
INFO - 2020-07-05 00:02:31 --> Language Class Initialized
INFO - 2020-07-05 00:02:31 --> Config Class Initialized
INFO - 2020-07-05 00:02:31 --> Loader Class Initialized
INFO - 2020-07-05 00:02:31 --> Helper loaded: url_helper
INFO - 2020-07-05 00:02:31 --> Helper loaded: main_helper
INFO - 2020-07-05 00:02:31 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:02:31 --> Controller Class Initialized
INFO - 2020-07-05 00:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:02:31 --> Pagination Class Initialized
ERROR - 2020-07-05 00:02:31 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:02:31 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:02:31 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:02:31 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:02:31 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:02:31 --> Final output sent to browser
DEBUG - 2020-07-05 00:02:31 --> Total execution time: 0.0040
INFO - 2020-07-05 00:02:36 --> Config Class Initialized
INFO - 2020-07-05 00:02:36 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:02:36 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:02:36 --> Utf8 Class Initialized
INFO - 2020-07-05 00:02:36 --> URI Class Initialized
INFO - 2020-07-05 00:02:36 --> Router Class Initialized
INFO - 2020-07-05 00:02:36 --> Output Class Initialized
INFO - 2020-07-05 00:02:36 --> Security Class Initialized
DEBUG - 2020-07-05 00:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:02:36 --> Input Class Initialized
INFO - 2020-07-05 00:02:36 --> Language Class Initialized
INFO - 2020-07-05 00:02:36 --> Language Class Initialized
INFO - 2020-07-05 00:02:36 --> Config Class Initialized
INFO - 2020-07-05 00:02:36 --> Loader Class Initialized
INFO - 2020-07-05 00:02:36 --> Helper loaded: url_helper
INFO - 2020-07-05 00:02:36 --> Helper loaded: main_helper
INFO - 2020-07-05 00:02:36 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:02:36 --> Controller Class Initialized
INFO - 2020-07-05 00:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:02:36 --> Pagination Class Initialized
ERROR - 2020-07-05 00:02:36 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:02:36 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:02:36 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:02:36 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:02:36 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:02:36 --> Final output sent to browser
DEBUG - 2020-07-05 00:02:36 --> Total execution time: 0.0076
INFO - 2020-07-05 00:02:42 --> Config Class Initialized
INFO - 2020-07-05 00:02:42 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:02:42 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:02:42 --> Utf8 Class Initialized
INFO - 2020-07-05 00:02:42 --> URI Class Initialized
INFO - 2020-07-05 00:02:42 --> Router Class Initialized
INFO - 2020-07-05 00:02:42 --> Output Class Initialized
INFO - 2020-07-05 00:02:42 --> Security Class Initialized
DEBUG - 2020-07-05 00:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:02:42 --> Input Class Initialized
INFO - 2020-07-05 00:02:42 --> Language Class Initialized
INFO - 2020-07-05 00:02:42 --> Language Class Initialized
INFO - 2020-07-05 00:02:42 --> Config Class Initialized
INFO - 2020-07-05 00:02:42 --> Loader Class Initialized
INFO - 2020-07-05 00:02:42 --> Helper loaded: url_helper
INFO - 2020-07-05 00:02:42 --> Helper loaded: main_helper
INFO - 2020-07-05 00:02:42 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:02:42 --> Controller Class Initialized
INFO - 2020-07-05 00:02:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:02:42 --> Pagination Class Initialized
ERROR - 2020-07-05 00:02:42 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:02:42 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:02:42 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:02:42 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:02:42 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:02:42 --> Final output sent to browser
DEBUG - 2020-07-05 00:02:42 --> Total execution time: 0.0057
INFO - 2020-07-05 00:02:46 --> Config Class Initialized
INFO - 2020-07-05 00:02:46 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:02:46 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:02:46 --> Utf8 Class Initialized
INFO - 2020-07-05 00:02:46 --> URI Class Initialized
INFO - 2020-07-05 00:02:46 --> Router Class Initialized
INFO - 2020-07-05 00:02:46 --> Output Class Initialized
INFO - 2020-07-05 00:02:46 --> Security Class Initialized
DEBUG - 2020-07-05 00:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:02:46 --> Input Class Initialized
INFO - 2020-07-05 00:02:46 --> Language Class Initialized
INFO - 2020-07-05 00:02:46 --> Language Class Initialized
INFO - 2020-07-05 00:02:46 --> Config Class Initialized
INFO - 2020-07-05 00:02:46 --> Loader Class Initialized
INFO - 2020-07-05 00:02:46 --> Helper loaded: url_helper
INFO - 2020-07-05 00:02:46 --> Helper loaded: main_helper
INFO - 2020-07-05 00:02:46 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:02:46 --> Controller Class Initialized
INFO - 2020-07-05 00:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:02:46 --> Pagination Class Initialized
ERROR - 2020-07-05 00:02:46 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:02:46 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:02:46 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:02:46 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:02:46 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:02:46 --> Final output sent to browser
DEBUG - 2020-07-05 00:02:46 --> Total execution time: 0.0078
INFO - 2020-07-05 00:02:54 --> Config Class Initialized
INFO - 2020-07-05 00:02:54 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:02:54 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:02:54 --> Utf8 Class Initialized
INFO - 2020-07-05 00:02:54 --> URI Class Initialized
INFO - 2020-07-05 00:02:54 --> Router Class Initialized
INFO - 2020-07-05 00:02:54 --> Output Class Initialized
INFO - 2020-07-05 00:02:54 --> Security Class Initialized
DEBUG - 2020-07-05 00:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:02:54 --> Input Class Initialized
INFO - 2020-07-05 00:02:54 --> Language Class Initialized
INFO - 2020-07-05 00:02:54 --> Language Class Initialized
INFO - 2020-07-05 00:02:54 --> Config Class Initialized
INFO - 2020-07-05 00:02:54 --> Loader Class Initialized
INFO - 2020-07-05 00:02:54 --> Helper loaded: url_helper
INFO - 2020-07-05 00:02:54 --> Helper loaded: main_helper
INFO - 2020-07-05 00:02:54 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:02:54 --> Controller Class Initialized
INFO - 2020-07-05 00:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:02:54 --> Pagination Class Initialized
ERROR - 2020-07-05 00:02:54 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:02:54 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:02:54 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:02:54 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:02:54 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:02:54 --> Final output sent to browser
DEBUG - 2020-07-05 00:02:54 --> Total execution time: 0.0078
INFO - 2020-07-05 00:02:59 --> Config Class Initialized
INFO - 2020-07-05 00:02:59 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:02:59 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:02:59 --> Utf8 Class Initialized
INFO - 2020-07-05 00:02:59 --> URI Class Initialized
INFO - 2020-07-05 00:02:59 --> Router Class Initialized
INFO - 2020-07-05 00:02:59 --> Output Class Initialized
INFO - 2020-07-05 00:02:59 --> Security Class Initialized
DEBUG - 2020-07-05 00:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:02:59 --> Input Class Initialized
INFO - 2020-07-05 00:02:59 --> Language Class Initialized
INFO - 2020-07-05 00:02:59 --> Language Class Initialized
INFO - 2020-07-05 00:02:59 --> Config Class Initialized
INFO - 2020-07-05 00:02:59 --> Loader Class Initialized
INFO - 2020-07-05 00:02:59 --> Helper loaded: url_helper
INFO - 2020-07-05 00:02:59 --> Helper loaded: main_helper
INFO - 2020-07-05 00:02:59 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:02:59 --> Controller Class Initialized
INFO - 2020-07-05 00:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:02:59 --> Pagination Class Initialized
ERROR - 2020-07-05 00:02:59 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:02:59 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:02:59 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:03:00 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 00:03:00 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:03:00 --> Final output sent to browser
DEBUG - 2020-07-05 00:03:00 --> Total execution time: 1.2746
INFO - 2020-07-05 00:03:08 --> Config Class Initialized
INFO - 2020-07-05 00:03:08 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:03:08 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:03:08 --> Utf8 Class Initialized
INFO - 2020-07-05 00:03:08 --> URI Class Initialized
INFO - 2020-07-05 00:03:08 --> Router Class Initialized
INFO - 2020-07-05 00:03:08 --> Output Class Initialized
INFO - 2020-07-05 00:03:08 --> Security Class Initialized
DEBUG - 2020-07-05 00:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:03:08 --> Input Class Initialized
INFO - 2020-07-05 00:03:08 --> Language Class Initialized
INFO - 2020-07-05 00:03:08 --> Language Class Initialized
INFO - 2020-07-05 00:03:08 --> Config Class Initialized
INFO - 2020-07-05 00:03:08 --> Loader Class Initialized
INFO - 2020-07-05 00:03:08 --> Helper loaded: url_helper
INFO - 2020-07-05 00:03:08 --> Helper loaded: main_helper
INFO - 2020-07-05 00:03:08 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:03:08 --> Controller Class Initialized
INFO - 2020-07-05 00:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 00:03:08 --> Pagination Class Initialized
ERROR - 2020-07-05 00:03:08 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 00:03:08 --> Helper loaded: file_helper
DEBUG - 2020-07-05 00:03:08 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 00:03:09 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 00:03:09 --> Final output sent to browser
DEBUG - 2020-07-05 00:03:09 --> Total execution time: 1.2124
INFO - 2020-07-05 00:03:37 --> Config Class Initialized
INFO - 2020-07-05 00:03:37 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:03:37 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:03:37 --> Utf8 Class Initialized
INFO - 2020-07-05 00:03:37 --> URI Class Initialized
INFO - 2020-07-05 00:03:37 --> Router Class Initialized
INFO - 2020-07-05 00:03:37 --> Output Class Initialized
INFO - 2020-07-05 00:03:37 --> Security Class Initialized
DEBUG - 2020-07-05 00:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:03:37 --> Input Class Initialized
INFO - 2020-07-05 00:03:37 --> Language Class Initialized
INFO - 2020-07-05 00:03:37 --> Language Class Initialized
INFO - 2020-07-05 00:03:37 --> Config Class Initialized
INFO - 2020-07-05 00:03:37 --> Loader Class Initialized
INFO - 2020-07-05 00:03:37 --> Helper loaded: url_helper
INFO - 2020-07-05 00:03:37 --> Helper loaded: main_helper
INFO - 2020-07-05 00:03:37 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:03:37 --> Controller Class Initialized
DEBUG - 2020-07-05 00:03:37 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-05 00:03:37 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 00:03:37 --> Final output sent to browser
DEBUG - 2020-07-05 00:03:37 --> Total execution time: 0.0084
INFO - 2020-07-05 00:03:38 --> Config Class Initialized
INFO - 2020-07-05 00:03:38 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:03:38 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:03:38 --> Utf8 Class Initialized
INFO - 2020-07-05 00:03:38 --> URI Class Initialized
INFO - 2020-07-05 00:03:38 --> Router Class Initialized
INFO - 2020-07-05 00:03:38 --> Output Class Initialized
INFO - 2020-07-05 00:03:38 --> Security Class Initialized
DEBUG - 2020-07-05 00:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:03:38 --> Input Class Initialized
INFO - 2020-07-05 00:03:38 --> Language Class Initialized
INFO - 2020-07-05 00:03:38 --> Language Class Initialized
INFO - 2020-07-05 00:03:38 --> Config Class Initialized
INFO - 2020-07-05 00:03:38 --> Loader Class Initialized
INFO - 2020-07-05 00:03:38 --> Helper loaded: url_helper
INFO - 2020-07-05 00:03:38 --> Helper loaded: main_helper
INFO - 2020-07-05 00:03:38 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:03:38 --> Controller Class Initialized
INFO - 2020-07-05 00:03:38 --> Final output sent to browser
DEBUG - 2020-07-05 00:03:38 --> Total execution time: 0.0064
INFO - 2020-07-05 00:03:41 --> Config Class Initialized
INFO - 2020-07-05 00:03:41 --> Hooks Class Initialized
DEBUG - 2020-07-05 00:03:41 --> UTF-8 Support Enabled
INFO - 2020-07-05 00:03:41 --> Utf8 Class Initialized
INFO - 2020-07-05 00:03:41 --> URI Class Initialized
INFO - 2020-07-05 00:03:41 --> Router Class Initialized
INFO - 2020-07-05 00:03:41 --> Output Class Initialized
INFO - 2020-07-05 00:03:41 --> Security Class Initialized
DEBUG - 2020-07-05 00:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 00:03:41 --> Input Class Initialized
INFO - 2020-07-05 00:03:41 --> Language Class Initialized
INFO - 2020-07-05 00:03:41 --> Language Class Initialized
INFO - 2020-07-05 00:03:41 --> Config Class Initialized
INFO - 2020-07-05 00:03:41 --> Loader Class Initialized
INFO - 2020-07-05 00:03:41 --> Helper loaded: url_helper
INFO - 2020-07-05 00:03:41 --> Helper loaded: main_helper
INFO - 2020-07-05 00:03:41 --> Database Driver Class Initialized
DEBUG - 2020-07-05 00:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 00:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 00:03:41 --> Controller Class Initialized
INFO - 2020-07-05 00:03:41 --> Final output sent to browser
DEBUG - 2020-07-05 00:03:41 --> Total execution time: 0.0044
INFO - 2020-07-05 06:30:37 --> Config Class Initialized
INFO - 2020-07-05 06:30:37 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:30:37 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:30:37 --> Utf8 Class Initialized
INFO - 2020-07-05 06:30:37 --> URI Class Initialized
INFO - 2020-07-05 06:30:37 --> Router Class Initialized
INFO - 2020-07-05 06:30:37 --> Output Class Initialized
INFO - 2020-07-05 06:30:37 --> Security Class Initialized
DEBUG - 2020-07-05 06:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:30:37 --> Input Class Initialized
INFO - 2020-07-05 06:30:37 --> Language Class Initialized
INFO - 2020-07-05 06:30:37 --> Language Class Initialized
INFO - 2020-07-05 06:30:37 --> Config Class Initialized
INFO - 2020-07-05 06:30:37 --> Loader Class Initialized
INFO - 2020-07-05 06:30:37 --> Helper loaded: url_helper
INFO - 2020-07-05 06:30:37 --> Helper loaded: main_helper
INFO - 2020-07-05 06:30:37 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:30:37 --> Controller Class Initialized
INFO - 2020-07-05 06:30:37 --> Email Class Initialized
INFO - 2020-07-05 06:30:37 --> Language file loaded: language/english/email_lang.php
ERROR - 2020-07-05 06:30:41 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`journal`.`message`, CONSTRAINT `message_FK` FOREIGN KEY (`sender`) REFERENCES `users` (`userid`) ON UPDATE CASCADE) - Invalid query: INSERT INTO `message` (`_key`, `recipient`, `cc`, `subject`, `sender`, `is_sent`, `message`) VALUES ('724df778e5c7edc447b9f83cdccaf0c1', 'a:2:{i:0;s:20:\"hilmawanyr@gmail.com\";i:1;s:25:\"hilmawan@ubharajaya.ac.id\";}', 'a:1:{i:0;s:18:\"mooiks22@gmail.com\";}', 'Test email for HYR', 'hilmawan', 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.')
INFO - 2020-07-05 06:30:41 --> Language file loaded: language/english/db_lang.php
INFO - 2020-07-05 06:31:13 --> Config Class Initialized
INFO - 2020-07-05 06:31:13 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:31:13 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:31:13 --> Utf8 Class Initialized
INFO - 2020-07-05 06:31:13 --> URI Class Initialized
INFO - 2020-07-05 06:31:13 --> Router Class Initialized
INFO - 2020-07-05 06:31:13 --> Output Class Initialized
INFO - 2020-07-05 06:31:13 --> Security Class Initialized
DEBUG - 2020-07-05 06:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:31:13 --> Input Class Initialized
INFO - 2020-07-05 06:31:13 --> Language Class Initialized
INFO - 2020-07-05 06:31:13 --> Language Class Initialized
INFO - 2020-07-05 06:31:13 --> Config Class Initialized
INFO - 2020-07-05 06:31:13 --> Loader Class Initialized
INFO - 2020-07-05 06:31:13 --> Helper loaded: url_helper
INFO - 2020-07-05 06:31:13 --> Helper loaded: main_helper
INFO - 2020-07-05 06:31:13 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:31:13 --> Controller Class Initialized
DEBUG - 2020-07-05 06:31:13 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-05 06:31:13 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:31:13 --> Final output sent to browser
DEBUG - 2020-07-05 06:31:13 --> Total execution time: 0.0054
INFO - 2020-07-05 06:31:14 --> Config Class Initialized
INFO - 2020-07-05 06:31:14 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:31:14 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:31:14 --> Utf8 Class Initialized
INFO - 2020-07-05 06:31:14 --> URI Class Initialized
INFO - 2020-07-05 06:31:14 --> Router Class Initialized
INFO - 2020-07-05 06:31:14 --> Output Class Initialized
INFO - 2020-07-05 06:31:14 --> Security Class Initialized
DEBUG - 2020-07-05 06:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:31:14 --> Input Class Initialized
INFO - 2020-07-05 06:31:14 --> Language Class Initialized
INFO - 2020-07-05 06:31:14 --> Language Class Initialized
INFO - 2020-07-05 06:31:14 --> Config Class Initialized
INFO - 2020-07-05 06:31:14 --> Loader Class Initialized
INFO - 2020-07-05 06:31:14 --> Helper loaded: url_helper
INFO - 2020-07-05 06:31:14 --> Helper loaded: main_helper
INFO - 2020-07-05 06:31:14 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:31:14 --> Controller Class Initialized
INFO - 2020-07-05 06:31:14 --> Final output sent to browser
DEBUG - 2020-07-05 06:31:14 --> Total execution time: 0.0047
INFO - 2020-07-05 06:33:13 --> Config Class Initialized
INFO - 2020-07-05 06:33:13 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:33:13 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:33:13 --> Utf8 Class Initialized
INFO - 2020-07-05 06:33:13 --> URI Class Initialized
DEBUG - 2020-07-05 06:33:13 --> No URI present. Default controller set.
INFO - 2020-07-05 06:33:13 --> Router Class Initialized
INFO - 2020-07-05 06:33:13 --> Output Class Initialized
INFO - 2020-07-05 06:33:13 --> Security Class Initialized
DEBUG - 2020-07-05 06:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:33:13 --> Input Class Initialized
INFO - 2020-07-05 06:33:13 --> Language Class Initialized
INFO - 2020-07-05 06:33:13 --> Language Class Initialized
INFO - 2020-07-05 06:33:13 --> Config Class Initialized
INFO - 2020-07-05 06:33:13 --> Loader Class Initialized
INFO - 2020-07-05 06:33:13 --> Helper loaded: url_helper
INFO - 2020-07-05 06:33:13 --> Helper loaded: main_helper
INFO - 2020-07-05 06:33:13 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:33:13 --> Controller Class Initialized
DEBUG - 2020-07-05 06:33:13 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-05 06:33:13 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:33:13 --> Final output sent to browser
DEBUG - 2020-07-05 06:33:13 --> Total execution time: 0.0074
INFO - 2020-07-05 06:33:46 --> Config Class Initialized
INFO - 2020-07-05 06:33:46 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:33:46 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:33:46 --> Utf8 Class Initialized
INFO - 2020-07-05 06:33:46 --> URI Class Initialized
INFO - 2020-07-05 06:33:46 --> Router Class Initialized
INFO - 2020-07-05 06:33:46 --> Output Class Initialized
INFO - 2020-07-05 06:33:46 --> Security Class Initialized
DEBUG - 2020-07-05 06:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:33:46 --> Input Class Initialized
INFO - 2020-07-05 06:33:46 --> Language Class Initialized
INFO - 2020-07-05 06:33:46 --> Language Class Initialized
INFO - 2020-07-05 06:33:46 --> Config Class Initialized
INFO - 2020-07-05 06:33:46 --> Loader Class Initialized
INFO - 2020-07-05 06:33:46 --> Helper loaded: url_helper
INFO - 2020-07-05 06:33:46 --> Helper loaded: main_helper
INFO - 2020-07-05 06:33:46 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:33:46 --> Controller Class Initialized
INFO - 2020-07-05 06:33:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:33:46 --> Pagination Class Initialized
ERROR - 2020-07-05 06:33:46 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:33:46 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:33:46 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:33:48 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:33:48 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:33:48 --> Final output sent to browser
DEBUG - 2020-07-05 06:33:48 --> Total execution time: 1.7071
INFO - 2020-07-05 06:33:55 --> Config Class Initialized
INFO - 2020-07-05 06:33:55 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:33:55 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:33:55 --> Utf8 Class Initialized
INFO - 2020-07-05 06:33:55 --> URI Class Initialized
INFO - 2020-07-05 06:33:55 --> Router Class Initialized
INFO - 2020-07-05 06:33:55 --> Output Class Initialized
INFO - 2020-07-05 06:33:55 --> Security Class Initialized
DEBUG - 2020-07-05 06:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:33:55 --> Input Class Initialized
INFO - 2020-07-05 06:33:55 --> Language Class Initialized
INFO - 2020-07-05 06:33:55 --> Language Class Initialized
INFO - 2020-07-05 06:33:55 --> Config Class Initialized
INFO - 2020-07-05 06:33:55 --> Loader Class Initialized
INFO - 2020-07-05 06:33:55 --> Helper loaded: url_helper
INFO - 2020-07-05 06:33:55 --> Helper loaded: main_helper
INFO - 2020-07-05 06:33:55 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:33:55 --> Controller Class Initialized
INFO - 2020-07-05 06:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:33:55 --> Pagination Class Initialized
ERROR - 2020-07-05 06:33:55 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:33:55 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:33:55 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:33:56 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 06:33:56 --> Final output sent to browser
DEBUG - 2020-07-05 06:33:56 --> Total execution time: 1.1990
INFO - 2020-07-05 06:34:10 --> Config Class Initialized
INFO - 2020-07-05 06:34:10 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:34:10 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:34:10 --> Utf8 Class Initialized
INFO - 2020-07-05 06:34:10 --> URI Class Initialized
INFO - 2020-07-05 06:34:10 --> Router Class Initialized
INFO - 2020-07-05 06:34:10 --> Output Class Initialized
INFO - 2020-07-05 06:34:10 --> Security Class Initialized
DEBUG - 2020-07-05 06:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:34:10 --> Input Class Initialized
INFO - 2020-07-05 06:34:10 --> Language Class Initialized
INFO - 2020-07-05 06:34:10 --> Language Class Initialized
INFO - 2020-07-05 06:34:10 --> Config Class Initialized
INFO - 2020-07-05 06:34:10 --> Loader Class Initialized
INFO - 2020-07-05 06:34:10 --> Helper loaded: url_helper
INFO - 2020-07-05 06:34:10 --> Helper loaded: main_helper
INFO - 2020-07-05 06:34:10 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:34:10 --> Controller Class Initialized
INFO - 2020-07-05 06:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:34:10 --> Pagination Class Initialized
ERROR - 2020-07-05 06:34:10 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:34:10 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:34:10 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:34:11 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 06:34:11 --> Final output sent to browser
DEBUG - 2020-07-05 06:34:11 --> Total execution time: 1.2359
INFO - 2020-07-05 06:34:23 --> Config Class Initialized
INFO - 2020-07-05 06:34:23 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:34:23 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:34:23 --> Utf8 Class Initialized
INFO - 2020-07-05 06:34:23 --> URI Class Initialized
INFO - 2020-07-05 06:34:23 --> Router Class Initialized
INFO - 2020-07-05 06:34:23 --> Output Class Initialized
INFO - 2020-07-05 06:34:23 --> Security Class Initialized
DEBUG - 2020-07-05 06:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:34:23 --> Input Class Initialized
INFO - 2020-07-05 06:34:23 --> Language Class Initialized
INFO - 2020-07-05 06:34:23 --> Language Class Initialized
INFO - 2020-07-05 06:34:23 --> Config Class Initialized
INFO - 2020-07-05 06:34:23 --> Loader Class Initialized
INFO - 2020-07-05 06:34:23 --> Helper loaded: url_helper
INFO - 2020-07-05 06:34:23 --> Helper loaded: main_helper
INFO - 2020-07-05 06:34:23 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:34:23 --> Controller Class Initialized
INFO - 2020-07-05 06:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:34:23 --> Pagination Class Initialized
ERROR - 2020-07-05 06:34:23 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:34:23 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:34:23 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:34:25 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:34:25 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:34:25 --> Final output sent to browser
DEBUG - 2020-07-05 06:34:25 --> Total execution time: 1.8596
INFO - 2020-07-05 06:34:37 --> Config Class Initialized
INFO - 2020-07-05 06:34:37 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:34:37 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:34:37 --> Utf8 Class Initialized
INFO - 2020-07-05 06:34:37 --> URI Class Initialized
INFO - 2020-07-05 06:34:37 --> Router Class Initialized
INFO - 2020-07-05 06:34:37 --> Output Class Initialized
INFO - 2020-07-05 06:34:37 --> Security Class Initialized
DEBUG - 2020-07-05 06:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:34:37 --> Input Class Initialized
INFO - 2020-07-05 06:34:37 --> Language Class Initialized
INFO - 2020-07-05 06:34:37 --> Language Class Initialized
INFO - 2020-07-05 06:34:37 --> Config Class Initialized
INFO - 2020-07-05 06:34:37 --> Loader Class Initialized
INFO - 2020-07-05 06:34:37 --> Helper loaded: url_helper
INFO - 2020-07-05 06:34:37 --> Helper loaded: main_helper
INFO - 2020-07-05 06:34:37 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:34:37 --> Controller Class Initialized
INFO - 2020-07-05 06:34:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:34:37 --> Pagination Class Initialized
ERROR - 2020-07-05 06:34:37 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:34:37 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:34:37 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:34:39 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:34:39 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:34:39 --> Final output sent to browser
DEBUG - 2020-07-05 06:34:39 --> Total execution time: 1.5988
INFO - 2020-07-05 06:35:00 --> Config Class Initialized
INFO - 2020-07-05 06:35:00 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:35:00 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:35:00 --> Utf8 Class Initialized
INFO - 2020-07-05 06:35:00 --> URI Class Initialized
INFO - 2020-07-05 06:35:00 --> Router Class Initialized
INFO - 2020-07-05 06:35:00 --> Output Class Initialized
INFO - 2020-07-05 06:35:00 --> Security Class Initialized
DEBUG - 2020-07-05 06:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:35:00 --> Input Class Initialized
INFO - 2020-07-05 06:35:00 --> Language Class Initialized
INFO - 2020-07-05 06:35:00 --> Language Class Initialized
INFO - 2020-07-05 06:35:00 --> Config Class Initialized
INFO - 2020-07-05 06:35:00 --> Loader Class Initialized
INFO - 2020-07-05 06:35:00 --> Helper loaded: url_helper
INFO - 2020-07-05 06:35:00 --> Helper loaded: main_helper
INFO - 2020-07-05 06:35:00 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:35:00 --> Controller Class Initialized
INFO - 2020-07-05 06:35:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:35:00 --> Pagination Class Initialized
ERROR - 2020-07-05 06:35:00 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:35:00 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:35:00 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:35:01 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 06:35:01 --> Final output sent to browser
DEBUG - 2020-07-05 06:35:01 --> Total execution time: 1.2128
INFO - 2020-07-05 06:35:26 --> Config Class Initialized
INFO - 2020-07-05 06:35:26 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:35:26 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:35:26 --> Utf8 Class Initialized
INFO - 2020-07-05 06:35:26 --> URI Class Initialized
INFO - 2020-07-05 06:35:26 --> Router Class Initialized
INFO - 2020-07-05 06:35:26 --> Output Class Initialized
INFO - 2020-07-05 06:35:26 --> Security Class Initialized
DEBUG - 2020-07-05 06:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:35:26 --> Input Class Initialized
INFO - 2020-07-05 06:35:26 --> Language Class Initialized
INFO - 2020-07-05 06:35:26 --> Language Class Initialized
INFO - 2020-07-05 06:35:26 --> Config Class Initialized
INFO - 2020-07-05 06:35:26 --> Loader Class Initialized
INFO - 2020-07-05 06:35:26 --> Helper loaded: url_helper
INFO - 2020-07-05 06:35:26 --> Helper loaded: main_helper
INFO - 2020-07-05 06:35:26 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:35:26 --> Controller Class Initialized
INFO - 2020-07-05 06:35:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:35:26 --> Pagination Class Initialized
ERROR - 2020-07-05 06:35:26 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:35:26 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:35:26 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:35:26 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:35:26 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:35:26 --> Final output sent to browser
DEBUG - 2020-07-05 06:35:26 --> Total execution time: 0.0057
INFO - 2020-07-05 06:35:31 --> Config Class Initialized
INFO - 2020-07-05 06:35:31 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:35:31 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:35:31 --> Utf8 Class Initialized
INFO - 2020-07-05 06:35:31 --> URI Class Initialized
INFO - 2020-07-05 06:35:31 --> Router Class Initialized
INFO - 2020-07-05 06:35:31 --> Output Class Initialized
INFO - 2020-07-05 06:35:31 --> Security Class Initialized
DEBUG - 2020-07-05 06:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:35:31 --> Input Class Initialized
INFO - 2020-07-05 06:35:31 --> Language Class Initialized
INFO - 2020-07-05 06:35:31 --> Language Class Initialized
INFO - 2020-07-05 06:35:31 --> Config Class Initialized
INFO - 2020-07-05 06:35:31 --> Loader Class Initialized
INFO - 2020-07-05 06:35:31 --> Helper loaded: url_helper
INFO - 2020-07-05 06:35:31 --> Helper loaded: main_helper
INFO - 2020-07-05 06:35:31 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:35:31 --> Controller Class Initialized
INFO - 2020-07-05 06:35:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:35:31 --> Pagination Class Initialized
ERROR - 2020-07-05 06:35:31 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:35:31 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:35:31 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:35:31 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:35:31 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:35:31 --> Final output sent to browser
DEBUG - 2020-07-05 06:35:31 --> Total execution time: 0.0066
INFO - 2020-07-05 06:39:00 --> Config Class Initialized
INFO - 2020-07-05 06:39:00 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:39:00 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:39:00 --> Utf8 Class Initialized
INFO - 2020-07-05 06:39:00 --> URI Class Initialized
INFO - 2020-07-05 06:39:00 --> Router Class Initialized
INFO - 2020-07-05 06:39:00 --> Output Class Initialized
INFO - 2020-07-05 06:39:00 --> Security Class Initialized
DEBUG - 2020-07-05 06:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:39:00 --> Input Class Initialized
INFO - 2020-07-05 06:39:00 --> Language Class Initialized
INFO - 2020-07-05 06:39:00 --> Language Class Initialized
INFO - 2020-07-05 06:39:00 --> Config Class Initialized
INFO - 2020-07-05 06:39:00 --> Loader Class Initialized
INFO - 2020-07-05 06:39:00 --> Helper loaded: url_helper
INFO - 2020-07-05 06:39:00 --> Helper loaded: main_helper
INFO - 2020-07-05 06:39:00 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:39:00 --> Controller Class Initialized
INFO - 2020-07-05 06:39:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:39:00 --> Pagination Class Initialized
ERROR - 2020-07-05 06:39:00 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:39:00 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:39:00 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
ERROR - 2020-07-05 06:39:02 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) /var/www/journal/application/modules/landing/views/result_v.php 61
INFO - 2020-07-05 06:39:15 --> Config Class Initialized
INFO - 2020-07-05 06:39:15 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:39:15 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:39:15 --> Utf8 Class Initialized
INFO - 2020-07-05 06:39:15 --> URI Class Initialized
INFO - 2020-07-05 06:39:15 --> Router Class Initialized
INFO - 2020-07-05 06:39:15 --> Output Class Initialized
INFO - 2020-07-05 06:39:15 --> Security Class Initialized
DEBUG - 2020-07-05 06:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:39:15 --> Input Class Initialized
INFO - 2020-07-05 06:39:15 --> Language Class Initialized
INFO - 2020-07-05 06:39:15 --> Language Class Initialized
INFO - 2020-07-05 06:39:15 --> Config Class Initialized
INFO - 2020-07-05 06:39:15 --> Loader Class Initialized
INFO - 2020-07-05 06:39:15 --> Helper loaded: url_helper
INFO - 2020-07-05 06:39:15 --> Helper loaded: main_helper
INFO - 2020-07-05 06:39:15 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:39:15 --> Controller Class Initialized
INFO - 2020-07-05 06:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:39:15 --> Pagination Class Initialized
ERROR - 2020-07-05 06:39:15 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:39:15 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:39:15 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:39:15 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:39:15 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:39:15 --> Final output sent to browser
DEBUG - 2020-07-05 06:39:15 --> Total execution time: 0.0040
INFO - 2020-07-05 06:39:27 --> Config Class Initialized
INFO - 2020-07-05 06:39:27 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:39:27 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:39:27 --> Utf8 Class Initialized
INFO - 2020-07-05 06:39:27 --> URI Class Initialized
INFO - 2020-07-05 06:39:27 --> Router Class Initialized
INFO - 2020-07-05 06:39:27 --> Output Class Initialized
INFO - 2020-07-05 06:39:27 --> Security Class Initialized
DEBUG - 2020-07-05 06:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:39:27 --> Input Class Initialized
INFO - 2020-07-05 06:39:27 --> Language Class Initialized
INFO - 2020-07-05 06:39:27 --> Language Class Initialized
INFO - 2020-07-05 06:39:27 --> Config Class Initialized
INFO - 2020-07-05 06:39:27 --> Loader Class Initialized
INFO - 2020-07-05 06:39:27 --> Helper loaded: url_helper
INFO - 2020-07-05 06:39:27 --> Helper loaded: main_helper
INFO - 2020-07-05 06:39:27 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:39:27 --> Controller Class Initialized
INFO - 2020-07-05 06:39:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:39:27 --> Pagination Class Initialized
ERROR - 2020-07-05 06:39:27 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:39:27 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:39:27 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:39:27 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:39:27 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:39:27 --> Final output sent to browser
DEBUG - 2020-07-05 06:39:27 --> Total execution time: 0.0041
INFO - 2020-07-05 06:39:47 --> Config Class Initialized
INFO - 2020-07-05 06:39:47 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:39:47 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:39:47 --> Utf8 Class Initialized
INFO - 2020-07-05 06:39:47 --> URI Class Initialized
INFO - 2020-07-05 06:39:47 --> Router Class Initialized
INFO - 2020-07-05 06:39:47 --> Output Class Initialized
INFO - 2020-07-05 06:39:47 --> Security Class Initialized
DEBUG - 2020-07-05 06:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:39:47 --> Input Class Initialized
INFO - 2020-07-05 06:39:47 --> Language Class Initialized
INFO - 2020-07-05 06:39:47 --> Language Class Initialized
INFO - 2020-07-05 06:39:47 --> Config Class Initialized
INFO - 2020-07-05 06:39:47 --> Loader Class Initialized
INFO - 2020-07-05 06:39:47 --> Helper loaded: url_helper
INFO - 2020-07-05 06:39:47 --> Helper loaded: main_helper
INFO - 2020-07-05 06:39:47 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:39:47 --> Controller Class Initialized
INFO - 2020-07-05 06:39:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:39:47 --> Pagination Class Initialized
ERROR - 2020-07-05 06:39:47 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:39:47 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:39:47 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:39:47 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:39:47 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:39:47 --> Final output sent to browser
DEBUG - 2020-07-05 06:39:47 --> Total execution time: 0.0043
INFO - 2020-07-05 06:39:59 --> Config Class Initialized
INFO - 2020-07-05 06:39:59 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:39:59 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:39:59 --> Utf8 Class Initialized
INFO - 2020-07-05 06:39:59 --> URI Class Initialized
INFO - 2020-07-05 06:39:59 --> Router Class Initialized
INFO - 2020-07-05 06:39:59 --> Output Class Initialized
INFO - 2020-07-05 06:39:59 --> Security Class Initialized
DEBUG - 2020-07-05 06:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:39:59 --> Input Class Initialized
INFO - 2020-07-05 06:39:59 --> Language Class Initialized
INFO - 2020-07-05 06:39:59 --> Language Class Initialized
INFO - 2020-07-05 06:39:59 --> Config Class Initialized
INFO - 2020-07-05 06:39:59 --> Loader Class Initialized
INFO - 2020-07-05 06:39:59 --> Helper loaded: url_helper
INFO - 2020-07-05 06:39:59 --> Helper loaded: main_helper
INFO - 2020-07-05 06:39:59 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:39:59 --> Controller Class Initialized
INFO - 2020-07-05 06:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:39:59 --> Pagination Class Initialized
ERROR - 2020-07-05 06:39:59 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:39:59 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:39:59 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:39:59 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:39:59 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:39:59 --> Final output sent to browser
DEBUG - 2020-07-05 06:39:59 --> Total execution time: 0.0059
INFO - 2020-07-05 06:40:12 --> Config Class Initialized
INFO - 2020-07-05 06:40:12 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:40:12 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:40:12 --> Utf8 Class Initialized
INFO - 2020-07-05 06:40:12 --> URI Class Initialized
INFO - 2020-07-05 06:40:12 --> Router Class Initialized
INFO - 2020-07-05 06:40:12 --> Output Class Initialized
INFO - 2020-07-05 06:40:12 --> Security Class Initialized
DEBUG - 2020-07-05 06:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:40:12 --> Input Class Initialized
INFO - 2020-07-05 06:40:12 --> Language Class Initialized
INFO - 2020-07-05 06:40:12 --> Language Class Initialized
INFO - 2020-07-05 06:40:12 --> Config Class Initialized
INFO - 2020-07-05 06:40:12 --> Loader Class Initialized
INFO - 2020-07-05 06:40:12 --> Helper loaded: url_helper
INFO - 2020-07-05 06:40:12 --> Helper loaded: main_helper
INFO - 2020-07-05 06:40:12 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:40:12 --> Controller Class Initialized
INFO - 2020-07-05 06:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:40:12 --> Pagination Class Initialized
ERROR - 2020-07-05 06:40:12 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:40:12 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:40:12 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:40:12 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:40:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:40:12 --> Final output sent to browser
DEBUG - 2020-07-05 06:40:12 --> Total execution time: 0.0044
INFO - 2020-07-05 06:40:35 --> Config Class Initialized
INFO - 2020-07-05 06:40:35 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:40:35 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:40:35 --> Utf8 Class Initialized
INFO - 2020-07-05 06:40:35 --> URI Class Initialized
INFO - 2020-07-05 06:40:35 --> Router Class Initialized
INFO - 2020-07-05 06:40:35 --> Output Class Initialized
INFO - 2020-07-05 06:40:35 --> Security Class Initialized
DEBUG - 2020-07-05 06:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:40:35 --> Input Class Initialized
INFO - 2020-07-05 06:40:35 --> Language Class Initialized
INFO - 2020-07-05 06:40:35 --> Language Class Initialized
INFO - 2020-07-05 06:40:35 --> Config Class Initialized
INFO - 2020-07-05 06:40:35 --> Loader Class Initialized
INFO - 2020-07-05 06:40:35 --> Helper loaded: url_helper
INFO - 2020-07-05 06:40:35 --> Helper loaded: main_helper
INFO - 2020-07-05 06:40:35 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:40:35 --> Controller Class Initialized
INFO - 2020-07-05 06:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:40:35 --> Pagination Class Initialized
ERROR - 2020-07-05 06:40:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:40:35 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:40:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:40:35 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:40:35 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:40:35 --> Final output sent to browser
DEBUG - 2020-07-05 06:40:35 --> Total execution time: 0.0044
INFO - 2020-07-05 06:40:40 --> Config Class Initialized
INFO - 2020-07-05 06:40:40 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:40:40 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:40:40 --> Utf8 Class Initialized
INFO - 2020-07-05 06:40:40 --> URI Class Initialized
INFO - 2020-07-05 06:40:40 --> Router Class Initialized
INFO - 2020-07-05 06:40:40 --> Output Class Initialized
INFO - 2020-07-05 06:40:40 --> Security Class Initialized
DEBUG - 2020-07-05 06:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:40:40 --> Input Class Initialized
INFO - 2020-07-05 06:40:40 --> Language Class Initialized
INFO - 2020-07-05 06:40:40 --> Language Class Initialized
INFO - 2020-07-05 06:40:40 --> Config Class Initialized
INFO - 2020-07-05 06:40:40 --> Loader Class Initialized
INFO - 2020-07-05 06:40:40 --> Helper loaded: url_helper
INFO - 2020-07-05 06:40:40 --> Helper loaded: main_helper
INFO - 2020-07-05 06:40:40 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:40:40 --> Controller Class Initialized
INFO - 2020-07-05 06:40:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:40:40 --> Pagination Class Initialized
ERROR - 2020-07-05 06:40:40 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:40:40 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:40:40 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:40:41 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:40:41 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:40:41 --> Final output sent to browser
DEBUG - 2020-07-05 06:40:41 --> Total execution time: 1.7357
INFO - 2020-07-05 06:41:13 --> Config Class Initialized
INFO - 2020-07-05 06:41:13 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:41:13 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:41:13 --> Utf8 Class Initialized
INFO - 2020-07-05 06:41:13 --> URI Class Initialized
INFO - 2020-07-05 06:41:13 --> Router Class Initialized
INFO - 2020-07-05 06:41:13 --> Output Class Initialized
INFO - 2020-07-05 06:41:13 --> Security Class Initialized
DEBUG - 2020-07-05 06:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:41:13 --> Input Class Initialized
INFO - 2020-07-05 06:41:13 --> Language Class Initialized
INFO - 2020-07-05 06:41:13 --> Language Class Initialized
INFO - 2020-07-05 06:41:13 --> Config Class Initialized
INFO - 2020-07-05 06:41:13 --> Loader Class Initialized
INFO - 2020-07-05 06:41:13 --> Helper loaded: url_helper
INFO - 2020-07-05 06:41:13 --> Helper loaded: main_helper
INFO - 2020-07-05 06:41:13 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:41:13 --> Controller Class Initialized
INFO - 2020-07-05 06:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:41:13 --> Pagination Class Initialized
ERROR - 2020-07-05 06:41:13 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:41:13 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:41:13 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:41:13 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:41:13 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:41:13 --> Final output sent to browser
DEBUG - 2020-07-05 06:41:13 --> Total execution time: 0.0051
INFO - 2020-07-05 06:41:21 --> Config Class Initialized
INFO - 2020-07-05 06:41:21 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:41:21 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:41:21 --> Utf8 Class Initialized
INFO - 2020-07-05 06:41:21 --> URI Class Initialized
INFO - 2020-07-05 06:41:21 --> Router Class Initialized
INFO - 2020-07-05 06:41:21 --> Output Class Initialized
INFO - 2020-07-05 06:41:21 --> Security Class Initialized
DEBUG - 2020-07-05 06:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:41:21 --> Input Class Initialized
INFO - 2020-07-05 06:41:21 --> Language Class Initialized
INFO - 2020-07-05 06:41:21 --> Language Class Initialized
INFO - 2020-07-05 06:41:21 --> Config Class Initialized
INFO - 2020-07-05 06:41:21 --> Loader Class Initialized
INFO - 2020-07-05 06:41:21 --> Helper loaded: url_helper
INFO - 2020-07-05 06:41:21 --> Helper loaded: main_helper
INFO - 2020-07-05 06:41:21 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:41:21 --> Controller Class Initialized
INFO - 2020-07-05 06:41:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:41:21 --> Pagination Class Initialized
ERROR - 2020-07-05 06:41:21 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:41:21 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:41:21 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:41:22 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:41:22 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:41:22 --> Final output sent to browser
DEBUG - 2020-07-05 06:41:22 --> Total execution time: 1.7011
INFO - 2020-07-05 06:49:02 --> Config Class Initialized
INFO - 2020-07-05 06:49:02 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:49:02 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:49:02 --> Utf8 Class Initialized
INFO - 2020-07-05 06:49:02 --> URI Class Initialized
INFO - 2020-07-05 06:49:02 --> Router Class Initialized
INFO - 2020-07-05 06:49:02 --> Output Class Initialized
INFO - 2020-07-05 06:49:02 --> Security Class Initialized
DEBUG - 2020-07-05 06:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:49:02 --> Input Class Initialized
INFO - 2020-07-05 06:49:02 --> Language Class Initialized
INFO - 2020-07-05 06:49:02 --> Language Class Initialized
INFO - 2020-07-05 06:49:02 --> Config Class Initialized
INFO - 2020-07-05 06:49:02 --> Loader Class Initialized
INFO - 2020-07-05 06:49:02 --> Helper loaded: url_helper
INFO - 2020-07-05 06:49:02 --> Helper loaded: main_helper
INFO - 2020-07-05 06:49:02 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:49:02 --> Controller Class Initialized
INFO - 2020-07-05 06:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:49:02 --> Pagination Class Initialized
ERROR - 2020-07-05 06:49:02 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:49:02 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:49:02 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:49:04 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:49:04 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:49:04 --> Final output sent to browser
DEBUG - 2020-07-05 06:49:04 --> Total execution time: 1.7276
INFO - 2020-07-05 06:49:24 --> Config Class Initialized
INFO - 2020-07-05 06:49:24 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:49:24 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:49:24 --> Utf8 Class Initialized
INFO - 2020-07-05 06:49:24 --> URI Class Initialized
INFO - 2020-07-05 06:49:24 --> Router Class Initialized
INFO - 2020-07-05 06:49:24 --> Output Class Initialized
INFO - 2020-07-05 06:49:24 --> Security Class Initialized
DEBUG - 2020-07-05 06:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:49:24 --> Input Class Initialized
INFO - 2020-07-05 06:49:24 --> Language Class Initialized
INFO - 2020-07-05 06:49:24 --> Language Class Initialized
INFO - 2020-07-05 06:49:24 --> Config Class Initialized
INFO - 2020-07-05 06:49:24 --> Loader Class Initialized
INFO - 2020-07-05 06:49:24 --> Helper loaded: url_helper
INFO - 2020-07-05 06:49:24 --> Helper loaded: main_helper
INFO - 2020-07-05 06:49:24 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:49:24 --> Controller Class Initialized
INFO - 2020-07-05 06:49:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:49:24 --> Pagination Class Initialized
ERROR - 2020-07-05 06:49:24 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:49:24 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:49:24 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:49:26 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:49:26 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:49:26 --> Final output sent to browser
DEBUG - 2020-07-05 06:49:26 --> Total execution time: 1.5635
INFO - 2020-07-05 06:50:35 --> Config Class Initialized
INFO - 2020-07-05 06:50:35 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:50:35 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:50:35 --> Utf8 Class Initialized
INFO - 2020-07-05 06:50:35 --> URI Class Initialized
DEBUG - 2020-07-05 06:50:35 --> No URI present. Default controller set.
INFO - 2020-07-05 06:50:35 --> Router Class Initialized
INFO - 2020-07-05 06:50:35 --> Output Class Initialized
INFO - 2020-07-05 06:50:35 --> Security Class Initialized
DEBUG - 2020-07-05 06:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:50:35 --> Input Class Initialized
INFO - 2020-07-05 06:50:35 --> Language Class Initialized
INFO - 2020-07-05 06:50:35 --> Language Class Initialized
INFO - 2020-07-05 06:50:35 --> Config Class Initialized
INFO - 2020-07-05 06:50:35 --> Loader Class Initialized
INFO - 2020-07-05 06:50:35 --> Helper loaded: url_helper
INFO - 2020-07-05 06:50:35 --> Helper loaded: main_helper
INFO - 2020-07-05 06:50:35 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:50:35 --> Controller Class Initialized
DEBUG - 2020-07-05 06:50:35 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-05 06:50:35 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:50:35 --> Final output sent to browser
DEBUG - 2020-07-05 06:50:35 --> Total execution time: 0.0049
INFO - 2020-07-05 06:52:00 --> Config Class Initialized
INFO - 2020-07-05 06:52:00 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:52:00 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:52:00 --> Utf8 Class Initialized
INFO - 2020-07-05 06:52:00 --> URI Class Initialized
DEBUG - 2020-07-05 06:52:00 --> No URI present. Default controller set.
INFO - 2020-07-05 06:52:00 --> Router Class Initialized
INFO - 2020-07-05 06:52:00 --> Output Class Initialized
INFO - 2020-07-05 06:52:00 --> Security Class Initialized
DEBUG - 2020-07-05 06:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:52:00 --> Input Class Initialized
INFO - 2020-07-05 06:52:00 --> Language Class Initialized
INFO - 2020-07-05 06:52:00 --> Language Class Initialized
INFO - 2020-07-05 06:52:00 --> Config Class Initialized
INFO - 2020-07-05 06:52:00 --> Loader Class Initialized
INFO - 2020-07-05 06:52:00 --> Helper loaded: url_helper
INFO - 2020-07-05 06:52:00 --> Helper loaded: main_helper
INFO - 2020-07-05 06:52:00 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:52:00 --> Controller Class Initialized
DEBUG - 2020-07-05 06:52:00 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-05 06:52:00 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:52:00 --> Final output sent to browser
DEBUG - 2020-07-05 06:52:00 --> Total execution time: 0.0042
INFO - 2020-07-05 06:52:14 --> Config Class Initialized
INFO - 2020-07-05 06:52:14 --> Hooks Class Initialized
DEBUG - 2020-07-05 06:52:14 --> UTF-8 Support Enabled
INFO - 2020-07-05 06:52:14 --> Utf8 Class Initialized
INFO - 2020-07-05 06:52:14 --> URI Class Initialized
INFO - 2020-07-05 06:52:14 --> Router Class Initialized
INFO - 2020-07-05 06:52:14 --> Output Class Initialized
INFO - 2020-07-05 06:52:14 --> Security Class Initialized
DEBUG - 2020-07-05 06:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 06:52:14 --> Input Class Initialized
INFO - 2020-07-05 06:52:14 --> Language Class Initialized
INFO - 2020-07-05 06:52:14 --> Language Class Initialized
INFO - 2020-07-05 06:52:14 --> Config Class Initialized
INFO - 2020-07-05 06:52:14 --> Loader Class Initialized
INFO - 2020-07-05 06:52:14 --> Helper loaded: url_helper
INFO - 2020-07-05 06:52:14 --> Helper loaded: main_helper
INFO - 2020-07-05 06:52:14 --> Database Driver Class Initialized
DEBUG - 2020-07-05 06:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 06:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 06:52:14 --> Controller Class Initialized
INFO - 2020-07-05 06:52:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 06:52:14 --> Pagination Class Initialized
ERROR - 2020-07-05 06:52:14 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 06:52:14 --> Helper loaded: file_helper
DEBUG - 2020-07-05 06:52:14 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 06:52:14 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 06:52:14 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 06:52:14 --> Final output sent to browser
DEBUG - 2020-07-05 06:52:14 --> Total execution time: 0.0043
INFO - 2020-07-05 07:03:53 --> Config Class Initialized
INFO - 2020-07-05 07:03:53 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:03:53 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:03:53 --> Utf8 Class Initialized
INFO - 2020-07-05 07:03:53 --> URI Class Initialized
INFO - 2020-07-05 07:03:53 --> Router Class Initialized
INFO - 2020-07-05 07:03:53 --> Output Class Initialized
INFO - 2020-07-05 07:03:53 --> Security Class Initialized
DEBUG - 2020-07-05 07:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:03:53 --> Input Class Initialized
INFO - 2020-07-05 07:03:53 --> Language Class Initialized
INFO - 2020-07-05 07:03:53 --> Language Class Initialized
INFO - 2020-07-05 07:03:53 --> Config Class Initialized
INFO - 2020-07-05 07:03:53 --> Loader Class Initialized
INFO - 2020-07-05 07:03:53 --> Helper loaded: url_helper
INFO - 2020-07-05 07:03:53 --> Helper loaded: main_helper
INFO - 2020-07-05 07:03:53 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:03:53 --> Controller Class Initialized
INFO - 2020-07-05 07:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 07:03:53 --> Pagination Class Initialized
ERROR - 2020-07-05 07:03:53 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 07:03:53 --> Helper loaded: file_helper
DEBUG - 2020-07-05 07:03:53 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
INFO - 2020-07-05 07:03:54 --> Config Class Initialized
INFO - 2020-07-05 07:03:54 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:03:54 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:03:54 --> Utf8 Class Initialized
INFO - 2020-07-05 07:03:54 --> URI Class Initialized
INFO - 2020-07-05 07:03:54 --> Router Class Initialized
INFO - 2020-07-05 07:03:54 --> Output Class Initialized
INFO - 2020-07-05 07:03:54 --> Security Class Initialized
DEBUG - 2020-07-05 07:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:03:54 --> Input Class Initialized
INFO - 2020-07-05 07:03:54 --> Language Class Initialized
INFO - 2020-07-05 07:03:54 --> Language Class Initialized
INFO - 2020-07-05 07:03:54 --> Config Class Initialized
INFO - 2020-07-05 07:03:54 --> Loader Class Initialized
INFO - 2020-07-05 07:03:54 --> Helper loaded: url_helper
INFO - 2020-07-05 07:03:54 --> Helper loaded: main_helper
INFO - 2020-07-05 07:03:54 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:03:54 --> Controller Class Initialized
INFO - 2020-07-05 07:04:39 --> Config Class Initialized
INFO - 2020-07-05 07:04:39 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:04:39 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:04:39 --> Utf8 Class Initialized
INFO - 2020-07-05 07:04:39 --> URI Class Initialized
INFO - 2020-07-05 07:04:39 --> Router Class Initialized
INFO - 2020-07-05 07:04:39 --> Output Class Initialized
INFO - 2020-07-05 07:04:39 --> Security Class Initialized
DEBUG - 2020-07-05 07:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:04:39 --> Input Class Initialized
INFO - 2020-07-05 07:04:39 --> Language Class Initialized
INFO - 2020-07-05 07:04:39 --> Language Class Initialized
INFO - 2020-07-05 07:04:39 --> Config Class Initialized
INFO - 2020-07-05 07:04:39 --> Loader Class Initialized
INFO - 2020-07-05 07:04:39 --> Helper loaded: url_helper
INFO - 2020-07-05 07:04:39 --> Helper loaded: main_helper
INFO - 2020-07-05 07:04:39 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:04:39 --> Controller Class Initialized
DEBUG - 2020-07-05 07:04:39 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:04:39 --> Final output sent to browser
DEBUG - 2020-07-05 07:04:39 --> Total execution time: 0.0040
INFO - 2020-07-05 07:05:50 --> Config Class Initialized
INFO - 2020-07-05 07:05:50 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:05:50 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:05:50 --> Utf8 Class Initialized
INFO - 2020-07-05 07:05:50 --> URI Class Initialized
INFO - 2020-07-05 07:05:50 --> Router Class Initialized
INFO - 2020-07-05 07:05:50 --> Output Class Initialized
INFO - 2020-07-05 07:05:50 --> Security Class Initialized
DEBUG - 2020-07-05 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:05:50 --> Input Class Initialized
INFO - 2020-07-05 07:05:50 --> Language Class Initialized
INFO - 2020-07-05 07:05:50 --> Language Class Initialized
INFO - 2020-07-05 07:05:50 --> Config Class Initialized
INFO - 2020-07-05 07:05:50 --> Loader Class Initialized
INFO - 2020-07-05 07:05:50 --> Helper loaded: url_helper
INFO - 2020-07-05 07:05:50 --> Helper loaded: main_helper
INFO - 2020-07-05 07:05:50 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:05:50 --> Controller Class Initialized
DEBUG - 2020-07-05 07:05:50 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:05:50 --> Final output sent to browser
DEBUG - 2020-07-05 07:05:50 --> Total execution time: 0.0050
INFO - 2020-07-05 07:12:21 --> Config Class Initialized
INFO - 2020-07-05 07:12:21 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:12:21 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:12:21 --> Utf8 Class Initialized
INFO - 2020-07-05 07:12:21 --> URI Class Initialized
INFO - 2020-07-05 07:12:21 --> Router Class Initialized
INFO - 2020-07-05 07:12:21 --> Output Class Initialized
INFO - 2020-07-05 07:12:21 --> Security Class Initialized
DEBUG - 2020-07-05 07:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:12:21 --> Input Class Initialized
INFO - 2020-07-05 07:12:21 --> Language Class Initialized
INFO - 2020-07-05 07:12:21 --> Language Class Initialized
INFO - 2020-07-05 07:12:21 --> Config Class Initialized
INFO - 2020-07-05 07:12:21 --> Loader Class Initialized
INFO - 2020-07-05 07:12:21 --> Helper loaded: url_helper
INFO - 2020-07-05 07:12:21 --> Helper loaded: main_helper
INFO - 2020-07-05 07:12:21 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:12:21 --> Controller Class Initialized
DEBUG - 2020-07-05 07:12:21 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:12:21 --> Final output sent to browser
DEBUG - 2020-07-05 07:12:21 --> Total execution time: 0.0082
INFO - 2020-07-05 07:17:57 --> Config Class Initialized
INFO - 2020-07-05 07:17:57 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:17:57 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:17:57 --> Utf8 Class Initialized
INFO - 2020-07-05 07:17:57 --> URI Class Initialized
INFO - 2020-07-05 07:17:57 --> Router Class Initialized
INFO - 2020-07-05 07:17:57 --> Output Class Initialized
INFO - 2020-07-05 07:17:57 --> Security Class Initialized
DEBUG - 2020-07-05 07:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:17:57 --> Input Class Initialized
INFO - 2020-07-05 07:17:57 --> Language Class Initialized
INFO - 2020-07-05 07:17:57 --> Language Class Initialized
INFO - 2020-07-05 07:17:57 --> Config Class Initialized
INFO - 2020-07-05 07:17:57 --> Loader Class Initialized
INFO - 2020-07-05 07:17:57 --> Helper loaded: url_helper
INFO - 2020-07-05 07:17:57 --> Helper loaded: main_helper
INFO - 2020-07-05 07:17:57 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:17:57 --> Controller Class Initialized
DEBUG - 2020-07-05 07:17:57 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:17:57 --> Final output sent to browser
DEBUG - 2020-07-05 07:17:57 --> Total execution time: 0.0042
INFO - 2020-07-05 07:18:21 --> Config Class Initialized
INFO - 2020-07-05 07:18:21 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:18:21 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:18:21 --> Utf8 Class Initialized
INFO - 2020-07-05 07:18:21 --> URI Class Initialized
INFO - 2020-07-05 07:18:21 --> Router Class Initialized
INFO - 2020-07-05 07:18:21 --> Output Class Initialized
INFO - 2020-07-05 07:18:21 --> Security Class Initialized
DEBUG - 2020-07-05 07:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:18:21 --> Input Class Initialized
INFO - 2020-07-05 07:18:21 --> Language Class Initialized
INFO - 2020-07-05 07:18:21 --> Language Class Initialized
INFO - 2020-07-05 07:18:21 --> Config Class Initialized
INFO - 2020-07-05 07:18:21 --> Loader Class Initialized
INFO - 2020-07-05 07:18:21 --> Helper loaded: url_helper
INFO - 2020-07-05 07:18:21 --> Helper loaded: main_helper
INFO - 2020-07-05 07:18:21 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:18:21 --> Controller Class Initialized
DEBUG - 2020-07-05 07:18:21 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:18:21 --> Final output sent to browser
DEBUG - 2020-07-05 07:18:21 --> Total execution time: 0.0045
INFO - 2020-07-05 07:18:45 --> Config Class Initialized
INFO - 2020-07-05 07:18:45 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:18:45 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:18:45 --> Utf8 Class Initialized
INFO - 2020-07-05 07:18:45 --> URI Class Initialized
INFO - 2020-07-05 07:18:45 --> Router Class Initialized
INFO - 2020-07-05 07:18:45 --> Output Class Initialized
INFO - 2020-07-05 07:18:45 --> Security Class Initialized
DEBUG - 2020-07-05 07:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:18:45 --> Input Class Initialized
INFO - 2020-07-05 07:18:45 --> Language Class Initialized
INFO - 2020-07-05 07:18:45 --> Language Class Initialized
INFO - 2020-07-05 07:18:45 --> Config Class Initialized
INFO - 2020-07-05 07:18:45 --> Loader Class Initialized
INFO - 2020-07-05 07:18:45 --> Helper loaded: url_helper
INFO - 2020-07-05 07:18:45 --> Helper loaded: main_helper
INFO - 2020-07-05 07:18:45 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:18:45 --> Controller Class Initialized
DEBUG - 2020-07-05 07:18:45 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:18:45 --> Final output sent to browser
DEBUG - 2020-07-05 07:18:45 --> Total execution time: 0.0036
INFO - 2020-07-05 07:19:01 --> Config Class Initialized
INFO - 2020-07-05 07:19:01 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:19:01 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:19:01 --> Utf8 Class Initialized
INFO - 2020-07-05 07:19:01 --> URI Class Initialized
INFO - 2020-07-05 07:19:01 --> Router Class Initialized
INFO - 2020-07-05 07:19:01 --> Output Class Initialized
INFO - 2020-07-05 07:19:01 --> Security Class Initialized
DEBUG - 2020-07-05 07:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:19:01 --> Input Class Initialized
INFO - 2020-07-05 07:19:01 --> Language Class Initialized
INFO - 2020-07-05 07:19:01 --> Language Class Initialized
INFO - 2020-07-05 07:19:01 --> Config Class Initialized
INFO - 2020-07-05 07:19:01 --> Loader Class Initialized
INFO - 2020-07-05 07:19:01 --> Helper loaded: url_helper
INFO - 2020-07-05 07:19:01 --> Helper loaded: main_helper
INFO - 2020-07-05 07:19:01 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:19:01 --> Controller Class Initialized
DEBUG - 2020-07-05 07:19:01 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:19:01 --> Final output sent to browser
DEBUG - 2020-07-05 07:19:01 --> Total execution time: 0.0046
INFO - 2020-07-05 07:19:23 --> Config Class Initialized
INFO - 2020-07-05 07:19:23 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:19:23 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:19:23 --> Utf8 Class Initialized
INFO - 2020-07-05 07:19:23 --> URI Class Initialized
INFO - 2020-07-05 07:19:23 --> Router Class Initialized
INFO - 2020-07-05 07:19:23 --> Output Class Initialized
INFO - 2020-07-05 07:19:23 --> Security Class Initialized
DEBUG - 2020-07-05 07:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:19:23 --> Input Class Initialized
INFO - 2020-07-05 07:19:23 --> Language Class Initialized
INFO - 2020-07-05 07:19:23 --> Language Class Initialized
INFO - 2020-07-05 07:19:23 --> Config Class Initialized
INFO - 2020-07-05 07:19:23 --> Loader Class Initialized
INFO - 2020-07-05 07:19:23 --> Helper loaded: url_helper
INFO - 2020-07-05 07:19:23 --> Helper loaded: main_helper
INFO - 2020-07-05 07:19:23 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:19:23 --> Controller Class Initialized
DEBUG - 2020-07-05 07:19:23 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:19:23 --> Final output sent to browser
DEBUG - 2020-07-05 07:19:23 --> Total execution time: 0.0035
INFO - 2020-07-05 07:20:14 --> Config Class Initialized
INFO - 2020-07-05 07:20:14 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:20:14 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:20:14 --> Utf8 Class Initialized
INFO - 2020-07-05 07:20:14 --> URI Class Initialized
INFO - 2020-07-05 07:20:14 --> Router Class Initialized
INFO - 2020-07-05 07:20:14 --> Output Class Initialized
INFO - 2020-07-05 07:20:14 --> Security Class Initialized
DEBUG - 2020-07-05 07:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:20:14 --> Input Class Initialized
INFO - 2020-07-05 07:20:14 --> Language Class Initialized
INFO - 2020-07-05 07:20:14 --> Language Class Initialized
INFO - 2020-07-05 07:20:14 --> Config Class Initialized
INFO - 2020-07-05 07:20:14 --> Loader Class Initialized
INFO - 2020-07-05 07:20:14 --> Helper loaded: url_helper
INFO - 2020-07-05 07:20:14 --> Helper loaded: main_helper
INFO - 2020-07-05 07:20:14 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:20:14 --> Controller Class Initialized
DEBUG - 2020-07-05 07:20:14 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:20:14 --> Final output sent to browser
DEBUG - 2020-07-05 07:20:14 --> Total execution time: 0.0037
INFO - 2020-07-05 07:20:51 --> Config Class Initialized
INFO - 2020-07-05 07:20:51 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:20:51 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:20:51 --> Utf8 Class Initialized
INFO - 2020-07-05 07:20:51 --> URI Class Initialized
INFO - 2020-07-05 07:20:51 --> Router Class Initialized
INFO - 2020-07-05 07:20:51 --> Output Class Initialized
INFO - 2020-07-05 07:20:51 --> Security Class Initialized
DEBUG - 2020-07-05 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:20:51 --> Input Class Initialized
INFO - 2020-07-05 07:20:51 --> Language Class Initialized
INFO - 2020-07-05 07:20:51 --> Language Class Initialized
INFO - 2020-07-05 07:20:51 --> Config Class Initialized
INFO - 2020-07-05 07:20:51 --> Loader Class Initialized
INFO - 2020-07-05 07:20:51 --> Helper loaded: url_helper
INFO - 2020-07-05 07:20:51 --> Helper loaded: main_helper
INFO - 2020-07-05 07:20:51 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:20:51 --> Controller Class Initialized
DEBUG - 2020-07-05 07:20:51 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:20:51 --> Final output sent to browser
DEBUG - 2020-07-05 07:20:51 --> Total execution time: 0.0060
INFO - 2020-07-05 07:21:01 --> Config Class Initialized
INFO - 2020-07-05 07:21:01 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:21:01 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:21:01 --> Utf8 Class Initialized
INFO - 2020-07-05 07:21:01 --> URI Class Initialized
INFO - 2020-07-05 07:21:01 --> Router Class Initialized
INFO - 2020-07-05 07:21:01 --> Output Class Initialized
INFO - 2020-07-05 07:21:01 --> Security Class Initialized
DEBUG - 2020-07-05 07:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:21:01 --> Input Class Initialized
INFO - 2020-07-05 07:21:01 --> Language Class Initialized
INFO - 2020-07-05 07:21:01 --> Language Class Initialized
INFO - 2020-07-05 07:21:01 --> Config Class Initialized
INFO - 2020-07-05 07:21:01 --> Loader Class Initialized
INFO - 2020-07-05 07:21:01 --> Helper loaded: url_helper
INFO - 2020-07-05 07:21:01 --> Helper loaded: main_helper
INFO - 2020-07-05 07:21:01 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:21:01 --> Controller Class Initialized
DEBUG - 2020-07-05 07:21:01 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:21:01 --> Final output sent to browser
DEBUG - 2020-07-05 07:21:01 --> Total execution time: 0.0058
INFO - 2020-07-05 07:21:22 --> Config Class Initialized
INFO - 2020-07-05 07:21:22 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:21:22 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:21:22 --> Utf8 Class Initialized
INFO - 2020-07-05 07:21:22 --> URI Class Initialized
INFO - 2020-07-05 07:21:22 --> Router Class Initialized
INFO - 2020-07-05 07:21:22 --> Output Class Initialized
INFO - 2020-07-05 07:21:22 --> Security Class Initialized
DEBUG - 2020-07-05 07:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:21:22 --> Input Class Initialized
INFO - 2020-07-05 07:21:22 --> Language Class Initialized
INFO - 2020-07-05 07:21:22 --> Language Class Initialized
INFO - 2020-07-05 07:21:22 --> Config Class Initialized
INFO - 2020-07-05 07:21:22 --> Loader Class Initialized
INFO - 2020-07-05 07:21:22 --> Helper loaded: url_helper
INFO - 2020-07-05 07:21:22 --> Helper loaded: main_helper
INFO - 2020-07-05 07:21:22 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:21:22 --> Controller Class Initialized
DEBUG - 2020-07-05 07:21:22 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:21:22 --> Final output sent to browser
DEBUG - 2020-07-05 07:21:22 --> Total execution time: 0.0044
INFO - 2020-07-05 07:21:24 --> Config Class Initialized
INFO - 2020-07-05 07:21:24 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:21:24 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:21:24 --> Utf8 Class Initialized
INFO - 2020-07-05 07:21:24 --> URI Class Initialized
INFO - 2020-07-05 07:21:24 --> Router Class Initialized
INFO - 2020-07-05 07:21:24 --> Output Class Initialized
INFO - 2020-07-05 07:21:24 --> Security Class Initialized
DEBUG - 2020-07-05 07:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:21:24 --> Input Class Initialized
INFO - 2020-07-05 07:21:24 --> Language Class Initialized
INFO - 2020-07-05 07:21:24 --> Language Class Initialized
INFO - 2020-07-05 07:21:24 --> Config Class Initialized
INFO - 2020-07-05 07:21:24 --> Loader Class Initialized
INFO - 2020-07-05 07:21:24 --> Helper loaded: url_helper
INFO - 2020-07-05 07:21:24 --> Helper loaded: main_helper
INFO - 2020-07-05 07:21:24 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:21:24 --> Controller Class Initialized
DEBUG - 2020-07-05 07:21:24 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:21:24 --> Final output sent to browser
DEBUG - 2020-07-05 07:21:24 --> Total execution time: 0.0091
INFO - 2020-07-05 07:21:54 --> Config Class Initialized
INFO - 2020-07-05 07:21:54 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:21:54 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:21:54 --> Utf8 Class Initialized
INFO - 2020-07-05 07:21:54 --> URI Class Initialized
INFO - 2020-07-05 07:21:54 --> Router Class Initialized
INFO - 2020-07-05 07:21:54 --> Output Class Initialized
INFO - 2020-07-05 07:21:54 --> Security Class Initialized
DEBUG - 2020-07-05 07:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:21:54 --> Input Class Initialized
INFO - 2020-07-05 07:21:54 --> Language Class Initialized
INFO - 2020-07-05 07:21:54 --> Language Class Initialized
INFO - 2020-07-05 07:21:54 --> Config Class Initialized
INFO - 2020-07-05 07:21:54 --> Loader Class Initialized
INFO - 2020-07-05 07:21:54 --> Helper loaded: url_helper
INFO - 2020-07-05 07:21:54 --> Helper loaded: main_helper
INFO - 2020-07-05 07:21:54 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:21:54 --> Controller Class Initialized
DEBUG - 2020-07-05 07:21:54 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:21:54 --> Final output sent to browser
DEBUG - 2020-07-05 07:21:54 --> Total execution time: 0.0042
INFO - 2020-07-05 07:22:00 --> Config Class Initialized
INFO - 2020-07-05 07:22:00 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:22:00 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:22:00 --> Utf8 Class Initialized
INFO - 2020-07-05 07:22:00 --> URI Class Initialized
INFO - 2020-07-05 07:22:00 --> Router Class Initialized
INFO - 2020-07-05 07:22:00 --> Output Class Initialized
INFO - 2020-07-05 07:22:00 --> Security Class Initialized
DEBUG - 2020-07-05 07:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:22:00 --> Input Class Initialized
INFO - 2020-07-05 07:22:00 --> Language Class Initialized
INFO - 2020-07-05 07:22:00 --> Language Class Initialized
INFO - 2020-07-05 07:22:00 --> Config Class Initialized
INFO - 2020-07-05 07:22:00 --> Loader Class Initialized
INFO - 2020-07-05 07:22:00 --> Helper loaded: url_helper
INFO - 2020-07-05 07:22:00 --> Helper loaded: main_helper
INFO - 2020-07-05 07:22:00 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:22:00 --> Controller Class Initialized
DEBUG - 2020-07-05 07:22:00 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:22:00 --> Final output sent to browser
DEBUG - 2020-07-05 07:22:00 --> Total execution time: 0.0032
INFO - 2020-07-05 07:22:05 --> Config Class Initialized
INFO - 2020-07-05 07:22:05 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:22:05 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:22:05 --> Utf8 Class Initialized
INFO - 2020-07-05 07:22:05 --> URI Class Initialized
INFO - 2020-07-05 07:22:05 --> Router Class Initialized
INFO - 2020-07-05 07:22:05 --> Output Class Initialized
INFO - 2020-07-05 07:22:05 --> Security Class Initialized
DEBUG - 2020-07-05 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:22:05 --> Input Class Initialized
INFO - 2020-07-05 07:22:05 --> Language Class Initialized
INFO - 2020-07-05 07:22:05 --> Language Class Initialized
INFO - 2020-07-05 07:22:05 --> Config Class Initialized
INFO - 2020-07-05 07:22:05 --> Loader Class Initialized
INFO - 2020-07-05 07:22:05 --> Helper loaded: url_helper
INFO - 2020-07-05 07:22:05 --> Helper loaded: main_helper
INFO - 2020-07-05 07:22:05 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:22:05 --> Controller Class Initialized
DEBUG - 2020-07-05 07:22:05 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:22:05 --> Final output sent to browser
DEBUG - 2020-07-05 07:22:05 --> Total execution time: 0.0048
INFO - 2020-07-05 07:23:11 --> Config Class Initialized
INFO - 2020-07-05 07:23:11 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:23:11 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:23:11 --> Utf8 Class Initialized
INFO - 2020-07-05 07:23:11 --> URI Class Initialized
INFO - 2020-07-05 07:23:11 --> Router Class Initialized
INFO - 2020-07-05 07:23:11 --> Output Class Initialized
INFO - 2020-07-05 07:23:11 --> Security Class Initialized
DEBUG - 2020-07-05 07:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:23:11 --> Input Class Initialized
INFO - 2020-07-05 07:23:11 --> Language Class Initialized
INFO - 2020-07-05 07:23:11 --> Language Class Initialized
INFO - 2020-07-05 07:23:11 --> Config Class Initialized
INFO - 2020-07-05 07:23:11 --> Loader Class Initialized
INFO - 2020-07-05 07:23:11 --> Helper loaded: url_helper
INFO - 2020-07-05 07:23:11 --> Helper loaded: main_helper
INFO - 2020-07-05 07:23:12 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:23:12 --> Controller Class Initialized
DEBUG - 2020-07-05 07:23:12 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:23:12 --> Final output sent to browser
DEBUG - 2020-07-05 07:23:12 --> Total execution time: 0.0045
INFO - 2020-07-05 07:23:25 --> Config Class Initialized
INFO - 2020-07-05 07:23:25 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:23:25 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:23:25 --> Utf8 Class Initialized
INFO - 2020-07-05 07:23:25 --> URI Class Initialized
INFO - 2020-07-05 07:23:25 --> Router Class Initialized
INFO - 2020-07-05 07:23:25 --> Output Class Initialized
INFO - 2020-07-05 07:23:25 --> Security Class Initialized
DEBUG - 2020-07-05 07:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:23:25 --> Input Class Initialized
INFO - 2020-07-05 07:23:25 --> Language Class Initialized
INFO - 2020-07-05 07:23:25 --> Language Class Initialized
INFO - 2020-07-05 07:23:25 --> Config Class Initialized
INFO - 2020-07-05 07:23:25 --> Loader Class Initialized
INFO - 2020-07-05 07:23:25 --> Helper loaded: url_helper
INFO - 2020-07-05 07:23:25 --> Helper loaded: main_helper
INFO - 2020-07-05 07:23:25 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:23:25 --> Controller Class Initialized
DEBUG - 2020-07-05 07:23:25 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:23:25 --> Final output sent to browser
DEBUG - 2020-07-05 07:23:25 --> Total execution time: 0.0053
INFO - 2020-07-05 07:23:40 --> Config Class Initialized
INFO - 2020-07-05 07:23:40 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:23:40 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:23:40 --> Utf8 Class Initialized
INFO - 2020-07-05 07:23:40 --> URI Class Initialized
INFO - 2020-07-05 07:23:40 --> Router Class Initialized
INFO - 2020-07-05 07:23:40 --> Output Class Initialized
INFO - 2020-07-05 07:23:40 --> Security Class Initialized
DEBUG - 2020-07-05 07:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:23:40 --> Input Class Initialized
INFO - 2020-07-05 07:23:40 --> Language Class Initialized
INFO - 2020-07-05 07:23:40 --> Language Class Initialized
INFO - 2020-07-05 07:23:40 --> Config Class Initialized
INFO - 2020-07-05 07:23:40 --> Loader Class Initialized
INFO - 2020-07-05 07:23:40 --> Helper loaded: url_helper
INFO - 2020-07-05 07:23:40 --> Helper loaded: main_helper
INFO - 2020-07-05 07:23:40 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:23:40 --> Controller Class Initialized
DEBUG - 2020-07-05 07:23:40 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:23:40 --> Final output sent to browser
DEBUG - 2020-07-05 07:23:40 --> Total execution time: 0.0058
INFO - 2020-07-05 07:23:52 --> Config Class Initialized
INFO - 2020-07-05 07:23:52 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:23:52 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:23:52 --> Utf8 Class Initialized
INFO - 2020-07-05 07:23:52 --> URI Class Initialized
INFO - 2020-07-05 07:23:52 --> Router Class Initialized
INFO - 2020-07-05 07:23:52 --> Output Class Initialized
INFO - 2020-07-05 07:23:52 --> Security Class Initialized
DEBUG - 2020-07-05 07:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:23:52 --> Input Class Initialized
INFO - 2020-07-05 07:23:52 --> Language Class Initialized
INFO - 2020-07-05 07:23:52 --> Language Class Initialized
INFO - 2020-07-05 07:23:52 --> Config Class Initialized
INFO - 2020-07-05 07:23:52 --> Loader Class Initialized
INFO - 2020-07-05 07:23:52 --> Helper loaded: url_helper
INFO - 2020-07-05 07:23:52 --> Helper loaded: main_helper
INFO - 2020-07-05 07:23:52 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:23:52 --> Controller Class Initialized
DEBUG - 2020-07-05 07:23:52 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:23:52 --> Final output sent to browser
DEBUG - 2020-07-05 07:23:52 --> Total execution time: 0.0031
INFO - 2020-07-05 07:24:07 --> Config Class Initialized
INFO - 2020-07-05 07:24:07 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:24:07 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:24:07 --> Utf8 Class Initialized
INFO - 2020-07-05 07:24:07 --> URI Class Initialized
INFO - 2020-07-05 07:24:07 --> Router Class Initialized
INFO - 2020-07-05 07:24:07 --> Output Class Initialized
INFO - 2020-07-05 07:24:07 --> Security Class Initialized
DEBUG - 2020-07-05 07:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:24:07 --> Input Class Initialized
INFO - 2020-07-05 07:24:07 --> Language Class Initialized
INFO - 2020-07-05 07:24:07 --> Language Class Initialized
INFO - 2020-07-05 07:24:07 --> Config Class Initialized
INFO - 2020-07-05 07:24:07 --> Loader Class Initialized
INFO - 2020-07-05 07:24:07 --> Helper loaded: url_helper
INFO - 2020-07-05 07:24:07 --> Helper loaded: main_helper
INFO - 2020-07-05 07:24:07 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:24:07 --> Controller Class Initialized
DEBUG - 2020-07-05 07:24:07 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:24:07 --> Final output sent to browser
DEBUG - 2020-07-05 07:24:07 --> Total execution time: 0.0067
INFO - 2020-07-05 07:24:17 --> Config Class Initialized
INFO - 2020-07-05 07:24:17 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:24:17 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:24:17 --> Utf8 Class Initialized
INFO - 2020-07-05 07:24:17 --> URI Class Initialized
INFO - 2020-07-05 07:24:17 --> Router Class Initialized
INFO - 2020-07-05 07:24:17 --> Output Class Initialized
INFO - 2020-07-05 07:24:17 --> Security Class Initialized
DEBUG - 2020-07-05 07:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:24:17 --> Input Class Initialized
INFO - 2020-07-05 07:24:17 --> Language Class Initialized
INFO - 2020-07-05 07:24:17 --> Language Class Initialized
INFO - 2020-07-05 07:24:17 --> Config Class Initialized
INFO - 2020-07-05 07:24:17 --> Loader Class Initialized
INFO - 2020-07-05 07:24:17 --> Helper loaded: url_helper
INFO - 2020-07-05 07:24:17 --> Helper loaded: main_helper
INFO - 2020-07-05 07:24:17 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:24:17 --> Controller Class Initialized
DEBUG - 2020-07-05 07:24:17 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:24:17 --> Final output sent to browser
DEBUG - 2020-07-05 07:24:17 --> Total execution time: 0.0048
INFO - 2020-07-05 07:24:22 --> Config Class Initialized
INFO - 2020-07-05 07:24:22 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:24:22 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:24:22 --> Utf8 Class Initialized
INFO - 2020-07-05 07:24:22 --> URI Class Initialized
INFO - 2020-07-05 07:24:22 --> Router Class Initialized
INFO - 2020-07-05 07:24:22 --> Output Class Initialized
INFO - 2020-07-05 07:24:22 --> Security Class Initialized
DEBUG - 2020-07-05 07:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:24:22 --> Input Class Initialized
INFO - 2020-07-05 07:24:22 --> Language Class Initialized
INFO - 2020-07-05 07:24:22 --> Language Class Initialized
INFO - 2020-07-05 07:24:22 --> Config Class Initialized
INFO - 2020-07-05 07:24:22 --> Loader Class Initialized
INFO - 2020-07-05 07:24:22 --> Helper loaded: url_helper
INFO - 2020-07-05 07:24:22 --> Helper loaded: main_helper
INFO - 2020-07-05 07:24:22 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:24:22 --> Controller Class Initialized
DEBUG - 2020-07-05 07:24:22 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:24:22 --> Final output sent to browser
DEBUG - 2020-07-05 07:24:22 --> Total execution time: 0.0063
INFO - 2020-07-05 07:25:00 --> Config Class Initialized
INFO - 2020-07-05 07:25:00 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:25:00 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:25:00 --> Utf8 Class Initialized
INFO - 2020-07-05 07:25:00 --> URI Class Initialized
INFO - 2020-07-05 07:25:00 --> Router Class Initialized
INFO - 2020-07-05 07:25:00 --> Output Class Initialized
INFO - 2020-07-05 07:25:00 --> Security Class Initialized
DEBUG - 2020-07-05 07:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:25:00 --> Input Class Initialized
INFO - 2020-07-05 07:25:00 --> Language Class Initialized
INFO - 2020-07-05 07:25:00 --> Language Class Initialized
INFO - 2020-07-05 07:25:00 --> Config Class Initialized
INFO - 2020-07-05 07:25:00 --> Loader Class Initialized
INFO - 2020-07-05 07:25:00 --> Helper loaded: url_helper
INFO - 2020-07-05 07:25:00 --> Helper loaded: main_helper
INFO - 2020-07-05 07:25:00 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:25:00 --> Controller Class Initialized
DEBUG - 2020-07-05 07:25:00 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:25:00 --> Final output sent to browser
DEBUG - 2020-07-05 07:25:00 --> Total execution time: 0.0033
INFO - 2020-07-05 07:25:13 --> Config Class Initialized
INFO - 2020-07-05 07:25:13 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:25:13 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:25:13 --> Utf8 Class Initialized
INFO - 2020-07-05 07:25:13 --> URI Class Initialized
INFO - 2020-07-05 07:25:13 --> Router Class Initialized
INFO - 2020-07-05 07:25:13 --> Output Class Initialized
INFO - 2020-07-05 07:25:13 --> Security Class Initialized
DEBUG - 2020-07-05 07:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:25:13 --> Input Class Initialized
INFO - 2020-07-05 07:25:13 --> Language Class Initialized
INFO - 2020-07-05 07:25:13 --> Language Class Initialized
INFO - 2020-07-05 07:25:13 --> Config Class Initialized
INFO - 2020-07-05 07:25:13 --> Loader Class Initialized
INFO - 2020-07-05 07:25:13 --> Helper loaded: url_helper
INFO - 2020-07-05 07:25:13 --> Helper loaded: main_helper
INFO - 2020-07-05 07:25:13 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:25:13 --> Controller Class Initialized
DEBUG - 2020-07-05 07:25:13 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:25:13 --> Final output sent to browser
DEBUG - 2020-07-05 07:25:13 --> Total execution time: 0.0032
INFO - 2020-07-05 07:25:37 --> Config Class Initialized
INFO - 2020-07-05 07:25:37 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:25:37 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:25:37 --> Utf8 Class Initialized
INFO - 2020-07-05 07:25:37 --> URI Class Initialized
INFO - 2020-07-05 07:25:37 --> Router Class Initialized
INFO - 2020-07-05 07:25:37 --> Output Class Initialized
INFO - 2020-07-05 07:25:37 --> Security Class Initialized
DEBUG - 2020-07-05 07:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:25:37 --> Input Class Initialized
INFO - 2020-07-05 07:25:37 --> Language Class Initialized
INFO - 2020-07-05 07:25:37 --> Language Class Initialized
INFO - 2020-07-05 07:25:37 --> Config Class Initialized
INFO - 2020-07-05 07:25:37 --> Loader Class Initialized
INFO - 2020-07-05 07:25:37 --> Helper loaded: url_helper
INFO - 2020-07-05 07:25:37 --> Helper loaded: main_helper
INFO - 2020-07-05 07:25:37 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:25:37 --> Controller Class Initialized
DEBUG - 2020-07-05 07:25:37 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:25:37 --> Final output sent to browser
DEBUG - 2020-07-05 07:25:37 --> Total execution time: 0.0053
INFO - 2020-07-05 07:25:42 --> Config Class Initialized
INFO - 2020-07-05 07:25:42 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:25:42 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:25:42 --> Utf8 Class Initialized
INFO - 2020-07-05 07:25:42 --> URI Class Initialized
INFO - 2020-07-05 07:25:42 --> Router Class Initialized
INFO - 2020-07-05 07:25:42 --> Output Class Initialized
INFO - 2020-07-05 07:25:42 --> Security Class Initialized
DEBUG - 2020-07-05 07:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:25:42 --> Input Class Initialized
INFO - 2020-07-05 07:25:42 --> Language Class Initialized
INFO - 2020-07-05 07:25:42 --> Language Class Initialized
INFO - 2020-07-05 07:25:42 --> Config Class Initialized
INFO - 2020-07-05 07:25:42 --> Loader Class Initialized
INFO - 2020-07-05 07:25:42 --> Helper loaded: url_helper
INFO - 2020-07-05 07:25:42 --> Helper loaded: main_helper
INFO - 2020-07-05 07:25:42 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:25:42 --> Controller Class Initialized
DEBUG - 2020-07-05 07:25:42 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:25:42 --> Final output sent to browser
DEBUG - 2020-07-05 07:25:42 --> Total execution time: 0.0055
INFO - 2020-07-05 07:25:55 --> Config Class Initialized
INFO - 2020-07-05 07:25:55 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:25:55 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:25:55 --> Utf8 Class Initialized
INFO - 2020-07-05 07:25:55 --> URI Class Initialized
INFO - 2020-07-05 07:25:55 --> Router Class Initialized
INFO - 2020-07-05 07:25:55 --> Output Class Initialized
INFO - 2020-07-05 07:25:55 --> Security Class Initialized
DEBUG - 2020-07-05 07:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:25:55 --> Input Class Initialized
INFO - 2020-07-05 07:25:55 --> Language Class Initialized
INFO - 2020-07-05 07:25:55 --> Language Class Initialized
INFO - 2020-07-05 07:25:55 --> Config Class Initialized
INFO - 2020-07-05 07:25:55 --> Loader Class Initialized
INFO - 2020-07-05 07:25:55 --> Helper loaded: url_helper
INFO - 2020-07-05 07:25:55 --> Helper loaded: main_helper
INFO - 2020-07-05 07:25:55 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:25:55 --> Controller Class Initialized
DEBUG - 2020-07-05 07:25:55 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:25:55 --> Final output sent to browser
DEBUG - 2020-07-05 07:25:55 --> Total execution time: 0.0032
INFO - 2020-07-05 07:26:02 --> Config Class Initialized
INFO - 2020-07-05 07:26:02 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:26:02 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:26:02 --> Utf8 Class Initialized
INFO - 2020-07-05 07:26:02 --> URI Class Initialized
INFO - 2020-07-05 07:26:02 --> Router Class Initialized
INFO - 2020-07-05 07:26:02 --> Output Class Initialized
INFO - 2020-07-05 07:26:02 --> Security Class Initialized
DEBUG - 2020-07-05 07:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:26:02 --> Input Class Initialized
INFO - 2020-07-05 07:26:02 --> Language Class Initialized
INFO - 2020-07-05 07:26:02 --> Language Class Initialized
INFO - 2020-07-05 07:26:02 --> Config Class Initialized
INFO - 2020-07-05 07:26:02 --> Loader Class Initialized
INFO - 2020-07-05 07:26:02 --> Helper loaded: url_helper
INFO - 2020-07-05 07:26:02 --> Helper loaded: main_helper
INFO - 2020-07-05 07:26:02 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:26:02 --> Controller Class Initialized
DEBUG - 2020-07-05 07:26:02 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:26:02 --> Final output sent to browser
DEBUG - 2020-07-05 07:26:02 --> Total execution time: 0.0052
INFO - 2020-07-05 07:26:25 --> Config Class Initialized
INFO - 2020-07-05 07:26:25 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:26:25 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:26:25 --> Utf8 Class Initialized
INFO - 2020-07-05 07:26:25 --> URI Class Initialized
INFO - 2020-07-05 07:26:25 --> Router Class Initialized
INFO - 2020-07-05 07:26:25 --> Output Class Initialized
INFO - 2020-07-05 07:26:25 --> Security Class Initialized
DEBUG - 2020-07-05 07:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:26:25 --> Input Class Initialized
INFO - 2020-07-05 07:26:25 --> Language Class Initialized
INFO - 2020-07-05 07:26:25 --> Language Class Initialized
INFO - 2020-07-05 07:26:25 --> Config Class Initialized
INFO - 2020-07-05 07:26:25 --> Loader Class Initialized
INFO - 2020-07-05 07:26:25 --> Helper loaded: url_helper
INFO - 2020-07-05 07:26:25 --> Helper loaded: main_helper
INFO - 2020-07-05 07:26:25 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:26:25 --> Controller Class Initialized
DEBUG - 2020-07-05 07:26:25 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:26:25 --> Final output sent to browser
DEBUG - 2020-07-05 07:26:25 --> Total execution time: 0.0035
INFO - 2020-07-05 07:26:32 --> Config Class Initialized
INFO - 2020-07-05 07:26:32 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:26:32 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:26:32 --> Utf8 Class Initialized
INFO - 2020-07-05 07:26:32 --> URI Class Initialized
INFO - 2020-07-05 07:26:32 --> Router Class Initialized
INFO - 2020-07-05 07:26:32 --> Output Class Initialized
INFO - 2020-07-05 07:26:32 --> Security Class Initialized
DEBUG - 2020-07-05 07:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:26:32 --> Input Class Initialized
INFO - 2020-07-05 07:26:32 --> Language Class Initialized
INFO - 2020-07-05 07:26:32 --> Language Class Initialized
INFO - 2020-07-05 07:26:32 --> Config Class Initialized
INFO - 2020-07-05 07:26:32 --> Loader Class Initialized
INFO - 2020-07-05 07:26:32 --> Helper loaded: url_helper
INFO - 2020-07-05 07:26:32 --> Helper loaded: main_helper
INFO - 2020-07-05 07:26:32 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:26:32 --> Controller Class Initialized
DEBUG - 2020-07-05 07:26:32 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:26:32 --> Final output sent to browser
DEBUG - 2020-07-05 07:26:32 --> Total execution time: 0.0036
INFO - 2020-07-05 07:26:52 --> Config Class Initialized
INFO - 2020-07-05 07:26:52 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:26:52 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:26:52 --> Utf8 Class Initialized
INFO - 2020-07-05 07:26:52 --> URI Class Initialized
DEBUG - 2020-07-05 07:26:52 --> No URI present. Default controller set.
INFO - 2020-07-05 07:26:52 --> Router Class Initialized
INFO - 2020-07-05 07:26:52 --> Output Class Initialized
INFO - 2020-07-05 07:26:52 --> Security Class Initialized
DEBUG - 2020-07-05 07:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:26:52 --> Input Class Initialized
INFO - 2020-07-05 07:26:52 --> Language Class Initialized
INFO - 2020-07-05 07:26:52 --> Language Class Initialized
INFO - 2020-07-05 07:26:52 --> Config Class Initialized
INFO - 2020-07-05 07:26:52 --> Loader Class Initialized
INFO - 2020-07-05 07:26:52 --> Helper loaded: url_helper
INFO - 2020-07-05 07:26:52 --> Helper loaded: main_helper
INFO - 2020-07-05 07:26:52 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:26:52 --> Controller Class Initialized
DEBUG - 2020-07-05 07:26:52 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-05 07:26:52 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 07:26:52 --> Final output sent to browser
DEBUG - 2020-07-05 07:26:52 --> Total execution time: 0.0058
INFO - 2020-07-05 07:27:00 --> Config Class Initialized
INFO - 2020-07-05 07:27:00 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:27:00 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:27:00 --> Utf8 Class Initialized
INFO - 2020-07-05 07:27:00 --> URI Class Initialized
INFO - 2020-07-05 07:27:00 --> Router Class Initialized
INFO - 2020-07-05 07:27:00 --> Output Class Initialized
INFO - 2020-07-05 07:27:00 --> Security Class Initialized
DEBUG - 2020-07-05 07:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:27:00 --> Input Class Initialized
INFO - 2020-07-05 07:27:00 --> Language Class Initialized
INFO - 2020-07-05 07:27:00 --> Language Class Initialized
INFO - 2020-07-05 07:27:00 --> Config Class Initialized
INFO - 2020-07-05 07:27:00 --> Loader Class Initialized
INFO - 2020-07-05 07:27:00 --> Helper loaded: url_helper
INFO - 2020-07-05 07:27:00 --> Helper loaded: main_helper
INFO - 2020-07-05 07:27:00 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:27:00 --> Controller Class Initialized
DEBUG - 2020-07-05 07:27:00 --> File loaded: /var/www/journal/application/modules/template/views/404.php
INFO - 2020-07-05 07:27:00 --> Final output sent to browser
DEBUG - 2020-07-05 07:27:00 --> Total execution time: 0.0077
INFO - 2020-07-05 07:27:14 --> Config Class Initialized
INFO - 2020-07-05 07:27:14 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:27:14 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:27:14 --> Utf8 Class Initialized
INFO - 2020-07-05 07:27:14 --> URI Class Initialized
DEBUG - 2020-07-05 07:27:14 --> No URI present. Default controller set.
INFO - 2020-07-05 07:27:14 --> Router Class Initialized
INFO - 2020-07-05 07:27:14 --> Output Class Initialized
INFO - 2020-07-05 07:27:14 --> Security Class Initialized
DEBUG - 2020-07-05 07:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:27:14 --> Input Class Initialized
INFO - 2020-07-05 07:27:14 --> Language Class Initialized
INFO - 2020-07-05 07:27:14 --> Language Class Initialized
INFO - 2020-07-05 07:27:14 --> Config Class Initialized
INFO - 2020-07-05 07:27:14 --> Loader Class Initialized
INFO - 2020-07-05 07:27:14 --> Helper loaded: url_helper
INFO - 2020-07-05 07:27:14 --> Helper loaded: main_helper
INFO - 2020-07-05 07:27:14 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:27:14 --> Controller Class Initialized
DEBUG - 2020-07-05 07:27:14 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-05 07:27:14 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 07:27:14 --> Final output sent to browser
DEBUG - 2020-07-05 07:27:14 --> Total execution time: 0.0046
INFO - 2020-07-05 07:27:35 --> Config Class Initialized
INFO - 2020-07-05 07:27:35 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:27:35 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:27:35 --> Utf8 Class Initialized
INFO - 2020-07-05 07:27:35 --> URI Class Initialized
INFO - 2020-07-05 07:27:35 --> Router Class Initialized
INFO - 2020-07-05 07:27:35 --> Output Class Initialized
INFO - 2020-07-05 07:27:35 --> Security Class Initialized
DEBUG - 2020-07-05 07:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:27:35 --> Input Class Initialized
INFO - 2020-07-05 07:27:35 --> Language Class Initialized
INFO - 2020-07-05 07:27:35 --> Language Class Initialized
INFO - 2020-07-05 07:27:35 --> Config Class Initialized
INFO - 2020-07-05 07:27:35 --> Loader Class Initialized
INFO - 2020-07-05 07:27:35 --> Helper loaded: url_helper
INFO - 2020-07-05 07:27:35 --> Helper loaded: main_helper
INFO - 2020-07-05 07:27:35 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:27:35 --> Controller Class Initialized
INFO - 2020-07-05 07:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 07:27:35 --> Pagination Class Initialized
ERROR - 2020-07-05 07:27:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 07:27:35 --> Helper loaded: file_helper
DEBUG - 2020-07-05 07:27:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 07:27:36 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 07:27:36 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 07:27:36 --> Final output sent to browser
DEBUG - 2020-07-05 07:27:36 --> Total execution time: 1.3523
INFO - 2020-07-05 07:27:43 --> Config Class Initialized
INFO - 2020-07-05 07:27:43 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:27:43 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:27:43 --> Utf8 Class Initialized
INFO - 2020-07-05 07:27:43 --> URI Class Initialized
INFO - 2020-07-05 07:27:43 --> Router Class Initialized
INFO - 2020-07-05 07:27:43 --> Output Class Initialized
INFO - 2020-07-05 07:27:43 --> Security Class Initialized
DEBUG - 2020-07-05 07:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:27:43 --> Input Class Initialized
INFO - 2020-07-05 07:27:43 --> Language Class Initialized
INFO - 2020-07-05 07:27:43 --> Language Class Initialized
INFO - 2020-07-05 07:27:43 --> Config Class Initialized
INFO - 2020-07-05 07:27:43 --> Loader Class Initialized
INFO - 2020-07-05 07:27:43 --> Helper loaded: url_helper
INFO - 2020-07-05 07:27:43 --> Helper loaded: main_helper
INFO - 2020-07-05 07:27:43 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:27:43 --> Controller Class Initialized
INFO - 2020-07-05 07:27:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 07:27:43 --> Pagination Class Initialized
ERROR - 2020-07-05 07:27:43 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 07:27:43 --> Helper loaded: file_helper
DEBUG - 2020-07-05 07:27:43 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 07:27:43 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 07:27:43 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 07:27:43 --> Final output sent to browser
DEBUG - 2020-07-05 07:27:43 --> Total execution time: 0.0072
INFO - 2020-07-05 07:27:54 --> Config Class Initialized
INFO - 2020-07-05 07:27:54 --> Hooks Class Initialized
DEBUG - 2020-07-05 07:27:54 --> UTF-8 Support Enabled
INFO - 2020-07-05 07:27:54 --> Utf8 Class Initialized
INFO - 2020-07-05 07:27:54 --> URI Class Initialized
INFO - 2020-07-05 07:27:54 --> Router Class Initialized
INFO - 2020-07-05 07:27:54 --> Output Class Initialized
INFO - 2020-07-05 07:27:54 --> Security Class Initialized
DEBUG - 2020-07-05 07:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 07:27:54 --> Input Class Initialized
INFO - 2020-07-05 07:27:54 --> Language Class Initialized
INFO - 2020-07-05 07:27:54 --> Language Class Initialized
INFO - 2020-07-05 07:27:54 --> Config Class Initialized
INFO - 2020-07-05 07:27:54 --> Loader Class Initialized
INFO - 2020-07-05 07:27:54 --> Helper loaded: url_helper
INFO - 2020-07-05 07:27:54 --> Helper loaded: main_helper
INFO - 2020-07-05 07:27:54 --> Database Driver Class Initialized
DEBUG - 2020-07-05 07:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 07:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 07:27:54 --> Controller Class Initialized
INFO - 2020-07-05 07:27:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 07:27:54 --> Pagination Class Initialized
ERROR - 2020-07-05 07:27:54 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 07:27:54 --> Helper loaded: file_helper
DEBUG - 2020-07-05 07:27:54 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 07:27:54 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 07:27:54 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 07:27:54 --> Final output sent to browser
DEBUG - 2020-07-05 07:27:54 --> Total execution time: 0.0116
INFO - 2020-07-05 11:18:59 --> Config Class Initialized
INFO - 2020-07-05 11:18:59 --> Hooks Class Initialized
DEBUG - 2020-07-05 11:18:59 --> UTF-8 Support Enabled
INFO - 2020-07-05 11:18:59 --> Utf8 Class Initialized
INFO - 2020-07-05 11:18:59 --> URI Class Initialized
DEBUG - 2020-07-05 11:18:59 --> No URI present. Default controller set.
INFO - 2020-07-05 11:18:59 --> Router Class Initialized
INFO - 2020-07-05 11:18:59 --> Output Class Initialized
INFO - 2020-07-05 11:18:59 --> Security Class Initialized
DEBUG - 2020-07-05 11:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 11:18:59 --> Input Class Initialized
INFO - 2020-07-05 11:18:59 --> Language Class Initialized
INFO - 2020-07-05 11:18:59 --> Language Class Initialized
INFO - 2020-07-05 11:18:59 --> Config Class Initialized
INFO - 2020-07-05 11:18:59 --> Loader Class Initialized
INFO - 2020-07-05 11:18:59 --> Helper loaded: url_helper
INFO - 2020-07-05 11:18:59 --> Helper loaded: main_helper
INFO - 2020-07-05 11:18:59 --> Database Driver Class Initialized
DEBUG - 2020-07-05 11:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 11:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 11:18:59 --> Controller Class Initialized
DEBUG - 2020-07-05 11:18:59 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-05 11:18:59 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 11:18:59 --> Final output sent to browser
DEBUG - 2020-07-05 11:18:59 --> Total execution time: 0.0040
INFO - 2020-07-05 11:19:07 --> Config Class Initialized
INFO - 2020-07-05 11:19:07 --> Hooks Class Initialized
DEBUG - 2020-07-05 11:19:07 --> UTF-8 Support Enabled
INFO - 2020-07-05 11:19:07 --> Utf8 Class Initialized
INFO - 2020-07-05 11:19:07 --> URI Class Initialized
INFO - 2020-07-05 11:19:07 --> Router Class Initialized
INFO - 2020-07-05 11:19:07 --> Output Class Initialized
INFO - 2020-07-05 11:19:07 --> Security Class Initialized
DEBUG - 2020-07-05 11:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 11:19:07 --> Input Class Initialized
INFO - 2020-07-05 11:19:07 --> Language Class Initialized
INFO - 2020-07-05 11:19:07 --> Language Class Initialized
INFO - 2020-07-05 11:19:07 --> Config Class Initialized
INFO - 2020-07-05 11:19:07 --> Loader Class Initialized
INFO - 2020-07-05 11:19:07 --> Helper loaded: url_helper
INFO - 2020-07-05 11:19:07 --> Helper loaded: main_helper
INFO - 2020-07-05 11:19:07 --> Database Driver Class Initialized
DEBUG - 2020-07-05 11:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 11:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 11:19:07 --> Controller Class Initialized
INFO - 2020-07-05 11:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 11:19:07 --> Pagination Class Initialized
ERROR - 2020-07-05 11:19:07 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 11:19:07 --> Helper loaded: file_helper
DEBUG - 2020-07-05 11:19:07 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 11:19:09 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 11:19:09 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 11:19:09 --> Final output sent to browser
DEBUG - 2020-07-05 11:19:09 --> Total execution time: 2.2473
INFO - 2020-07-05 11:19:27 --> Config Class Initialized
INFO - 2020-07-05 11:19:27 --> Hooks Class Initialized
DEBUG - 2020-07-05 11:19:27 --> UTF-8 Support Enabled
INFO - 2020-07-05 11:19:27 --> Utf8 Class Initialized
INFO - 2020-07-05 11:19:27 --> URI Class Initialized
INFO - 2020-07-05 11:19:27 --> Router Class Initialized
INFO - 2020-07-05 11:19:27 --> Output Class Initialized
INFO - 2020-07-05 11:19:27 --> Security Class Initialized
DEBUG - 2020-07-05 11:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 11:19:27 --> Input Class Initialized
INFO - 2020-07-05 11:19:27 --> Language Class Initialized
INFO - 2020-07-05 11:19:27 --> Language Class Initialized
INFO - 2020-07-05 11:19:27 --> Config Class Initialized
INFO - 2020-07-05 11:19:27 --> Loader Class Initialized
INFO - 2020-07-05 11:19:27 --> Helper loaded: url_helper
INFO - 2020-07-05 11:19:27 --> Helper loaded: main_helper
INFO - 2020-07-05 11:19:27 --> Database Driver Class Initialized
DEBUG - 2020-07-05 11:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 11:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 11:19:27 --> Controller Class Initialized
DEBUG - 2020-07-05 11:19:27 --> File loaded: /var/www/journal/application/modules/mail/views/mail_v.php
DEBUG - 2020-07-05 11:19:27 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 11:19:27 --> Final output sent to browser
DEBUG - 2020-07-05 11:19:27 --> Total execution time: 0.0073
INFO - 2020-07-05 11:19:28 --> Config Class Initialized
INFO - 2020-07-05 11:19:28 --> Hooks Class Initialized
DEBUG - 2020-07-05 11:19:28 --> UTF-8 Support Enabled
INFO - 2020-07-05 11:19:28 --> Utf8 Class Initialized
INFO - 2020-07-05 11:19:28 --> URI Class Initialized
INFO - 2020-07-05 11:19:28 --> Router Class Initialized
INFO - 2020-07-05 11:19:28 --> Output Class Initialized
INFO - 2020-07-05 11:19:28 --> Security Class Initialized
DEBUG - 2020-07-05 11:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 11:19:28 --> Input Class Initialized
INFO - 2020-07-05 11:19:28 --> Language Class Initialized
INFO - 2020-07-05 11:19:28 --> Language Class Initialized
INFO - 2020-07-05 11:19:28 --> Config Class Initialized
INFO - 2020-07-05 11:19:28 --> Loader Class Initialized
INFO - 2020-07-05 11:19:28 --> Helper loaded: url_helper
INFO - 2020-07-05 11:19:28 --> Helper loaded: main_helper
INFO - 2020-07-05 11:19:28 --> Database Driver Class Initialized
DEBUG - 2020-07-05 11:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 11:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 11:19:28 --> Controller Class Initialized
INFO - 2020-07-05 11:19:28 --> Final output sent to browser
DEBUG - 2020-07-05 11:19:28 --> Total execution time: 0.0290
INFO - 2020-07-05 11:19:43 --> Config Class Initialized
INFO - 2020-07-05 11:19:43 --> Hooks Class Initialized
DEBUG - 2020-07-05 11:19:43 --> UTF-8 Support Enabled
INFO - 2020-07-05 11:19:43 --> Utf8 Class Initialized
INFO - 2020-07-05 11:19:43 --> URI Class Initialized
DEBUG - 2020-07-05 11:19:43 --> No URI present. Default controller set.
INFO - 2020-07-05 11:19:43 --> Router Class Initialized
INFO - 2020-07-05 11:19:43 --> Output Class Initialized
INFO - 2020-07-05 11:19:43 --> Security Class Initialized
DEBUG - 2020-07-05 11:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 11:19:43 --> Input Class Initialized
INFO - 2020-07-05 11:19:43 --> Language Class Initialized
INFO - 2020-07-05 11:19:43 --> Language Class Initialized
INFO - 2020-07-05 11:19:43 --> Config Class Initialized
INFO - 2020-07-05 11:19:43 --> Loader Class Initialized
INFO - 2020-07-05 11:19:43 --> Helper loaded: url_helper
INFO - 2020-07-05 11:19:43 --> Helper loaded: main_helper
INFO - 2020-07-05 11:19:43 --> Database Driver Class Initialized
DEBUG - 2020-07-05 11:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 11:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 11:19:43 --> Controller Class Initialized
DEBUG - 2020-07-05 11:19:43 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-05 11:19:43 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 11:19:43 --> Final output sent to browser
DEBUG - 2020-07-05 11:19:43 --> Total execution time: 0.0040
INFO - 2020-07-05 11:19:51 --> Config Class Initialized
INFO - 2020-07-05 11:19:51 --> Hooks Class Initialized
DEBUG - 2020-07-05 11:19:51 --> UTF-8 Support Enabled
INFO - 2020-07-05 11:19:51 --> Utf8 Class Initialized
INFO - 2020-07-05 11:19:51 --> URI Class Initialized
INFO - 2020-07-05 11:19:51 --> Router Class Initialized
INFO - 2020-07-05 11:19:51 --> Output Class Initialized
INFO - 2020-07-05 11:19:51 --> Security Class Initialized
DEBUG - 2020-07-05 11:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 11:19:51 --> Input Class Initialized
INFO - 2020-07-05 11:19:51 --> Language Class Initialized
INFO - 2020-07-05 11:19:51 --> Language Class Initialized
INFO - 2020-07-05 11:19:51 --> Config Class Initialized
INFO - 2020-07-05 11:19:51 --> Loader Class Initialized
INFO - 2020-07-05 11:19:51 --> Helper loaded: url_helper
INFO - 2020-07-05 11:19:51 --> Helper loaded: main_helper
INFO - 2020-07-05 11:19:51 --> Database Driver Class Initialized
DEBUG - 2020-07-05 11:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 11:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 11:19:51 --> Controller Class Initialized
INFO - 2020-07-05 11:19:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 11:19:51 --> Pagination Class Initialized
ERROR - 2020-07-05 11:19:51 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 11:19:51 --> Helper loaded: file_helper
DEBUG - 2020-07-05 11:19:51 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 11:19:51 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 11:19:51 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 11:19:51 --> Final output sent to browser
DEBUG - 2020-07-05 11:19:51 --> Total execution time: 0.0038
INFO - 2020-07-05 11:19:55 --> Config Class Initialized
INFO - 2020-07-05 11:19:55 --> Hooks Class Initialized
DEBUG - 2020-07-05 11:19:55 --> UTF-8 Support Enabled
INFO - 2020-07-05 11:19:55 --> Utf8 Class Initialized
INFO - 2020-07-05 11:19:55 --> URI Class Initialized
INFO - 2020-07-05 11:19:55 --> Router Class Initialized
INFO - 2020-07-05 11:19:55 --> Output Class Initialized
INFO - 2020-07-05 11:19:55 --> Security Class Initialized
DEBUG - 2020-07-05 11:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 11:19:55 --> Input Class Initialized
INFO - 2020-07-05 11:19:55 --> Language Class Initialized
INFO - 2020-07-05 11:19:55 --> Language Class Initialized
INFO - 2020-07-05 11:19:55 --> Config Class Initialized
INFO - 2020-07-05 11:19:55 --> Loader Class Initialized
INFO - 2020-07-05 11:19:55 --> Helper loaded: url_helper
INFO - 2020-07-05 11:19:55 --> Helper loaded: main_helper
INFO - 2020-07-05 11:19:55 --> Database Driver Class Initialized
DEBUG - 2020-07-05 11:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 11:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 11:19:55 --> Controller Class Initialized
INFO - 2020-07-05 11:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 11:19:55 --> Pagination Class Initialized
ERROR - 2020-07-05 11:19:55 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 11:19:55 --> Helper loaded: file_helper
DEBUG - 2020-07-05 11:19:55 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 11:20:28 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 11:20:28 --> Final output sent to browser
DEBUG - 2020-07-05 11:20:28 --> Total execution time: 32.9289
INFO - 2020-07-05 11:20:28 --> Config Class Initialized
INFO - 2020-07-05 11:20:28 --> Hooks Class Initialized
DEBUG - 2020-07-05 11:20:28 --> UTF-8 Support Enabled
INFO - 2020-07-05 11:20:28 --> Utf8 Class Initialized
INFO - 2020-07-05 11:20:28 --> URI Class Initialized
INFO - 2020-07-05 11:20:28 --> Router Class Initialized
INFO - 2020-07-05 11:20:28 --> Output Class Initialized
INFO - 2020-07-05 11:20:28 --> Security Class Initialized
DEBUG - 2020-07-05 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 11:20:28 --> Input Class Initialized
INFO - 2020-07-05 11:20:28 --> Language Class Initialized
INFO - 2020-07-05 11:20:28 --> Language Class Initialized
INFO - 2020-07-05 11:20:28 --> Config Class Initialized
INFO - 2020-07-05 11:20:28 --> Loader Class Initialized
INFO - 2020-07-05 11:20:28 --> Helper loaded: url_helper
INFO - 2020-07-05 11:20:28 --> Helper loaded: main_helper
INFO - 2020-07-05 11:20:28 --> Database Driver Class Initialized
DEBUG - 2020-07-05 11:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 11:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 11:20:28 --> Controller Class Initialized
INFO - 2020-07-05 11:20:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 11:20:28 --> Pagination Class Initialized
ERROR - 2020-07-05 11:20:28 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 11:20:28 --> Helper loaded: file_helper
DEBUG - 2020-07-05 11:20:28 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 11:20:31 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 11:20:31 --> Final output sent to browser
DEBUG - 2020-07-05 11:20:31 --> Total execution time: 2.7120
INFO - 2020-07-05 11:25:18 --> Config Class Initialized
INFO - 2020-07-05 11:25:18 --> Hooks Class Initialized
DEBUG - 2020-07-05 11:25:18 --> UTF-8 Support Enabled
INFO - 2020-07-05 11:25:18 --> Utf8 Class Initialized
INFO - 2020-07-05 11:25:18 --> URI Class Initialized
INFO - 2020-07-05 11:25:18 --> Router Class Initialized
INFO - 2020-07-05 11:25:18 --> Output Class Initialized
INFO - 2020-07-05 11:25:18 --> Security Class Initialized
DEBUG - 2020-07-05 11:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 11:25:18 --> Input Class Initialized
INFO - 2020-07-05 11:25:18 --> Language Class Initialized
INFO - 2020-07-05 11:25:18 --> Language Class Initialized
INFO - 2020-07-05 11:25:18 --> Config Class Initialized
INFO - 2020-07-05 11:25:18 --> Loader Class Initialized
INFO - 2020-07-05 11:25:18 --> Helper loaded: url_helper
INFO - 2020-07-05 11:25:18 --> Helper loaded: main_helper
INFO - 2020-07-05 11:25:18 --> Database Driver Class Initialized
DEBUG - 2020-07-05 11:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 11:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 11:25:18 --> Controller Class Initialized
INFO - 2020-07-05 11:25:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 11:25:18 --> Pagination Class Initialized
ERROR - 2020-07-05 11:25:18 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 11:25:18 --> Helper loaded: file_helper
DEBUG - 2020-07-05 11:25:18 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 11:25:23 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 11:25:23 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 11:25:23 --> Final output sent to browser
DEBUG - 2020-07-05 11:25:23 --> Total execution time: 5.3183
INFO - 2020-07-05 11:25:37 --> Config Class Initialized
INFO - 2020-07-05 11:25:37 --> Hooks Class Initialized
DEBUG - 2020-07-05 11:25:37 --> UTF-8 Support Enabled
INFO - 2020-07-05 11:25:37 --> Utf8 Class Initialized
INFO - 2020-07-05 11:25:37 --> URI Class Initialized
INFO - 2020-07-05 11:25:37 --> Router Class Initialized
INFO - 2020-07-05 11:25:37 --> Output Class Initialized
INFO - 2020-07-05 11:25:37 --> Security Class Initialized
DEBUG - 2020-07-05 11:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 11:25:37 --> Input Class Initialized
INFO - 2020-07-05 11:25:37 --> Language Class Initialized
INFO - 2020-07-05 11:25:37 --> Language Class Initialized
INFO - 2020-07-05 11:25:37 --> Config Class Initialized
INFO - 2020-07-05 11:25:37 --> Loader Class Initialized
INFO - 2020-07-05 11:25:37 --> Helper loaded: url_helper
INFO - 2020-07-05 11:25:37 --> Helper loaded: main_helper
INFO - 2020-07-05 11:25:37 --> Database Driver Class Initialized
DEBUG - 2020-07-05 11:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 11:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 11:25:37 --> Controller Class Initialized
INFO - 2020-07-05 11:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 11:25:37 --> Pagination Class Initialized
ERROR - 2020-07-05 11:25:37 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 11:25:37 --> Helper loaded: file_helper
DEBUG - 2020-07-05 11:25:37 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 11:25:39 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 11:25:39 --> Final output sent to browser
DEBUG - 2020-07-05 11:25:39 --> Total execution time: 2.5093
INFO - 2020-07-05 12:42:37 --> Config Class Initialized
INFO - 2020-07-05 12:42:37 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:42:37 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:42:37 --> Utf8 Class Initialized
INFO - 2020-07-05 12:42:37 --> URI Class Initialized
INFO - 2020-07-05 12:42:37 --> Router Class Initialized
INFO - 2020-07-05 12:42:37 --> Output Class Initialized
INFO - 2020-07-05 12:42:37 --> Security Class Initialized
DEBUG - 2020-07-05 12:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:42:37 --> Input Class Initialized
INFO - 2020-07-05 12:42:37 --> Language Class Initialized
INFO - 2020-07-05 12:42:37 --> Language Class Initialized
INFO - 2020-07-05 12:42:37 --> Config Class Initialized
INFO - 2020-07-05 12:42:37 --> Loader Class Initialized
INFO - 2020-07-05 12:42:37 --> Helper loaded: url_helper
INFO - 2020-07-05 12:42:37 --> Helper loaded: main_helper
INFO - 2020-07-05 12:42:37 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:42:37 --> Controller Class Initialized
INFO - 2020-07-05 12:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:42:37 --> Pagination Class Initialized
ERROR - 2020-07-05 12:42:37 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:42:37 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:42:37 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:42:39 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:42:39 --> Final output sent to browser
DEBUG - 2020-07-05 12:42:39 --> Total execution time: 1.9306
INFO - 2020-07-05 12:44:55 --> Config Class Initialized
INFO - 2020-07-05 12:44:55 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:44:55 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:44:55 --> Utf8 Class Initialized
INFO - 2020-07-05 12:44:55 --> URI Class Initialized
INFO - 2020-07-05 12:44:55 --> Router Class Initialized
INFO - 2020-07-05 12:44:55 --> Output Class Initialized
INFO - 2020-07-05 12:44:55 --> Security Class Initialized
DEBUG - 2020-07-05 12:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:44:55 --> Input Class Initialized
INFO - 2020-07-05 12:44:55 --> Language Class Initialized
INFO - 2020-07-05 12:44:55 --> Language Class Initialized
INFO - 2020-07-05 12:44:55 --> Config Class Initialized
INFO - 2020-07-05 12:44:55 --> Loader Class Initialized
INFO - 2020-07-05 12:44:55 --> Helper loaded: url_helper
INFO - 2020-07-05 12:44:55 --> Helper loaded: main_helper
INFO - 2020-07-05 12:44:55 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:44:55 --> Controller Class Initialized
INFO - 2020-07-05 12:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:44:55 --> Pagination Class Initialized
ERROR - 2020-07-05 12:44:55 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:44:55 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:44:55 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:44:58 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:44:58 --> Final output sent to browser
DEBUG - 2020-07-05 12:44:58 --> Total execution time: 2.8718
INFO - 2020-07-05 12:45:06 --> Config Class Initialized
INFO - 2020-07-05 12:45:06 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:45:06 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:45:06 --> Utf8 Class Initialized
INFO - 2020-07-05 12:45:06 --> URI Class Initialized
INFO - 2020-07-05 12:45:06 --> Router Class Initialized
INFO - 2020-07-05 12:45:06 --> Output Class Initialized
INFO - 2020-07-05 12:45:06 --> Security Class Initialized
DEBUG - 2020-07-05 12:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:45:06 --> Input Class Initialized
INFO - 2020-07-05 12:45:06 --> Language Class Initialized
INFO - 2020-07-05 12:45:06 --> Language Class Initialized
INFO - 2020-07-05 12:45:06 --> Config Class Initialized
INFO - 2020-07-05 12:45:06 --> Loader Class Initialized
INFO - 2020-07-05 12:45:06 --> Helper loaded: url_helper
INFO - 2020-07-05 12:45:06 --> Helper loaded: main_helper
INFO - 2020-07-05 12:45:06 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:45:06 --> Controller Class Initialized
INFO - 2020-07-05 12:45:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:45:06 --> Pagination Class Initialized
ERROR - 2020-07-05 12:45:06 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:45:06 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:45:06 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:45:11 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:45:11 --> Final output sent to browser
DEBUG - 2020-07-05 12:45:11 --> Total execution time: 4.7489
INFO - 2020-07-05 12:45:22 --> Config Class Initialized
INFO - 2020-07-05 12:45:22 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:45:22 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:45:22 --> Utf8 Class Initialized
INFO - 2020-07-05 12:45:22 --> URI Class Initialized
INFO - 2020-07-05 12:45:22 --> Router Class Initialized
INFO - 2020-07-05 12:45:22 --> Output Class Initialized
INFO - 2020-07-05 12:45:22 --> Security Class Initialized
DEBUG - 2020-07-05 12:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:45:22 --> Input Class Initialized
INFO - 2020-07-05 12:45:22 --> Language Class Initialized
INFO - 2020-07-05 12:45:22 --> Language Class Initialized
INFO - 2020-07-05 12:45:22 --> Config Class Initialized
INFO - 2020-07-05 12:45:22 --> Loader Class Initialized
INFO - 2020-07-05 12:45:22 --> Helper loaded: url_helper
INFO - 2020-07-05 12:45:22 --> Helper loaded: main_helper
INFO - 2020-07-05 12:45:22 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:45:22 --> Controller Class Initialized
INFO - 2020-07-05 12:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:45:22 --> Pagination Class Initialized
ERROR - 2020-07-05 12:45:22 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:45:22 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:45:22 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:45:24 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:45:24 --> Final output sent to browser
DEBUG - 2020-07-05 12:45:24 --> Total execution time: 2.6765
INFO - 2020-07-05 12:47:23 --> Config Class Initialized
INFO - 2020-07-05 12:47:23 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:47:23 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:47:23 --> Utf8 Class Initialized
INFO - 2020-07-05 12:47:23 --> URI Class Initialized
INFO - 2020-07-05 12:47:23 --> Router Class Initialized
INFO - 2020-07-05 12:47:23 --> Output Class Initialized
INFO - 2020-07-05 12:47:23 --> Security Class Initialized
DEBUG - 2020-07-05 12:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:47:23 --> Input Class Initialized
INFO - 2020-07-05 12:47:23 --> Language Class Initialized
INFO - 2020-07-05 12:47:23 --> Language Class Initialized
INFO - 2020-07-05 12:47:23 --> Config Class Initialized
INFO - 2020-07-05 12:47:23 --> Loader Class Initialized
INFO - 2020-07-05 12:47:23 --> Helper loaded: url_helper
INFO - 2020-07-05 12:47:23 --> Helper loaded: main_helper
INFO - 2020-07-05 12:47:23 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:47:23 --> Controller Class Initialized
INFO - 2020-07-05 12:47:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:47:23 --> Pagination Class Initialized
ERROR - 2020-07-05 12:47:23 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:47:23 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:47:23 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:47:24 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:47:24 --> Final output sent to browser
DEBUG - 2020-07-05 12:47:24 --> Total execution time: 1.5913
INFO - 2020-07-05 12:47:35 --> Config Class Initialized
INFO - 2020-07-05 12:47:35 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:47:35 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:47:35 --> Utf8 Class Initialized
INFO - 2020-07-05 12:47:35 --> URI Class Initialized
INFO - 2020-07-05 12:47:35 --> Router Class Initialized
INFO - 2020-07-05 12:47:35 --> Output Class Initialized
INFO - 2020-07-05 12:47:35 --> Security Class Initialized
DEBUG - 2020-07-05 12:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:47:35 --> Input Class Initialized
INFO - 2020-07-05 12:47:35 --> Language Class Initialized
INFO - 2020-07-05 12:47:35 --> Language Class Initialized
INFO - 2020-07-05 12:47:35 --> Config Class Initialized
INFO - 2020-07-05 12:47:35 --> Loader Class Initialized
INFO - 2020-07-05 12:47:35 --> Helper loaded: url_helper
INFO - 2020-07-05 12:47:35 --> Helper loaded: main_helper
INFO - 2020-07-05 12:47:35 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:47:35 --> Controller Class Initialized
INFO - 2020-07-05 12:47:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:47:35 --> Pagination Class Initialized
ERROR - 2020-07-05 12:47:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:47:35 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:47:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:47:37 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:47:37 --> Final output sent to browser
DEBUG - 2020-07-05 12:47:37 --> Total execution time: 2.6190
INFO - 2020-07-05 12:47:47 --> Config Class Initialized
INFO - 2020-07-05 12:47:47 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:47:47 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:47:47 --> Utf8 Class Initialized
INFO - 2020-07-05 12:47:47 --> URI Class Initialized
INFO - 2020-07-05 12:47:47 --> Router Class Initialized
INFO - 2020-07-05 12:47:47 --> Output Class Initialized
INFO - 2020-07-05 12:47:47 --> Security Class Initialized
DEBUG - 2020-07-05 12:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:47:47 --> Input Class Initialized
INFO - 2020-07-05 12:47:47 --> Language Class Initialized
INFO - 2020-07-05 12:47:47 --> Language Class Initialized
INFO - 2020-07-05 12:47:47 --> Config Class Initialized
INFO - 2020-07-05 12:47:47 --> Loader Class Initialized
INFO - 2020-07-05 12:47:47 --> Helper loaded: url_helper
INFO - 2020-07-05 12:47:47 --> Helper loaded: main_helper
INFO - 2020-07-05 12:47:47 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:47:47 --> Controller Class Initialized
INFO - 2020-07-05 12:47:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:47:47 --> Pagination Class Initialized
ERROR - 2020-07-05 12:47:47 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:47:47 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:47:47 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:47:50 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:47:50 --> Final output sent to browser
DEBUG - 2020-07-05 12:47:50 --> Total execution time: 2.8866
INFO - 2020-07-05 12:47:52 --> Config Class Initialized
INFO - 2020-07-05 12:47:52 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:47:52 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:47:52 --> Utf8 Class Initialized
INFO - 2020-07-05 12:47:52 --> URI Class Initialized
INFO - 2020-07-05 12:47:52 --> Router Class Initialized
INFO - 2020-07-05 12:47:52 --> Output Class Initialized
INFO - 2020-07-05 12:47:52 --> Security Class Initialized
DEBUG - 2020-07-05 12:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:47:52 --> Input Class Initialized
INFO - 2020-07-05 12:47:52 --> Language Class Initialized
INFO - 2020-07-05 12:47:52 --> Language Class Initialized
INFO - 2020-07-05 12:47:52 --> Config Class Initialized
INFO - 2020-07-05 12:47:52 --> Loader Class Initialized
INFO - 2020-07-05 12:47:52 --> Helper loaded: url_helper
INFO - 2020-07-05 12:47:52 --> Helper loaded: main_helper
INFO - 2020-07-05 12:47:52 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:47:52 --> Controller Class Initialized
INFO - 2020-07-05 12:47:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:47:52 --> Pagination Class Initialized
ERROR - 2020-07-05 12:47:52 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:47:52 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:47:52 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
ERROR - 2020-07-05 12:47:54 --> Severity: Notice --> Trying to get property 'total-results' of non-object /var/www/journal/application/modules/landing/controllers/Search.php 72
ERROR - 2020-07-05 12:47:54 --> Severity: Notice --> Trying to get property 'items' of non-object /var/www/journal/application/modules/landing/controllers/Search.php 73
ERROR - 2020-07-05 12:47:54 --> Severity: error --> Exception: Argument 2 passed to ConvertResponse::convert() must be of the type array, null given, called in /var/www/journal/application/modules/landing/controllers/Search.php on line 73 /var/www/journal/application/libraries/ConvertResponse.php 13
INFO - 2020-07-05 12:48:38 --> Config Class Initialized
INFO - 2020-07-05 12:48:38 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:48:38 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:48:38 --> Utf8 Class Initialized
INFO - 2020-07-05 12:48:38 --> URI Class Initialized
INFO - 2020-07-05 12:48:38 --> Router Class Initialized
INFO - 2020-07-05 12:48:38 --> Output Class Initialized
INFO - 2020-07-05 12:48:38 --> Security Class Initialized
DEBUG - 2020-07-05 12:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:48:38 --> Input Class Initialized
INFO - 2020-07-05 12:48:38 --> Language Class Initialized
INFO - 2020-07-05 12:48:38 --> Language Class Initialized
INFO - 2020-07-05 12:48:38 --> Config Class Initialized
INFO - 2020-07-05 12:48:38 --> Loader Class Initialized
INFO - 2020-07-05 12:48:38 --> Helper loaded: url_helper
INFO - 2020-07-05 12:48:38 --> Helper loaded: main_helper
INFO - 2020-07-05 12:48:38 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:48:38 --> Controller Class Initialized
INFO - 2020-07-05 12:48:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:48:38 --> Pagination Class Initialized
ERROR - 2020-07-05 12:48:38 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:48:38 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:48:38 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:48:41 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 12:48:41 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 12:48:41 --> Final output sent to browser
DEBUG - 2020-07-05 12:48:41 --> Total execution time: 3.2985
INFO - 2020-07-05 12:48:58 --> Config Class Initialized
INFO - 2020-07-05 12:48:58 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:48:58 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:48:58 --> Utf8 Class Initialized
INFO - 2020-07-05 12:48:58 --> URI Class Initialized
INFO - 2020-07-05 12:48:58 --> Router Class Initialized
INFO - 2020-07-05 12:48:58 --> Output Class Initialized
INFO - 2020-07-05 12:48:58 --> Security Class Initialized
DEBUG - 2020-07-05 12:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:48:58 --> Input Class Initialized
INFO - 2020-07-05 12:48:58 --> Language Class Initialized
INFO - 2020-07-05 12:48:58 --> Language Class Initialized
INFO - 2020-07-05 12:48:58 --> Config Class Initialized
INFO - 2020-07-05 12:48:58 --> Loader Class Initialized
INFO - 2020-07-05 12:48:58 --> Helper loaded: url_helper
INFO - 2020-07-05 12:48:58 --> Helper loaded: main_helper
INFO - 2020-07-05 12:48:58 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:48:58 --> Controller Class Initialized
INFO - 2020-07-05 12:48:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:48:58 --> Pagination Class Initialized
ERROR - 2020-07-05 12:48:58 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:48:58 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:48:58 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:49:03 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 12:49:03 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 12:49:03 --> Final output sent to browser
DEBUG - 2020-07-05 12:49:03 --> Total execution time: 4.5613
INFO - 2020-07-05 12:49:20 --> Config Class Initialized
INFO - 2020-07-05 12:49:20 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:49:20 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:49:20 --> Utf8 Class Initialized
INFO - 2020-07-05 12:49:20 --> URI Class Initialized
INFO - 2020-07-05 12:49:20 --> Router Class Initialized
INFO - 2020-07-05 12:49:20 --> Output Class Initialized
INFO - 2020-07-05 12:49:20 --> Security Class Initialized
DEBUG - 2020-07-05 12:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:49:20 --> Input Class Initialized
INFO - 2020-07-05 12:49:20 --> Language Class Initialized
INFO - 2020-07-05 12:49:20 --> Language Class Initialized
INFO - 2020-07-05 12:49:20 --> Config Class Initialized
INFO - 2020-07-05 12:49:20 --> Loader Class Initialized
INFO - 2020-07-05 12:49:20 --> Helper loaded: url_helper
INFO - 2020-07-05 12:49:20 --> Helper loaded: main_helper
INFO - 2020-07-05 12:49:20 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:49:20 --> Controller Class Initialized
INFO - 2020-07-05 12:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:49:20 --> Pagination Class Initialized
ERROR - 2020-07-05 12:49:20 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:49:20 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:49:20 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:49:23 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:49:23 --> Final output sent to browser
DEBUG - 2020-07-05 12:49:23 --> Total execution time: 2.7002
INFO - 2020-07-05 12:49:35 --> Config Class Initialized
INFO - 2020-07-05 12:49:35 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:49:35 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:49:35 --> Utf8 Class Initialized
INFO - 2020-07-05 12:49:35 --> URI Class Initialized
INFO - 2020-07-05 12:49:35 --> Router Class Initialized
INFO - 2020-07-05 12:49:35 --> Output Class Initialized
INFO - 2020-07-05 12:49:35 --> Security Class Initialized
DEBUG - 2020-07-05 12:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:49:35 --> Input Class Initialized
INFO - 2020-07-05 12:49:35 --> Language Class Initialized
INFO - 2020-07-05 12:49:35 --> Language Class Initialized
INFO - 2020-07-05 12:49:35 --> Config Class Initialized
INFO - 2020-07-05 12:49:35 --> Loader Class Initialized
INFO - 2020-07-05 12:49:35 --> Helper loaded: url_helper
INFO - 2020-07-05 12:49:35 --> Helper loaded: main_helper
INFO - 2020-07-05 12:49:35 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:49:35 --> Controller Class Initialized
INFO - 2020-07-05 12:49:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:49:35 --> Pagination Class Initialized
ERROR - 2020-07-05 12:49:35 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:49:35 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:49:35 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:49:37 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:49:37 --> Final output sent to browser
DEBUG - 2020-07-05 12:49:37 --> Total execution time: 2.1932
INFO - 2020-07-05 12:49:43 --> Config Class Initialized
INFO - 2020-07-05 12:49:43 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:49:43 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:49:43 --> Utf8 Class Initialized
INFO - 2020-07-05 12:49:43 --> URI Class Initialized
INFO - 2020-07-05 12:49:43 --> Router Class Initialized
INFO - 2020-07-05 12:49:43 --> Output Class Initialized
INFO - 2020-07-05 12:49:43 --> Security Class Initialized
DEBUG - 2020-07-05 12:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:49:43 --> Input Class Initialized
INFO - 2020-07-05 12:49:43 --> Language Class Initialized
INFO - 2020-07-05 12:49:43 --> Language Class Initialized
INFO - 2020-07-05 12:49:43 --> Config Class Initialized
INFO - 2020-07-05 12:49:43 --> Loader Class Initialized
INFO - 2020-07-05 12:49:43 --> Helper loaded: url_helper
INFO - 2020-07-05 12:49:43 --> Helper loaded: main_helper
INFO - 2020-07-05 12:49:43 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:49:43 --> Controller Class Initialized
INFO - 2020-07-05 12:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:49:43 --> Pagination Class Initialized
ERROR - 2020-07-05 12:49:43 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:49:43 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:49:43 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:49:47 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:49:47 --> Final output sent to browser
DEBUG - 2020-07-05 12:49:47 --> Total execution time: 4.0293
INFO - 2020-07-05 12:50:11 --> Config Class Initialized
INFO - 2020-07-05 12:50:11 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:50:11 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:50:11 --> Utf8 Class Initialized
INFO - 2020-07-05 12:50:11 --> URI Class Initialized
INFO - 2020-07-05 12:50:11 --> Router Class Initialized
INFO - 2020-07-05 12:50:11 --> Output Class Initialized
INFO - 2020-07-05 12:50:11 --> Security Class Initialized
DEBUG - 2020-07-05 12:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:50:11 --> Input Class Initialized
INFO - 2020-07-05 12:50:11 --> Language Class Initialized
INFO - 2020-07-05 12:50:11 --> Language Class Initialized
INFO - 2020-07-05 12:50:11 --> Config Class Initialized
INFO - 2020-07-05 12:50:11 --> Loader Class Initialized
INFO - 2020-07-05 12:50:11 --> Helper loaded: url_helper
INFO - 2020-07-05 12:50:11 --> Helper loaded: main_helper
INFO - 2020-07-05 12:50:11 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:50:11 --> Controller Class Initialized
INFO - 2020-07-05 12:50:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:50:11 --> Pagination Class Initialized
ERROR - 2020-07-05 12:50:11 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:50:11 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:50:11 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:50:14 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 12:50:14 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 12:50:14 --> Final output sent to browser
DEBUG - 2020-07-05 12:50:14 --> Total execution time: 3.8312
INFO - 2020-07-05 12:50:21 --> Config Class Initialized
INFO - 2020-07-05 12:50:21 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:50:21 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:50:21 --> Utf8 Class Initialized
INFO - 2020-07-05 12:50:21 --> URI Class Initialized
INFO - 2020-07-05 12:50:21 --> Router Class Initialized
INFO - 2020-07-05 12:50:21 --> Output Class Initialized
INFO - 2020-07-05 12:50:21 --> Security Class Initialized
DEBUG - 2020-07-05 12:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:50:21 --> Input Class Initialized
INFO - 2020-07-05 12:50:21 --> Language Class Initialized
INFO - 2020-07-05 12:50:21 --> Language Class Initialized
INFO - 2020-07-05 12:50:21 --> Config Class Initialized
INFO - 2020-07-05 12:50:21 --> Loader Class Initialized
INFO - 2020-07-05 12:50:21 --> Helper loaded: url_helper
INFO - 2020-07-05 12:50:21 --> Helper loaded: main_helper
INFO - 2020-07-05 12:50:21 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:50:21 --> Controller Class Initialized
INFO - 2020-07-05 12:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:50:21 --> Pagination Class Initialized
ERROR - 2020-07-05 12:50:21 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:50:21 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:50:21 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:50:24 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:50:24 --> Final output sent to browser
DEBUG - 2020-07-05 12:50:24 --> Total execution time: 2.8755
INFO - 2020-07-05 12:51:21 --> Config Class Initialized
INFO - 2020-07-05 12:51:21 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:51:21 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:51:21 --> Utf8 Class Initialized
INFO - 2020-07-05 12:51:21 --> URI Class Initialized
INFO - 2020-07-05 12:51:21 --> Router Class Initialized
INFO - 2020-07-05 12:51:21 --> Output Class Initialized
INFO - 2020-07-05 12:51:21 --> Security Class Initialized
DEBUG - 2020-07-05 12:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:51:21 --> Input Class Initialized
INFO - 2020-07-05 12:51:21 --> Language Class Initialized
INFO - 2020-07-05 12:51:21 --> Language Class Initialized
INFO - 2020-07-05 12:51:21 --> Config Class Initialized
INFO - 2020-07-05 12:51:21 --> Loader Class Initialized
INFO - 2020-07-05 12:51:21 --> Helper loaded: url_helper
INFO - 2020-07-05 12:51:21 --> Helper loaded: main_helper
INFO - 2020-07-05 12:51:21 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:51:21 --> Controller Class Initialized
INFO - 2020-07-05 12:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:51:21 --> Pagination Class Initialized
ERROR - 2020-07-05 12:51:21 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:51:21 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:51:21 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:51:23 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 12:51:23 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 12:51:23 --> Final output sent to browser
DEBUG - 2020-07-05 12:51:23 --> Total execution time: 2.7617
INFO - 2020-07-05 12:52:44 --> Config Class Initialized
INFO - 2020-07-05 12:52:44 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:52:44 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:52:44 --> Utf8 Class Initialized
INFO - 2020-07-05 12:52:44 --> URI Class Initialized
INFO - 2020-07-05 12:52:44 --> Router Class Initialized
INFO - 2020-07-05 12:52:44 --> Output Class Initialized
INFO - 2020-07-05 12:52:44 --> Security Class Initialized
DEBUG - 2020-07-05 12:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:52:44 --> Input Class Initialized
INFO - 2020-07-05 12:52:44 --> Language Class Initialized
INFO - 2020-07-05 12:52:44 --> Language Class Initialized
INFO - 2020-07-05 12:52:44 --> Config Class Initialized
INFO - 2020-07-05 12:52:44 --> Loader Class Initialized
INFO - 2020-07-05 12:52:44 --> Helper loaded: url_helper
INFO - 2020-07-05 12:52:44 --> Helper loaded: main_helper
INFO - 2020-07-05 12:52:44 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:52:44 --> Controller Class Initialized
INFO - 2020-07-05 12:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:52:44 --> Pagination Class Initialized
ERROR - 2020-07-05 12:52:44 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:52:44 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:52:44 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:52:46 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 12:52:46 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 12:52:46 --> Final output sent to browser
DEBUG - 2020-07-05 12:52:46 --> Total execution time: 2.2549
INFO - 2020-07-05 12:53:01 --> Config Class Initialized
INFO - 2020-07-05 12:53:01 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:53:01 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:53:01 --> Utf8 Class Initialized
INFO - 2020-07-05 12:53:01 --> URI Class Initialized
INFO - 2020-07-05 12:53:01 --> Router Class Initialized
INFO - 2020-07-05 12:53:01 --> Output Class Initialized
INFO - 2020-07-05 12:53:01 --> Security Class Initialized
DEBUG - 2020-07-05 12:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:53:01 --> Input Class Initialized
INFO - 2020-07-05 12:53:01 --> Language Class Initialized
INFO - 2020-07-05 12:53:01 --> Language Class Initialized
INFO - 2020-07-05 12:53:01 --> Config Class Initialized
INFO - 2020-07-05 12:53:01 --> Loader Class Initialized
INFO - 2020-07-05 12:53:01 --> Helper loaded: url_helper
INFO - 2020-07-05 12:53:01 --> Helper loaded: main_helper
INFO - 2020-07-05 12:53:01 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:53:01 --> Controller Class Initialized
INFO - 2020-07-05 12:53:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:53:01 --> Pagination Class Initialized
ERROR - 2020-07-05 12:53:01 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:53:01 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:53:01 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:53:04 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:53:04 --> Final output sent to browser
DEBUG - 2020-07-05 12:53:04 --> Total execution time: 3.4608
INFO - 2020-07-05 12:53:10 --> Config Class Initialized
INFO - 2020-07-05 12:53:10 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:53:10 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:53:10 --> Utf8 Class Initialized
INFO - 2020-07-05 12:53:10 --> URI Class Initialized
INFO - 2020-07-05 12:53:10 --> Router Class Initialized
INFO - 2020-07-05 12:53:10 --> Output Class Initialized
INFO - 2020-07-05 12:53:10 --> Security Class Initialized
DEBUG - 2020-07-05 12:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:53:10 --> Input Class Initialized
INFO - 2020-07-05 12:53:10 --> Language Class Initialized
INFO - 2020-07-05 12:53:10 --> Language Class Initialized
INFO - 2020-07-05 12:53:10 --> Config Class Initialized
INFO - 2020-07-05 12:53:10 --> Loader Class Initialized
INFO - 2020-07-05 12:53:10 --> Helper loaded: url_helper
INFO - 2020-07-05 12:53:10 --> Helper loaded: main_helper
INFO - 2020-07-05 12:53:10 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:53:10 --> Controller Class Initialized
INFO - 2020-07-05 12:53:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:53:10 --> Pagination Class Initialized
ERROR - 2020-07-05 12:53:10 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:53:10 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:53:10 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:53:12 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 12:53:12 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 12:53:12 --> Final output sent to browser
DEBUG - 2020-07-05 12:53:12 --> Total execution time: 2.4419
INFO - 2020-07-05 12:53:19 --> Config Class Initialized
INFO - 2020-07-05 12:53:19 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:53:19 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:53:19 --> Utf8 Class Initialized
INFO - 2020-07-05 12:53:19 --> URI Class Initialized
INFO - 2020-07-05 12:53:19 --> Router Class Initialized
INFO - 2020-07-05 12:53:19 --> Output Class Initialized
INFO - 2020-07-05 12:53:19 --> Security Class Initialized
DEBUG - 2020-07-05 12:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:53:19 --> Input Class Initialized
INFO - 2020-07-05 12:53:19 --> Language Class Initialized
INFO - 2020-07-05 12:53:19 --> Language Class Initialized
INFO - 2020-07-05 12:53:19 --> Config Class Initialized
INFO - 2020-07-05 12:53:19 --> Loader Class Initialized
INFO - 2020-07-05 12:53:19 --> Helper loaded: url_helper
INFO - 2020-07-05 12:53:19 --> Helper loaded: main_helper
INFO - 2020-07-05 12:53:19 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:53:19 --> Controller Class Initialized
INFO - 2020-07-05 12:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:53:19 --> Pagination Class Initialized
ERROR - 2020-07-05 12:53:19 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:53:19 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:53:19 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:53:22 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 12:53:22 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 12:53:22 --> Final output sent to browser
DEBUG - 2020-07-05 12:53:22 --> Total execution time: 3.6275
INFO - 2020-07-05 12:53:34 --> Config Class Initialized
INFO - 2020-07-05 12:53:34 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:53:34 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:53:34 --> Utf8 Class Initialized
INFO - 2020-07-05 12:53:34 --> URI Class Initialized
INFO - 2020-07-05 12:53:34 --> Router Class Initialized
INFO - 2020-07-05 12:53:34 --> Output Class Initialized
INFO - 2020-07-05 12:53:34 --> Security Class Initialized
DEBUG - 2020-07-05 12:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:53:34 --> Input Class Initialized
INFO - 2020-07-05 12:53:34 --> Language Class Initialized
INFO - 2020-07-05 12:53:34 --> Language Class Initialized
INFO - 2020-07-05 12:53:34 --> Config Class Initialized
INFO - 2020-07-05 12:53:34 --> Loader Class Initialized
INFO - 2020-07-05 12:53:34 --> Helper loaded: url_helper
INFO - 2020-07-05 12:53:34 --> Helper loaded: main_helper
INFO - 2020-07-05 12:53:34 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:53:34 --> Controller Class Initialized
INFO - 2020-07-05 12:53:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:53:34 --> Pagination Class Initialized
ERROR - 2020-07-05 12:53:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:53:34 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:53:34 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:53:43 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 12:53:43 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 12:53:43 --> Final output sent to browser
DEBUG - 2020-07-05 12:53:43 --> Total execution time: 8.7263
INFO - 2020-07-05 12:53:46 --> Config Class Initialized
INFO - 2020-07-05 12:53:46 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:53:46 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:53:46 --> Utf8 Class Initialized
INFO - 2020-07-05 12:53:46 --> URI Class Initialized
INFO - 2020-07-05 12:53:46 --> Router Class Initialized
INFO - 2020-07-05 12:53:46 --> Output Class Initialized
INFO - 2020-07-05 12:53:46 --> Security Class Initialized
DEBUG - 2020-07-05 12:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:53:46 --> Input Class Initialized
INFO - 2020-07-05 12:53:46 --> Language Class Initialized
INFO - 2020-07-05 12:53:46 --> Language Class Initialized
INFO - 2020-07-05 12:53:46 --> Config Class Initialized
INFO - 2020-07-05 12:53:46 --> Loader Class Initialized
INFO - 2020-07-05 12:53:46 --> Helper loaded: url_helper
INFO - 2020-07-05 12:53:46 --> Helper loaded: main_helper
INFO - 2020-07-05 12:53:46 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:53:46 --> Controller Class Initialized
INFO - 2020-07-05 12:53:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:53:46 --> Pagination Class Initialized
ERROR - 2020-07-05 12:53:46 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:53:46 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:53:46 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:53:48 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:53:48 --> Final output sent to browser
DEBUG - 2020-07-05 12:53:48 --> Total execution time: 2.5541
INFO - 2020-07-05 12:53:54 --> Config Class Initialized
INFO - 2020-07-05 12:53:54 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:53:54 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:53:54 --> Utf8 Class Initialized
INFO - 2020-07-05 12:53:54 --> URI Class Initialized
INFO - 2020-07-05 12:53:54 --> Router Class Initialized
INFO - 2020-07-05 12:53:54 --> Output Class Initialized
INFO - 2020-07-05 12:53:54 --> Security Class Initialized
DEBUG - 2020-07-05 12:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:53:54 --> Input Class Initialized
INFO - 2020-07-05 12:53:54 --> Language Class Initialized
INFO - 2020-07-05 12:53:54 --> Language Class Initialized
INFO - 2020-07-05 12:53:54 --> Config Class Initialized
INFO - 2020-07-05 12:53:54 --> Loader Class Initialized
INFO - 2020-07-05 12:53:54 --> Helper loaded: url_helper
INFO - 2020-07-05 12:53:54 --> Helper loaded: main_helper
INFO - 2020-07-05 12:53:54 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:53:54 --> Controller Class Initialized
INFO - 2020-07-05 12:53:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:53:54 --> Pagination Class Initialized
ERROR - 2020-07-05 12:53:54 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:53:54 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:53:54 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:53:58 --> File loaded: /var/www/journal/application/modules/landing/views/article_detail_v.php
INFO - 2020-07-05 12:53:58 --> Final output sent to browser
DEBUG - 2020-07-05 12:53:58 --> Total execution time: 4.7996
INFO - 2020-07-05 12:54:34 --> Config Class Initialized
INFO - 2020-07-05 12:54:34 --> Hooks Class Initialized
DEBUG - 2020-07-05 12:54:34 --> UTF-8 Support Enabled
INFO - 2020-07-05 12:54:34 --> Utf8 Class Initialized
INFO - 2020-07-05 12:54:34 --> URI Class Initialized
INFO - 2020-07-05 12:54:34 --> Router Class Initialized
INFO - 2020-07-05 12:54:34 --> Output Class Initialized
INFO - 2020-07-05 12:54:34 --> Security Class Initialized
DEBUG - 2020-07-05 12:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 12:54:34 --> Input Class Initialized
INFO - 2020-07-05 12:54:34 --> Language Class Initialized
INFO - 2020-07-05 12:54:34 --> Language Class Initialized
INFO - 2020-07-05 12:54:34 --> Config Class Initialized
INFO - 2020-07-05 12:54:34 --> Loader Class Initialized
INFO - 2020-07-05 12:54:34 --> Helper loaded: url_helper
INFO - 2020-07-05 12:54:34 --> Helper loaded: main_helper
INFO - 2020-07-05 12:54:34 --> Database Driver Class Initialized
DEBUG - 2020-07-05 12:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 12:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 12:54:34 --> Controller Class Initialized
INFO - 2020-07-05 12:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 12:54:34 --> Pagination Class Initialized
ERROR - 2020-07-05 12:54:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 12:54:34 --> Helper loaded: file_helper
DEBUG - 2020-07-05 12:54:34 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 12:54:36 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 12:54:36 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 12:54:36 --> Final output sent to browser
DEBUG - 2020-07-05 12:54:36 --> Total execution time: 1.9560
INFO - 2020-07-05 13:09:48 --> Config Class Initialized
INFO - 2020-07-05 13:09:48 --> Hooks Class Initialized
DEBUG - 2020-07-05 13:09:48 --> UTF-8 Support Enabled
INFO - 2020-07-05 13:09:48 --> Utf8 Class Initialized
INFO - 2020-07-05 13:09:48 --> URI Class Initialized
INFO - 2020-07-05 13:09:48 --> Router Class Initialized
INFO - 2020-07-05 13:09:48 --> Output Class Initialized
INFO - 2020-07-05 13:09:48 --> Security Class Initialized
DEBUG - 2020-07-05 13:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 13:09:48 --> Input Class Initialized
INFO - 2020-07-05 13:09:48 --> Language Class Initialized
INFO - 2020-07-05 13:09:48 --> Language Class Initialized
INFO - 2020-07-05 13:09:48 --> Config Class Initialized
INFO - 2020-07-05 13:09:48 --> Loader Class Initialized
INFO - 2020-07-05 13:09:48 --> Helper loaded: url_helper
INFO - 2020-07-05 13:09:48 --> Helper loaded: main_helper
INFO - 2020-07-05 13:09:48 --> Database Driver Class Initialized
DEBUG - 2020-07-05 13:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 13:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 13:09:48 --> Controller Class Initialized
INFO - 2020-07-05 13:09:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-07-05 13:09:48 --> Pagination Class Initialized
ERROR - 2020-07-05 13:09:48 --> Cache: Failed to initialize APC; extension not loaded/enabled?
INFO - 2020-07-05 13:09:48 --> Helper loaded: file_helper
DEBUG - 2020-07-05 13:09:48 --> Cache adapter "apc" is unavailable. Falling back to "file" backup adapter.
DEBUG - 2020-07-05 13:09:50 --> File loaded: /var/www/journal/application/modules/landing/views/result_v.php
DEBUG - 2020-07-05 13:09:50 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 13:09:50 --> Final output sent to browser
DEBUG - 2020-07-05 13:09:50 --> Total execution time: 2.3897
INFO - 2020-07-05 15:52:59 --> Config Class Initialized
INFO - 2020-07-05 15:52:59 --> Hooks Class Initialized
DEBUG - 2020-07-05 15:52:59 --> UTF-8 Support Enabled
INFO - 2020-07-05 15:52:59 --> Utf8 Class Initialized
INFO - 2020-07-05 15:52:59 --> URI Class Initialized
DEBUG - 2020-07-05 15:52:59 --> No URI present. Default controller set.
INFO - 2020-07-05 15:52:59 --> Router Class Initialized
INFO - 2020-07-05 15:52:59 --> Output Class Initialized
INFO - 2020-07-05 15:52:59 --> Security Class Initialized
DEBUG - 2020-07-05 15:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-05 15:52:59 --> Input Class Initialized
INFO - 2020-07-05 15:52:59 --> Language Class Initialized
INFO - 2020-07-05 15:52:59 --> Language Class Initialized
INFO - 2020-07-05 15:52:59 --> Config Class Initialized
INFO - 2020-07-05 15:52:59 --> Loader Class Initialized
INFO - 2020-07-05 15:52:59 --> Helper loaded: url_helper
INFO - 2020-07-05 15:52:59 --> Helper loaded: main_helper
INFO - 2020-07-05 15:52:59 --> Database Driver Class Initialized
DEBUG - 2020-07-05 15:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-07-05 15:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-05 15:52:59 --> Controller Class Initialized
DEBUG - 2020-07-05 15:52:59 --> File loaded: /var/www/journal/application/modules/landing/views/landing_v.php
DEBUG - 2020-07-05 15:52:59 --> File loaded: /var/www/journal/application/modules/template/views/template.php
INFO - 2020-07-05 15:52:59 --> Final output sent to browser
DEBUG - 2020-07-05 15:52:59 --> Total execution time: 0.0818
